import {
  publishTweetToX,
  PublishTweetResult,
  getPublishingMode,
  getServerXCredentials,
} from "./xPublisher";
import { parseMatchDateTime } from "./dateScheduler";
import { readJsonState, writeJsonState } from "./botStorage";

export type TweetPriority = "HIGH" | "NORMAL" | "LOW";

export interface QueuedTweetItem {
  id: string;
  tweetText: string;
  type: "GOAL_LIVE" | "RECAP_FT" | "PRONO_H1" | "DAILY_RECAP" | "MANUAL";
  matchTitle?: string;
  inReplyToTweetId?: string;
  priority: TweetPriority;
  enqueuedAt: number;
  status: "QUEUED" | "PUBLISHING" | "PUBLISHED" | "FAILED";
  retryCount?: number;
  nextRetryAt?: number;
  scheduledFor?: number;
  publishedAt?: number;
  tweetId?: string;
  isDirectPublished?: boolean;
  error?: string;
  metadata?: Record<string, any>;
}

const QUEUE_STORAGE_KEY = "tweet_queue.json";

// Anti-Spam Guarantee: Minimum delay between two tweets (60 seconds)
const DEFAULT_MIN_SPACING_MS = 60 * 1000;
const MAX_RETRIES = 3;
const RETRY_BACKOFF_MS = [45_000, 120_000, 300_000]; // 45s -> 2min -> 5min
const MAX_QUEUE_ITEM_AGE_MS = 12 * 60 * 60 * 1000; // Auto-prune any queued tweet older than 12h

let minSpacingMs = DEFAULT_MIN_SPACING_MS;
let lastTweetPublishedTimestamp = 0;
let isPublishing = false;
let lastMissingCookiePauseNoticeAt = 0;
const queue: QueuedTweetItem[] = [];
const publishedHistory: QueuedTweetItem[] = [];

function isStaleQueueItem(item: QueuedTweetItem, now: number): boolean {
  if (!item || typeof item.enqueuedAt !== "number" || now - item.enqueuedAt > MAX_QUEUE_ITEM_AGE_MS) {
    return true;
  }
  if (item.type === "PRONO_H1" && (item.metadata?.date || item.metadata?.kickoffTime)) {
    const timing = parseMatchDateTime(item.metadata?.date, item.metadata?.kickoffTime);
    if (timing.isMatchFinished || timing.totalDiffMinutes < -5) {
      return true;
    }
  }
  return false;
}

function pruneStaleQueueItems(): boolean {
  const now = Date.now();
  let removed = 0;
  for (let i = queue.length - 1; i >= 0; i--) {
    if (isStaleQueueItem(queue[i], now)) {
      queue.splice(i, 1);
      removed++;
    }
  }
  if (removed > 0) {
    console.log(`[TweetQueue] 🧹 ${removed} tweet(s) obsolète(s) retiré(s) automatiquement de la file.`);
    persistQueue();
    return true;
  }
  return false;
}

function isMissingRequiredCookies(): boolean {
  if (getPublishingMode() !== "LIVE_COOKIES") return false;
  const creds = getServerXCredentials();
  return !(creds.authToken && creds.ct0);
}

// Load queue from ./data/tweet_queue.json on startup (never import stale pre-refactor root dotfiles)
{
  const data = readJsonState<{
    queue?: QueuedTweetItem[];
    publishedHistory?: QueuedTweetItem[];
    lastTweetPublishedTimestamp?: number;
    minSpacingMs?: number;
  }>(QUEUE_STORAGE_KEY, {});

  const now = Date.now();
  if (Array.isArray(data.queue)) {
    for (const item of data.queue) {
      if ((item.status === "QUEUED" || item.status === "PUBLISHING") && !isStaleQueueItem(item, now)) {
        item.status = "QUEUED";
        queue.push(item);
      }
    }
  }
  if (Array.isArray(data.publishedHistory)) {
    publishedHistory.push(...data.publishedHistory.slice(0, 60));
  }
  if (typeof data.lastTweetPublishedTimestamp === "number") {
    lastTweetPublishedTimestamp = data.lastTweetPublishedTimestamp;
  }
  if (typeof data.minSpacingMs === "number" && data.minSpacingMs >= 30_000) {
    minSpacingMs = data.minSpacingMs;
  }
}

export type QueueEventCallback = (item: QueuedTweetItem, result: PublishTweetResult) => void;
let onTweetSuccessCallback: QueueEventCallback | null = null;
let onTweetFailureCallback: QueueEventCallback | null = null;

export function registerQueueCallbacks(callbacks: {
  onSuccess?: QueueEventCallback;
  onFailure?: QueueEventCallback;
}) {
  if (callbacks.onSuccess) onTweetSuccessCallback = callbacks.onSuccess;
  if (callbacks.onFailure) onTweetFailureCallback = callbacks.onFailure;
}

export function clearFailedHistory(): void {
  for (let i = publishedHistory.length - 1; i >= 0; i--) {
    if (publishedHistory[i].status === "FAILED") {
      publishedHistory.splice(i, 1);
    }
  }
  persistQueue();
}

export function clearQueueAndHistory(): void {
  queue.length = 0;
  publishedHistory.length = 0;
  lastTweetPublishedTimestamp = 0;
  persistQueue();
}

function persistQueue() {
  writeJsonState(QUEUE_STORAGE_KEY, {
    lastTweetPublishedTimestamp,
    minSpacingMs,
    queue,
    publishedHistory: publishedHistory.slice(0, 60),
  });
}

/**
 * Enqueue a tweet for strictly paced, anti-spam publication with automatic retry.
 */
export function enqueueTweet(params: {
  id?: string;
  tweetText: string;
  type: "GOAL_LIVE" | "RECAP_FT" | "PRONO_H1" | "DAILY_RECAP" | "MANUAL";
  matchTitle?: string;
  inReplyToTweetId?: string;
  priority?: TweetPriority;
  metadata?: Record<string, any>;
}): QueuedTweetItem | null {
  const cleanText = params.tweetText.trim();
  if (!cleanText) return null;

  // Deduplication: never enqueue identical text already queued
  const isAlreadyQueued = queue.some(
    (item) => item.tweetText.trim() === cleanText && (item.status === "QUEUED" || item.status === "PUBLISHING")
  );
  if (isAlreadyQueued) {
    return null;
  }

  // Deduplication: never re-publish identical text already published successfully within 30 minutes
  const isRecentlyPublished = publishedHistory.some(
    (item) =>
      item.status === "PUBLISHED" &&
      item.tweetText.trim() === cleanText &&
      Date.now() - (item.publishedAt || 0) < 30 * 60 * 1000
  );
  if (isRecentlyPublished) {
    return null;
  }

  // Strict security guard: never enqueue H-1 prediction for an already-started/finished match
  if (params.type === "PRONO_H1") {
    const metaDate = params.metadata?.date;
    const metaKickoff = params.metadata?.kickoffTime;
    if (metaDate || metaKickoff) {
      const timing = parseMatchDateTime(metaDate, metaKickoff);
      if (timing.isMatchFinished || timing.totalDiffMinutes < -5) {
        console.warn(
          `[TweetQueue] 🛑 Rejet sécurité : match déjà commencé/terminé (${params.matchTitle || "Match"})`
        );
        return null;
      }
    }
  }

  const priority = params.priority || (params.type === "GOAL_LIVE" ? "HIGH" : "NORMAL");

  const item: QueuedTweetItem = {
    id: params.id || `tweet-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    tweetText: cleanText,
    type: params.type,
    matchTitle: params.matchTitle,
    inReplyToTweetId: params.inReplyToTweetId,
    priority,
    enqueuedAt: Date.now(),
    status: "QUEUED",
    retryCount: 0,
    metadata: params.metadata,
  };

  if (priority === "HIGH") {
    let lastHighIndex = -1;
    for (let i = queue.length - 1; i >= 0; i--) {
      if (queue[i].priority === "HIGH") {
        lastHighIndex = i;
        break;
      }
    }
    if (lastHighIndex >= 0) {
      queue.splice(lastHighIndex + 1, 0, item);
    } else {
      queue.unshift(item);
    }
  } else {
    queue.push(item);
  }

  persistQueue();
  console.log(
    `[TweetQueue] 📥 Tweet ajouté à la file (${item.type}, Priorité: ${item.priority}). En attente : ${queue.length}.`
  );

  return item;
}

/**
 * Returns current status of the publishing queue
 */
export function getQueueStatus(): {
  queueLength: number;
  isPublishing: boolean;
  isPausedForMissingCookies: boolean;
  minSpacingMs: number;
  minSpacingSeconds: number;
  secondsUntilNextAllowed: number;
  lastTweetPublishedTimestamp: number;
  queuedItems: QueuedTweetItem[];
  recentPublished: QueuedTweetItem[];
} {
  const now = Date.now();
  const elapsedSinceLast = now - lastTweetPublishedTimestamp;
  const remainingCooldown = Math.max(0, minSpacingMs - elapsedSinceLast);
  const secondsUntilNextAllowed = Math.ceil(remainingCooldown / 1000);

  return {
    queueLength: queue.filter((q) => q.status === "QUEUED" || q.status === "PUBLISHING").length,
    isPublishing,
    isPausedForMissingCookies: isMissingRequiredCookies(),
    minSpacingMs,
    minSpacingSeconds: Math.round(minSpacingMs / 1000),
    secondsUntilNextAllowed,
    lastTweetPublishedTimestamp,
    queuedItems: [...queue],
    recentPublished: publishedHistory.slice(0, 30),
  };
}

export function setMinSpacingSeconds(seconds: number) {
  const bounded = Math.max(30, Math.min(300, seconds));
  minSpacingMs = bounded * 1000;
  persistQueue();
}

/**
 * Processes the next eligible item in the queue with strict anti-spam pacing and automatic retry.
 */
export async function processQueueTick(): Promise<{
  processed: boolean;
  published?: boolean;
  paused?: boolean;
  error?: string;
}> {
  if (isPublishing) return { processed: false };

  // Always drop expired/stale queued tweets before dispatching
  pruneStaleQueueItems();

  const now = Date.now();
  const nextItem = queue.find(
    (q) => q.status === "QUEUED" && (!q.nextRetryAt || now >= q.nextRetryAt)
  );
  if (!nextItem) return { processed: false };

  // Pause cleanly without spamming ERROR logs when LIVE_COOKIES is selected before user pastes cookies
  if (isMissingRequiredCookies()) {
    if (now - lastMissingCookiePauseNoticeAt > 30 * 60 * 1000) {
      lastMissingCookiePauseNoticeAt = now;
      console.log(
        `[TweetQueue] ⏸️ ${queue.length} tweet(s) en attente de vos cookies X (auth_token + ct0). Ouvrez 'Cookies X' pour activer l'envoi automatique.`
      );
    }
    return { processed: false, paused: true };
  }

  const elapsed = now - lastTweetPublishedTimestamp;
  if (lastTweetPublishedTimestamp > 0 && elapsed < minSpacingMs) {
    return { processed: false };
  }

  isPublishing = true;
  nextItem.status = "PUBLISHING";
  persistQueue();

  console.log(
    `[TweetQueue] 🚀 Envoi tweet (${nextItem.type}, essai ${(nextItem.retryCount || 0) + 1}/${MAX_RETRIES + 1}) : "${nextItem.tweetText.slice(0, 55)}..."`
  );

  try {
    const result: PublishTweetResult = await publishTweetToX({
      tweetText: nextItem.tweetText,
      inReplyToTweetId: nextItem.inReplyToTweetId,
    });

    if (result.success) {
      nextItem.status = "PUBLISHED";
      nextItem.publishedAt = Date.now();
      nextItem.tweetId = result.tweetId;
      nextItem.isDirectPublished = result.isDirectPublished;
      nextItem.error = undefined;
      lastTweetPublishedTimestamp = Date.now();

      const idx = queue.findIndex((q) => q.id === nextItem.id);
      if (idx >= 0) queue.splice(idx, 1);
      publishedHistory.unshift(nextItem);

      if (onTweetSuccessCallback) {
        try {
          onTweetSuccessCallback(nextItem, result);
        } catch (cbErr) {
          console.warn("[TweetQueue] onTweetSuccessCallback error:", cbErr);
        }
      }

      console.log(
        `[TweetQueue] ✅ Tweet publié (${result.mode}) ! Prochain envoi autorisé dans ${Math.round(minSpacingMs / 1000)}s.`
      );
      return { processed: true, published: true };
    }

    // Check if we should automatically retry with exponential backoff
    const currentRetries = nextItem.retryCount || 0;
    if (result.retryable && currentRetries < MAX_RETRIES) {
      const backoffMs = RETRY_BACKOFF_MS[currentRetries] || 180_000;
      nextItem.status = "QUEUED";
      nextItem.retryCount = currentRetries + 1;
      nextItem.nextRetryAt = Date.now() + backoffMs;
      nextItem.error = result.message;
      console.warn(
        `[TweetQueue] ⏳ Échec temporaire (${result.errorCode || "RETRY"}). Nouvelle tentative ${nextItem.retryCount}/${MAX_RETRIES} dans ${Math.round(backoffMs / 1000)}s.`
      );
      return { processed: true, published: false, error: result.message };
    }

    // Permanent failure (non-retryable or max retries reached)
    console.warn(`[TweetQueue] ❌ Échec définitif de publication : ${result.message}`);
    nextItem.status = "FAILED";
    nextItem.error = result.message;

    const idx = queue.findIndex((q) => q.id === nextItem.id);
    if (idx >= 0) queue.splice(idx, 1);
    publishedHistory.unshift(nextItem);

    if (onTweetFailureCallback) {
      try {
        onTweetFailureCallback(nextItem, result);
      } catch (cbErr) {
        console.warn("[TweetQueue] onTweetFailureCallback error:", cbErr);
      }
    }
    return { processed: true, published: false, error: result.message };
  } catch (err: any) {
    console.error("[TweetQueue] Erreur critique pendant publication:", err);
    nextItem.status = "FAILED";
    nextItem.error = err?.message || "Erreur inconnue";

    const idx = queue.findIndex((q) => q.id === nextItem.id);
    if (idx >= 0) queue.splice(idx, 1);
    publishedHistory.unshift(nextItem);

    if (onTweetFailureCallback) {
      try {
        onTweetFailureCallback(nextItem, {
          success: false,
          mode: "cookie_error",
          isDirectPublished: false,
          message: err?.message || "Erreur critique",
          error: err?.message,
        });
      } catch (cbErr) {
        console.warn("[TweetQueue] onTweetFailureCallback error:", cbErr);
      }
    }
    return { processed: true, published: false, error: err?.message };
  } finally {
    isPublishing = false;
    persistQueue();
  }
}

// Background queue ticker every 5 seconds
const queueTimer = setInterval(() => {
  processQueueTick().catch((err) =>
    console.warn("[TweetQueue Worker Error]:", err?.message)
  );
}, 5000);
if (queueTimer && typeof queueTimer.unref === "function") {
  queueTimer.unref();
}
