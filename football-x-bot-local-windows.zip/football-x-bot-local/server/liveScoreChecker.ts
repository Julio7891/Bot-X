export interface LiveScoreGoalEvent {
  scorerName: string;
  team: "home" | "away";
  minute: string;
}

export interface LiveScoreResult {
  matchId?: string;
  homeTeam: string;
  awayTeam: string;
  scoreHome: number;
  scoreAway: number;
  isLive: boolean;
  isFinished: boolean;
  statusText: string;
  liveMinute?: string;
  league: string;
  goals?: LiveScoreGoalEvent[];
}

// Comprehensive list of leagues including all top 1st and 2nd divisions + European & International cups
const LEAGUE_CODES: Record<string, string> = {
  // European & Global Cups
  "UEFA Champions League": "uefa.champions",
  "UEFA Europa League": "uefa.europa",
  "UEFA Europa Conference League": "uefa.europa.conf",
  "UEFA Nations League": "uefa.nations",
  "UEFA Super Cup": "uefa.super_cup",
  "Club World Cup": "fifa.cwc",

  // Spain
  "La Liga": "esp.1",
  "LaLiga": "esp.1",
  "La Liga 2": "esp.2",
  "LaLiga 2": "esp.2",
  "Segunda Division": "esp.2",
  "Copa del Rey": "esp.copa_del_rey",
  "Supercopa de Espana": "esp.super_copa",

  // England
  "Premier League": "eng.1",
  "EFL Championship": "eng.2",
  "Championship": "eng.2",
  "FA Cup": "eng.fa",
  "Carabao Cup": "eng.league_cup",
  "EFL Cup": "eng.league_cup",

  // France
  "Ligue 1": "fra.1",
  "Ligue 2": "fra.2",
  "Coupe de France": "fra.coupe_de_france",
  "Trophée des Champions": "fra.trophee_champions",

  // Italy
  "Serie A": "ita.1",
  "Serie B": "ita.2",
  "Coppa Italia": "ita.coppa_italia",
  "Supercoppa Italiana": "ita.super_coppa",

  // Germany
  "Bundesliga": "ger.1",
  "2. Bundesliga": "ger.2",
  "DFB-Pokal": "ger.dfb_pokal",
  "DFL-Supercup": "ger.super_cup",

  // Portugal, Netherlands, Belgium, Turkey, Saudi, Americas, Asia
  "Liga Portugal": "por.1",
  "Primeira Liga": "por.1",
  "Eredivisie": "ned.1",
  "Belgian Pro League": "bel.1",
  "Jupiler Pro League": "bel.1",
  "Super Lig": "tur.1",
  "Süper Lig": "tur.1",
  "Saudi Pro League": "sau.1",
  "Scottish Premiership": "sco.1",
  "Swiss Super League": "sui.1",
  "Super League": "sui.1",
  "Austrian Bundesliga": "aut.1",
  "Admiral Bundesliga": "aut.1",
  "Superliga": "den.1",
  "Superleague Greece": "gre.1",
  "MLS": "usa.1",
  "Brasileirão": "bra.1",
  "Brasileirao": "bra.1",
  "Leagues Cup": "concacaf.leagues_cup",
  "Liga MX": "mex.1",
  "DFB Pokal": "ger.dfb_pokal",
  "Chinese Super League": "chn.1",
  "J-League": "jpn.1",
  "K-League": "kor.1",
  "Copa Libertadores": "conmebol.libertadores",
  "Copa Sudamericana": "conmebol.sudamericana",
  "FIFA World Cup": "fifa.world",
  "International Friendly": "fifa.friendly",
};

/**
 * Massive team alias dictionary mapping key identifier to various spellings (French, English, official, abbreviations)
 */
const TEAM_ALIASES: Record<string, string[]> = {
  barcelona: ["barcelona", "barcelone", "fcbarcelona", "fcbarcelone", "barca", "fcb"],
  realmadrid: ["realmadrid", "rma", "madrid", "realmadridcf"],
  atleticomadrid: ["atleticomadrid", "atletico", "atlético", "atm", "atleticomadridfc", "atleticomad"],
  athleticclub: ["athleticclub", "athleticbilbao", "bilbao", "athletic"],
  sevilla: ["sevilla", "seville", "fcsevilla", "fcseville", "sevillafc"],
  realbetis: ["realbetis", "betis", "betisseville", "betissevilla"],
  valencia: ["valencia", "valence", "valenciacf", "valencecf"],
  villarreal: ["villarreal", "villareal", "villarrealcf"],
  realsociedad: ["realsociedad", "sociedad", "la_real"],
  mallorca: ["mallorca", "majorque", "rcdmallorca", "rcdmajorque"],
  celta: ["celta", "celtavigo", "celtadevigo"],
  espanyol: ["espanyol", "rcdespanyol", "espagnol"],
  osasuna: ["osasuna", "caosasuna"],
  getafe: ["getafe", "getafecf"],
  girona: ["girona", "girone", "gironafc"],
  alaves: ["alaves", "deportivoalaves"],
  rayovallecano: ["rayovallecano", "rayo"],
  laspalmas: ["laspalmas", "udlaspalmas"],
  valladolid: ["valladolid", "realvalladolid"],
  leganes: ["leganes", "cdleganes"],
  racingsantander: ["racingsantander", "santander", "racingdesantander", "racingsant"],
  elche: ["elche", "elchecf"],
  zaragoza: ["zaragoza", "realzaragoza"],
  sportinggijon: ["sportinggijon", "gijon"],
  oviedo: ["oviedo", "realoviedo"],
  levante: ["levante", "levanteud"],
  eibar: ["eibar", "sdeibar"],
  albacete: ["albacete", "albacetebp"],
  burgos: ["burgos", "burgoscf"],
  tenerife: ["tenerife", "cdtenerife"],
  cadiz: ["cadiz", "cadizcf"],
  granada: ["granada", "granadacf"],
  almeria: ["almeria", "udalmeria"],
  cordoba: ["cordoba", "cordobacf"],
  huesca: ["huesca", "sdhuesca"],
  malaga: ["malaga", "malagacf"],
  cartagena: ["cartagena", "fccartagena"],
  mirandes: ["mirandes", "cdmirandes"],
  ferrol: ["ferrol", "racingdeferrol"],
  castellon: ["castellon", "cdcastellon"],
  deportivolacoruna: ["deportivolacoruna", "deportivo", "depor", "lacoruna"],

  psg: ["psg", "parissaintgermain", "paris", "parissg"],
  marseille: ["marseille", "om", "olympiquedemarseille"],
  lyon: ["lyon", "ol", "olympiquelyonnais"],
  monaco: ["monaco", "asmonaco", "asm"],
  lille: ["lille", "losc", "losclille"],
  rennes: ["rennes", "staderennais", "srfc"],
  saintetienne: ["saintetienne", "asse", "stetienne"],
  lens: ["lens", "rclens"],
  nice: ["nice", "ogcnice", "ogcn"],
  strasbourg: ["strasbourg", "rcstrasbourg"],
  nantes: ["nantes", "fcnantes"],
  toulouse: ["toulouse", "tfc"],
  reims: ["reims", "stadereims"],
  brest: ["brest", "stadebrestois", "sb29"],
  montpellier: ["montpellier", "mhsc"],
  auxerre: ["auxerre", "ajauxerre"],
  angers: ["angers", "angerssco"],
  lehavre: ["lehavre", "hac"],
  troyes: ["troyes", "estactroyes", "estac"],
  metz: ["metz", "fcmetz"],
  lorient: ["lorient", "fclorient"],
  clermont: ["clermont", "clermontfoot"],
  parisfc: ["parisfc", "pfc"],
  bordeaux: ["bordeaux", "girondinsdebordeaux", "girondins"],

  manchestercity: ["manchestercity", "mancity", "mci"],
  manchesterunited: ["manchesterunited", "manunited", "manutd", "mun"],
  liverpool: ["liverpool", "liv", "lfc"],
  arsenal: ["arsenal", "ars", "afc"],
  chelsea: ["chelsea", "che", "cfc"],
  tottenham: ["tottenham", "tottenhamhotspur", "spurs", "tot"],
  newcastle: ["newcastle", "newcastleunited", "new", "nufc"],
  astonvilla: ["astonvilla", "avfc", "astonvillafc"],
  wolverhampton: ["wolverhampton", "wolves", "wolverhamptonwanderers"],
  westham: ["westham", "westhamunited", "whu"],
  everton: ["everton", "evertonfc"],
  brighton: ["brighton", "brightonhovealbion", "bha"],
  brentford: ["brentford", "brentfordfc"],
  fulham: ["fulham", "fulhamfc"],
  crystalpalace: ["crystalpalace", "crystalpalacefc"],
  bournemouth: ["bournemouth", "afcbournemouth"],
  nottinghamforest: ["nottinghamforest", "nottingham", "nfo", "forest"],
  leicester: ["leicester", "leicestercity", "lcfc"],
  southampton: ["southampton", "southamptonfc"],
  ipswich: ["ipswich", "ipswichtown"],
  leeds: ["leeds", "leedsunited"],
  burnley: ["burnley", "burnleyfc"],
  sheffieldunited: ["sheffieldunited", "sheffutd"],
  sunderland: ["sunderland", "safc"],
  middlesbrough: ["middlesbrough", "mfc"],
  norwich: ["norwich", "norwichcity"],
  westbrom: ["westbrom", "wbafc", "westbromwich", "westbromwichalbion"],

  bayern: ["bayern", "bayernmunich", "bayernmunchen", "fcbayern", "bay"],
  dortmund: ["dortmund", "borussiadortmund", "bvb"],
  leipzig: ["leipzig", "rbleipzig", "rbl"],
  leverkusen: ["leverkusen", "bayerleverkusen", "b04"],
  frankfurt: ["frankfurt", "eintrachtfrankfurt", "sge"],
  stuttgart: ["stuttgart", "vfb"],
  wolfsburg: ["wolfsburg", "vflwolfsburg"],
  gladbach: ["gladbach", "monchengladbach", "borussiamonchengladbach", "bmg"],
  werderbremen: ["werderbremen", "bremen", "svw"],
  freiburg: ["freiburg", "scfreiburg"],
  unionberlin: ["unionberlin", "1fcunionberlin"],
  hoffenheim: ["hoffenheim", "tsghoffenheim"],
  mainz: ["mainz", "fsvmainz"],
  heidenheim: ["heidenheim", "1fcheidenheim"],
  stpauli: ["stpauli", "fcstpauli"],

  acmilan: ["acmilan", "milan", "milanac", "mil"],
  inter: ["inter", "intermilan", "internazionale", "int"],
  juventus: ["juventus", "juve", "juv"],
  roma: ["roma", "asroma", "rome", "asrome"],
  napoli: ["napoli", "naples", "sscnapoli", "nap"],
  lazio: ["lazio", "sslazio", "laz"],
  atalanta: ["atalanta", "atalantabc", "ata"],
  fiorentina: ["fiorentina", "acf_fiorentina", "fio"],
  bologna: ["bologna", "bolognafc", "bol"],
  torino: ["torino", "torinofc", "tor"],
  udinese: ["udinese", "udinesecalcio"],
  genoa: ["genoa", "genoacfc"],
  cagliari: ["cagliari", "cagliaricalcio"],
  verona: ["verona", "hellasverona"],
  parma: ["parma", "parmacalcio"],
  como: ["como", "comofc"],
  empoli: ["empoli", "empolifc"],
  venezia: ["venezia", "veneziafc"],
  monza: ["monza", "acmonza"],

  benfica: ["benfica", "slbenfica", "slb"],
  sporting: ["sporting", "sportingcp", "sportinglisbon", "sportingportugal", "scp"],
  porto: ["porto", "fcporto", "fcp"],
  braga: ["braga", "scbraga"],

  ajax: ["ajax", "afcajax", "ajaxamsterdam"],
  psv: ["psv", "psveindhoven"],
  feyenoord: ["feyenoord", "feyenoordrotterdam"],
  az: ["az", "azalkmaar"],

  galatasaray: ["galatasaray", "gala", "gs"],
  fenerbahce: ["fenerbahce", "fener", "fb"],
  besiktas: ["besiktas", "bjk"],

  celtic: ["celtic", "celticfc"],
  rangers: ["rangers", "rangersfc"],

  alnassr: ["alnassr", "nassr"],
  alhilal: ["alhilal", "hilal"],
  alittihad: ["alittihad", "ittihad"],
  alahli: ["alahli", "ahli"],
};

/**
 * Normalizes team name for fuzzy matching (removes accents, non-alphanumeric, generic club prefixes)
 */
export function normalizeName(name: string): string {
  if (!name) return "";
  return name
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/^(fc|cf|as|ac|rc|rcd|ud|cd|sc|afc|losc|ogc|rb|vfb|vfl|ssc|ssl|ca|estac|stade|sporting)\s+/g, "")
    .replace(/\s+(fc|cf|sc|afc|club)$/g, "")
    .replace(/[^a-z0-9]/g, "");
}

/**
 * Simple Levenshtein distance for fuzzy typo tolerance
 */
function levenshteinDistance(a: string, b: string): number {
  if (a.length === 0) return b.length;
  if (b.length === 0) return a.length;

  const matrix: number[][] = [];
  for (let i = 0; i <= b.length; i++) {
    matrix[i] = [i];
  }
  for (let j = 0; j <= a.length; j++) {
    matrix[0][j] = j;
  }

  for (let i = 1; i <= b.length; i++) {
    for (let j = 1; j <= a.length; j++) {
      if (b.charAt(i - 1) === a.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1, // substitution
          matrix[i][j - 1] + 1,     // insertion
          matrix[i - 1][j] + 1      // deletion
        );
      }
    }
  }

  return matrix[b.length][a.length];
}

/**
 * Returns canonical club identifier from team aliases
 */
export function getTeamCanonicalKey(name: string): string | null {
  if (!name) return null;
  const norm = normalizeName(name);
  if (!norm) return null;

  for (const [key, aliases] of Object.entries(TEAM_ALIASES)) {
    for (const al of aliases) {
      if (norm === al) return key;
      if (norm.length >= 6 && al.length >= 6) {
        if (norm.startsWith(al) || al.startsWith(norm)) return key;
      }
    }
  }
  return null;
}

/**
 * Checks if two team names refer to the same football club
 */
export function matchesTeam(nameA: string, nameB: string): boolean {
  if (!nameA || !nameB) return false;

  const normA = normalizeName(nameA);
  const normB = normalizeName(nameB);

  if (!normA || !normB) return false;

  // 1. Direct exact match
  if (normA === normB) return true;

  // 2. Canonical aliases match (strongest guarantee against false positives)
  const canA = getTeamCanonicalKey(nameA);
  const canB = getTeamCanonicalKey(nameB);
  if (canA && canB && canA === canB) return true;

  // 3. Safe substring match: only if length is at least 6 characters and one starts with the other
  if (normA.length >= 6 && normB.length >= 6) {
    if (normA.startsWith(normB) || normB.startsWith(normA)) return true;
  }

  // 4. Levenshtein fuzzy match for long names with minor spelling difference (e.g. Barcelone vs Barcelona)
  if (normA.length >= 6 && normB.length >= 6) {
    const dist = levenshteinDistance(normA, normB);
    const maxLen = Math.max(normA.length, normB.length);
    if (dist <= 2 && dist / maxLen <= 0.2) {
      return true;
    }
  }

  return false;
}

/**
 * Priority leagues that contain 99% of European and tracked fixtures
 */
const PRIORITY_LEAGUE_CODES = [
  "eng.1", "fra.1", "esp.1", "ita.1", "ger.1",
  "por.1", "ned.1", "sau.1", "tur.1", "bel.1",
  "sco.1", "usa.1", "bra.1", "uefa.champions", "uefa.wchampions", "uefa.europa",
  "uefa.europa.conf", "uefa.nations",
  "eng.2", "fra.2", "esp.2", "ita.2", "ger.2"
];

// In-memory cache of live scores with timestamp and manual overrides
let cachedLiveScores: LiveScoreResult[] = [];
let lastFetchTimestamp = 0;
const CACHE_TTL_MS = 10000; // 10 seconds cache
let isCurrentlyFetching = false;

// Store manual or simulated scores set by user/pipeline
const manualLiveScoresMap = new Map<string, LiveScoreResult>();

export function setManualMatchScore(
  homeTeam: string,
  awayTeam: string,
  data: Partial<LiveScoreResult>
): LiveScoreResult {
  const key = `${normalizeName(homeTeam)}_${normalizeName(awayTeam)}`;
  const existing = manualLiveScoresMap.get(key) || {
    homeTeam,
    awayTeam,
    scoreHome: 0,
    scoreAway: 0,
    isLive: false,
    isFinished: false,
    statusText: "À venir",
    liveMinute: "",
    league: "Football",
    goals: [],
  };

  const updated: LiveScoreResult = {
    ...existing,
    ...data,
    homeTeam: data.homeTeam || existing.homeTeam,
    awayTeam: data.awayTeam || existing.awayTeam,
    scoreHome: data.scoreHome !== undefined ? data.scoreHome : existing.scoreHome,
    scoreAway: data.scoreAway !== undefined ? data.scoreAway : existing.scoreAway,
  };

  manualLiveScoresMap.set(key, updated);
  return updated;
}

export function getManualMatchScores(): LiveScoreResult[] {
  return Array.from(manualLiveScoresMap.values());
}

/**
 * Fetches real scores from ESPN scoreboard with fast batching and strict timeout
 */
export async function fetchLiveScoresForLeagues(forceRefresh: boolean = false): Promise<LiveScoreResult[]> {
  const now = Date.now();
  if (!forceRefresh && cachedLiveScores.length > 0 && now - lastFetchTimestamp < CACHE_TTL_MS) {
    return cachedLiveScores;
  }

  if (isCurrentlyFetching) {
    return cachedLiveScores;
  }

  isCurrentlyFetching = true;
  const resultsMap = new Map<string, LiveScoreResult>();

  try {
    // Process leagues in batches of 5 to avoid socket congestion and timeouts
    for (let i = 0; i < PRIORITY_LEAGUE_CODES.length; i += 5) {
      const batch = PRIORITY_LEAGUE_CODES.slice(i, i + 5);
      await Promise.all(
        batch.map(async (code) => {
          try {
            const url = `https://site.api.espn.com/apis/site/v2/sports/soccer/${code}/scoreboard`;
            const res = await fetch(url, {
              headers: {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                Accept: "application/json",
              },
              signal: AbortSignal.timeout(3500),
            });

            if (!res.ok) return;
            const data = await res.json();
            const events = data.events || [];

            for (const ev of events) {
              const comp = ev.competitions?.[0];
              if (!comp) continue;

              const statusName = comp.status?.type?.name || "";
              const statusDesc = comp.status?.type?.description || "";
              const shortDetail = comp.status?.type?.shortDetail || "";

              const isFinished =
                statusName === "STATUS_FINAL" ||
                statusName === "STATUS_FULL_TIME" ||
                statusName === "STATUS_AFTER_ET" ||
                statusName === "STATUS_AFTER_PK" ||
                comp.status?.type?.completed === true ||
                comp.status?.type?.state === "post" ||
                statusDesc.toLowerCase().includes("final") ||
                statusDesc.toLowerCase().includes("full time") ||
                shortDetail === "FT";

              const isLive =
                !isFinished &&
                (comp.status?.type?.state === "in" ||
                  statusName === "STATUS_IN_PROGRESS" ||
                  statusName === "STATUS_HALFTIME" ||
                  statusName === "STATUS_FIRST_HALF" ||
                  statusName === "STATUS_SECOND_HALF" ||
                  statusName === "STATUS_EXTRA_TIME" ||
                  statusDesc.toLowerCase().includes("half"));

              const statusText = shortDetail || statusDesc || statusName;
              const liveMinute = comp.status?.displayClock || shortDetail || (isFinished ? "FT" : "");

              const competitors = comp.competitors || [];
              const homeComp = competitors.find((c: any) => c.homeAway === "home") || competitors[0];
              const awayComp = competitors.find((c: any) => c.homeAway === "away") || competitors[1];

              if (!homeComp || !awayComp) continue;

              const homeTeam = homeComp.team?.displayName || homeComp.team?.name || "";
              const awayTeam = awayComp.team?.displayName || awayComp.team?.name || "";

              const scoreHome = parseInt(homeComp.score || "0", 10);
              const scoreAway = parseInt(awayComp.score || "0", 10);

              const goals: LiveScoreGoalEvent[] = [];
              const details = comp.details || [];
              for (const det of details) {
                const detText = (det.type?.text || "").toLowerCase();
                if (detText.includes("goal") || detText.includes("but") || detText.includes("penalty")) {
                  const isHomeScorer = det.team?.id === homeComp.team?.id;
                  goals.push({
                    scorerName:
                      det.athletesInvolved?.[0]?.displayName ||
                      det.participant?.displayName ||
                      "Buteur",
                    team: isHomeScorer ? "home" : "away",
                    minute: det.clock?.displayValue || `${det.clock?.value || ""}'`,
                  });
                }
              }

              const key = `${ev.id || `${homeTeam}_${awayTeam}`}`;
              resultsMap.set(key, {
                matchId: ev.id,
                homeTeam,
                awayTeam,
                scoreHome: isNaN(scoreHome) ? 0 : scoreHome,
                scoreAway: isNaN(scoreAway) ? 0 : scoreAway,
                isLive,
                isFinished,
                statusText,
                liveMinute,
                league: data.leagues?.[0]?.name || code,
                goals,
              });
            }
          } catch {
            // League fetch timed out or failed gracefully
          }
        })
      );
    }
  } catch (outerErr) {
    console.warn("[LiveScoreChecker] Error in batch fetch:", outerErr);
  } finally {
    isCurrentlyFetching = false;
  }

  // Overlay manual / simulated scores so user actions always take precedence
  for (const manualScore of manualLiveScoresMap.values()) {
    const key = `manual_${manualScore.homeTeam}_${manualScore.awayTeam}`;
    resultsMap.set(key, manualScore);
  }

  cachedLiveScores = Array.from(resultsMap.values());
  lastFetchTimestamp = Date.now();
  return cachedLiveScores;
}

/**
 * Finds if a match has a real live/finished score
 */
export function findMatchScore(
  homeTeam: string,
  awayTeam: string,
  scores: LiveScoreResult[]
): LiveScoreResult | null {
  // First priority: check manual overrides
  const manualKey = `${normalizeName(homeTeam)}_${normalizeName(awayTeam)}`;
  if (manualLiveScoresMap.has(manualKey)) {
    return manualLiveScoresMap.get(manualKey)!;
  }
  const reverseManualKey = `${normalizeName(awayTeam)}_${normalizeName(homeTeam)}`;
  if (manualLiveScoresMap.has(reverseManualKey)) {
    const s = manualLiveScoresMap.get(reverseManualKey)!;
    return {
      ...s,
      scoreHome: s.scoreAway,
      scoreAway: s.scoreHome,
    };
  }

  for (const s of scores) {
    if (matchesTeam(homeTeam, s.homeTeam) && matchesTeam(awayTeam, s.awayTeam)) {
      return s;
    }
    // Also check inverted just in case
    if (matchesTeam(homeTeam, s.awayTeam) && matchesTeam(awayTeam, s.homeTeam)) {
      return {
        ...s,
        scoreHome: s.scoreAway,
        scoreAway: s.scoreHome,
      };
    }
  }
  return null;
}
