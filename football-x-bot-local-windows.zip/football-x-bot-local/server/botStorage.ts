import fs from "fs";
import path from "path";

/**
 * Centralized, atomic JSON file persistence for Football X-Bot Pro.
 * Stores all runtime state inside DATA_DIR (default: ./data) so Docker volumes
 * and .gitignore keep secrets (X cookies) cleanly isolated from source code.
 */

export const DATA_DIR = process.env.BOT_DATA_DIR
  ? path.resolve(process.env.BOT_DATA_DIR)
  : path.join(process.cwd(), "data");

function ensureDataDir(): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

export function getDataFilePath(filename: string): string {
  ensureDataDir();
  return path.join(DATA_DIR, filename);
}

/**
 * Read a JSON file from DATA_DIR, with optional one-time migration from a legacy root dotfile.
 */
export function readJsonState<T>(
  filename: string,
  fallback: T,
  legacyRootFilename?: string
): T {
  ensureDataDir();
  const targetPath = path.join(DATA_DIR, filename);

  // One-time migration from legacy root dotfile if target doesn't exist yet
  if (!fs.existsSync(targetPath) && legacyRootFilename) {
    const legacyPath = path.join(process.cwd(), legacyRootFilename);
    if (fs.existsSync(legacyPath)) {
      try {
        const rawLegacy = fs.readFileSync(legacyPath, "utf-8");
        const parsedLegacy = JSON.parse(rawLegacy);
        writeJsonState(filename, parsedLegacy);
        return parsedLegacy as T;
      } catch (e) {
        console.warn(`[BotStorage] Migration warning for ${legacyRootFilename}:`, e);
      }
    }
  }

  try {
    if (fs.existsSync(targetPath)) {
      const raw = fs.readFileSync(targetPath, "utf-8");
      if (!raw.trim()) return fallback;
      return JSON.parse(raw) as T;
    }
  } catch (e) {
    console.warn(`[BotStorage] Failed to read ${filename}:`, e);
  }

  return fallback;
}

/**
 * Atomically write JSON state (temp file + rename) to prevent corrupted files on restart.
 */
export function writeJsonState(filename: string, data: unknown): void {
  try {
    ensureDataDir();
    const targetPath = path.join(DATA_DIR, filename);
    const tmpPath = `${targetPath}.${process.pid}.${Date.now()}.tmp`;
    fs.writeFileSync(tmpPath, JSON.stringify(data, null, 2), "utf-8");
    fs.renameSync(tmpPath, targetPath);
  } catch (e) {
    console.warn(`[BotStorage] Failed to write ${filename}:`, e);
  }
}
