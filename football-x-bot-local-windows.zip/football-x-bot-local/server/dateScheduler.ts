/**
 * Robust, timezone-aware date & time scheduler for match predictions (Europe/Paris).
 * Strictly guarantees:
 * 1. Past or already-started matches NEVER trigger H-1h predictions.
 * 2. H-1h predictions fire strictly in the 15-75 min pre-match window (centered at H-1h).
 * 3. Anti-collision window prevents overlapping matches within 75 minutes of each other.
 */

export const MONTH_MAP_FR: Record<string, number> = {
  janvier: 0,
  janv: 0,
  jan: 0,
  fevrier: 1,
  février: 1,
  fevr: 1,
  fev: 1,
  mars: 2,
  mar: 2,
  avril: 3,
  avr: 3,
  mai: 4,
  juin: 5,
  juillet: 6,
  juil: 6,
  aout: 7,
  août: 7,
  aou: 7,
  septembre: 8,
  sept: 8,
  sep: 8,
  octobre: 9,
  oct: 9,
  novembre: 10,
  nov: 10,
  decembre: 11,
  décembre: 11,
  dec: 11,
};

export interface MatchTimingInfo {
  matchYear: number;
  matchMonth: number;
  matchDay: number;
  hours: number;
  minutes: number;
  kickoffEpochApprox: number;
  totalDiffMinutes: number; // positive = in the future, negative = in the past
  isPastKickoff: boolean;
  isMatchFinished: boolean;
  isWithinH1Window: boolean; // pre-match window strictly 15 to 75 minutes in the FUTURE before kickoff
  isToday: boolean;
  isTomorrow: boolean;
  isFuture: boolean;
  formattedDate: string;
  formattedKickoffTime: string;
  isoDateKey: string; // YYYY-MM-DD
}

/**
 * Returns current date & time broken down in Europe/Paris timezone.
 */
export function getParisNow(): {
  year: number;
  month: number;
  day: number;
  hour: number;
  minute: number;
  second: number;
  isoDate: string;
} {
  const now = new Date();
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: "Europe/Paris",
    year: "numeric",
    month: "numeric",
    day: "numeric",
    hour: "numeric",
    minute: "numeric",
    second: "numeric",
    hour12: false,
  }).formatToParts(now);

  const map: Record<string, number> = {};
  for (const p of parts) {
    map[p.type] = parseInt(p.value, 10);
  }

  const year = map.year || now.getFullYear();
  const month = (map.month || now.getMonth() + 1) - 1;
  const day = map.day || now.getDate();
  const hour = map.hour === 24 ? 0 : map.hour !== undefined ? map.hour : now.getHours();
  const minute = map.minute !== undefined ? map.minute : now.getMinutes();
  const second = map.second !== undefined ? map.second : now.getSeconds();

  const pad = (n: number) => (n < 10 ? `0${n}` : `${n}`);
  const isoDate = `${year}-${pad(month + 1)}-${pad(day)}`;

  return { year, month, day, hour, minute, second, isoDate };
}

/**
 * Returns YYYYMMDD string for ESPN API queries in Europe/Paris timezone.
 */
export function getEspnDateForOffset(offsetDays: number = 0): string {
  const parisNow = getParisNow();
  const d = new Date(Date.UTC(parisNow.year, parisNow.month, parisNow.day + offsetDays, 12, 0, 0));
  const pad = (n: number) => (n < 10 ? `0${n}` : `${n}`);
  return `${d.getUTCFullYear()}${pad(d.getUTCMonth() + 1)}${pad(d.getUTCDate())}`;
}

/**
 * Parses match date and kickoff time string and returns full timing calculations.
 */
export function parseMatchDateTime(
  dateStr?: string,
  kickoffTimeStr?: string
): MatchTimingInfo {
  const parisNow = getParisNow();
  let matchYear = parisNow.year;
  let matchMonth = parisNow.month;
  let matchDay = parisNow.day;

  let hours = 20;
  let minutes = 0;

  if (kickoffTimeStr) {
    const timeClean = String(kickoffTimeStr).trim().toLowerCase();
    const m = timeClean.match(/(\d{1,2})[:h](\d{2})/);
    if (m) {
      hours = parseInt(m[1], 10);
      minutes = parseInt(m[2], 10);
    } else {
      const single = timeClean.match(/(\d{1,2})/);
      if (single) {
        hours = parseInt(single[1], 10);
      }
    }
  }

  if (dateStr) {
    const clean = String(dateStr).trim().toLowerCase();
    if (clean.includes("demain")) {
      const tom = new Date(Date.UTC(parisNow.year, parisNow.month, parisNow.day + 1, 12, 0, 0));
      matchYear = tom.getUTCFullYear();
      matchMonth = tom.getUTCMonth();
      matchDay = tom.getUTCDate();
    } else if (clean.includes("hier")) {
      const yest = new Date(Date.UTC(parisNow.year, parisNow.month, parisNow.day - 1, 12, 0, 0));
      matchYear = yest.getUTCFullYear();
      matchMonth = yest.getUTCMonth();
      matchDay = yest.getUTCDate();
    } else if (clean.includes("aujourd") || clean.includes("ce soir") || clean === "today") {
      matchYear = parisNow.year;
      matchMonth = parisNow.month;
      matchDay = parisNow.day;
    } else {
      const isoMatch = clean.match(/(\d{4})-(\d{2})-(\d{2})/);
      const slashMatch = clean.match(/(\d{1,2})[\/\.-](\d{1,2})(?:[\/\.-](\d{2,4}))?/);
      const frenchWordMatch = clean.match(/(\d{1,2})\s+([a-zéûèà]+)\.?(?:\s+(\d{4}))?/i);

      if (isoMatch) {
        matchYear = parseInt(isoMatch[1], 10);
        matchMonth = parseInt(isoMatch[2], 10) - 1;
        matchDay = parseInt(isoMatch[3], 10);
      } else if (frenchWordMatch) {
        matchDay = parseInt(frenchWordMatch[1], 10);
        const mWord = frenchWordMatch[2]
          .toLowerCase()
          .normalize("NFD")
          .replace(/[\u0300-\u036f]/g, "");
        for (const [k, v] of Object.entries(MONTH_MAP_FR)) {
          const kNorm = k.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
          if (mWord.startsWith(kNorm) || kNorm.startsWith(mWord)) {
            matchMonth = v;
            break;
          }
        }
        if (frenchWordMatch[3]) {
          matchYear = parseInt(frenchWordMatch[3], 10);
        } else {
          // Handle year rollover (e.g. December -> January)
          if (parisNow.month === 11 && matchMonth === 0) {
            matchYear = parisNow.year + 1;
          } else if (parisNow.month === 0 && matchMonth === 11) {
            matchYear = parisNow.year - 1;
          }
        }
      } else if (slashMatch) {
        matchDay = parseInt(slashMatch[1], 10);
        matchMonth = parseInt(slashMatch[2], 10) - 1;
        if (slashMatch[3]) {
          matchYear =
            slashMatch[3].length === 2
              ? 2000 + parseInt(slashMatch[3], 10)
              : parseInt(slashMatch[3], 10);
        }
      }
    }
  }

  // Exact difference in minutes between match kickoff and current time in Paris
  const dayDiff =
    (Date.UTC(matchYear, matchMonth, matchDay) -
      Date.UTC(parisNow.year, parisNow.month, parisNow.day)) /
    86400000;

  const totalKickoffMinsFromParisMidnight = hours * 60 + minutes;
  const totalParisNowMinsFromMidnight = parisNow.hour * 60 + parisNow.minute;

  const totalDiffMinutes = Math.round(
    dayDiff * 1440 +
      (totalKickoffMinsFromParisMidnight - totalParisNowMinsFromMidnight)
  );

  const kickoffEpochApprox = Date.now() + totalDiffMinutes * 60 * 1000;
  const isPastKickoff = totalDiffMinutes <= 0;
  const isMatchFinished = totalDiffMinutes <= -115;
  // Strict H-1h pre-match window: between 15 and 70 minutes BEFORE kickoff
  const isWithinH1Window =
    !isPastKickoff && totalDiffMinutes >= 15 && totalDiffMinutes <= 70;
  const isToday = dayDiff === 0;
  const isTomorrow = dayDiff === 1;
  const isFuture = totalDiffMinutes > 0;

  const pad = (n: number) => (n < 10 ? `0${n}` : `${n}`);
  const formattedKickoffTime = `${pad(hours)}:${pad(minutes)}`;
  const isoDateKey = `${matchYear}-${pad(matchMonth + 1)}-${pad(matchDay)}`;
  const monthsFr = [
    "janv.",
    "févr.",
    "mars",
    "avr.",
    "mai",
    "juin",
    "juil.",
    "août",
    "sept.",
    "oct.",
    "nov.",
    "déc.",
  ];
  const formattedDate = `${matchDay} ${monthsFr[matchMonth]} ${matchYear}`;

  return {
    matchYear,
    matchMonth,
    matchDay,
    hours,
    minutes,
    kickoffEpochApprox,
    totalDiffMinutes,
    isPastKickoff,
    isMatchFinished,
    isWithinH1Window,
    isToday,
    isTomorrow,
    isFuture,
    formattedDate,
    formattedKickoffTime,
    isoDateKey,
  };
}

/**
 * Returns absolute minutes difference between two match datetimes.
 */
export function getMinutesBetweenMatches(
  dateA?: string,
  timeA?: string,
  dateB?: string,
  timeB?: string
): number {
  const a = parseMatchDateTime(dateA, timeA);
  const b = parseMatchDateTime(dateB, timeB);
  return Math.abs(a.totalDiffMinutes - b.totalDiffMinutes);
}

/**
 * Returns a formatted date string (e.g. "18 nov. 2026") for Paris timezone with day offset.
 */
export function getFormattedDateForOffset(offsetDays: number = 0): string {
  const parisNow = getParisNow();
  const d = new Date(Date.UTC(parisNow.year, parisNow.month, parisNow.day + offsetDays, 12, 0, 0));
  const monthsFr = [
    "janv.",
    "févr.",
    "mars",
    "avr.",
    "mai",
    "juin",
    "juil.",
    "août",
    "sept.",
    "oct.",
    "nov.",
    "déc.",
  ];
  return `${d.getUTCDate()} ${monthsFr[d.getUTCMonth()]} ${d.getUTCFullYear()}`;
}

/**
 * Checks if a match belongs to an expired date:
 * - Unconditionally expired if kickoff was > 18 hours ago (yesterday's finished matches).
 * - Also expired if kickoff is > 7 days in the future or older than yesterday.
 */
export function isExpiredOldMatch(dateStr?: string, kickoffTimeStr?: string): boolean {
  if (!dateStr) return false;
  const timing = parseMatchDateTime(dateStr, kickoffTimeStr);

  // Purge matches whose kickoff was more than 18 hours ago
  if (timing.totalDiffMinutes < -1080) {
    return true;
  }

  return false;
}

/**
 * STRICT CHECK: Is this match in the past?
 * Returns true if the kickoff date/time has already passed.
 */
export function isMatchInThePast(
  dateStr?: string,
  kickoffTimeStr?: string
): boolean {
  const timing = parseMatchDateTime(dateStr, kickoffTimeStr);
  return timing.isPastKickoff;
}

/**
 * STRICT CHECK: Is this match due for H-1h tweet right now?
 * Returns true ONLY IF the match is in the future AND between 15 and 70 minutes from now.
 */
export function isMatchDueForH1(
  dateStr?: string,
  kickoffTimeStr?: string
): boolean {
  const timing = parseMatchDateTime(dateStr, kickoffTimeStr);
  return timing.isWithinH1Window;
}
