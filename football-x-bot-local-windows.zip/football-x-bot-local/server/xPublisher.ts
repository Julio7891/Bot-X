import { readJsonState, writeJsonState } from "./botStorage";

/**
 * 100% Free Autonomous X (Twitter) Publisher via Session Cookies (auth_token & ct0)
 * - ZERO Paid Twitter/X API ($0/month)
 * - Dynamic GraphQL QueryId auto-discovery from x.com bundles (auto-heals when X rotates hashes)
 * - Automatic ct0 cookie rotation capture from Set-Cookie headers
 * - Honest session verification (real @username or exact failure reason)
 * - Thread reply support (inReplyToTweetId) for Live Goals & FT Debriefs
 * - Optional Playwright fallback on local PC / VPS when X_USE_PLAYWRIGHT=true
 */

const CREDS_STORAGE_KEY = "x_credentials.json";
const LEGACY_CREDS_FILE = ".x_credentials.json";

export type PublishingMode = "LIVE_COOKIES" | "SIMULATION" | "AUTO";

export type CookieHealthStatus =
  | "UNKNOWN"
  | "VALID"
  | "MISSING"
  | "EXPIRED"
  | "IP_BLOCKED"
  | "NETWORK_ERROR";

export interface CookieHealthSnapshot {
  status: CookieHealthStatus;
  username?: string;
  displayName?: string;
  checkedAt?: number;
  message: string;
}

export interface XApiCredentials {
  publishingMode?: PublishingMode;
  authToken?: string;
  ct0?: string;
  username?: string;
  displayName?: string;
  booster1AuthToken?: string;
  booster1Ct0?: string;
  booster2AuthToken?: string;
  booster2Ct0?: string;
}

const TWITTER_BEARER_TOKEN =
  "Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA";

// Curated fallback GraphQL Query IDs (prepended dynamically by live bundle discovery!)
const FALLBACK_CREATE_TWEET_IDS = [
  "xT38ISTsnnFdJRNEcJUyJw",
  "a1p9RWpkYKBjWv_I3WzS-A",
  "SoAxQO084qK_A94qX72c-Q",
  "oB-5XZ4n1PxbgYSLklvNSA",
  "5V_dkq1kcR3yTuhRBguCTA",
  "Hb9T6cmq0cxjK46tTf47vg",
  "znqclUmRkbsmAOzyPdUoaQ",
];

const FALLBACK_FAVORITE_TWEET_IDS = [
  "lI07N6Otwv1PhnEgXILM7A",
  "jP28whgjw2OZCW8OMPbc6A",
  "I5Oq6aZ9K64pC8f2U_5iEg",
];

interface DynamicQueryIdCache {
  createTweetId?: string;
  favoriteTweetId?: string;
  fetchedAt: number;
}

let queryIdCache: DynamicQueryIdCache = { fetchedAt: 0 };
const QUERY_ID_TTL_MS = 6 * 60 * 60 * 1000; // 6 hours

function sanitizeCookie(val?: string, prefix?: string): string {
  if (!val) return "";
  let clean = val.trim();
  if (prefix) {
    clean = clean.replace(new RegExp(`^${prefix}=`, "i"), "");
  }
  return clean.replace(/[;"'\s]/g, "");
}

function normalizePublishingMode(mode?: string): "LIVE_COOKIES" | "SIMULATION" {
  // Upgrade legacy "AUTO" (which silently masked failures as simulation) to honest LIVE_COOKIES
  if (mode === "SIMULATION") return "SIMULATION";
  return "LIVE_COOKIES";
}

function loadStoredCredentials(): XApiCredentials {
  const stored = readJsonState<Partial<XApiCredentials>>(
    CREDS_STORAGE_KEY,
    {},
    LEGACY_CREDS_FILE
  );
  return {
    publishingMode: normalizePublishingMode(stored.publishingMode),
    authToken: sanitizeCookie(stored.authToken || process.env.X_AUTH_TOKEN, "auth_token"),
    ct0: sanitizeCookie(stored.ct0 || process.env.X_CT0, "ct0"),
    username: stored.username || undefined,
    displayName: stored.displayName || undefined,
    booster1AuthToken: sanitizeCookie(
      stored.booster1AuthToken || process.env.X_BOOSTER1_AUTH_TOKEN,
      "auth_token"
    ),
    booster1Ct0: sanitizeCookie(
      stored.booster1Ct0 || process.env.X_BOOSTER1_CT0,
      "ct0"
    ),
    booster2AuthToken: sanitizeCookie(
      stored.booster2AuthToken || process.env.X_BOOSTER2_AUTH_TOKEN,
      "auth_token"
    ),
    booster2Ct0: sanitizeCookie(
      stored.booster2Ct0 || process.env.X_BOOSTER2_CT0,
      "ct0"
    ),
  };
}

let cachedCredentials: XApiCredentials = loadStoredCredentials();
let currentPublishingMode: "LIVE_COOKIES" | "SIMULATION" = normalizePublishingMode(
  cachedCredentials.publishingMode
);

let cookieHealth: CookieHealthSnapshot = {
  status:
    cachedCredentials.authToken && cachedCredentials.ct0 ? "UNKNOWN" : "MISSING",
  username: cachedCredentials.username,
  displayName: cachedCredentials.displayName,
  message:
    cachedCredentials.authToken && cachedCredentials.ct0
      ? "Cookies présents, vérification en cours..."
      : "Aucun cookie X (auth_token + ct0) configuré.",
};

export function getCookieHealth(): CookieHealthSnapshot {
  return { ...cookieHealth };
}

export function getPublishingMode(): "LIVE_COOKIES" | "SIMULATION" {
  return currentPublishingMode;
}

export function setPublishingMode(mode: PublishingMode) {
  const normalized = normalizePublishingMode(mode);
  currentPublishingMode = normalized;
  cachedCredentials.publishingMode = normalized;
  writeJsonState(CREDS_STORAGE_KEY, cachedCredentials);
  console.log(`[XPublisher] 🔄 Mode de publication mis à jour : ${normalized}`);
}

export function updateServerXCredentials(creds: Partial<XApiCredentials>) {
  if (creds.publishingMode) {
    currentPublishingMode = normalizePublishingMode(creds.publishingMode);
  }
  const merged: XApiCredentials = {
    ...cachedCredentials,
    ...(creds.publishingMode ? { publishingMode: currentPublishingMode } : {}),
    ...(creds.authToken !== undefined
      ? { authToken: sanitizeCookie(creds.authToken, "auth_token") }
      : {}),
    ...(creds.ct0 !== undefined ? { ct0: sanitizeCookie(creds.ct0, "ct0") } : {}),
    ...(creds.username !== undefined ? { username: creds.username } : {}),
    ...(creds.displayName !== undefined ? { displayName: creds.displayName } : {}),
    ...(creds.booster1AuthToken !== undefined
      ? { booster1AuthToken: sanitizeCookie(creds.booster1AuthToken, "auth_token") }
      : {}),
    ...(creds.booster1Ct0 !== undefined
      ? { booster1Ct0: sanitizeCookie(creds.booster1Ct0, "ct0") }
      : {}),
    ...(creds.booster2AuthToken !== undefined
      ? { booster2AuthToken: sanitizeCookie(creds.booster2AuthToken, "auth_token") }
      : {}),
    ...(creds.booster2Ct0 !== undefined
      ? { booster2Ct0: sanitizeCookie(creds.booster2Ct0, "ct0") }
      : {}),
  };

  cachedCredentials = merged;
  writeJsonState(CREDS_STORAGE_KEY, cachedCredentials);

  if (!cachedCredentials.authToken || !cachedCredentials.ct0) {
    cookieHealth = {
      status: "MISSING",
      checkedAt: Date.now(),
      message: "Cookies X (auth_token + ct0) manquants.",
    };
  }
  console.log("[XPublisher] 💾 Cookies enregistrés de façon sécurisée dans data/x_credentials.json.");
}

export function getServerXCredentials(): XApiCredentials {
  return { ...cachedCredentials, publishingMode: currentPublishingMode };
}

/**
 * Captures any rotated ct0 cookie sent back by X in Set-Cookie headers
 */
function captureRotatedCt0(response: Response, currentAuth: string): void {
  try {
    const rawSetCookie = response.headers.get("set-cookie");
    if (!rawSetCookie) return;
    const match = rawSetCookie.match(/ct0=([a-fA-F0-9]{20,256})/);
    if (match && match[1]) {
      const freshCt0 = match[1].trim();
      if (
        freshCt0 &&
        freshCt0 !== cachedCredentials.ct0 &&
        currentAuth === cachedCredentials.authToken
      ) {
        console.log("[XPublisher] 🔄 Rotation automatique du cookie ct0 détectée et sauvegardée.");
        cachedCredentials.ct0 = freshCt0;
        writeJsonState(CREDS_STORAGE_KEY, cachedCredentials);
      }
    }
  } catch {
    // Ignore header parsing edge cases
  }
}

function buildXHeaders(authToken: string, ct0: string, referer = "https://x.com/compose/post"): Record<string, string> {
  return {
    Authorization: TWITTER_BEARER_TOKEN,
    "x-csrf-token": ct0,
    "x-twitter-auth-type": "OAuth2Session",
    "x-twitter-active-user": "yes",
    "x-twitter-client-language": "fr",
    Cookie: `auth_token=${authToken}; ct0=${ct0}`,
    "User-Agent":
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    Accept: "*/*",
    "Accept-Language": "fr-FR,fr;q=0.9,en-US;q=0.8,en;q=0.7",
    Origin: "https://x.com",
    Referer: referer,
    "sec-ch-ua": '"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"',
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-origin",
  };
}

/**
 * Dynamically discovers the live CreateTweet and FavoriteTweet GraphQL Query IDs
 * from X's active web client JavaScript bundle so the bot auto-heals whenever X rotates hashes.
 */
export async function refreshDynamicQueryIds(force = false): Promise<DynamicQueryIdCache> {
  if (!force && Date.now() - queryIdCache.fetchedAt < QUERY_ID_TTL_MS && queryIdCache.createTweetId) {
    return queryIdCache;
  }

  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 9000);
    const homeRes = await fetch("https://x.com/", {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        Accept: "text/html,application/xhtml+xml",
      },
      signal: controller.signal,
    }).finally(() => clearTimeout(timer));

    if (!homeRes.ok) {
      return queryIdCache;
    }

    const html = await homeRes.text();
    const mainJsMatches = html.match(/https:\/\/abs\.twimg\.com\/responsive-web\/client-web\/main\.[a-zA-Z0-9_-]+\.js/g);
    if (!mainJsMatches || mainJsMatches.length === 0) {
      return queryIdCache;
    }

    const jsController = new AbortController();
    const jsTimer = setTimeout(() => jsController.abort(), 12000);
    const jsRes = await fetch(mainJsMatches[0], {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
      },
      signal: jsController.signal,
    }).finally(() => clearTimeout(jsTimer));

    if (!jsRes.ok) {
      return queryIdCache;
    }

    const jsText = await jsRes.text();
    const createMatch = jsText.match(/queryId:"([a-zA-Z0-9_-]{18,32})",operationName:"CreateTweet"/);
    const favMatch = jsText.match(/queryId:"([a-zA-Z0-9_-]{18,32})",operationName:"FavoriteTweet"/);

    queryIdCache = {
      createTweetId: createMatch?.[1] || queryIdCache.createTweetId,
      favoriteTweetId: favMatch?.[1] || queryIdCache.favoriteTweetId,
      fetchedAt: Date.now(),
    };

    if (queryIdCache.createTweetId) {
      console.log(`[XPublisher] 🔍 QueryId CreateTweet actif découvert : ${queryIdCache.createTweetId}`);
    }
  } catch (err: any) {
    console.warn("[XPublisher] Découverte dynamique QueryId ignorée:", err?.message || err);
  }

  return queryIdCache;
}

export interface PublishTweetParams {
  tweetText: string;
  inReplyToTweetId?: string;
  authToken?: string;
  ct0?: string;
  booster1AuthToken?: string;
  booster1Ct0?: string;
  booster2AuthToken?: string;
  booster2Ct0?: string;
}

export interface PublishTweetResult {
  success: boolean;
  tweetId?: string;
  tweetUrl?: string;
  intentUrl?: string;
  mode: "real_x_cookies" | "real_x_playwright" | "simulation" | "cookie_error";
  isDirectPublished?: boolean;
  retryable?: boolean;
  errorCode?:
    | "MISSING_COOKIES"
    | "COOKIES_EXPIRED"
    | "IP_BLOCKED"
    | "RATE_LIMITED"
    | "DUPLICATE_TWEET"
    | "X_ERROR";
  httpStatus?: number;
  message: string;
  details?: any;
  error?: string;
}

export interface LikeTweetResult {
  success: boolean;
  tweetId: string;
  message: string;
  error?: string;
}

/**
 * Likes / Favorites a tweet on X using GraphQL FavoriteTweet with session cookies
 */
export async function likeTweetViaCookies(
  tweetId: string,
  authToken?: string,
  ct0?: string
): Promise<LikeTweetResult> {
  const cleanTweetId = (tweetId || "").toString().match(/\d{10,30}/)?.[0] || "";
  const cleanAuth = sanitizeCookie(authToken || cachedCredentials.authToken, "auth_token");
  const cleanCt0 = sanitizeCookie(ct0 || cachedCredentials.ct0, "ct0");

  if (!cleanTweetId || cleanAuth.length < 15 || cleanCt0.length < 15) {
    return {
      success: false,
      tweetId: cleanTweetId || tweetId,
      message: "Paramètres ou cookies manquants pour le Like.",
    };
  }

  const dynamic = await refreshDynamicQueryIds(false);
  const queryIds = Array.from(
    new Set([dynamic.favoriteTweetId, ...FALLBACK_FAVORITE_TWEET_IDS].filter(Boolean) as string[])
  );

  const headers = buildXHeaders(cleanAuth, cleanCt0, `https://x.com/i/web/status/${cleanTweetId}`);
  let lastError = "";

  for (const queryId of queryIds) {
    const url = `https://x.com/i/api/graphql/${queryId}/FavoriteTweet`;
    try {
      const res = await fetch(url, {
        method: "POST",
        headers: { ...headers, "Content-Type": "application/json" },
        body: JSON.stringify({ variables: { tweet_id: cleanTweetId }, queryId }),
      });
      captureRotatedCt0(res, cleanAuth);
      const data = await res.json().catch(() => ({}));

      if (
        data?.data?.favorite_tweet === "Done" ||
        data?.data?.favorite_tweet?.favorite_state === "Favorited" ||
        (res.ok && !data?.errors?.length)
      ) {
        return {
          success: true,
          tweetId: cleanTweetId,
          message: "❤️ Tweet liké avec succès !",
        };
      }

      if (data?.errors?.[0]?.code === 139) {
        return {
          success: true,
          tweetId: cleanTweetId,
          message: "❤️ Tweet déjà liké.",
        };
      }

      lastError = data?.errors?.[0]?.message || `HTTP ${res.status}`;
      if (res.status === 401 || res.status === 403) break;
    } catch (err: any) {
      lastError = err?.message || "Erreur réseau";
    }
  }

  return {
    success: false,
    tweetId: cleanTweetId,
    message: `Échec auto-like : ${lastError}`,
    error: lastError,
  };
}

/**
 * Multi-Account Booster Auto-Like (Main + Satellites)
 */
export async function likeTweetWithAllAccounts(
  tweetId: string,
  overrideCreds?: Partial<XApiCredentials>
): Promise<{
  main: boolean;
  booster1: boolean;
  booster2: boolean;
  totalLikes: number;
  details: Record<string, string>;
}> {
  const cleanTweetId = (tweetId || "").toString().match(/\d{10,30}/)?.[0] || "";
  if (!cleanTweetId) {
    return { main: false, booster1: false, booster2: false, totalLikes: 0, details: {} };
  }

  const creds = { ...cachedCredentials, ...overrideCreds };
  let totalLikes = 0;
  let main = false;
  let booster1 = false;
  let booster2 = false;
  const details: Record<string, string> = {};

  const accounts: Array<{ key: "main" | "booster1" | "booster2"; auth?: string; ct0?: string; delayMs: number }> = [
    { key: "main", auth: creds.authToken, ct0: creds.ct0, delayMs: 2500 },
    { key: "booster1", auth: creds.booster1AuthToken, ct0: creds.booster1Ct0, delayMs: 4000 },
    { key: "booster2", auth: creds.booster2AuthToken, ct0: creds.booster2Ct0, delayMs: 4500 },
  ];

  for (const acc of accounts) {
    if (!acc.auth || !acc.ct0) {
      details[acc.key] = "Non configuré";
      continue;
    }
    await new Promise((r) => setTimeout(r, acc.delayMs));
    const res = await likeTweetViaCookies(cleanTweetId, acc.auth, acc.ct0);
    if (res.success) {
      totalLikes++;
      if (acc.key === "main") main = true;
      if (acc.key === "booster1") booster1 = true;
      if (acc.key === "booster2") booster2 = true;
      details[acc.key] = "Liké ✅";
    } else {
      details[acc.key] = res.message;
    }
  }

  return { main, booster1, booster2, totalLikes, details };
}

/**
 * Optional local/VPS Playwright browser publishing fallback (only if X_USE_PLAYWRIGHT=true)
 */
async function tryPlaywrightPublish(
  tweetText: string,
  authToken: string,
  ct0: string
): Promise<PublishTweetResult | null> {
  if (process.env.X_USE_PLAYWRIGHT !== "true") return null;

  try {
    // Dynamic import so Playwright is strictly optional and never crashes cloud deployments
    const pwModuleName = "playwright";
    const pw: any = await import(/* @vite-ignore */ pwModuleName);
    if (!pw?.chromium) return null;

    const browser = await pw.chromium.launch({ headless: true });
    try {
      const context = await browser.newContext({
        userAgent:
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
      });
      await context.addCookies([
        { name: "auth_token", value: authToken, domain: ".x.com", path: "/", httpOnly: true, secure: true },
        { name: "ct0", value: ct0, domain: ".x.com", path: "/", secure: true },
      ]);

      const page = await context.newPage();
      let capturedTweetId: string | undefined;

      page.on("response", async (resp: any) => {
        if (resp.url().includes("CreateTweet") && resp.status() === 200) {
          try {
            const json = await resp.json();
            const id =
              json?.data?.create_tweet?.tweet_results?.result?.rest_id ||
              json?.data?.create_tweet?.tweet_results?.result?.tweet?.rest_id;
            if (id) capturedTweetId = String(id);
          } catch {}
        }
      });

      await page.goto("https://x.com/compose/post", { waitUntil: "domcontentloaded", timeout: 25000 });
      const editor = page.locator('[data-testid="tweetTextarea_0"]').first();
      await editor.waitFor({ state: "visible", timeout: 15000 });
      await editor.click();
      await page.keyboard.type(tweetText, { delay: 12 });
      await page.keyboard.press("Control+Enter");
      await page.waitForTimeout(4500);

      if (capturedTweetId) {
        return {
          success: true,
          mode: "real_x_playwright",
          isDirectPublished: true,
          tweetId: capturedTweetId,
          tweetUrl: `https://x.com/i/web/status/${capturedTweetId}`,
          message: `✅ [Playwright Cookies] Tweet publié sur X (ID: ${capturedTweetId}) !`,
        };
      }
    } finally {
      await browser.close();
    }
  } catch (err: any) {
    console.warn("[XPublisher Playwright Fallback]:", err?.message || err);
  }
  return null;
}

/**
 * Core Cookie-Only GraphQL CreateTweet Publisher
 */
async function publishViaCookies(
  tweetText: string,
  authToken: string,
  ct0: string,
  inReplyToTweetId?: string,
  retriedWithFreshIds = false
): Promise<PublishTweetResult> {
  const webIntentUrl = `https://x.com/intent/tweet?text=${encodeURIComponent(tweetText)}`;
  const cleanAuth = sanitizeCookie(authToken, "auth_token");
  const cleanCt0 = sanitizeCookie(ct0, "ct0");

  const dynamic = await refreshDynamicQueryIds(retriedWithFreshIds);
  const queryIds = Array.from(
    new Set([dynamic.createTweetId, ...FALLBACK_CREATE_TWEET_IDS].filter(Boolean) as string[])
  );

  const validReplyId =
    inReplyToTweetId && /^\d{10,30}$/.test(inReplyToTweetId.trim())
      ? inReplyToTweetId.trim()
      : undefined;

  let lastHttpStatus = 0;
  let lastErrorMsg = "Impossible de joindre X";
  let sawNotFound = false;
  let sawAuthError = false;
  let sawCloudflareBlock = false;
  let sawRateLimit = false;
  let sawDuplicate = false;

  const attemptCreateTweet = async (replyId?: string): Promise<PublishTweetResult | null> => {
    for (const queryId of queryIds) {
      const url = `https://x.com/i/api/graphql/${queryId}/CreateTweet`;
      try {
        const variables: Record<string, any> = {
          tweet_text: tweetText,
          dark_request: false,
          media: {
            media_entities: [],
            possibly_sensitive: false,
          },
          semantic_annotation_ids: [],
        };

        if (replyId) {
          variables.reply = {
            in_reply_to_tweet_id: replyId,
            exclude_reply_user_ids: [],
          };
        }

        const payload = {
          variables,
          features: {
            communities_web_enable_tweet_community_results_fetch: true,
            c9s_tweet_anatomy_moderator_badge_enabled: true,
            articles_preview_enabled: true,
            responsive_web_edit_tweet_api_enabled: true,
            graphql_is_translatable_rweb_tweet_is_translatable_enabled: true,
            view_counts_everywhere_api_enabled: true,
            longform_notetweets_consumption_enabled: true,
            responsive_web_twitter_article_tweet_consumption_enabled: true,
            tweet_awards_web_tipping_enabled: false,
            creator_subscriptions_quote_tweet_preview_enabled: false,
            freedom_of_speech_not_reach_fetch_enabled: true,
            standardized_nudges_misinfo: true,
            tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled: true,
            rweb_video_timestamps_enabled: true,
            longform_notetweets_rich_text_read_enabled: true,
            longform_notetweets_inline_media_enabled: true,
            responsive_web_enhance_cards_enabled: false,
          },
          queryId,
        };

        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 12000);
        const response = await fetch(url, {
          method: "POST",
          headers: {
            ...buildXHeaders(cleanAuth, cleanCt0),
            "Content-Type": "application/json",
          },
          body: JSON.stringify(payload),
          signal: controller.signal,
        }).finally(() => clearTimeout(timer));

        captureRotatedCt0(response, cleanAuth);
        lastHttpStatus = response.status;

        const rawText = await response.text();
        let responseData: any = {};
        try {
          responseData = JSON.parse(rawText);
        } catch {
          // Non-JSON response (usually Cloudflare HTML challenge)
        }

        const restId =
          responseData?.data?.create_tweet?.tweet_results?.result?.rest_id ||
          responseData?.data?.create_tweet?.tweet_results?.result?.tweet?.rest_id ||
          responseData?.data?.create_tweet?.tweet_results?.result?.legacy?.id_str;

        if (response.ok && restId) {
          cookieHealth = {
            ...cookieHealth,
            status: "VALID",
            checkedAt: Date.now(),
            message: `Session active${cookieHealth.username ? ` (${cookieHealth.username})` : ""} — dernier tweet publié avec succès.`,
          };
          return {
            success: true,
            mode: "real_x_cookies",
            isDirectPublished: true,
            tweetId: String(restId),
            tweetUrl: `https://x.com/i/web/status/${restId}`,
            intentUrl: webIntentUrl,
            message: `✅ Tweet publié en direct sur X (ID: ${restId}) !`,
            details: responseData,
          };
        }

        const xErr = responseData?.errors?.[0];
        const xErrCode = xErr?.code;
        const xErrMsg = xErr?.message || "";

        if (xErrCode === 187 || xErrMsg.toLowerCase().includes("duplicate")) {
          sawDuplicate = true;
          lastErrorMsg = "Tweet déjà publié récemment (doublon refusé par X).";
          return null;
        }

        if (response.status === 401 || xErrCode === 32 || xErrCode === 64 || xErrCode === 89 || xErrCode === 239) {
          sawAuthError = true;
          lastErrorMsg = xErrMsg || "Cookies X expirés ou invalides (HTTP 401).";
          return null;
        }

        if (response.status === 429) {
          sawRateLimit = true;
          lastErrorMsg = "Limite temporaire de X (HTTP 429). Nouvelle tentative automatique prévue.";
          return null;
        }

        if (response.status === 403 || rawText.includes("cf-browser-verification") || xErrCode === 226) {
          sawCloudflareBlock = true;
          lastErrorMsg =
            xErrMsg ||
            "X/Cloudflare a bloqué la requête depuis cette IP serveur (HTTP 403).";
          return null;
        }

        if (response.status === 404) {
          sawNotFound = true;
          lastErrorMsg = `Endpoint GraphQL obsolète (${queryId})`;
          continue; // Try next queryId
        }

        lastErrorMsg = xErrMsg || `Erreur X (HTTP ${response.status})`;
      } catch (err: any) {
        lastErrorMsg = err?.message || "Erreur réseau vers x.com";
      }
    }
    return null;
  };

  // 1. Try publishing (as thread reply if parent tweet ID exists)
  let result = await attemptCreateTweet(validReplyId);

  // If reply failed for non-auth reasons, retry once as standalone tweet
  if (!result && validReplyId && !sawAuthError && !sawCloudflareBlock && !sawDuplicate) {
    result = await attemptCreateTweet(undefined);
  }

  if (result) return result;

  // 2. Auto-heal: if X rotated GraphQL queryId (HTTP 404), force refresh once and retry immediately!
  if (sawNotFound && !retriedWithFreshIds && !sawAuthError && !sawCloudflareBlock) {
    console.log("[XPublisher] 🔄 QueryId obsolète détecté (404), rafraîchissement automatique depuis x.com...");
    return publishViaCookies(tweetText, cleanAuth, cleanCt0, undefined, true);
  }

  // 3. Optional local Playwright fallback when enabled on PC/VPS
  if (sawCloudflareBlock) {
    const pwRes = await tryPlaywrightPublish(tweetText, cleanAuth, cleanCt0);
    if (pwRes) return pwRes;
  }

  // 4. Update honest cookieHealth state
  if (sawAuthError) {
    cookieHealth = {
      ...cookieHealth,
      status: "EXPIRED",
      checkedAt: Date.now(),
      message: "Cookies expirés ou révoqués par X. Copiez de nouveaux auth_token et ct0.",
    };
    return {
      success: false,
      mode: "cookie_error",
      isDirectPublished: false,
      retryable: false,
      errorCode: "COOKIES_EXPIRED",
      httpStatus: lastHttpStatus,
      intentUrl: webIntentUrl,
      message: `❌ Cookies X expirés ou invalides (${lastErrorMsg}). Remplacez auth_token et ct0 dans Compte X.`,
      error: lastErrorMsg,
    };
  }

  if (sawDuplicate) {
    return {
      success: false,
      mode: "cookie_error",
      isDirectPublished: false,
      retryable: false,
      errorCode: "DUPLICATE_TWEET",
      httpStatus: lastHttpStatus,
      intentUrl: webIntentUrl,
      message: `⚠️ ${lastErrorMsg}`,
      error: lastErrorMsg,
    };
  }

  if (sawRateLimit) {
    return {
      success: false,
      mode: "cookie_error",
      isDirectPublished: false,
      retryable: true,
      errorCode: "RATE_LIMITED",
      httpStatus: 429,
      intentUrl: webIntentUrl,
      message: `⏳ ${lastErrorMsg}`,
      error: lastErrorMsg,
    };
  }

  if (sawCloudflareBlock) {
    cookieHealth = {
      ...cookieHealth,
      status: "IP_BLOCKED",
      checkedAt: Date.now(),
      message:
        "X/Cloudflare bloque les cookies depuis l'IP cloud. Lancez le bot en local (npm run bot) ou avec un proxy/VPS résidentiel.",
    };
    return {
      success: false,
      mode: "cookie_error",
      isDirectPublished: false,
      retryable: true,
      errorCode: "IP_BLOCKED",
      httpStatus: lastHttpStatus || 403,
      intentUrl: webIntentUrl,
      message: `🛡️ ${lastErrorMsg} (Astuce : exécutez "npm run bot" sur votre PC pour contourner le blocage d'IP serveur).`,
      error: lastErrorMsg,
    };
  }

  return {
    success: false,
    mode: "cookie_error",
    isDirectPublished: false,
    retryable: true,
    errorCode: "X_ERROR",
    httpStatus: lastHttpStatus,
    intentUrl: webIntentUrl,
    message: `⚠️ Échec d'envoi vers X (${lastErrorMsg}). Nouvelle tentative automatique prévue.`,
    error: lastErrorMsg,
  };
}

/**
 * HONEST Live Diagnostic & Verification of X Session Cookies (auth_token + ct0).
 * Never fakes "OK" when X rejects the session!
 */
export async function testXCookies(
  authToken?: string,
  ct0?: string
): Promise<{
  success: boolean;
  validFormat: boolean;
  status: "OK" | "INVALID_FORMAT" | "IP_BLOCKED" | "EXPIRED" | "NETWORK_ERROR";
  username?: string;
  displayName?: string;
  httpStatus?: number;
  message: string;
  explanation: string;
  solution: string;
}> {
  const cleanAuthToken = sanitizeCookie(authToken || cachedCredentials.authToken, "auth_token");
  const cleanCt0 = sanitizeCookie(ct0 || cachedCredentials.ct0, "ct0");

  if (!cleanAuthToken || !cleanCt0) {
    cookieHealth = {
      status: "MISSING",
      checkedAt: Date.now(),
      message: "Cookies auth_token et ct0 manquants.",
    };
    return {
      success: false,
      validFormat: false,
      status: "INVALID_FORMAT",
      message: "Cookies X manquants.",
      explanation: "Les deux cookies auth_token et ct0 sont obligatoires pour publier gratuitement sans API X.",
      solution: "Ouvrez x.com > F12 > Application > Cookies > https://x.com et copiez auth_token et ct0.",
    };
  }

  if (cleanAuthToken.length < 20 || cleanCt0.length < 20) {
    return {
      success: false,
      validFormat: false,
      status: "INVALID_FORMAT",
      message: "Format de cookie incomplet.",
      explanation: `auth_token (${cleanAuthToken.length} car.) ou ct0 (${cleanCt0.length} car.) trop court.`,
      solution: "Copiez la valeur entière sans guillemets ni espaces.",
    };
  }

  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 10000);
    const verifyRes = await fetch("https://x.com/i/api/1.1/account/verify_credentials.json?skip_status=true", {
      headers: buildXHeaders(cleanAuthToken, cleanCt0, "https://x.com/home"),
      signal: controller.signal,
    }).finally(() => clearTimeout(timer));

    captureRotatedCt0(verifyRes, cleanAuthToken);
    const text = await verifyRes.text();
    let json: any = {};
    try {
      json = JSON.parse(text);
    } catch {}

    if (verifyRes.ok && (json?.screen_name || json?.id_str)) {
      const username = json.screen_name ? `@${json.screen_name}` : undefined;
      const displayName = json.name || undefined;

      // Save verified username on server
      if (cleanAuthToken === cachedCredentials.authToken) {
        cachedCredentials.username = username;
        cachedCredentials.displayName = displayName;
        writeJsonState(CREDS_STORAGE_KEY, cachedCredentials);
      }

      cookieHealth = {
        status: "VALID",
        username,
        displayName,
        checkedAt: Date.now(),
        message: `Session X vérifiée : ${username || "compte actif"}`,
      };

      return {
        success: true,
        validFormat: true,
        status: "OK",
        username,
        displayName,
        httpStatus: verifyRes.status,
        message: `✅ Session X vérifiée et active (${username || "Connecté"}) !`,
        explanation: "X a confirmé vos cookies de session. La publication automatique (H-1, Buts, Débriefs) est opérationnelle.",
        solution: "Laissez le bot tourner : aucune action supplémentaire nécessaire.",
      };
    }

    if (verifyRes.status === 401 || json?.errors?.[0]?.code === 32 || json?.errors?.[0]?.code === 89) {
      cookieHealth = {
        status: "EXPIRED",
        checkedAt: Date.now(),
        message: "Cookies expirés ou refusés par X (HTTP 401).",
      };
      return {
        success: false,
        validFormat: true,
        status: "EXPIRED",
        httpStatus: verifyRes.status,
        message: "❌ Cookies X expirés ou invalides (HTTP 401).",
        explanation: "X refuse cette session : vous avez peut-être été déconnecté ou le cookie ct0 a changé.",
        solution: "Reconnectez-vous sur x.com, ouvrez F12 > Application > Cookies et collez les nouvelles valeurs auth_token et ct0.",
      };
    }

    if (verifyRes.status === 403 || verifyRes.status === 429 || text.includes("cloudflare")) {
      cookieHealth = {
        status: "IP_BLOCKED",
        checkedAt: Date.now(),
        message: `X/Cloudflare bloque la connexion depuis cette IP serveur (HTTP ${verifyRes.status}).`,
      };
      return {
        success: false,
        validFormat: true,
        status: "IP_BLOCKED",
        httpStatus: verifyRes.status,
        message: `🛡️ IP serveur bloquée par X/Cloudflare (HTTP ${verifyRes.status}).`,
        explanation: "Vos cookies sont au bon format, mais X bloque souvent les IP de datacenters cloud en mode cookies.",
        solution: "Téléchargez le projet (.ZIP) et lancez 'npm run bot' sur votre PC (IP résidentielle) : vos cookies y fonctionneront sans blocage.",
      };
    }

    return {
      success: false,
      validFormat: true,
      status: "NETWORK_ERROR",
      httpStatus: verifyRes.status,
      message: `⚠️ Réponse inattendue de X (HTTP ${verifyRes.status}).`,
      explanation: json?.errors?.[0]?.message || "Impossible de confirmer la session auprès de x.com.",
      solution: "Réessayez dans quelques secondes ou vérifiez vos cookies sur x.com.",
    };
  } catch (err: any) {
    cookieHealth = {
      status: "NETWORK_ERROR",
      checkedAt: Date.now(),
      message: `Erreur réseau lors du test X : ${err?.message || "timeout"}`,
    };
    return {
      success: false,
      validFormat: true,
      status: "NETWORK_ERROR",
      message: `⚠️ Impossible de joindre x.com (${err?.message || "erreur réseau"}).`,
      explanation: "Le serveur n'a pas pu établir la connexion avec x.com.",
      solution: "Vérifiez la connexion réseau du serveur et réessayez.",
    };
  }
}

/**
 * Main Tweet Publisher (100% Cookie-Only — Honest Results, Zero Fake Silent Success)
 */
export async function publishTweetToX(params: PublishTweetParams): Promise<PublishTweetResult> {
  const { tweetText, inReplyToTweetId } = params;
  const webIntentUrl = `https://x.com/intent/tweet?text=${encodeURIComponent(tweetText || "")}`;

  if (!tweetText || tweetText.trim().length === 0) {
    return {
      success: false,
      mode: "cookie_error",
      isDirectPublished: false,
      retryable: false,
      intentUrl: webIntentUrl,
      message: "Le contenu du tweet est vide.",
      error: "Empty tweet text",
    };
  }

  // Only simulate if the user EXPLICITLY selected SIMULATION mode
  if (currentPublishingMode === "SIMULATION") {
    const simTweetId = `sim-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    console.log(`[XPublisher] 🧪 Mode Test/Simulation : "${tweetText.slice(0, 50)}..."`);
    return {
      success: true,
      mode: "simulation",
      isDirectPublished: false,
      tweetId: simTweetId,
      tweetUrl: webIntentUrl,
      intentUrl: webIntentUrl,
      message: "🧪 [Mode Simulation] Tweet généré en test (non envoyé sur X).",
    };
  }

  const authToken = sanitizeCookie(params.authToken || cachedCredentials.authToken, "auth_token");
  const ct0 = sanitizeCookie(params.ct0 || cachedCredentials.ct0, "ct0");

  if (authToken.length < 20 || ct0.length < 20) {
    cookieHealth = {
      status: "MISSING",
      checkedAt: Date.now(),
      message: "Cookies X (auth_token + ct0) manquants.",
    };
    return {
      success: false,
      mode: "cookie_error",
      isDirectPublished: false,
      retryable: false,
      errorCode: "MISSING_COOKIES",
      intentUrl: webIntentUrl,
      message: "❌ Cookies X manquants : ouvrez 'Compte X' et collez auth_token + ct0 pour publier automatiquement.",
      error: "Missing X session cookies",
    };
  }

  // Direct Cookie Publishing
  const result = await publishViaCookies(tweetText, authToken, ct0, inReplyToTweetId);

  if (result.success && result.tweetId) {
    // Background Auto-Like (Main + Boosters) without blocking the response
    likeTweetWithAllAccounts(result.tweetId, {
      authToken,
      ct0,
      booster1AuthToken: params.booster1AuthToken,
      booster1Ct0: params.booster1Ct0,
      booster2AuthToken: params.booster2AuthToken,
      booster2Ct0: params.booster2Ct0,
    }).catch((err) => console.warn("[Multi-Like Background Error]:", err?.message));
  }

  return result;
}
