import * as cheerio from "cheerio";
import crypto from "node:crypto";
import { getEspnDateForOffset, getFormattedDateForOffset, parseMatchDateTime } from "./dateScheduler";
import { fetchEspnFixtures, RealFootballMatch } from "./footballService";
import { generateAutoPronosForLiveFixtures } from "./geminiService";

const URL = "https://www.sportytrader.com/pronostics/football/";

export type ScrapeDataSource = "SPORTYTRADER_LIVE" | "ESPN_LIVE_AI" | "EMPTY";

export interface LiveScrapeResult {
  pronos: SportyTraderProno[];
  source: ScrapeDataSource;
  message: string;
  fetchedAt: number;
}

export type SportyTraderProno = {
  id: string;
  date: string;
  kickoffTime: string;
  competition: "Ligue 1" | "Premier League" | "La Liga" | "Serie A" | string;
  homeTeam: string;
  awayTeam: string;
  prediction: string;
  odds: string;
  probability?: string;
  sourceUrl: string;
  keyReasoning?: string;
  predictedScore?: string;
  confidencePercent?: number;
};

// Allowed leagues - extended to Champions League, Top European Leagues and Cups
const ALLOWED_LEAGUES = [
  "UEFA Champions League",
  "UEFA Europa League",
  "UEFA Conference League",
  "Ligue 1",
  "Premier League",
  "La Liga",
  "Serie A",
  "Bundesliga",
  "Carabao Cup",
];

export function normalizeCompetition(raw: string): string {
  if (!raw) return "Football";
  const lower = raw.replace(/\s+/g, " ").trim().toLowerCase();

  if (lower.includes("championship")) return "Championship";
  if (lower.includes("libertadores")) return "Copa Libertadores";
  if (lower.includes("sudamericana")) return "Copa Sudamericana";
  if (lower.includes("veikkausliiga")) return "Veikkausliiga";

  if (
    (lower.includes("champions") || lower.includes("ldc") || lower.includes("ligue des champions")) &&
    (lower.includes("féminine") || lower.includes("feminine") || lower.includes("women"))
  ) {
    return "Ligue des Champions (F)";
  }
  if (
    (lower.includes("champions") || lower.includes("ldc") || lower.includes("ligue des champions")) &&
    !lower.includes("championship")
  ) {
    return "UEFA Champions League";
  }
  if (lower.includes("conference")) return "UEFA Conference League";
  if (lower.includes("europa") || lower.includes("ligue europa")) return "UEFA Europa League";

  // Bundesliga before Liga
  if (lower.includes("bundesliga 2") || lower.includes("2. bundesliga")) return "2. Bundesliga";
  if (lower.includes("bundesliga")) return "Bundesliga";
  if (lower.includes("dfb pokal") || lower.includes("pokal")) return "DFB Pokal";

  if (lower.includes("ligue 1")) return "Ligue 1";
  if (lower.includes("ligue 2")) return "Ligue 2";
  if (lower.includes("premier league") && !lower.includes("egyptian") && !lower.includes("malte")) return "Premier League";
  if (lower.includes("carabao") || lower.includes("efl cup") || lower.includes("angleterre - carabao")) return "Carabao Cup";
  
  if (lower.includes("laliga 2") || lower.includes("espagne - laliga 2") || lower.includes("segunda")) return "LaLiga 2";
  if (
    (lower.includes("la liga") || lower.includes("espagne - liga") || lower.includes("primera division") || lower.includes("laliga") || lower.includes("liga")) &&
    !lower.includes("bundesliga") &&
    !lower.includes("liga portugal") &&
    !lower.includes("liga mx") &&
    !lower.includes("liga pro") &&
    !lower.includes("chance liga") &&
    !lower.includes("prva liga") &&
    !lower.includes("premier-liha") &&
    !lower.includes("premijer liga")
  ) {
    return "La Liga";
  }
  if (lower.includes("serie a") && !lower.includes("serie b") && !lower.includes("serie c")) return "Serie A";
  if (lower.includes("saudi") || lower.includes("saoudite")) return "Saudi Pro League";
  if (lower.includes("eredivisie") || lower.includes("pays-bas")) return "Eredivisie";
  if (lower.includes("liga portugal") || lower.includes("portugal")) return "Liga Portugal";
  if (lower.includes("chinese super league") || lower.includes("chine")) return "Chinese Super League";
  if (lower.includes("suisse") || lower.includes("super league")) return "Super League";
  if (lower.includes("süper lig") || lower.includes("super lig") || lower.includes("turquie")) return "Süper Lig";
  if (lower.includes("jupiler") || lower.includes("belgique")) return "Jupiler Pro League";
  if (lower.includes("brasileirão") || lower.includes("bresil") || lower.includes("brésil")) return "Brasileirão";
  if (lower.includes("mls") || lower.includes("etats-unis")) return "MLS";
  if (lower.includes("j-league") || lower.includes("japon")) return "J-League";
  if (lower.includes("k-league") || lower.includes("corée")) return "K-League";
  if (lower.includes("scottish") || lower.includes("ecosse") || lower.includes("écosse")) return "Scottish Premiership";
  if (lower.includes("leagues cup")) return "Leagues Cup";
  if (lower.includes("grèce") || lower.includes("greece") || lower.includes("superleague")) return "Superleague Greece";
  if (lower.includes("chance liga") || lower.includes("tchèque")) return "Chance Liga";

  // Clean raw if unknown
  return raw.replace(/^[a-zéûèàA-Z\s]+-\s+/i, "").trim() || "Football";
}

function makeId(data: {
  date?: string;
  competition?: string;
  homeTeam: string;
  awayTeam: string;
  prediction: string;
  odds?: string;
}) {
  return crypto
    .createHash("sha256")
    .update(
      [
        data.date || "",
        data.competition || "",
        data.homeTeam || "",
        data.awayTeam || "",
        data.prediction || "",
        data.odds || "",
      ].join("|")
    )
    .digest("hex")
    .slice(0, 24);
}

/**
 * Normalizes French, English or raw market texts into clear, international English betting terms
 */
export function formatPredictionToEnglish(
  prediction: string,
  homeTeam: string = "",
  awayTeam: string = ""
): string {
  if (!prediction) return `${homeTeam || "Home"} to Win`;
  const p = prediction.trim();
  const pLower = p.toLowerCase();

  // BTTS variations
  if (
    pLower === "btts" ||
    pLower === "btts: yes" ||
    pLower === "both teams to score" ||
    pLower.includes("les deux équipes marquent") ||
    pLower.includes("les 2 équipes marquent") ||
    pLower.includes("les 2 marquent") ||
    pLower.includes("deux équipes marquent")
  ) {
    if (pLower.includes("ne marquent pas") || pLower.includes("non") || pLower.includes("no") || pLower.includes("btts – no") || pLower.includes("btts: no")) {
      return "Both Teams to Score (BTTS - No)";
    }
    if (pLower.includes("ou nul") || pLower.includes("or draw")) {
      return `${homeTeam || "Home"} or Draw & BTTS (Yes)`;
    }
    if (pLower.includes("victoire") || pLower.includes("wins")) {
      const team = (homeTeam && pLower.includes(homeTeam.toLowerCase().slice(0, 4))) ? homeTeam : (awayTeam && pLower.includes(awayTeam.toLowerCase().slice(0, 4))) ? awayTeam : homeTeam || "Home";
      return `${team} to Win & BTTS (Yes)`;
    }
    return "Both Teams to Score (BTTS - Yes)";
  }

  if (pLower.includes("ne marquent pas") || pLower.includes("btts: no") || pLower.includes("btts - no") || pLower.includes("btts – no") || pLower === "btts no") {
    if (pLower.includes("victoire") || pLower.includes("gagne") || pLower.includes("win")) {
      const team = (homeTeam && pLower.includes(homeTeam.toLowerCase().slice(0, 4))) ? homeTeam : (awayTeam && pLower.includes(awayTeam.toLowerCase().slice(0, 4))) ? awayTeam : homeTeam || "Home";
      return `${team} to Win to Nil`;
    }
    return "Both Teams to Score (BTTS - No)";
  }

  // Goalscorer + Win combo
  if (pLower.includes("buteur") && (pLower.includes("victoire") || pLower.includes("gagne"))) {
    const rawPlayer = p.replace(/.*(?:et|avec)\s+/i, "").replace(/\s+buteur.*/i, "").trim();
    const cleanHome = homeTeam.toLowerCase().replace(/[^a-z0-9]/g, "");
    const cleanAway = awayTeam.toLowerCase().replace(/[^a-z0-9]/g, "");
    const cleanP = pLower.replace(/[^a-z0-9]/g, "");
    const team = (cleanHome && cleanP.includes(cleanHome)) ? homeTeam : (cleanAway && cleanP.includes(cleanAway)) ? awayTeam : (homeTeam && pLower.includes(homeTeam.toLowerCase().slice(0, 4))) ? homeTeam : awayTeam || homeTeam || "Team";
    return `${team} to Win & ${rawPlayer || "Star Striker"} to Score`;
  }

  // Goalscorer / Assist bets (e.g. "Kylian Mbappe buteur", "Fermin Lopez buteur", "Raphinha buteur")
  if (pLower.includes("buteur") || pLower.includes("to score") || pLower.includes("goalscorer")) {
    const rawPlayer = p.replace(/\s+(?:buteur|to score|anytime goalscorer)$/i, "").trim();
    return `${rawPlayer || homeTeam || "Striker"} to Score Anytime`;
  }
  if (pLower.includes("passeur") || pLower.includes("assist")) {
    const rawPlayer = p.replace(/\s+(?:passeur décisif|passeur|to provide an assist)$/i, "").trim();
    return `${rawPlayer || homeTeam || "Playmaker"} to Provide an Assist`;
  }

  // HT/FT and Halftime leads
  if (pLower.includes("mi-temps/fin de match") || pLower.includes("ht/ft")) {
    const scorePart = p.replace(/^.*:\s*/i, "").trim();
    return `HT/FT: ${scorePart}`;
  }
  if (pLower.includes("mène à la mi-temps") || pLower.includes("mène à la pause") || pLower.includes("lead at half-time")) {
    const team = (homeTeam && pLower.includes(homeTeam.toLowerCase().slice(0, 4))) ? homeTeam : (awayTeam && pLower.includes(awayTeam.toLowerCase().slice(0, 4))) ? awayTeam : homeTeam || "Favorite";
    return `${team} to Lead at Half-Time`;
  }

  // Complex multiple goalscorers (e.g. Burkardt / Ebnoutalib / Kade marque plus de 1,5 but)
  if (pLower.includes("marque plus de") || pLower.includes("marquent plus de")) {
    const actors = p.replace(/\s+marqu.*$/i, "").replace(/^Le trio\s+/i, "").trim();
    return `${actors} to Score Over 1.5 Goals`;
  }

  // Win by 2+ goals / Handicap
  if (pLower.includes("par 2 buts d'écart") || pLower.includes("2 buts ou plus") || pLower.includes("-1.5 handicap") || pLower.includes("handicap")) {
    const team = (homeTeam && pLower.includes(homeTeam.toLowerCase().slice(0, 4))) ? homeTeam : (awayTeam && pLower.includes(awayTeam.toLowerCase().slice(0, 4))) ? awayTeam : homeTeam || "Favorite";
    return `${team} to Win (-1.5 Handicap)`;
  }

  // Win & Over 3.5 Goals
  if ((pLower.includes("victoire") || pLower.includes("gagne")) && (pLower.includes("plus de 3,5") || pLower.includes("plus de 3.5") || pLower.includes("over 3.5"))) {
    const team = (homeTeam && pLower.includes(homeTeam.toLowerCase().slice(0, 4))) ? homeTeam : (awayTeam && pLower.includes(awayTeam.toLowerCase().slice(0, 4))) ? awayTeam : homeTeam || "Favorite";
    return `${team} to Win & Over 3.5 Goals`;
  }

  // Double chance combos with Over / Under (e.g. "Newcastle ou nul et plus de 2.5 buts", "Nul ou Fribourg et plus de 1,5 but")
  if (pLower.includes("ou nul") || pLower.includes("ne perd pas") || pLower.includes("or draw") || pLower.includes("nul ou")) {
    let team = homeTeam || "Favorite";
    if (pLower.includes("nul ou ")) {
      const candidate = p.replace(/^.*nul ou\s+/i, "").replace(/\s+et\s+.*$/i, "").trim();
      if (candidate) team = candidate;
    } else if (pLower.includes(" ou nul")) {
      const candidate = p.replace(/\s+ou nul.*$/i, "").trim();
      if (candidate) team = candidate;
    } else if (awayTeam && pLower.includes(awayTeam.toLowerCase().slice(0, 4))) {
      team = awayTeam;
    } else if (homeTeam && pLower.includes(homeTeam.toLowerCase().slice(0, 4))) {
      team = homeTeam;
    }

    if (pLower.includes("plus de 2,5") || pLower.includes("plus de 2.5") || pLower.includes("over 2.5")) {
      return `${team} or Draw & Over 2.5 Goals`;
    }
    if (pLower.includes("plus de 1,5") || pLower.includes("plus de 1.5") || pLower.includes("over 1.5")) {
      return `${team} or Draw & Over 1.5 Goals`;
    }
    if (pLower.includes("moins de 2,5") || pLower.includes("moins de 2.5") || pLower.includes("under 2.5")) {
      return `${team} or Draw & Under 2.5 Goals`;
    }
    if (pLower.includes("moins de 3,5") || pLower.includes("moins de 3.5") || pLower.includes("under 3.5")) {
      return `${team} or Draw & Under 3.5 Goals`;
    }

    const isHome = homeTeam && team.toLowerCase().includes(homeTeam.toLowerCase().slice(0, 4));
    return `${team} or Draw (${isHome ? "1X" : "X2"})`;
  }

  // Under / Over combinations
  if (pLower.includes("under 2.5") && (pLower.includes("btts - no") || pLower.includes("btts – no") || pLower.includes("btts: no"))) {
    return "Under 2.5 Goals & BTTS (No)";
  }

  if (pLower.includes("btts & over 2.5") || pLower.includes("btts and over 2.5") || pLower.includes("over 2.5 goals and btts") || pLower.includes("over 2.5 and btts")) {
    return "Over 2.5 Goals & BTTS (Yes)";
  }

  // Win and Over/Under
  if (pLower.includes("wins and over 1.5") || pLower.includes("wins & over 1.5") || pLower.includes("to win & over 1.5")) {
    const team = (awayTeam && pLower.includes(awayTeam.toLowerCase().slice(0, 4))) ? awayTeam : (homeTeam && pLower.includes(homeTeam.toLowerCase().slice(0, 4))) ? homeTeam : homeTeam || "Home";
    return `${team} to Win & Over 1.5 Goals`;
  }
  if (pLower.includes("wins and over 2.5") || pLower.includes("wins & over 2.5") || pLower.includes("to win & over 2.5")) {
    const team = (awayTeam && pLower.includes(awayTeam.toLowerCase().slice(0, 4))) ? awayTeam : (homeTeam && pLower.includes(homeTeam.toLowerCase().slice(0, 4))) ? homeTeam : homeTeam || "Home";
    return `${team} to Win & Over 2.5 Goals`;
  }
  if (pLower.includes("to win & under 2.5") || pLower.includes("wins & under 2.5") || pLower.includes("wins and under 2.5")) {
    const team = (awayTeam && pLower.includes(awayTeam.toLowerCase().slice(0, 4))) ? awayTeam : (homeTeam && pLower.includes(homeTeam.toLowerCase().slice(0, 4))) ? homeTeam : homeTeam || "Home";
    return `${team} to Win & Under 2.5 Goals`;
  }
  if (pLower.includes("to win & under 3.5") || pLower.includes("wins & under 3.5") || pLower.includes("moins de 3.5") || pLower.includes("moins de 3,5")) {
    if (pLower.includes("victoire") || pLower.includes("gagne") || pLower.includes("win")) {
      const team = (homeTeam && pLower.includes(homeTeam.toLowerCase().slice(0, 4))) ? homeTeam : (awayTeam && pLower.includes(awayTeam.toLowerCase().slice(0, 4))) ? awayTeam : homeTeam || "Home";
      return `${team} to Win & Under 3.5 Goals`;
    }
  }

  // Win to nil / Clean sheet
  if (pLower.includes("wins to nil") || pLower.includes("to win to nil") || pLower.includes("wins with a clean sheet") || pLower.includes("clean sheet")) {
    const team = (awayTeam && pLower.includes(awayTeam.toLowerCase().slice(0, 4))) ? awayTeam : (homeTeam && pLower.includes(homeTeam.toLowerCase().slice(0, 4))) ? homeTeam : homeTeam || "Home";
    return `${team} to Win to Nil`;
  }

  // First goal / Halftime bets
  if (pLower.includes("premier but") || pLower.includes("first goal")) {
    const team = (homeTeam && pLower.includes(homeTeam.toLowerCase().slice(0, 4))) ? homeTeam : (awayTeam && pLower.includes(awayTeam.toLowerCase().slice(0, 4))) ? awayTeam : homeTeam || "Home";
    return `${team} to Score 1st Goal`;
  }
  if (pLower.includes("mi-temps") || pLower.includes("half-time") || pLower.includes("halftime")) {
    const team = (homeTeam && pLower.includes(homeTeam.toLowerCase().slice(0, 4))) ? homeTeam : (awayTeam && pLower.includes(awayTeam.toLowerCase().slice(0, 4))) ? awayTeam : homeTeam || "Home";
    return `${team} to Lead at Half-Time`;
  }

  // Goal ranges (e.g. "2-4 match goals", "2-4 goals", "3-6 total goals")
  if (pLower.includes("2-4 match goals") || pLower.includes("2-4 goals") || pLower.includes("2 à 4 buts")) {
    if (homeTeam && pLower.includes(homeTeam.toLowerCase().slice(0, 4))) {
      return `${homeTeam} 2-4 Team Goals`;
    }
    return "2-4 Match Goals";
  }

  // Qualification
  if (pLower.includes("qualifie") || pLower.includes("qualification") || pLower.includes("to qualify")) {
    if (pLower.includes("ol") || (homeTeam && pLower.includes(homeTeam.toLowerCase().slice(0, 4)))) {
      return `${homeTeam || "Home Team"} to Qualify`;
    }
    if (awayTeam && pLower.includes(awayTeam.toLowerCase().slice(0, 4))) {
      return `${awayTeam || "Away Team"} to Qualify`;
    }
    return `${homeTeam || "Team"} to Qualify`;
  }

  // Win & Over/Under combinations in French
  if (pLower.includes("moins de 4,5") || pLower.includes("moins de 4.5") || pLower.includes("under 4.5")) {
    if (pLower.includes("victoire") || pLower.includes("gagne") || pLower.includes("win")) {
      const team = (homeTeam && pLower.includes(homeTeam.toLowerCase().slice(0, 4))) ? homeTeam : (awayTeam && pLower.includes(awayTeam.toLowerCase().slice(0, 4))) ? awayTeam : homeTeam || "Home";
      return `${team} to Win & Under 4.5 Goals`;
    }
    return "Under 4.5 Goals";
  }

  if (pLower.includes("plus de 2,5") || pLower.includes("plus de 2.5") || pLower.includes("over 2.5")) {
    if (pLower.includes("victoire") || pLower.includes("gagne") || pLower.includes("win")) {
      const team = (homeTeam && pLower.includes(homeTeam.toLowerCase().slice(0, 4))) ? homeTeam : (awayTeam && pLower.includes(awayTeam.toLowerCase().slice(0, 4))) ? awayTeam : homeTeam || "Home";
      return `${team} to Win & Over 2.5 Goals`;
    }
    if (pLower.includes("les deux") || pLower.includes("btts")) {
      return "Over 2.5 Goals & BTTS (Yes)";
    }
    return "Over 2.5 Goals";
  }

  if (pLower.includes("plus de 1,5") || pLower.includes("plus de 1.5") || pLower.includes("over 1.5")) {
    if (pLower.includes("nul") || pLower.includes("draw")) {
      const team = (homeTeam && pLower.includes(homeTeam.toLowerCase().slice(0, 4))) ? homeTeam : (awayTeam && pLower.includes(awayTeam.toLowerCase().slice(0, 4))) ? awayTeam : awayTeam || "Favorite";
      return `${team} or Draw & Over 1.5 Goals`;
    }
    return "Over 1.5 Goals";
  }

  // Over / Under goals
  if (pLower.includes("under 2.5") || pLower.includes("-2.5") || pLower.includes("moins de 2.5") || pLower.includes("moins de 2,5")) {
    return "Under 2.5 Goals";
  }
  if (pLower.includes("under 3.5") || pLower.includes("-3.5") || pLower.includes("moins de 3.5") || pLower.includes("moins de 3,5")) {
    return "Under 3.5 Goals";
  }
  if (pLower.includes("over 3.5") || pLower.includes("+3.5") || pLower.includes("plus de 3.5") || pLower.includes("plus de 3,5")) {
    return "Over 3.5 Goals";
  }

  // Double Chance (e.g. "Draw or Brentford", "Aberdeen or Draw", "Draw or Santa Clara")
  if (pLower.includes("or draw") || pLower.includes("draw or") || pLower.includes("ou nul") || pLower.includes("ou n") || pLower.includes("ou match nul") || pLower.includes("nul /") || pLower.includes("nul ou") || pLower.includes("wins or draws")) {
    if (homeTeam && (pLower.includes(homeTeam.toLowerCase().slice(0, 4)) || pLower.includes("home"))) {
      return `${homeTeam} or Draw (1X)`;
    }
    if (awayTeam && (pLower.includes(awayTeam.toLowerCase().slice(0, 4)) || pLower.includes("away"))) {
      return `${awayTeam} or Draw (X2)`;
    }
    if (pLower.includes("brentford")) return "Brentford or Draw (X2)";
    if (pLower.includes("fulham")) return "Fulham or Draw (X2)";
    if (pLower.includes("millwall")) return "Millwall or Draw (X2)";
    if (pLower.includes("santa clara")) return "Santa Clara or Draw (X2)";
    if (pLower.includes("lens")) return "Lens or Draw & Over 1.5 Goals";
    if (pLower.includes("aberdeen")) return "Aberdeen or Draw (1X)";
    if (pLower.includes("dundee")) return "Dundee FC or Draw (1X)";
    return "Double Chance (1X)";
  }

  // Exact team win phrases
  if (p.endsWith(" gagne") || p.endsWith(" wins")) {
    const rawTeam = p.replace(/\s+(?:gagne|wins)$/i, "").trim();
    return `${rawTeam} to Win`;
  }
  if (p.startsWith("Victoire de ") || p.startsWith("Victoire du ") || p.startsWith("Victoire d'")) {
    return `${p.replace(/^Victoire d['eu]\s+/i, "")} to Win`;
  }
  if (p.startsWith("Victoire ")) {
    return `${p.replace(/^Victoire\s+/i, "")} to Win`;
  }

  // 1X2 Win / Handicap
  if (pLower.includes("victoire") || pLower.includes("gagne") || pLower.includes("win") || pLower.endsWith(" wins")) {
    if (pLower.includes("2+ buts") || pLower.includes("2 buts ou plus") || pLower.includes("handicap") || pLower.includes("d'écart")) {
      const team = (homeTeam && pLower.includes(homeTeam.toLowerCase().slice(0, 4))) ? homeTeam : (awayTeam && pLower.includes(awayTeam.toLowerCase().slice(0, 4))) ? awayTeam : homeTeam || "Home";
      return `${team} to Win (-1.5 Handicap)`;
    }
    if (homeTeam && (pLower.includes(homeTeam.toLowerCase().slice(0, 4)) || pLower.startsWith(homeTeam.toLowerCase()))) {
      return `${homeTeam} to Win`;
    }
    if (awayTeam && (pLower.includes(awayTeam.toLowerCase().slice(0, 4)) || pLower.startsWith(awayTeam.toLowerCase()))) {
      return `${awayTeam} to Win`;
    }
    if (pLower.includes("domicile") || p === "1") return `${homeTeam || "Home"} to Win`;
    if (pLower.includes("extérieur") || p === "2") return `${awayTeam || "Away"} to Win`;
  }

  if (pLower === "1" || pLower === "1x") return `${homeTeam || "Home"} to Win`;
  if (pLower === "2" || pLower === "x2") return `${awayTeam || "Away"} to Win`;
  if (pLower === "n" || pLower === "x" || pLower.includes("match nul") || pLower === "nul" || pLower === "draw") return "Match Draw (X)";

  return p;
}

/**
 * Extracts pronos with precision from pasted plain text (copy-pasted directly from SportyTrader website)
 */
export function parseSportyTraderRawText(text: string): SportyTraderProno[] {
  const results: SportyTraderProno[] = [];
  if (!text || text.trim().length === 0) return results;

  // Segment text by date headers (e.g. "5 sept. 2026, 18:00" or "31 août 2026, 21:00" or "30 Aug 2026, 15:00")
  const dateRegex = /(\d{1,2}\s+[a-zA-ZÀ-ÿ.]+\s+\d{4},\s+\d{1,2}[:h]\d{2})/gi;
  const indices: Array<{ index: number; dateStr: string }> = [];
  let match: RegExpExecArray | null;

  while ((match = dateRegex.exec(text)) !== null) {
    indices.push({ index: match.index, dateStr: match[1] });
  }

  // If date pattern segmentation succeeded
  if (indices.length > 0) {
    for (let i = 0; i < indices.length; i++) {
      const start = indices[i].index;
      const end = i < indices.length - 1 ? indices[i + 1].index : text.length;
      const chunk = text.slice(start, end);
      const rawLines = chunk
        .split(/\r?\n/)
        .map((l) => l.trim())
        .filter((l) => l.length > 0 && !l.startsWith("18+") && !l.includes("Annonce publicitaire") && !l.includes("New customers only") && !l.includes("Commercial content") && !l.includes("T&Cs apply") && !l.includes("Inscription gratuite") && !l.includes("bonus : code"));

      if (rawLines.length < 2) continue;

      const dateLine = indices[i].dateStr;
      const timeMatch = dateLine.match(/(\d{1,2}[:h]\d{2})/);
      const kickoffTime = timeMatch ? timeMatch[1].replace("h", ":") : "20:45";
      const date = dateLine.split(",")[0]?.trim() || "Aujourd'hui";

      let competition = "Football";
      let homeTeam = "";
      let awayTeam = "";
      let prediction = "";
      let odds = "1.80";

      for (let j = 1; j < rawLines.length; j++) {
        const line = rawLines[j];
        if (
          competition === "Football" &&
          !line.startsWith("Pronostic") &&
          !line.startsWith("PARIEZ") &&
          !line.startsWith("Probabilité") &&
          !line.startsWith("Cote")
        ) {
          const compCheck = normalizeCompetition(line);
          if (compCheck !== "Football" || line.includes(" - ") || line.includes("Cup")) {
            competition = compCheck !== "Football" ? compCheck : line;
          }
        }

        // Teams separated by "-" line
        if (line === "-" && j > 0 && j < rawLines.length - 1) {
          homeTeam = rawLines[j - 1];
          awayTeam = rawLines[j + 1];
        }

        // Pronostic header line
        if (line.startsWith("Pronostic ") || line.startsWith("Prediction ")) {
          if (rawLines[j + 1] && !rawLines[j + 1].startsWith("Cote") && !rawLines[j + 1].startsWith("PARIEZ") && !rawLines[j + 1].startsWith("En détails") && !rawLines[j + 1].startsWith("Bonus")) {
            prediction = rawLines[j + 1];
          }
          if (!homeTeam || !awayTeam) {
            const vsParts = line.replace(/^(?:Pronostic|Prediction)\s+/i, "").trim().split(/\s+(?:vs|v\.|contre)\s+/i);
            if (vsParts.length === 2) {
              homeTeam = vsParts[0].trim();
              awayTeam = vsParts[1].trim();
            }
          }
        }

        // Odds line
        if ((line === "Cote" || line === "Odds") && rawLines[j + 1]) {
          const val = rawLines[j + 1].replace(",", ".").trim();
          if (/\d+[.,]?\d*/.test(val)) {
            odds = val;
          }
        }

        // 1X2 table pattern
        if (line.startsWith("Probabilité") && j >= 4) {
          // Typically: Team1, Team1, Team2, Team2, 1, X, 2, Probabilité XX%
          const probMatch = line.match(/(\d+)%/);
          const probVal = probMatch ? probMatch[1] : "60";
          if (!homeTeam || !awayTeam) {
            // Find distinct team names in preceding lines
            const candidateTeams: string[] = [];
            for (let k = 1; k < j; k++) {
              const candidate = rawLines[k];
              const isComp =
                candidate.includes(" - ") ||
                candidate.includes("Round") ||
                candidate.includes("Ligue Des Champions") ||
                normalizeCompetition(candidate) !== "Football";
              if (
                candidate.length > 2 &&
                candidate !== "1" &&
                candidate !== "X" &&
                candidate !== "2" &&
                candidate !== "-" &&
                candidate !== competition &&
                !isComp &&
                !candidate.startsWith("Pronostic")
              ) {
                if (!candidateTeams.includes(candidate)) {
                  candidateTeams.push(candidate);
                }
              }
            }
            if (candidateTeams.length >= 2) {
              homeTeam = candidateTeams[0];
              awayTeam = candidateTeams[1];
            }
          }
          // Odds is usually the next line
          if (rawLines[j + 1] && /^[1-9]\d*[.,]?\d*$/.test(rawLines[j + 1].trim())) {
            odds = rawLines[j + 1].replace(",", ".").trim();
          }
          if (!prediction && awayTeam) {
            prediction = `${awayTeam} to Win`;
          }
        }
      }

      // Fallback odds
      if (odds === "1.80") {
        const floatLine = rawLines.find((l) => /^[1-9]\d*[.,]\d{2}$/.test(l.trim()));
        if (floatLine) {
          odds = floatLine.replace(",", ".");
        }
      }

      if (homeTeam && awayTeam && homeTeam !== awayTeam) {
        const cleanComp = normalizeCompetition(competition);
        const englishTip = formatPredictionToEnglish(prediction || `${homeTeam} to Win`, homeTeam, awayTeam);
        const oddNum = parseFloat(odds) || 1.80;
        const confidence = oddNum <= 1.5 ? 88 : oddNum <= 1.8 ? 85 : oddNum <= 2.2 ? 80 : 75;

        const itemData: Omit<SportyTraderProno, "id"> = {
          date,
          kickoffTime,
          competition: cleanComp,
          homeTeam: homeTeam.replace(/\s+/g, " ").trim(),
          awayTeam: awayTeam.replace(/\s+/g, " ").trim(),
          prediction: englishTip,
          odds,
          probability: `${confidence}%`,
          sourceUrl: "https://www.sportytrader.com/pronostics/football/",
          predictedScore: englishTip.toLowerCase().includes("over") || englishTip.toLowerCase().includes("btts") ? "2-1" : "2-0",
          confidencePercent: confidence,
          keyReasoning: `${homeTeam} vs ${awayTeam} (${cleanComp}) - ${englishTip} @${odds}`,
        };

        results.push({
          ...itemData,
          id: makeId(itemData),
        });
      }
    }
  }

  // 1X2 Table Scanner for condensed SportyTrader tables
  const tableRegex = /(\d{1,2}\s+[a-zA-ZÀ-ÿ]+\s+\d{4},\s+\d{1,2}[:h]\d{2})\s+([^\n]+)\s+([^\n]+)\s+\3\s+([^\n]+)\s+\4\s+1\s+X\s+2\s+Probabilit[ée]\s+(\d+)%\s+([0-9.,]+)/gi;
  let tMatch;
  while ((tMatch = tableRegex.exec(text)) !== null) {
    const dateStr = tMatch[1];
    const compStr = tMatch[2];
    const home = tMatch[3];
    const away = tMatch[4];
    const prob = tMatch[5];
    const oddStr = tMatch[6].replace(",", ".");
    const timeMatch = dateStr.match(/(\d{1,2}[:h]\d{2})/);
    const kickoffTime = timeMatch ? timeMatch[1].replace("h", ":") : "18:00";

    const cleanComp = normalizeCompetition(compStr);
    const englishTip = `${home} to Win`;

    const itemData: Omit<SportyTraderProno, "id"> = {
      date: dateStr.split(",")[0]?.trim() || "Aujourd'hui",
      kickoffTime,
      competition: cleanComp,
      homeTeam: home.trim(),
      awayTeam: away.trim(),
      prediction: englishTip,
      odds: oddStr,
      probability: `${prob}%`,
      sourceUrl: "https://www.sportytrader.com/pronostics/football/",
      predictedScore: "2-0",
      confidencePercent: parseInt(prob, 10) || 75,
      keyReasoning: `${home} vs ${away} - Probabilité ${prob}%`,
    };

    results.push({
      ...itemData,
      id: makeId(itemData),
    });
  }

  return [...new Map(results.map((i) => [i.id, i])).values()];
}

/**
 * Universal Parser: Extracts pronos from both DOM HTML and Plain-Text copy-pastes
 */
export function parseSportyTraderInput(content: string): SportyTraderProno[] {
  if (!content || !content.trim()) return [];

  // If HTML tags are detected, try DOM extraction first
  if (content.includes("<div") || content.includes("<a") || content.includes("<p")) {
    const htmlResults = parseSportyTraderHtml(content);
    if (htmlResults.length > 0) return htmlResults;
  }

  // Fallback to robust plain-text extraction
  return parseSportyTraderRawText(content);
}

/**
 * Formats an exact ISO UTC timestamp into Paris date ("18 nov. 2026") & kickoffTime ("18:45").
 */
function parseIsoStartDateToParis(isoStr: string): { date: string; kickoffTime: string } | null {
  const ts = Date.parse(isoStr);
  if (isNaN(ts)) return null;
  const d = new Date(ts);
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: "Europe/Paris",
    year: "numeric",
    month: "numeric",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).formatToParts(d);

  const map: Record<string, string> = {};
  for (const p of parts) map[p.type] = p.value;

  const monthsFr = [
    "janv.",
    "févr.",
    "mars",
    "avr.",
    "mai",
    "juin",
    "juil.",
    "août",
    "sept.",
    "oct.",
    "nov.",
    "déc.",
  ];
  const day = parseInt(map.day || "1", 10);
  const monthIdx = parseInt(map.month || "1", 10) - 1;
  const year = parseInt(map.year || String(d.getUTCFullYear()), 10);
  const rawHour = parseInt(map.hour || "20", 10);
  const hour = rawHour === 24 ? "00" : String(rawHour).padStart(2, "0");
  const minute = String(parseInt(map.minute || "0", 10)).padStart(2, "0");

  return {
    date: `${day} ${monthsFr[monthIdx] || "nov."} ${year}`,
    kickoffTime: `${hour}:${minute}`,
  };
}

/**
 * Estimates a realistic decimal odd when SportyTrader hides bookmaker odds ("Cote 0" on non-FR proxy IPs).
 */
function estimateCalibratedOddFromTip(tip: string): string {
  const lower = (tip || "").toLowerCase();
  if (lower.includes("buteur") || lower.includes("score anytime")) return "2.35";
  if (lower.includes("2 buts d'écart") || lower.includes("handicap") || lower.includes("-1.5")) return "1.95";
  if (lower.includes("cage inviolée") || lower.includes("win to nil")) return "2.15";
  if (lower.includes("ou nul") && (lower.includes("moins") || lower.includes("plus"))) return "1.75";
  if (lower.includes("ou nul") || lower.includes("nul ou")) return "1.52";
  if ((lower.includes("victoire") || lower.includes("gagne")) && (lower.includes("plus de") || lower.includes("moins de"))) {
    return "1.92";
  }
  if (lower.includes("plus de 5.5") || lower.includes("plus de 4.5") || lower.includes("plus de 3.5")) return "2.10";
  if (lower.includes("plus de 2.5") || lower.includes("les deux équipes marquent")) return "1.80";
  if (lower.includes("moins de 2.5")) return "1.85";
  if (lower.includes("match nul") || lower === "nul") return "3.25";
  return "1.78";
}

/**
 * Cleans a raw French SportyTrader prediction without translating native French into English.
 */
function cleanNativeFrenchTip(rawTip: string, homeTeam: string, awayTeam: string): string {
  const clean = (rawTip || "").replace(/\s+/g, " ").trim();
  if (!clean) return `Victoire ${homeTeam}`;
  const lower = clean.toLowerCase();
  if (lower === "1") return `Victoire ${homeTeam}`;
  if (lower === "2") return `Victoire ${awayTeam}`;
  if (lower === "x" || lower === "n") return "Match nul";
  if (lower === "1x") return `${homeTeam} ou Nul`;
  if (lower === "x2") return `${awayTeam} ou Nul`;
  return clean;
}

/**
 * Extracts pronos with precision from HTML using the exact F12 card DOM structure
 * + JSON-LD SportsEvent UTC timestamps for 100% accurate Europe/Paris kickoff times.
 */
export function parseSportyTraderHtml(html: string): SportyTraderProno[] {
  const $ = cheerio.load(html);
  const results: SportyTraderProno[] = [];

  // Build exact URL -> ISO startDate map from JSON-LD SportsEvent blocks embedded by SportyTrader
  const jsonLdStartDates = new Map<string, string>();
  $('script[type="application/ld+json"]').each((_, el) => {
    try {
      const raw = $(el).html();
      if (!raw || !raw.includes("startDate")) return;
      const parsed = JSON.parse(raw);
      const items = Array.isArray(parsed)
        ? parsed
        : Array.isArray(parsed?.["@graph"])
        ? parsed["@graph"]
        : [parsed];
      for (const item of items) {
        const list = Array.isArray(item?.itemListElement) ? item.itemListElement : [item];
        for (const entry of list) {
          const ev = entry?.item || entry;
          if (ev?.url && ev?.startDate) {
            const normalizedUrl = String(ev.url).trim();
            jsonLdStartDates.set(normalizedUrl, String(ev.startDate));
            // Also index by relative path
            try {
              const u = new globalThis.URL(normalizedUrl);
              jsonLdStartDates.set(u.pathname, String(ev.startDate));
            } catch {}
          }
        }
      }
    } catch {
      // Ignore non-event JSON-LD blocks
    }
  });

  // Match each card in the pronostics wrapper
  $("div.card, div[class*='card']").each((_, container) => {
    const card = $(container);

    // 1. League / Competition
    const compText = card.find("p.text-sm, p.dark\\:text-white.text-sm").first().text().replace(/\s+/g, " ").trim();
    const normalizedComp = normalizeCompetition(compText);

    // 2. Teams (Home & Away) from the spans
    let homeTeam = "";
    let awayTeam = "";

    const teamSpans = card.find("a.clickandstop span.font-semibold, a[href*='/pronostics/'] span.font-semibold");
    if (teamSpans.length >= 2) {
      homeTeam = $(teamSpans[0]).text().trim();
      awayTeam = $(teamSpans[1]).text().trim();
    }

    // 3. Source URL
    const navUrl = card.attr("data-navigation-url-value") || card.find("a.clickandstop").attr("href") || "";
    const sourceUrl = navUrl.startsWith("http")
      ? navUrl
      : `https://www.sportytrader.com${navUrl}`;

    if (!homeTeam || !awayTeam || homeTeam === awayTeam) {
      return;
    }

    // 4. Date & Kickoff Time (Prefer exact JSON-LD UTC -> Europe/Paris conversion to avoid proxy timezone shift)
    const exactIso = jsonLdStartDates.get(sourceUrl) || jsonLdStartDates.get(navUrl);
    const parisFromJsonLd = exactIso ? parseIsoStartDateToParis(exactIso) : null;

    const dateText = card.find("p.font-bold, p.dark\\:text-white.font-bold").first().text().replace(/\s+/g, " ").trim();
    const timeMatch = dateText.match(/(\d{1,2}[:h]\d{2})/);
    const kickoffTime = parisFromJsonLd?.kickoffTime || (timeMatch ? timeMatch[1].replace("h", ":") : "20:45");
    const date = parisFromJsonLd?.date || dateText.split(",")[0]?.trim() || "Aujourd'hui";

    // 5. Prediction Text (preserve native French tip cleanly)
    const tipBlock = card.find("div.bg-gray-100, div[class*='bg-gray']").first();
    let rawPrediction = tipBlock.find("p.font-semibold, p.text-left").first().text().trim();
    if (!rawPrediction || rawPrediction.includes("Pronostic")) {
      const allP = tipBlock.find("p");
      if (allP.length > 0) {
        rawPrediction = $(allP[allP.length - 1]).text().trim();
      }
    }

    const prediction = cleanNativeFrenchTip(rawPrediction, homeTeam, awayTeam);

    // 6. Odds / Cote (Reject geo-hidden "0" values and fall back to calibrated decimal odd)
    let odds = "";
    const oddSpan = tipBlock.find("span.tabular-nums, span.font-bold, [class*='tabular-nums']").first().text().trim();
    const oddMatch = oddSpan.match(/\d+[.,]\d{1,2}/) || oddSpan.match(/\d+/);
    if (oddMatch) {
      const parsedOdd = parseFloat(oddMatch[0].replace(",", "."));
      if (!isNaN(parsedOdd) && parsedOdd >= 1.05 && parsedOdd <= 30) {
        odds = parsedOdd.toFixed(2);
      }
    }
    if (!odds) {
      odds = estimateCalibratedOddFromTip(prediction);
    }

    // 7. Confidence estimation
    const oddsNum = parseFloat(odds) || 1.8;
    const confidence = oddsNum <= 1.5 ? 88 : oddsNum <= 1.8 ? 85 : oddsNum <= 2.2 ? 80 : 75;

    const itemData: Omit<SportyTraderProno, "id"> = {
      date,
      kickoffTime,
      competition: normalizedComp,
      homeTeam,
      awayTeam,
      prediction,
      odds,
      probability: `${confidence}%`,
      sourceUrl,
      predictedScore: prediction.toLowerCase().includes(homeTeam.toLowerCase()) ? "2-1" : "1-2",
      confidencePercent: confidence,
      keyReasoning: `Pronostic officiel SportyTrader : ${homeTeam} vs ${awayTeam} (${prediction}).`,
    };

    results.push({
      ...itemData,
      id: makeId(itemData),
    });
  });

  // If DOM matched items, return them
  if (results.length > 0) {
    return [...new Map(results.map((item) => [item.id, item])).values()];
  }

  // Otherwise fallback to text parser on the HTML string
  return parseSportyTraderRawText(html);
}

/**
 * Legacy helper kept empty so no stale/hardcoded September matches ever enter the live pipeline.
 */
export function getVerifiedTop4LeaguesPronos(): SportyTraderProno[] {
  return [];
}

/**
 * Formats an ESPN timestamp into our standard French date format ("18 nov. 2026") in Europe/Paris timezone.
 */
function formatTimestampToParisDateFr(timestamp: number): string {
  const d = new Date(timestamp);
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: "Europe/Paris",
    year: "numeric",
    month: "numeric",
    day: "numeric",
  }).formatToParts(d);
  const map: Record<string, number> = {};
  for (const p of parts) map[p.type] = parseInt(p.value, 10);

  const monthsFr = [
    "janv.",
    "févr.",
    "mars",
    "avr.",
    "mai",
    "juin",
    "juil.",
    "août",
    "sept.",
    "oct.",
    "nov.",
    "déc.",
  ];
  const day = map.day || d.getDate();
  const monthIdx = (map.month || d.getMonth() + 1) - 1;
  const year = map.year || d.getFullYear();
  return `${day} ${monthsFr[monthIdx] || "nov."} ${year}`;
}

/**
 * Real Live Fallback: fetches genuine official fixtures for Today, Tomorrow, and Day+2 from ESPN
 * and generates calibrated AI pronostics (NEVER fake or hardcoded fixtures).
 */
async function fetchRealEspnFixturesAsPronos(): Promise<SportyTraderProno[]> {
  const allMatches: RealFootballMatch[] = [];

  // Query default active matchweek scoreboard (no dates param -> catches upcoming weekend PL/L1/LaLiga/SerieA)
  // plus today & tomorrow explicitly
  const batches = await Promise.all([
    fetchEspnFixtures().catch(() => []),
    fetchEspnFixtures(getEspnDateForOffset(0)).catch(() => []),
    fetchEspnFixtures(getEspnDateForOffset(1)).catch(() => []),
  ]);

  const seenIds = new Set<string>();
  for (const batch of batches) {
    for (const m of batch) {
      if (m.status === "FINISHED") continue;
      const dedupeKey = `${m.homeTeam.toLowerCase()}_${m.awayTeam.toLowerCase()}`;
      if (seenIds.has(dedupeKey)) continue;
      seenIds.add(dedupeKey);
      allMatches.push(m);
    }
  }

  if (allMatches.length === 0) {
    return [];
  }

  allMatches.sort((a, b) => a.kickoffTimestamp - b.kickoffTimestamp);

  const aiPronosMap = await generateAutoPronosForLiveFixtures(allMatches);

  const pronos: SportyTraderProno[] = [];
  for (const m of allMatches) {
    const ai = aiPronosMap.get(m.id);
    const formattedDate = isNaN(m.kickoffTimestamp)
      ? getFormattedDateForOffset(0)
      : formatTimestampToParisDateFr(m.kickoffTimestamp);

    const competition = normalizeCompetition(m.league);
    const prediction = ai?.prediction || `Victoire ${m.homeTeam}`;
    const odds = ai?.odds || m.odds.home || "1.85";
    const confidence = ai?.confidencePercent || 78;

    const itemData: Omit<SportyTraderProno, "id"> = {
      date: formattedDate,
      kickoffTime: m.kickoffTime || "21:00",
      competition,
      homeTeam: m.homeTeam,
      awayTeam: m.awayTeam,
      prediction,
      odds,
      probability: `${confidence}%`,
      sourceUrl: `https://www.sportytrader.com/pronostics/football/`,
      predictedScore: ai?.predictedScore || "2-1",
      confidencePercent: confidence,
      keyReasoning: ai?.keyReasoning || `Analyse officielle en direct pour ${m.homeTeam} vs ${m.awayTeam}.`,
    };

    pronos.push({
      ...itemData,
      id: makeId(itemData),
    });
  }

  return pronos;
}

/**
 * Helper to fetch live SportyTrader HTML directly first, then transparently via Jina HTML reader
 * if Cloudflare returns 403 on cloud/datacenter IPs.
 */
async function fetchSportyTraderLiveHtml(): Promise<{ html: string; viaProxy: boolean } | null> {
  // 1a. Direct fetch (works natively from residential EU/FR PCs with real French bookmaker odds)
  try {
    const response = await fetch(URL, {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        Accept:
          "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
        "Accept-Language": "fr-FR,fr;q=0.9,en-US;q=0.8,en;q=0.7",
        "Cache-Control": "no-cache",
      },
      signal: AbortSignal.timeout(7000),
    });

    if (response.ok) {
      const html = await response.text();
      if (html.length > 5000 && html.includes("/pronostics/")) {
        return { html, viaProxy: false };
      }
    } else {
      console.warn(`[SportyTrader Direct] HTTP ${response.status} — tentative via lecteur HTML Cloudflare-bypass...`);
    }
  } catch (err: any) {
    console.warn("[SportyTrader Direct] Erreur réseau — tentative via lecteur HTML :", err?.message || err);
  }

  // 1b. Cloudflare-bypass HTML fetch via r.jina.ai (returns full rendered SportyTrader DOM + JSON-LD UTC timestamps)
  try {
    const jinaRes = await fetch(`https://r.jina.ai/${URL}`, {
      headers: {
        "X-Return-Format": "html",
        Accept: "text/html",
        "Accept-Language": "fr-FR,fr;q=0.9",
      },
      signal: AbortSignal.timeout(12000),
    });
    if (jinaRes.ok) {
      const html = await jinaRes.text();
      if (html.length > 5000 && html.includes("/pronostics/")) {
        return { html, viaProxy: true };
      }
    }
  } catch (err: any) {
    console.warn("[SportyTrader Jina Fallback] Indisponible :", err?.message || err);
  }

  return null;
}

/**
 * Fetches REAL live predictions:
 * 1. Scrapes live SportyTrader HTML (direct first, then Cloudflare-bypass HTML reader with JSON-LD Paris times).
 * 2. If SportyTrader has 0 valid upcoming fixtures, falls back to REAL ESPN official fixtures + AI pronostics.
 * 3. NEVER fabricates hardcoded/fake matches.
 */
export async function scrapeSportyTraderWithSource(): Promise<LiveScrapeResult> {
  const fetchedAt = Date.now();

  // 1. Live SportyTrader Scrape (Direct or Cloudflare-bypass HTML)
  try {
    const fetched = await fetchSportyTraderLiveHtml();
    if (fetched?.html) {
      const parsed = parseSportyTraderHtml(fetched.html);
      const validLive = parsed.filter((p) => {
        const timing = parseMatchDateTime(p.date, p.kickoffTime);
        return timing.totalDiffMinutes > -120 && timing.totalDiffMinutes < 60 * 24 * 6;
      });

      if (validLive.length > 0) {
        const modeTag = fetched.viaProxy ? "SportyTrader Live (via relais anti-Cloudflare)" : "SportyTrader Direct";
        console.log(`[LiveScraper] ✅ ${modeTag} : ${validLive.length} vrais pronostics récupérés.`);
        return {
          pronos: validLive,
          source: "SPORTYTRADER_LIVE",
          message: `${validLive.length} vrais pronostics récupérés en direct sur SportyTrader.`,
          fetchedAt,
        };
      }
    }
  } catch (error: any) {
    console.warn("[SportyTrader Scraper] Bascule sur ESPN Live + IA :", error?.message || error);
  }

  // 2. Real Live Fallback: Official ESPN Fixtures + AI Pronostics
  try {
    const espnPronos = await fetchRealEspnFixturesAsPronos();
    if (espnPronos.length > 0) {
      console.log(`[LiveScraper] ✅ Calendrier Officiel ESPN + IA : ${espnPronos.length} vrais matchs synchronisés.`);
      return {
        pronos: espnPronos,
        source: "ESPN_LIVE_AI",
        message: `${espnPronos.length} vrais matchs officiels synchronisés en direct (ESPN + Analyse IA).`,
        fetchedAt,
      };
    }
  } catch (err: any) {
    console.warn("[ESPN Live Fallback Error]:", err?.message || err);
  }

  return {
    pronos: [],
    source: "EMPTY",
    message: "Aucun match officiel à venir détecté pour le moment.",
    fetchedAt,
  };
}

export async function scrapeSportyTrader(): Promise<SportyTraderProno[]> {
  const res = await scrapeSportyTraderWithSource();
  return res.pronos;
}
