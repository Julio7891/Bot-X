export interface RealFootballMatch {
  id: string;
  league: string;
  leagueFlag?: string;
  leagueId?: string;
  homeTeam: string;
  awayTeam: string;
  homeLogo: string;
  awayLogo: string;
  homeLogoUrl?: string;
  awayLogoUrl?: string;
  kickoffTime: string;
  kickoffDate: string;
  kickoffTimestamp: number;
  stadium?: string;
  liveMinute?: string;
  matchClock?: string;
  odds: {
    home: string;
    draw: string;
    away: string;
    over25?: string;
    under25?: string;
    bttsYes?: string;
    bttsNo?: string;
    dnbHome?: string;
    dnbAway?: string;
  };
  formHome: string;
  formAway: string;
  keyStat?: string;
  sourceApi: "ESPN" | "Football-Data" | "API-Football" | "TheSportsDB" | "Gemini-AI";
  status: "UPCOMING" | "READY_FOR_PRONO" | "PRONO_PUBLISHED" | "LIVE" | "FINISHED" | "RECAP_PUBLISHED";
  actualScore?: {
    home: number;
    away: number;
  };
  goalScorers?: string[];
}

function parseOddsToDecimal(val: any, fallback: number): string {
  if (val === undefined || val === null || val === "") return fallback.toFixed(2);
  const str = String(val).trim();
  const num = parseFloat(str);
  if (isNaN(num)) return fallback.toFixed(2);

  // If American odds format (e.g. +140, -175)
  if (str.startsWith("+") || num > 30) {
    const dec = (num / 100) + 1;
    return Number(dec.toFixed(2)).toString();
  }
  if (str.startsWith("-") || num < -30) {
    const dec = (100 / Math.abs(num)) + 1;
    return Number(dec.toFixed(2)).toString();
  }
  
  // If already decimal format
  if (num >= 1.05 && num <= 30) {
    return Number(num.toFixed(2)).toString();
  }

  return fallback.toFixed(2);
}

// European Team Elo / Power Ratings for smart odds calculation
const TEAM_RATINGS: Record<string, { rating: number; attack: number; defense: number }> = {
  "real madrid": { rating: 92, attack: 94, defense: 88 },
  "manchester city": { rating: 93, attack: 95, defense: 89 },
  "paris saint-germain": { rating: 89, attack: 90, defense: 86 },
  "psg": { rating: 89, attack: 90, defense: 86 },
  "bayern munich": { rating: 90, attack: 92, defense: 87 },
  "arsenal": { rating: 90, attack: 89, defense: 92 },
  "liverpool": { rating: 91, attack: 93, defense: 88 },
  "barcelona": { rating: 89, attack: 92, defense: 85 },
  "inter milan": { rating: 88, attack: 88, defense: 90 },
  "bayer leverkusen": { rating: 87, attack: 89, defense: 86 },
  "atletico madrid": { rating: 86, attack: 86, defense: 88 },
  "juventus": { rating: 85, attack: 84, defense: 87 },
  "ac milan": { rating: 84, attack: 86, defense: 82 },
  "borussia dortmund": { rating: 85, attack: 87, defense: 82 },
  "chelsea": { rating: 84, attack: 86, defense: 81 },
  "tottenham": { rating: 84, attack: 87, defense: 80 },
  "manchester united": { rating: 83, attack: 83, defense: 81 },
  "aston villa": { rating: 84, attack: 85, defense: 82 },
  "newcastle": { rating: 83, attack: 85, defense: 82 },
  "olympique de marseille": { rating: 82, attack: 85, defense: 78 },
  "om": { rating: 82, attack: 85, defense: 78 },
  "monaco": { rating: 83, attack: 86, defense: 80 },
  "as monaco": { rating: 83, attack: 86, defense: 80 },
  "olympique lyonnais": { rating: 80, attack: 82, defense: 77 },
  "lyon": { rating: 80, attack: 82, defense: 77 },
  "lille": { rating: 82, attack: 83, defense: 82 },
  "losc": { rating: 82, attack: 83, defense: 82 },
  "lens": { rating: 79, attack: 78, defense: 81 },
  "rc lens": { rating: 79, attack: 78, defense: 81 },
  "rennes": { rating: 78, attack: 80, defense: 76 },
  "nice": { rating: 80, attack: 80, defense: 81 },
  "brest": { rating: 79, attack: 80, defense: 78 },
  "strasbourg": { rating: 76, attack: 78, defense: 74 },
  "nantes": { rating: 75, attack: 74, defense: 76 },
  "toulouse": { rating: 76, attack: 76, defense: 75 },
  "reims": { rating: 77, attack: 79, defense: 75 },
  "auxerre": { rating: 74, attack: 75, defense: 72 },
  "saint-étienne": { rating: 73, attack: 72, defense: 73 },
  "angers": { rating: 72, attack: 71, defense: 72 },
  "le havre": { rating: 72, attack: 70, defense: 73 },
  "montpellier": { rating: 73, attack: 76, defense: 69 },
};

function getTeamRating(name: string) {
  const clean = name.toLowerCase().trim();
  for (const [key, val] of Object.entries(TEAM_RATINGS)) {
    if (clean.includes(key) || key.includes(clean)) return val;
  }
  return { rating: 76, attack: 76, defense: 75 };
}

function calculateCalibratedOdds(homeTeam: string, awayTeam: string, rawOdds?: any) {
  const homeInfo = getTeamRating(homeTeam);
  const awayInfo = getTeamRating(awayTeam);

  // If raw odds exist from API, parse them safely
  let homeDec = 2.10;
  let drawDec = 3.40;
  let awayDec = 3.20;

  if (rawOdds?.homeTeamOdds?.moneyLine || rawOdds?.awayTeamOdds?.moneyLine) {
    homeDec = parseFloat(parseOddsToDecimal(rawOdds.homeTeamOdds?.moneyLine, 2.10));
    drawDec = parseFloat(parseOddsToDecimal(rawOdds.drawOdds?.moneyLine, 3.40));
    awayDec = parseFloat(parseOddsToDecimal(rawOdds.awayTeamOdds?.moneyLine, 3.20));
  } else {
    // Calculate from team rating difference (+3 home advantage)
    const diff = (homeInfo.rating + 3) - awayInfo.rating;
    const homeWinProb = 1 / (1 + Math.pow(10, -diff / 22));
    const awayWinProb = 1 / (1 + Math.pow(10, diff / 22));
    const drawProb = Math.max(0.18, 0.32 - Math.abs(diff) * 0.008);
    const totalProb = homeWinProb + awayWinProb + drawProb;
    const margin = 1.06;

    homeDec = Math.max(1.15, Math.min(12.5, Number(((1 / (homeWinProb / totalProb)) / margin).toFixed(2))));
    drawDec = Math.max(2.80, Math.min(8.0, Number(((1 / (drawProb / totalProb)) / margin).toFixed(2))));
    awayDec = Math.max(1.20, Math.min(15.0, Number(((1 / (awayWinProb / totalProb)) / margin).toFixed(2))));
  }

  // Realistic Over/Under & BTTS calculation
  const totalAtt = (homeInfo.attack + awayInfo.attack) / 2;
  const isHighScoring = totalAtt > 84;
  const over25 = isHighScoring ? "1.65" : "1.88";
  const under25 = isHighScoring ? "2.20" : "1.92";
  const bttsYes = totalAtt > 82 ? "1.70" : "1.85";
  const bttsNo = totalAtt > 82 ? "2.10" : "1.92";
  const dnbHome = String(Math.max(1.15, Number((homeDec * (1 - 1 / drawDec)).toFixed(2))));
  const dnbAway = String(Math.max(1.18, Number((awayDec * (1 - 1 / drawDec)).toFixed(2))));

  return {
    home: String(homeDec),
    draw: String(drawDec),
    away: String(awayDec),
    over25,
    under25,
    bttsYes,
    bttsNo,
    dnbHome,
    dnbAway,
  };
}

const ESPN_LEAGUES: { slug: string; name: string; flag: string }[] = [
  { slug: "uefa.champions", name: "UEFA Champions League", flag: "🏆" },
  { slug: "uefa.wchampions", name: "Ligue des Champions (F)", flag: "🏆" },
  { slug: "uefa.europa", name: "UEFA Europa League", flag: "🌍" },
  { slug: "uefa.europa.conf", name: "UEFA Conference League", flag: "🌟" },
  { slug: "uefa.nations", name: "UEFA Nations League", flag: "🇪🇺" },
  { slug: "eng.1", name: "Premier League", flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿" },
  { slug: "fra.1", name: "Ligue 1", flag: "🇫🇷" },
  { slug: "esp.1", name: "La Liga", flag: "🇪🇸" },
  { slug: "ita.1", name: "Serie A", flag: "🇮🇹" },
  { slug: "ger.1", name: "Bundesliga", flag: "🇩🇪" },
  { slug: "por.1", name: "Liga Portugal", flag: "🇵🇹" },
  { slug: "ned.1", name: "Eredivisie", flag: "🇳🇱" },
  { slug: "eng.2", name: "Championship", flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿" },
  { slug: "fra.2", name: "Ligue 2", flag: "🇫🇷" },
  { slug: "eng.fa", name: "FA Cup", flag: "🏆" },
  { slug: "eng.league_cup", name: "Carabao Cup", flag: "🏆" },
  { slug: "fra.coupe_de_france", name: "Coupe de France", flag: "🇫🇷" },
  { slug: "esp.copa_del_rey", name: "Copa del Rey", flag: "🇪🇸" },
  { slug: "fifa.worldq.uefa", name: "Qualifs Coupe du Monde (UEFA)", flag: "🌍" },
  { slug: "fifa.worldq.conmebol", name: "Qualifs Coupe du Monde (CONMEBOL)", flag: "🌎" },
  { slug: "fifa.friendly", name: "Match International", flag: "🌍" },
  { slug: "bra.1", name: "Brasileirão", flag: "🇧🇷" },
  { slug: "usa.1", name: "MLS", flag: "🇺🇸" },
];

/**
 * Fetch real live football fixtures from ESPN public scoreboards (batched in parallel with strict timeout)
 */
export async function fetchEspnFixtures(dateStr?: string): Promise<RealFootballMatch[]> {
  const allMatches: RealFootballMatch[] = [];

  for (let i = 0; i < ESPN_LEAGUES.length; i += 6) {
    const batch = ESPN_LEAGUES.slice(i, i + 6);
    await Promise.all(
      batch.map(async (league) => {
        try {
          const url = `https://site.api.espn.com/apis/site/v2/sports/soccer/${league.slug}/scoreboard${dateStr ? `?dates=${dateStr}` : ""}`;
          const response = await fetch(url, {
            headers: {
              "User-Agent": "Mozilla/5.0 (compatible; FootballBot/1.0)",
              Accept: "application/json",
            },
            signal: AbortSignal.timeout(4500),
          });

          if (!response.ok) return;

          const data = await response.json();
          if (!data.events || !Array.isArray(data.events)) return;

          for (const event of data.events) {
        const competition = event.competitions?.[0];
        if (!competition) continue;

        const competitors = competition.competitors || [];
        const homeComp = competitors.find((c: any) => c.homeAway === "home") || competitors[0];
        const awayComp = competitors.find((c: any) => c.homeAway === "away") || competitors[1];

        if (!homeComp || !awayComp) continue;

        const homeTeam = homeComp.team?.displayName || homeComp.team?.name || "Équipe 1";
        const awayTeam = awayComp.team?.displayName || awayComp.team?.name || "Équipe 2";
        const homeLogoUrl = homeComp.team?.logo || "";
        const awayLogoUrl = awayComp.team?.logo || "";

        const kickoffDateRaw = new Date(event.date || competition.date || Date.now());
        const kickoffTimestamp = kickoffDateRaw.getTime();
        
        // Format time in Paris/Europe time
        const timeOptions: Intl.DateTimeFormatOptions = {
          hour: "2-digit",
          minute: "2-digit",
          hour12: false,
          timeZone: "Europe/Paris",
        };
        const kickoffTime = isNaN(kickoffTimestamp) 
          ? "21:00" 
          : new Intl.DateTimeFormat("fr-FR", timeOptions).format(kickoffDateRaw);

        const dateOptions: Intl.DateTimeFormatOptions = {
          weekday: "short",
          day: "numeric",
          month: "short",
          timeZone: "Europe/Paris",
        };
        const isToday = new Date().toDateString() === kickoffDateRaw.toDateString();
        const kickoffDate = isToday 
          ? "Aujourd'hui" 
          : new Intl.DateTimeFormat("fr-FR", dateOptions).format(kickoffDateRaw);

        // Status mapping
        const statusType = event.status?.type?.name || "";
        const now = Date.now();
        const diffMs = kickoffTimestamp - now;
        const diffMinutes = Math.floor(diffMs / (1000 * 60));

        let status: RealFootballMatch["status"] = "UPCOMING";
        let liveMinute: string | undefined = undefined;

        if (statusType === "STATUS_FINAL" || statusType === "STATUS_FULL_TIME" || event.status?.type?.completed) {
          status = "FINISHED";
          liveMinute = "FT";
        } else if (
          statusType === "STATUS_IN_PROGRESS" ||
          statusType === "STATUS_FIRST_HALF" ||
          statusType === "STATUS_SECOND_HALF" ||
          statusType === "STATUS_HALFTIME"
        ) {
          status = "LIVE";
          liveMinute = event.status?.displayClock ? `${event.status.displayClock}` : "En direct";
        } else {
          // If scheduled and within 75 minutes of kickoff, mark ready for prono
          if (diffMinutes <= 75 && diffMinutes >= -10) {
            status = "READY_FOR_PRONO";
          } else {
            status = "UPCOMING";
          }
        }

        // Score
        let actualScore: { home: number; away: number } | undefined = undefined;
        if (homeComp.score !== undefined && awayComp.score !== undefined && (status === "LIVE" || status === "FINISHED")) {
          actualScore = {
            home: parseInt(homeComp.score, 10) || 0,
            away: parseInt(awayComp.score, 10) || 0,
          };
        }

        // Odds extraction or realistic fallback with accurate decimal conversion & team calibration
        const odds = calculateCalibratedOdds(homeTeam, awayTeam, competition.odds?.[0]);

        // Goal scorers extraction if available
        const goalScorers: string[] = [];
        if (competition.details && Array.isArray(competition.details)) {
          for (const d of competition.details) {
            if (d.type?.text?.toLowerCase().includes("goal") && d.participants?.[0]?.athlete?.displayName) {
              goalScorers.push(`${d.participants[0].athlete.displayName} (${d.clock?.displayValue || ""})`);
            }
          }
        }

        allMatches.push({
          id: `espn-${event.id || Math.random().toString(36).substring(7)}`,
          league: league.name,
          leagueFlag: league.flag,
          leagueId: league.slug,
          homeTeam,
          awayTeam,
          homeLogo: homeTeam.substring(0, 3).toUpperCase(),
          awayLogo: awayTeam.substring(0, 3).toUpperCase(),
          homeLogoUrl,
          awayLogoUrl,
          kickoffTime,
          kickoffDate,
          kickoffTimestamp,
          stadium: competition.venue?.fullName || undefined,
          liveMinute,
          matchClock: event.status?.displayClock,
          odds,
          formHome: homeComp.form || "V-V-N-V-D",
          formAway: awayComp.form || "V-N-V-D-V",
          sourceApi: "ESPN",
          status,
          actualScore,
          goalScorers: goalScorers.length > 0 ? goalScorers : undefined,
        });
      }
        } catch (err) {
          console.warn(`[ESPN API] Error fetching ${league.slug}:`, err);
        }
      })
    );
  }

  return allMatches;
}

/**
 * Fetch from Football-Data.org API if token provided
 */
export async function fetchFootballDataOrg(apiKey: string): Promise<RealFootballMatch[]> {
  try {
    const url = "https://api.football-data.org/v4/matches";
    const res = await fetch(url, {
      headers: { "X-Auth-Token": apiKey },
    });
    if (!res.ok) throw new Error(`Football-Data error: ${res.statusText}`);
    const data = await res.json();
    if (!data.matches) return [];

    return data.matches.map((m: any) => {
      const kickoffTimestamp = new Date(m.utcDate).getTime();
      const kickoffDateRaw = new Date(m.utcDate);
      const timeOptions: Intl.DateTimeFormatOptions = {
        hour: "2-digit",
        minute: "2-digit",
        hour12: false,
        timeZone: "Europe/Paris",
      };
      const kickoffTime = new Intl.DateTimeFormat("fr-FR", timeOptions).format(kickoffDateRaw);

      let status: RealFootballMatch["status"] = "UPCOMING";
      if (m.status === "FINISHED") status = "FINISHED";
      else if (m.status === "IN_PLAY" || m.status === "PAUSED") status = "LIVE";
      else {
        const diffMinutes = Math.floor((kickoffTimestamp - Date.now()) / 60000);
        if (diffMinutes <= 75 && diffMinutes >= -10) status = "READY_FOR_PRONO";
      }

      return {
        id: `fd-${m.id}`,
        league: m.competition?.name || "Football",
        leagueFlag: "⚽",
        homeTeam: m.homeTeam?.name || "Home",
        awayTeam: m.awayTeam?.name || "Away",
        homeLogo: m.homeTeam?.tla || "HOM",
        awayLogo: m.awayTeam?.tla || "AWY",
        homeLogoUrl: m.homeTeam?.crest,
        awayLogoUrl: m.awayTeam?.crest,
        kickoffTime,
        kickoffDate: "Aujourd'hui",
        kickoffTimestamp,
        odds: calculateCalibratedOdds(m.homeTeam?.name || "Home", m.awayTeam?.name || "Away"),
        formHome: "V-V-N-V-D",
        formAway: "V-N-V-D-V",
        sourceApi: "Football-Data" as const,
        status,
        actualScore: m.score?.fullTime?.home !== null ? {
          home: m.score.fullTime.home,
          away: m.score.fullTime.away,
        } : undefined,
      };
    });
  } catch (e) {
    console.error("[Football-Data] fetch error:", e);
    return [];
  }
}

/**
 * Fetch from API-Football / API-Sports (Direct & RapidAPI)
 * Covers UEFA Champions League (League ID 2), Ligue 1 (61), Premier League (39), La Liga (140), Serie A (135)
 */
export async function fetchApiFootballFixtures(apiKey: string): Promise<RealFootballMatch[]> {
  try {
    const today = new Date().toISOString().split("T")[0];
    const isRapidApiKey = apiKey.length > 40 || !/^[a-f0-9]{32}$/i.test(apiKey);

    const headers: Record<string, string> = isRapidApiKey
      ? {
          "x-rapidapi-key": apiKey,
          "x-rapidapi-host": "v3.football.api-sports.io",
        }
      : {
          "x-apisports-key": apiKey,
        };

    const targetLeagues = [2, 3, 61, 39, 140, 135, 78]; // 2 = UCL, 3 = Europa, 61 = L1, 39 = PL, 140 = LaLiga
    const matches: RealFootballMatch[] = [];

    const url = `https://v3.football.api-sports.io/fixtures?date=${today}`;
    const res = await fetch(url, { headers });
    if (!res.ok) {
      console.warn(`[API-Football] Request status ${res.status}: ${res.statusText}`);
      return [];
    }

    const json = await res.json();
    if (!json.response || !Array.isArray(json.response)) return [];

    for (const item of json.response) {
      const leagueId = item.league?.id;
      const isTarget = targetLeagues.includes(leagueId);
      if (!isTarget && json.response.length > 20) continue;

      const f = item.fixture;
      const teams = item.teams;
      const goals = item.goals;
      const kickoffTimestamp = f.timestamp ? f.timestamp * 1000 : new Date(f.date).getTime();
      const kickoffDateRaw = new Date(kickoffTimestamp);

      const timeOptions: Intl.DateTimeFormatOptions = {
        hour: "2-digit",
        minute: "2-digit",
        hour12: false,
        timeZone: "Europe/Paris",
      };
      const kickoffTime = new Intl.DateTimeFormat("fr-FR", timeOptions).format(kickoffDateRaw);

      let status: RealFootballMatch["status"] = "UPCOMING";
      const shortStatus = f.status?.short;
      if (["FT", "AET", "PEN"].includes(shortStatus)) {
        status = "FINISHED";
      } else if (["1H", "2H", "HT", "ET", "P", "LIVE"].includes(shortStatus)) {
        status = "LIVE";
      } else {
        const diffMinutes = Math.floor((kickoffTimestamp - Date.now()) / 60000);
        if (diffMinutes <= 75 && diffMinutes >= -10) status = "READY_FOR_PRONO";
      }

      const leagueName = item.league?.name || "UEFA Champions League";
      const flag = leagueId === 2 ? "🏆" : leagueId === 61 ? "🇫🇷" : leagueId === 39 ? "🏴󠁧󠁢󠁥󠁮󠁧󠁿" : "⚽";

      matches.push({
        id: `apifb-${f.id}`,
        league: leagueName,
        leagueFlag: flag,
        homeTeam: teams.home?.name || "Home",
        awayTeam: teams.away?.name || "Away",
        homeLogo: teams.home?.name?.substring(0, 3).toUpperCase() || "HOM",
        awayLogo: teams.away?.name?.substring(0, 3).toUpperCase() || "AWY",
        homeLogoUrl: teams.home?.logo,
        awayLogoUrl: teams.away?.logo,
        kickoffTime,
        kickoffDate: "Aujourd'hui",
        kickoffTimestamp,
        stadium: f.venue?.name,
        liveMinute: f.status?.elapsed ? `${f.status.elapsed}'` : undefined,
        odds: calculateCalibratedOdds(teams.home?.name || "Home", teams.away?.name || "Away"),
        formHome: "V-V-N-V-D",
        formAway: "V-N-V-D-V",
        sourceApi: "API-Football" as const,
        status,
        actualScore: goals.home !== null ? {
          home: goals.home,
          away: goals.away,
        } : undefined,
      });
    }

    return matches;
  } catch (e) {
    console.error("[API-Football] Fetch error:", e);
    return [];
  }
}

