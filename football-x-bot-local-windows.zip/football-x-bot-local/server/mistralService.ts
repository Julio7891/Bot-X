/**
 * Mistral AI Service for Football Predictions & Recaps
 * Connects directly to Mistral AI endpoint with multi-model fallback and JSON enforcement
 */

const DEFAULT_MISTRAL_KEY = "F8E2yH0nLTy8bFlIIspcH7CnVRuQRZhG";

const MISTRAL_MODELS = [
  "mistral-large-latest",
  "mistral-small-latest",
  "open-mistral-nemo",
  "codestral-latest",
];

export function getMistralApiKey(): string {
  return process.env.MISTRAL_API_KEY || DEFAULT_MISTRAL_KEY;
}

/**
 * Execute chat completion via Mistral AI with JSON mode and multi-model fallback
 */
export async function executeMistralWithFallback(prompt: string, systemPrompt?: string): Promise<string> {
  const apiKey = getMistralApiKey();
  let lastError: any = null;

  const defaultSystem = `Tu es l'analyste de football data-driven et expert en value betting le plus pointu d'Europe (spécialiste Ligue 1, Premier League, La Liga, Serie A, Champions League). Tu rédiges des analyses tactiques percutantes et des tweets prêts à publier. Tu réponds TOUJOURS en JSON valide.`;

  for (const modelName of MISTRAL_MODELS) {
    for (let attempt = 1; attempt <= 2; attempt++) {
      try {
        const response = await fetch("https://api.mistral.ai/v1/chat/completions", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${apiKey}`,
            "Accept": "application/json",
          },
          body: JSON.stringify({
            model: modelName,
            messages: [
              {
                role: "system",
                content: systemPrompt || defaultSystem,
              },
              {
                role: "user",
                content: prompt,
              },
            ],
            response_format: { type: "json_object" },
            temperature: 0.65,
          }),
        });

        if (!response.ok) {
          const errBody = await response.text().catch(() => "");
          throw new Error(`Mistral API error (${modelName} status ${response.status}): ${errBody.slice(0, 150)}`);
        }

        const data = (await response.json()) as any;
        const content = data?.choices?.[0]?.message?.content;

        if (content && typeof content === "string") {
          return content.trim();
        }
      } catch (err: any) {
        lastError = err;
        console.warn(`[Mistral AI] Attempt ${attempt} on ${modelName} failed:`, err?.message || err);
        // Wait slightly before retry
        await new Promise((r) => setTimeout(r, 250 * attempt));
      }
    }
  }

  throw lastError || new Error("Mistral AI service unavailable across all models");
}

/**
 * Safely parse JSON from LLM responses even if wrapped in codeblocks
 */
export function cleanAndParseJson<T = any>(rawText: string): T {
  let cleaned = rawText.trim();
  if (cleaned.startsWith("```json")) {
    cleaned = cleaned.replace(/^```json\s*/, "").replace(/\s*```$/, "");
  } else if (cleaned.startsWith("```")) {
    cleaned = cleaned.replace(/^```\s*/, "").replace(/\s*```$/, "");
  }
  return JSON.parse(cleaned);
}
