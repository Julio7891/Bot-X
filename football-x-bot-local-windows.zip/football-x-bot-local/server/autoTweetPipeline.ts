import {
  scrapeSportyTraderWithSource,
  parseSportyTraderInput,
  SportyTraderProno,
  ScrapeDataSource,
} from "./sportytraderScraper";
import {
  fetchLiveScoresForLeagues,
  findMatchScore,
  setManualMatchScore,
  LiveScoreResult,
  LiveScoreGoalEvent,
  matchesTeam,
} from "./liveScoreChecker";
import { updateServerXCredentials } from "./xPublisher";
import {
  enqueueTweet,
  registerQueueCallbacks,
  clearFailedHistory,
} from "./tweetQueue";
import {
  isMatchDueForH1,
  isMatchInThePast,
  parseMatchDateTime,
  isExpiredOldMatch,
  getFormattedDateForOffset,
  getMinutesBetweenMatches,
  getParisNow,
} from "./dateScheduler";
import { readJsonState, writeJsonState } from "./botStorage";

// Storage file names inside ./data/ (with automatic migration from legacy dotfiles)
const TRACKED_PREDS_KEY = "tracked_predictions.json";
const BOT_STATE_KEY = "bot_state.json";
const BOT_LOGS_KEY = "bot_activity_logs.json";
const HANDLED_EVENTS_KEY = "handled_events.json";
const MANAGED_PRONOS_KEY = "managed_pronos.json";
const MANAGED_TWEETS_KEY = "managed_tweets.json";

const ANTI_COLLISION_WINDOW_MINUTES = 75;

export interface BotLogEntry {
  id: string;
  timestamp: number;
  type: "SCRAPE" | "SELECTION" | "SCHEDULE" | "PUBLISH" | "GOAL" | "FT" | "LIKE" | "ERROR" | "INFO";
  title: string;
  message: string;
  badge?: string;
  metadata?: any;
}

export interface BotState {
  isAutoPilotEnabled: boolean;
  isAutoGoalAlertsEnabled: boolean;
  autoLikeEnabled: boolean;
  slotCollisionMode: "ANTI_COLLISION" | "PUBLISH_ALL";
  lastAutoRunTimestamp: number;
  totalGoalsTweeted: number;
  totalLikesPerformed: number;
  lastSyncSource?: ScrapeDataSource;
  lastSyncMessage?: string;
  lastSyncDateParis?: string;
  lastDailyRecapDateParis?: string;
}

export interface GoalAlertRecord {
  homeScore: number;
  awayScore: number;
  scorer?: string;
  minute?: string;
  tweetId?: string;
  tweetText?: string;
  publishedAt: number;
}

export interface ScheduledTweetRecord {
  id: string;
  pronoId: string;
  matchTitle: string;
  homeTeam: string;
  awayTeam: string;
  competition: string;
  date: string;
  kickoffTime: string;
  type: "PRONO_H1" | "GOAL_LIVE" | "RECAP_FT" | "MORNING_ROADMAP" | "DAILY_RECAP";
  tweetText: string;
  scheduledTimeLabel: string;
  status: "SCHEDULED" | "READY" | "PUBLISHED" | "ERROR";
  createdAt: number;
  publishedAt?: number;
  odd?: string;
  prediction: string;
  isWon?: boolean;
  scoreHome?: number;
  scoreAway?: number;
  autoLiked?: boolean;
}

export interface TrackedMatchPrediction {
  id: string;
  homeTeam: string;
  awayTeam: string;
  competition: string;
  date: string;
  kickoffTime: string;
  prediction: string;
  odd: string;
  status:
    | "SCHEDULED"
    | "PUBLISHED"
    | "LIVE"
    | "DEBRIEF_SENT"
    | "SKIPPED_SLOT_DUPLICATE"
    | "FAILED_PUBLISH";
  publishError?: string;
  isQueued?: boolean;
  publishedAt?: number;
  publishedTweetId?: string;
  publishedTweetText?: string;
  finalScore?: string;
  isWon?: boolean;
  scoreHome?: number;
  scoreAway?: number;
  lastLiveMinute?: string;
  isAutoSelectedSlot?: boolean;
  slotKey?: string;
  slotSelectionReason?: string;
  goalAlertsSent?: GoalAlertRecord[];
  debriefTweetSent?: boolean;
  debriefTweetText?: string;
  debriefTweetId?: string;
  debriefPublishedAt?: number;
}

function makeMatchKey(homeTeam: string, awayTeam: string): string {
  return `${homeTeam.trim().toLowerCase()}_vs_${awayTeam.trim().toLowerCase()}`;
}

function findTrackedByIdOrKey(matchIdOrKey: string): TrackedMatchPrediction | undefined {
  if (!matchIdOrKey) return undefined;
  const direct = trackedPredictionsMap.get(matchIdOrKey);
  if (direct) return direct;
  const lower = matchIdOrKey.trim().toLowerCase();
  for (const [k, pred] of trackedPredictionsMap.entries()) {
    if (
      pred.id === matchIdOrKey ||
      k === lower ||
      `${pred.homeTeam}_${pred.awayTeam}`.toLowerCase() === lower
    ) {
      return pred;
    }
  }
  return undefined;
}

function loadStoredManagedPronos(): SportyTraderProno[] {
  const list = readJsonState<SportyTraderProno[]>(MANAGED_PRONOS_KEY, []);
  return Array.isArray(list) ? list.filter((p) => p && !isExpiredOldMatch(p.date, p.kickoffTime)) : [];
}

function persistManagedPronos() {
  writeJsonState(MANAGED_PRONOS_KEY, latestManagedPronos);
}

function loadStoredManagedTweets(): ScheduledTweetRecord[] {
  const list = readJsonState<ScheduledTweetRecord[]>(MANAGED_TWEETS_KEY, []);
  return Array.isArray(list) ? list.slice(0, 150) : [];
}

function persistManagedTweets() {
  writeJsonState(MANAGED_TWEETS_KEY, allManagedTweets.slice(0, 150));
}

function loadStoredLogs(): BotLogEntry[] {
  const list = readJsonState<BotLogEntry[]>(BOT_LOGS_KEY, []);
  return Array.isArray(list) ? list.slice(0, 200) : [];
}

function persistLogs() {
  writeJsonState(BOT_LOGS_KEY, botLogs.slice(0, 200));
}

let botLogs: BotLogEntry[] = loadStoredLogs();

export function addBotLog(
  type: BotLogEntry["type"],
  title: string,
  message: string,
  badge?: string,
  metadata?: any
): BotLogEntry {
  const entry: BotLogEntry = {
    id: `log-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    timestamp: Date.now(),
    type,
    title,
    message,
    badge,
    metadata,
  };
  botLogs.unshift(entry);
  if (botLogs.length > 200) botLogs.pop();
  persistLogs();
  console.log(`[Bot Log] [${type}] ${title} - ${message}`);
  return entry;
}

export function getBotLogs(limit = 100): BotLogEntry[] {
  return botLogs.slice(0, limit);
}

export function clearBotLogs() {
  botLogs = [];
  persistLogs();
}

function loadStoredBotState(): BotState {
  const parsed = readJsonState<Partial<BotState>>(BOT_STATE_KEY, {});
  return {
    isAutoPilotEnabled: parsed.isAutoPilotEnabled !== undefined ? parsed.isAutoPilotEnabled : true,
    isAutoGoalAlertsEnabled: parsed.isAutoGoalAlertsEnabled !== undefined ? parsed.isAutoGoalAlertsEnabled : true,
    autoLikeEnabled: parsed.autoLikeEnabled !== undefined ? parsed.autoLikeEnabled : true,
    slotCollisionMode: parsed.slotCollisionMode === "PUBLISH_ALL" ? "PUBLISH_ALL" : "ANTI_COLLISION",
    lastAutoRunTimestamp: parsed.lastAutoRunTimestamp || Date.now(),
    totalGoalsTweeted: parsed.totalGoalsTweeted || 0,
    totalLikesPerformed: parsed.totalLikesPerformed || 0,
    lastSyncSource: parsed.lastSyncSource,
    lastSyncMessage: parsed.lastSyncMessage,
    lastSyncDateParis: parsed.lastSyncDateParis,
    lastDailyRecapDateParis: parsed.lastDailyRecapDateParis,
  };
}

let botState: BotState = loadStoredBotState();

function persistBotState() {
  writeJsonState(BOT_STATE_KEY, botState);
}

export function getBotState(): BotState {
  return { ...botState };
}

export function setAutoPilotEnabled(enabled: boolean): BotState {
  botState.isAutoPilotEnabled = enabled;
  persistBotState();
  addBotLog(
    "INFO",
    enabled ? "🤖 Auto-Pilote Activé" : "⏸️ Auto-Pilote en Pause",
    enabled
      ? "Surveillance active : scraping auto, publication H-1h sans superposition, alertes buts live et débriefs FT."
      : "Le bot est mis en pause par l'utilisateur."
  );
  return { ...botState };
}

export function setSlotCollisionMode(mode: "ANTI_COLLISION" | "PUBLISH_ALL"): BotState {
  botState.slotCollisionMode = mode;
  persistBotState();
  applySmartSlotArbitration();
  addBotLog(
    "INFO",
    mode === "PUBLISH_ALL"
      ? "⚡ Mode Tout Publier Activé"
      : "👑 Mode Anti-Collision Strict (75 min) Activé",
    mode === "PUBLISH_ALL"
      ? "Tous les matchs à venir sont programmés (espacés par la file d'attente 60s)."
      : "Arbitrage strict actif : 1 seul match par fenêtre de 75 min avec priorité Premier League."
  );
  return { ...botState };
}

export function getSlotCollisionMode(): "ANTI_COLLISION" | "PUBLISH_ALL" {
  return botState.slotCollisionMode || "ANTI_COLLISION";
}

export function setAutoGoalAlertsEnabled(enabled: boolean) {
  botState.isAutoGoalAlertsEnabled = enabled;
  persistBotState();
}

export function isAutoGoalAlertsEnabled(): boolean {
  return botState.isAutoGoalAlertsEnabled;
}

export function isAutoPilotEnabled(): boolean {
  return botState.isAutoPilotEnabled;
}

function loadStoredTrackedPredictions(): Map<string, TrackedMatchPrediction> {
  const map = new Map<string, TrackedMatchPrediction>();
  const list = readJsonState<TrackedMatchPrediction[]>(TRACKED_PREDS_KEY, []);
  if (Array.isArray(list)) {
    for (const item of list) {
      if (item && item.homeTeam && item.awayTeam && !isExpiredOldMatch(item.date, item.kickoffTime)) {
        const key = makeMatchKey(item.homeTeam, item.awayTeam);
        // Reset stuck isQueued flags after server restart
        item.isQueued = false;
        map.set(key, item);
      }
    }
  }
  return map;
}

function persistTrackedPredictions() {
  const list = Array.from(trackedPredictionsMap.values());
  writeJsonState(TRACKED_PREDS_KEY, list);
}

// Runtime in-memory state (NO fake hardcoded September seeding!)
const discoveredPronoIds = new Set<string>();
const allManagedTweets: ScheduledTweetRecord[] = loadStoredManagedTweets();
let latestManagedPronos: SportyTraderProno[] = loadStoredManagedPronos();
const trackedPredictionsMap = loadStoredTrackedPredictions();

const finishedMatchesHandled = new Set<string>();
const goalEventsHandled = new Set<string>(); // key: matchId_scoreHome_scoreAway
const previousScoresMap = new Map<string, { scoreHome: number; scoreAway: number }>();

{
  const data = readJsonState<{
    finishedMatches?: string[];
    goalEvents?: string[];
    previousScores?: Array<{ id: string; scoreHome: number; scoreAway: number }>;
  }>(HANDLED_EVENTS_KEY, {});

  if (Array.isArray(data.finishedMatches)) {
    for (const id of data.finishedMatches) finishedMatchesHandled.add(id);
  }
  if (Array.isArray(data.goalEvents)) {
    for (const k of data.goalEvents) goalEventsHandled.add(k);
  }
  if (Array.isArray(data.previousScores)) {
    for (const s of data.previousScores) {
      if (s && s.id) {
        previousScoresMap.set(s.id, { scoreHome: s.scoreHome, scoreAway: s.scoreAway });
      }
    }
  }
}

function persistHandledEvents() {
  writeJsonState(HANDLED_EVENTS_KEY, {
    finishedMatches: Array.from(finishedMatchesHandled).slice(-200),
    goalEvents: Array.from(goalEventsHandled).slice(-300),
    previousScores: Array.from(previousScoresMap.entries())
      .slice(-100)
      .map(([id, val]) => ({
        id,
        scoreHome: val.scoreHome,
        scoreAway: val.scoreAway,
      })),
  });
}

// Register Queue Event Callbacks — ONLY mark PUBLISHED / DEBRIEF_SENT / goalAlertsSent when X actually succeeds!
registerQueueCallbacks({
  onSuccess: (item, result) => {
    const pronoId = item.metadata?.pronoId;
    let foundPred: TrackedMatchPrediction | undefined;
    if (pronoId) {
      foundPred = findTrackedByIdOrKey(pronoId);
    }
    if (!foundPred && item.matchTitle) {
      const titleClean = item.matchTitle.toLowerCase();
      foundPred = Array.from(trackedPredictionsMap.values()).find(
        (p) =>
          titleClean.includes(p.homeTeam.toLowerCase()) &&
          titleClean.includes(p.awayTeam.toLowerCase())
      );
    }

    if (foundPred) {
      if (item.type === "RECAP_FT") {
        foundPred.status = "DEBRIEF_SENT";
        foundPred.debriefTweetSent = true;
        foundPred.debriefTweetId = result.tweetId;
        foundPred.debriefTweetText = item.tweetText;
        foundPred.debriefPublishedAt = item.publishedAt || Date.now();
        finishedMatchesHandled.add(foundPred.id);
        persistHandledEvents();
      } else if (item.type === "GOAL_LIVE") {
        if (foundPred.status !== "DEBRIEF_SENT") {
          foundPred.status = "LIVE";
        }
        const hScore = item.metadata?.scoreHome ?? foundPred.scoreHome ?? 0;
        const aScore = item.metadata?.scoreAway ?? foundPred.scoreAway ?? 0;
        if (!Array.isArray(foundPred.goalAlertsSent)) {
          foundPred.goalAlertsSent = [];
        }
        const alreadyRecorded = foundPred.goalAlertsSent.some(
          (g) => g.homeScore === hScore && g.awayScore === aScore
        );
        if (!alreadyRecorded) {
          foundPred.goalAlertsSent.push({
            homeScore: hScore,
            awayScore: aScore,
            scorer: item.metadata?.scorerName,
            minute: item.metadata?.minuteText,
            tweetId: result.tweetId,
            tweetText: item.tweetText,
            publishedAt: item.publishedAt || Date.now(),
          });
        }
        botState.totalGoalsTweeted += 1;
        if (typeof result.details?.likesCount === "number") {
          botState.totalLikesPerformed += result.details.likesCount;
        }
        persistBotState();
      } else if (item.type === "PRONO_H1" && foundPred.status !== "DEBRIEF_SENT") {
        foundPred.status = "PUBLISHED";
        foundPred.publishedAt = item.publishedAt || Date.now();
        foundPred.publishedTweetId = result.tweetId;
        foundPred.publishedTweetText = item.tweetText;
        if (typeof result.details?.likesCount === "number") {
          botState.totalLikesPerformed += result.details.likesCount;
          persistBotState();
        }
      }

      foundPred.isQueued = false;
      foundPred.publishError = undefined;
      persistTrackedPredictions();
    }

    // Update allManagedTweets record
    const managedTweet = allManagedTweets.find(
      (t) =>
        (pronoId && t.pronoId === pronoId && t.type === item.type) ||
        t.tweetText === item.tweetText
    );
    if (managedTweet) {
      managedTweet.status = "PUBLISHED";
      managedTweet.publishedAt = item.publishedAt || Date.now();
      if (result.tweetId) {
        managedTweet.id = result.tweetId;
      }
      persistManagedTweets();
    }

    addBotLog(
      item.type === "GOAL_LIVE" ? "GOAL" : item.type === "RECAP_FT" ? "FT" : "PUBLISH",
      `🚀 Tweet publié (${item.type}) : ${item.matchTitle || "Match"}`,
      `${result.message}${result.tweetId ? ` [ID: ${result.tweetId}]` : ""}`,
      result.mode === "simulation" ? "Simulation" : "Publié sur X"
    );
  },
  onFailure: (item, result) => {
    const pronoId = item.metadata?.pronoId;
    let foundPred: TrackedMatchPrediction | undefined;
    if (pronoId) {
      foundPred = findTrackedByIdOrKey(pronoId);
    }
    if (!foundPred && item.matchTitle) {
      const titleClean = item.matchTitle.toLowerCase();
      foundPred = Array.from(trackedPredictionsMap.values()).find(
        (p) =>
          titleClean.includes(p.homeTeam.toLowerCase()) &&
          titleClean.includes(p.awayTeam.toLowerCase())
      );
    }

    if (foundPred) {
      foundPred.isQueued = false;
      foundPred.publishError = result.message;

      if (item.type === "PRONO_H1") {
        foundPred.status = "FAILED_PUBLISH";
      } else if (item.type === "RECAP_FT") {
        // Keep debrief unsent so it can be retried once cookies are fixed!
        foundPred.debriefTweetSent = false;
        finishedMatchesHandled.delete(foundPred.id);
        if (foundPred.status === "DEBRIEF_SENT") {
          foundPred.status = "LIVE";
        }
        persistHandledEvents();
      }
      persistTrackedPredictions();
    }

    const managedTweet = allManagedTweets.find(
      (t) =>
        (pronoId && t.pronoId === pronoId && t.type === item.type) ||
        t.tweetText === item.tweetText
    );
    if (managedTweet) {
      managedTweet.status = "ERROR";
      persistManagedTweets();
    }

    addBotLog(
      "ERROR",
      `⚠️ Échec publication (${item.type}) : ${item.matchTitle || "Match"}`,
      result.message || "Erreur lors de l'envoi vers X",
      result.errorCode || "Échec X"
    );
  },
});

/**
 * Unlocks matches that previously failed to publish (e.g., before valid cookies were entered)
 * so the auto-pilot automatically retries them.
 */
export function unlockFailedUpcomingMatchesForRetry(): number {
  let unlocked = 0;
  clearFailedHistory();
  for (const pred of trackedPredictionsMap.values()) {
    if (pred.status === "FAILED_PUBLISH") {
      const timing = parseMatchDateTime(pred.date, pred.kickoffTime);
      if (!timing.isMatchFinished) {
        pred.status = timing.isPastKickoff ? "LIVE" : "SCHEDULED";
        pred.isQueued = false;
        pred.publishError = undefined;
        unlocked++;
      }
    } else if (pred.publishError && !pred.debriefTweetSent) {
      pred.publishError = undefined;
      pred.isQueued = false;
      unlocked++;
    }
  }
  if (unlocked > 0) {
    applySmartSlotArbitration();
    persistTrackedPredictions();
    addBotLog(
      "INFO",
      `🔓 ${unlocked} match(s) débloqué(s) pour republication`,
      "Les nouveaux cookies X sont actifs : les matchs en échec ont été réintégrés dans la file automatique.",
      `${unlocked} Débloqués`
    );
  }
  return unlocked;
}

/**
 * Reset Tonight's Matches for Re-publishing
 */
export function resetTonightMatchesForRetry(): {
  resetCount: number;
  message: string;
} {
  let resetCount = 0;
  clearFailedHistory();

  for (const pred of trackedPredictionsMap.values()) {
    const timing = parseMatchDateTime(pred.date, pred.kickoffTime);
    if (timing.isToday && !timing.isMatchFinished && pred.status !== "SKIPPED_SLOT_DUPLICATE") {
      pred.status = "SCHEDULED";
      pred.isQueued = false;
      pred.publishError = undefined;
      pred.publishedAt = undefined;
      pred.publishedTweetId = undefined;
      resetCount++;
    }
  }

  for (const t of allManagedTweets) {
    if (t.status === "ERROR") {
      t.status = "SCHEDULED";
    }
  }

  persistTrackedPredictions();
  persistManagedTweets();
  const arbitration = applySmartSlotArbitration();

  addBotLog(
    "INFO",
    `🔄 Matchs du jour réinitialisés (${resetCount})`,
    `Créneaux ouverts et prêts (Arbitrage : ${arbitration.retainedMatchesCount} créneaux retenus sans superposition).`,
    "Reset Jour"
  );

  return {
    resetCount,
    message: `${resetCount} match(s) du jour réinitialisé(s) et prêts pour publication.`,
  };
}

/**
 * Enqueue all retained (non-duplicate) upcoming matches of today immediately into TweetQueue.
 */
export function forceEnqueueAllTonightMatches(): {
  enqueuedCount: number;
  matches: string[];
} {
  let enqueuedCount = 0;
  const enqueuedMatches: string[] = [];

  for (const pred of trackedPredictionsMap.values()) {
    if (pred.status !== "SCHEDULED" || pred.isQueued) continue;
    const timing = parseMatchDateTime(pred.date, pred.kickoffTime);
    if (timing.isToday && !timing.isPastKickoff) {
      const h1Text =
        pred.publishedTweetText ||
        generateH1TweetText({
          id: pred.id,
          homeTeam: pred.homeTeam,
          awayTeam: pred.awayTeam,
          competition: pred.competition,
          date: pred.date,
          kickoffTime: pred.kickoffTime,
          prediction: pred.prediction,
          odds: pred.odd,
          sourceUrl: "https://www.sportytrader.com/pronostics/football/",
        });
      const queued = enqueueTweet({
        tweetText: h1Text,
        type: "PRONO_H1",
        matchTitle: `${pred.homeTeam} vs ${pred.awayTeam}`,
        priority: "HIGH",
        metadata: {
          pronoId: pred.id,
          date: pred.date,
          kickoffTime: pred.kickoffTime,
        },
      });

      if (queued) {
        pred.isQueued = true;
        pred.publishedTweetText = h1Text;
        enqueuedCount++;
        enqueuedMatches.push(`${pred.homeTeam} vs ${pred.awayTeam} (${pred.kickoffTime})`);
      }
    }
  }

  persistTrackedPredictions();
  addBotLog(
    "PUBLISH",
    `⚡ ${enqueuedCount} match(s) du jour ajouté(s) à la file d'attente`,
    enqueuedCount > 0
      ? `File anti-spam alimentée (${enqueuedMatches.join(", ")}). Espacement 60s garanti.`
      : "Aucun match du jour à venir en statut PROGRAMMÉ à enfiler.",
    "Envoi Forcé"
  );

  return {
    enqueuedCount,
    matches: enqueuedMatches,
  };
}

/**
 * Purges ONLY genuinely expired old matches (> 18h past kickoff) and re-applies slot arbitration.
 * NEVER injects fake static matches and NEVER deletes active live/upcoming matches!
 */
export function autoPurgeOldMatchesAndSyncFresh(): {
  purgedCount: number;
  remainingTrackedCount: number;
  newMatchesAdded: number;
} {
  let purgedCount = 0;

  for (const [key, pred] of trackedPredictionsMap.entries()) {
    if (isExpiredOldMatch(pred.date, pred.kickoffTime)) {
      trackedPredictionsMap.delete(key);
      finishedMatchesHandled.delete(pred.id);
      previousScoresMap.delete(pred.id);
      purgedCount++;
    }
  }

  latestManagedPronos = latestManagedPronos.filter(
    (p) => !isExpiredOldMatch(p.date, p.kickoffTime)
  );

  const freshTweets = allManagedTweets.filter(
    (t) => !isExpiredOldMatch(t.date, t.kickoffTime)
  );
  allManagedTweets.length = 0;
  allManagedTweets.push(...freshTweets);

  if (trackedPredictionsMap.size > 0) {
    applySmartSlotArbitration();
  }

  persistTrackedPredictions();
  persistManagedPronos();
  persistManagedTweets();
  persistHandledEvents();

  if (purgedCount > 0) {
    addBotLog(
      "INFO",
      `🧹 Nettoyage automatique (${purgedCount} ancien(s) match(s) purgé(s))`,
      `Il reste ${trackedPredictionsMap.size} match(s) actif(s) ou à venir.`,
      `${trackedPredictionsMap.size} Actifs`
    );
  }

  return {
    purgedCount,
    remainingTrackedCount: trackedPredictionsMap.size,
    newMatchesAdded: 0,
  };
}

/**
 * Repairs any match predictions that were incorrectly marked DEBRIEF_SENT
 * without an actual debrief tweet having been confirmed.
 */
export function repairCorruptedDebriefStatuses(): number {
  let repairedCount = 0;
  for (const pred of trackedPredictionsMap.values()) {
    if (pred.status === "DEBRIEF_SENT" && !pred.debriefTweetSent) {
      pred.status = isMatchInThePast(pred.date, pred.kickoffTime) ? "LIVE" : "SCHEDULED";
      repairedCount++;
    }
  }
  for (const id of Array.from(finishedMatchesHandled)) {
    const pred = findTrackedByIdOrKey(id);
    if (pred && !pred.debriefTweetSent) {
      finishedMatchesHandled.delete(id);
    }
  }
  if (repairedCount > 0) {
    persistTrackedPredictions();
    persistHandledEvents();
  }
  return repairedCount;
}

// Clean up any expired matches & corrupted debriefs on module boot
try {
  autoPurgeOldMatchesAndSyncFresh();
  repairCorruptedDebriefStatuses();
} catch (bootErr) {
  console.warn("[AutoTweetPipeline] Boot cleanup warning:", bootErr);
}

/**
 * Registers or updates a prediction in the tracking system without clobbering active statuses.
 */
export function registerTrackedPrediction(pred: {
  id?: string;
  homeTeam: string;
  awayTeam: string;
  competition?: string;
  date?: string;
  kickoffTime?: string;
  prediction: string;
  odd?: string;
  status?: "SCHEDULED" | "PUBLISHED" | "LIVE" | "DEBRIEF_SENT";
  publishedAt?: number;
  publishedTweetId?: string;
  publishedTweetText?: string;
}): TrackedMatchPrediction {
  const key = makeMatchKey(pred.homeTeam, pred.awayTeam);
  const id = pred.id || `pred-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;

  const existing = trackedPredictionsMap.get(key);
  const preserveStatus =
    existing &&
    (existing.status === "PUBLISHED" ||
      existing.status === "LIVE" ||
      existing.status === "DEBRIEF_SENT") &&
    pred.status === "SCHEDULED";

  const updated: TrackedMatchPrediction = {
    id: existing?.id || id,
    homeTeam: pred.homeTeam.trim(),
    awayTeam: pred.awayTeam.trim(),
    competition: pred.competition || existing?.competition || "Football",
    date: pred.date || existing?.date || getFormattedDateForOffset(0),
    kickoffTime: pred.kickoffTime || existing?.kickoffTime || "21:00",
    prediction: pred.prediction || existing?.prediction || "Victoire",
    odd: pred.odd || existing?.odd || "1.85",
    status: preserveStatus ? existing.status : pred.status || existing?.status || "SCHEDULED",
    isQueued: existing?.isQueued || false,
    publishError: existing?.publishError,
    publishedAt: pred.publishedAt || existing?.publishedAt,
    publishedTweetId: pred.publishedTweetId || existing?.publishedTweetId,
    publishedTweetText: pred.publishedTweetText || existing?.publishedTweetText,
    finalScore: existing?.finalScore,
    isWon: existing?.isWon,
    scoreHome: existing?.scoreHome,
    scoreAway: existing?.scoreAway,
    lastLiveMinute: existing?.lastLiveMinute,
    isAutoSelectedSlot: existing?.isAutoSelectedSlot,
    slotKey: existing?.slotKey,
    slotSelectionReason: existing?.slotSelectionReason,
    goalAlertsSent: existing?.goalAlertsSent || [],
    debriefTweetSent: existing?.debriefTweetSent,
    debriefTweetText: existing?.debriefTweetText,
    debriefTweetId: existing?.debriefTweetId,
    debriefPublishedAt: existing?.debriefPublishedAt,
  };

  trackedPredictionsMap.set(key, updated);
  persistTrackedPredictions();
  return updated;
}

export function getTrackedPredictions(): TrackedMatchPrediction[] {
  let hasExpired = false;
  for (const pred of trackedPredictionsMap.values()) {
    if (isExpiredOldMatch(pred.date, pred.kickoffTime)) {
      hasExpired = true;
      break;
    }
  }
  if (hasExpired) {
    autoPurgeOldMatchesAndSyncFresh();
  }
  // Sort chronologically by kickoff time
  return Array.from(trackedPredictionsMap.values())
    .filter((p) => !isExpiredOldMatch(p.date, p.kickoffTime))
    .sort((a, b) => {
      const ta = parseMatchDateTime(a.date, a.kickoffTime);
      const tb = parseMatchDateTime(b.date, b.kickoffTime);
      return ta.totalDiffMinutes - tb.totalDiffMinutes;
    });
}

export function removeTrackedPrediction(keyOrId: string) {
  for (const [k, p] of trackedPredictionsMap.entries()) {
    if (k === keyOrId || p.id === keyOrId) {
      trackedPredictionsMap.delete(k);
      persistTrackedPredictions();
      break;
    }
  }
}

function getTrigram(team: string): string {
  const t = team.trim();
  const lower = t.toLowerCase();
  if (t.toUpperCase() === "PSG" || t.toUpperCase() === "OM" || t.toUpperCase() === "OL") {
    return t.toUpperCase();
  }
  if (lower.includes("atletico") || lower.includes("atlético")) return "ATM";
  if (lower.includes("real madrid")) return "RMA";
  if (lower.includes("ac milan")) return "MIL";
  if (lower.includes("inter")) return "INT";
  if (lower.includes("manchester city") || lower.includes("man city")) return "MCI";
  if (lower.includes("manchester united") || lower.includes("man utd")) return "MUN";
  if (lower.includes("bayern")) return "BAY";
  if (lower.includes("barca") || lower.includes("barcelon")) return "BAR";
  if (lower.includes("arsenal")) return "ARS";
  if (lower.includes("chelsea")) return "CHE";
  if (lower.includes("liverpool")) return "LIV";
  if (lower.includes("juventus") || lower.includes("juve")) return "JUV";
  return t.replace(/[^A-Za-zÀ-ÿ]/g, "").slice(0, 3).toUpperCase() || "FOT";
}

function makeCleanHashtag(raw: string): string {
  return raw
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-zA-Z0-9]/g, "")
    .slice(0, 18);
}

/**
 * Formats prediction labels cleanly in French for tweets (kept exported as formatPredictionToEnglish for backwards compat).
 */
export function formatPredictionToEnglish(
  prediction: string,
  homeTeam: string = "",
  awayTeam: string = ""
): string {
  if (!prediction) return `Victoire ${homeTeam || "Domicile"}`;
  const p = prediction.trim();
  const pLower = p.toLowerCase();

  // Preserve compound French tips verbatim (e.g. "Victoire de Chelsea & moins de 4,5 buts", "Santos ou nul et moins de 3.5 buts")
  const isCompound =
    pLower.includes("&") ||
    pLower.includes(" et ") ||
    pLower.includes("ou nul") ||
    pLower.includes("nul ou ") ||
    pLower.includes("cage inviolée") ||
    pLower.includes("buts d'écart") ||
    pLower.includes("buteur");

  if (isCompound) {
    return p;
  }

  if (pLower.includes("btts - no") || pLower.includes("btts non") || pLower.includes("ne marquent pas")) {
    return "Les deux équipes ne marquent pas";
  }
  if (
    pLower.includes("both teams to score") ||
    pLower.includes("btts") ||
    pLower.includes("les deux équipes marquent") ||
    pLower.includes("les 2 équipes marquent")
  ) {
    return "Les deux équipes marquent";
  }
  if (pLower.includes("over 3.5") || pLower.includes("+3.5") || pLower.includes("plus de 3.5") || pLower.includes("plus de 3,5")) {
    return "Plus de 3.5 buts";
  }
  if (pLower.includes("under 3.5") || pLower.includes("-3.5") || pLower.includes("moins de 3.5") || pLower.includes("moins de 3,5")) {
    return "Moins de 3.5 buts";
  }
  if (pLower.includes("over 2.5") || pLower.includes("+2.5") || pLower.includes("plus de 2.5") || pLower.includes("plus de 2,5")) {
    return "Plus de 2.5 buts";
  }
  if (pLower.includes("under 2.5") || pLower.includes("-2.5") || pLower.includes("moins de 2.5") || pLower.includes("moins de 2,5")) {
    return "Moins de 2.5 buts";
  }
  if (pLower.includes("over 1.5") || pLower.includes("+1.5") || pLower.includes("plus de 1.5") || pLower.includes("plus de 1,5")) {
    return "Plus de 1.5 buts";
  }
  if (pLower.includes("under 1.5") || pLower.includes("-1.5") || pLower.includes("moins de 1.5") || pLower.includes("moins de 1,5")) {
    if (!pLower.includes("handicap")) return "Moins de 1.5 buts";
  }
  if (pLower.endsWith(" to win")) {
    return `Victoire ${p.replace(/\s+to win$/i, "")}`;
  }
  if (pLower === "1") return `Victoire ${homeTeam || "Domicile"}`;
  if (pLower === "2") return `Victoire ${awayTeam || "Extérieur"}`;
  if (pLower === "x" || pLower === "n") return "Match nul";

  return p;
}

/**
 * Accurate prediction outcome evaluator covering 1X2, Double Chance, Over/Under 1.5-5.5,
 * BTTS Yes/No, Win to Nil / Cage inviolée, Handicap -1.5, DNB, and combined French/English markets.
 */
export function evaluatePredictionWon(
  prediction: string,
  scoreHome: number,
  scoreAway: number,
  homeTeam: string,
  awayTeam: string
): boolean {
  const predLower = (prediction || "").toLowerCase().replace(/,/g, ".");
  const homeLower = (homeTeam || "").toLowerCase();
  const awayLower = (awayTeam || "").toLowerCase();
  const totalGoals = scoreHome + scoreAway;
  const isHomeWin = scoreHome > scoreAway;
  const isAwayWin = scoreAway > scoreHome;
  const isDraw = scoreHome === scoreAway;
  const btts = scoreHome > 0 && scoreAway > 0;

  const mentionsHome =
    Boolean(homeLower) &&
    (predLower.includes(homeLower) ||
      (homeLower.length >= 4 && predLower.includes(homeLower.slice(0, 5))) ||
      matchesTeam(predLower, homeTeam));
  const mentionsAway =
    Boolean(awayLower) &&
    (predLower.includes(awayLower) ||
      (awayLower.length >= 4 && predLower.includes(awayLower.slice(0, 5))) ||
      matchesTeam(predLower, awayTeam));

  // Win to nil / Garde sa cage inviolée
  if (
    predLower.includes("cage inviolée") ||
    predLower.includes("cage inviolee") ||
    predLower.includes("win to nil")
  ) {
    if (mentionsAway && !mentionsHome) return isAwayWin && scoreHome === 0;
    return isHomeWin && scoreAway === 0;
  }

  // BTTS - No
  if (
    predLower.includes("btts - no") ||
    predLower.includes("btts non") ||
    predLower.includes("ne marquent pas") ||
    predLower.includes("clean sheet")
  ) {
    return !btts;
  }

  // Over / Under checks (collect if combined with 1X/X2/Win)
  let goalsCondition: boolean | null = null;
  if (predLower.includes("plus de 5.5") || predLower.includes("+5.5") || predLower.includes("over 5.5")) {
    goalsCondition = totalGoals >= 6;
  } else if (predLower.includes("moins de 5.5") || predLower.includes("-5.5") || predLower.includes("under 5.5")) {
    goalsCondition = totalGoals <= 5;
  } else if (predLower.includes("plus de 4.5") || predLower.includes("+4.5") || predLower.includes("over 4.5")) {
    goalsCondition = totalGoals >= 5;
  } else if (predLower.includes("moins de 4.5") || predLower.includes("-4.5") || predLower.includes("under 4.5")) {
    goalsCondition = totalGoals <= 4;
  } else if (predLower.includes("plus de 3.5") || predLower.includes("+3.5") || predLower.includes("over 3.5")) {
    goalsCondition = totalGoals >= 4;
  } else if (predLower.includes("moins de 3.5") || predLower.includes("-3.5") || predLower.includes("under 3.5")) {
    goalsCondition = totalGoals <= 3;
  } else if (predLower.includes("plus de 2.5") || predLower.includes("+2.5") || predLower.includes("over 2.5")) {
    goalsCondition = totalGoals >= 3;
  } else if (predLower.includes("moins de 2.5") || predLower.includes("-2.5") || predLower.includes("under 2.5")) {
    goalsCondition = totalGoals <= 2;
  } else if (predLower.includes("plus de 1.5") || predLower.includes("+1.5") || predLower.includes("over 1.5")) {
    goalsCondition = totalGoals >= 2;
  } else if (
    (predLower.includes("moins de 1.5") || predLower.includes("under 1.5")) &&
    !predLower.includes("handicap")
  ) {
    goalsCondition = totalGoals <= 1;
  }

  // BTTS Yes (possibly combined with 1X / X2 / Win)
  const isBttsYes =
    predLower.includes("les deux équipes marquent") ||
    predLower.includes("les 2 équipes marquent") ||
    predLower.includes("les 2 marquent") ||
    predLower.includes("both teams") ||
    predLower.includes("btts");

  // Double chance (1X / X2 / ou nul / nul ou / or draw)
  const isDoubleChance =
    predLower.includes("ou nul") ||
    predLower.includes("nul ou ") ||
    predLower.includes("or draw") ||
    predLower.includes("draw or") ||
    predLower.includes("1x") ||
    predLower.includes("x2") ||
    predLower.includes("double chance");

  if (isDoubleChance) {
    let dcResult = isHomeWin || isDraw;
    if (predLower.includes("x2") || (mentionsAway && !mentionsHome)) {
      dcResult = isAwayWin || isDraw;
    } else if (predLower.includes("1x") || mentionsHome) {
      dcResult = isHomeWin || isDraw;
    }
    if (isBttsYes) return dcResult && btts;
    if (goalsCondition !== null) return dcResult && goalsCondition;
    return dcResult;
  }

  // Handicap -1.5 / 2+ goals margin
  if (
    predLower.includes("handicap") ||
    predLower.includes("-1.5") ||
    predLower.includes("2+ buts") ||
    predLower.includes("2 buts d'écart") ||
    predLower.includes("2 buts d'ecart") ||
    predLower.includes("au moins 2 buts")
  ) {
    if (mentionsAway && !mentionsHome) {
      return scoreAway - scoreHome >= 2;
    }
    return scoreHome - scoreAway >= 2;
  }

  // Draw No Bet / Remboursé si nul
  if (predLower.includes("dnb") || predLower.includes("rembours") || predLower.includes("draw no bet")) {
    if (mentionsAway && !mentionsHome) return isAwayWin || isDraw;
    return isHomeWin || isDraw;
  }

  if (isBttsYes) {
    if (predLower.includes("victoire") || predLower.includes("win") || predLower.includes("gagne")) {
      if (mentionsAway && !mentionsHome) return btts && isAwayWin;
      if (mentionsHome) return btts && isHomeWin;
    }
    return btts;
  }

  if (goalsCondition !== null) {
    if (predLower.includes("victoire") || predLower.includes("win") || predLower.includes("gagne")) {
      if (mentionsAway && !mentionsHome) return goalsCondition && isAwayWin;
      if (mentionsHome) return goalsCondition && isHomeWin;
    }
    return goalsCondition;
  }

  if (
    predLower === "x" ||
    predLower === "n" ||
    predLower.includes("match nul") ||
    predLower.includes("draw")
  ) {
    return isDraw;
  }

  if (mentionsAway && !mentionsHome) return isAwayWin;
  if (mentionsHome && !mentionsAway) return isHomeWin;
  if (predLower.includes("extérieur") || predLower === "2") return isAwayWin;

  return isHomeWin;
}

/**
 * 1. MORNING ROADMAP TWEET (French, < 275 chars)
 */
export function generateMorningAnnouncementTweet(
  pronos: SportyTraderProno[],
  dateLabel?: string
): string {
  const parisTiming = parseMatchDateTime();
  const dateStr = dateLabel || parisTiming.formattedDate;

  const todayUpcoming = pronos.filter((p) => {
    const timing = parseMatchDateTime(p.date, p.kickoffTime);
    return timing.isToday && !timing.isPastKickoff;
  });

  const candidates =
    todayUpcoming.length > 0
      ? todayUpcoming
      : pronos.filter((p) => !isMatchInThePast(p.date, p.kickoffTime));

  const topMatches = candidates.slice(0, 4);

  if (topMatches.length === 0) {
    return `☀️ PROGRAMME DU JOUR (${dateStr}) ⚽\n\nAucun grand match détecté pour l'instant aujourd'hui. Le bot surveille les affiches en continu ! 📊\n\n#Football #Pronostics`;
  }

  const lines = topMatches.map((p) => {
    const tip = formatPredictionToEnglish(p.prediction, p.homeTeam, p.awayTeam);
    return `⚽ ${p.kickoffTime || "21:00"} ${p.homeTeam}-${p.awayTeam} ➔ ${tip} (@${p.odds || "1.85"})`;
  });

  return `☀️ PROGRAMME DU JOUR (${dateStr}) ⚽\n\n${lines.join("\n")}\n\n⚡ Prono détaillé 1h avant chaque match + alertes buts live !\n#Football #Pronostics`.slice(0, 278);
}

/**
 * 2. H-1h PRE-MATCH TWEET (Clean French, strictly < 275 chars)
 */
export function generateH1TweetText(prono: SportyTraderProno): string {
  const triHome = getTrigram(prono.homeTeam);
  const triAway = getTrigram(prono.awayTeam);
  const tagHome = makeCleanHashtag(prono.homeTeam);
  const tagAway = makeCleanHashtag(prono.awayTeam);
  const conf = prono.confidencePercent || 82;
  const tip = formatPredictionToEnglish(prono.prediction, prono.homeTeam, prono.awayTeam);

  const text = `🔥 PRONO H-1 | ${prono.homeTeam} vs ${prono.awayTeam}
🏆 ${prono.competition} · Coup d'envoi ${prono.kickoffTime || "21:00"}

🎯 Prono : ${tip}
📈 Cote : @${prono.odds || "1.85"}
⚡ Confiance : ${conf}%

⚽ Suivi buts en direct & débrief FT ici 👇
#Pronostics #${triHome}${triAway} #${tagHome} #${tagAway}`;

  return text.length > 275 ? text.slice(0, 272) + "..." : text;
}

/**
 * 3. LIVE GOAL ALERT TWEET (Clean French, strictly < 275 chars)
 */
export function generateLiveGoalTweet(
  prono: { homeTeam: string; awayTeam: string; prediction: string; odds?: string; competition?: string },
  liveScore: LiveScoreResult,
  scoringSide: "home" | "away",
  minuteText?: string,
  scorerName?: string
): string {
  const triHome = getTrigram(prono.homeTeam);
  const triAway = getTrigram(prono.awayTeam);
  const tagHome = makeCleanHashtag(prono.homeTeam);
  const tagAway = makeCleanHashtag(prono.awayTeam);

  const scoringTeamName = scoringSide === "home" ? prono.homeTeam : prono.awayTeam;
  const currentScoreStr = `${liveScore.scoreHome}-${liveScore.scoreAway}`;
  const minuteDisplay = minuteText ? `(${minuteText})` : "";
  const hasRealScorer =
    scorerName &&
    scorerName !== "Buteur" &&
    scorerName !== "Goal" &&
    scorerName !== prono.homeTeam &&
    scorerName !== prono.awayTeam &&
    !scorerName.endsWith("Striker");

  const totalGoals = liveScore.scoreHome + liveScore.scoreAway;
  const tip = formatPredictionToEnglish(prono.prediction, prono.homeTeam, prono.awayTeam);
  const predLower = (prono.prediction || "").toLowerCase();

  let headline = `⚽ BUT ! ${hasRealScorer ? `${scorerName} (${scoringTeamName})` : scoringTeamName} ${minuteDisplay} !`;
  if (liveScore.scoreHome === 1 && liveScore.scoreAway === 1) {
    headline = `⚽ ÉGALISATION 1-1 ! ${hasRealScorer ? scorerName : scoringTeamName} remet les compteurs à zéro ${minuteDisplay} ! ⚡`;
  } else if (totalGoals >= 3) {
    headline = `⚽ BUT ! ${currentScoreStr} ! ${hasRealScorer ? `${scorerName} (${scoringTeamName})` : scoringTeamName} ${minuteDisplay} ! 🔥`;
  }

  let impactMessage = `Avantage ${scoringTeamName}, on suit la suite en direct ! ⚡`;
  if (predLower.includes("btts") || predLower.includes("deux équipes marquent") || predLower.includes("2 équipes marquent")) {
    impactMessage =
      liveScore.scoreHome > 0 && liveScore.scoreAway > 0
        ? "✅ LES 2 ÉQUIPES ONT MARQUÉ ! Prono validé en direct ! 💰"
        : "Plus qu'un but de l'autre équipe pour valider le BTTS ! ⏳";
  } else if (predLower.includes("2.5") && (predLower.includes("plus") || predLower.includes("over") || predLower.includes("+"))) {
    impactMessage =
      totalGoals >= 3
        ? "✅ PLUS DE 2.5 BUTS VALIDÉ EN DIRECT ! 🚀💰"
        : `Déjà ${totalGoals} but(s), encore ${3 - totalGoals} pour valider ! 📈`;
  } else if (predLower.includes("1.5") && (predLower.includes("plus") || predLower.includes("over") || predLower.includes("+"))) {
    impactMessage =
      totalGoals >= 2
        ? "✅ PLUS DE 1.5 BUTS VALIDÉ EN DIRECT ! 🚀💰"
        : "Encore 1 petit but pour valider le +1.5 ! 📈";
  }

  const text = `${headline}

🏟️ ${prono.homeTeam} ${currentScoreStr} ${prono.awayTeam}
🎯 Notre prono : ${tip} (@${prono.odds || "1.85"})

${impactMessage}

#LiveFoot #${triHome}${triAway} #${tagHome} #${tagAway}`;

  return text.length > 275 ? text.slice(0, 272) + "..." : text;
}

/**
 * 4. INDIVIDUAL FT DEBRIEF TWEET (Clean French, strictly < 275 chars)
 */
export function generateResultTweetText(
  prono: { homeTeam: string; awayTeam: string; competition?: string; odds?: string; prediction: string },
  scoreHome: number,
  scoreAway: number,
  isWon: boolean
): string {
  const triHome = getTrigram(prono.homeTeam);
  const triAway = getTrigram(prono.awayTeam);
  const tagHome = makeCleanHashtag(prono.homeTeam);
  const tagAway = makeCleanHashtag(prono.awayTeam);
  const scoreStr = `${scoreHome}-${scoreAway}`;
  const odd = prono.odds || "1.85";
  const profit = Math.max(0.1, parseFloat(odd) - 1).toFixed(2);
  const tip = formatPredictionToEnglish(prono.prediction, prono.homeTeam, prono.awayTeam);

  const text = isWon
    ? `🏁 FIN DE MATCH | ${prono.homeTeam} ${scoreStr} ${prono.awayTeam}
🏆 ${prono.competition || "Football"}

✅ PRONO VALIDÉ ! (@${odd})
🎯 "${tip}" passe parfaitement !
💰 Bilan : +${profit}u sur ce match 🚀

#Pronostics #Gagné #${triHome}${triAway} #${tagHome} #${tagAway}`
    : `🏁 FIN DE MATCH | ${prono.homeTeam} ${scoreStr} ${prono.awayTeam}
🏆 ${prono.competition || "Football"}

❌ PRONO MANQUÉ (${scoreStr})
🎯 "${tip}" ne passe pas cette fois.
100% transparent, on rebondit au prochain match ! 📈

#Pronostics #${triHome}${triAway} #${tagHome} #${tagAway}`;

  return text.length > 275 ? text.slice(0, 272) + "..." : text;
}

/**
 * 5. GRAND DAILY DEBRIEF TWEET (French, < 278 chars)
 */
export function generateDailyRecapTweet(
  finishedResults: Array<{
    prono: { homeTeam: string; awayTeam: string; prediction: string; odds?: string };
    scoreHome: number;
    scoreAway: number;
    isWon: boolean;
  }>,
  dateLabel?: string
): {
  tweetText: string;
  totalMatches: number;
  wonCount: number;
  winRate: number;
  netProfit: number;
} {
  const dateStr =
    dateLabel ||
    new Date().toLocaleDateString("fr-FR", { day: "numeric", month: "long", timeZone: "Europe/Paris" });
  const totalMatches = finishedResults.length;
  const wonCount = finishedResults.filter((r) => r.isWon).length;
  const winRate = totalMatches > 0 ? Math.round((wonCount / totalMatches) * 100) : 0;

  let netProfit = 0;
  for (const r of finishedResults) {
    const odd = parseFloat(r.prono.odds || "1.85");
    netProfit += r.isWon ? odd - 1 : -1;
  }

  const profitDisplay = netProfit >= 0 ? `+${netProfit.toFixed(2)}u 💰` : `${netProfit.toFixed(2)}u 📉`;

  if (totalMatches === 0) {
    const text = `🌙 BILAN DU JOUR (${dateStr}) 📊\n\nAucun match pronostiqué terminé aujourd'hui. Rendez-vous demain pour la prochaine sélection ! 🚀\n\n#Pronostics #Football`;
    return { tweetText: text, totalMatches: 0, wonCount: 0, winRate: 0, netProfit: 0 };
  }

  const matchLines = finishedResults.slice(0, 4).map((r) => {
    const icon = r.isWon ? "✅" : "❌";
    return `${icon} ${r.prono.homeTeam} ${r.scoreHome}-${r.scoreAway} ${r.prono.awayTeam} (@${r.prono.odds || "1.85"})`;
  });

  const headerEmoji = winRate >= 60 ? "🔥 SOIRÉE GAGNANTE" : "📊 BILAN DU JOUR";
  const tweetText = `🏁 ${headerEmoji} (${dateStr})

${matchLines.join("\n")}

📊 ${wonCount}/${totalMatches} VALIDÉS (${winRate}%) · Bilan : ${profitDisplay}
#Pronostics #Bilan #Football`.slice(0, 278);

  return {
    tweetText,
    totalMatches,
    wonCount,
    winRate,
    netProfit: parseFloat(netProfit.toFixed(2)),
  };
}

/**
 * Strategic Priority Score: Premier League #1, Champions League #2, Ligue 1 #3,
 * La Liga / Serie A / Bundesliga / Nations League, plus prestige clubs & optimal value odds.
 */
export function calculatePronoQualityScore(prono: {
  competition?: string;
  homeTeam: string;
  awayTeam: string;
  odds?: string;
  confidencePercent?: number;
}): number {
  let score = 0;
  const comp = (prono.competition || "").toLowerCase();
  const teams = `${prono.homeTeam} ${prono.awayTeam}`.toLowerCase();

  if (comp.includes("premier league")) {
    score += 130;
  } else if (comp.includes("champions league")) {
    score += 105;
  } else if (comp.includes("ligue 1")) {
    score += 85;
  } else if (comp.includes("la liga") || comp.includes("liga")) {
    score += 75;
  } else if (comp.includes("serie a")) {
    score += 70;
  } else if (comp.includes("bundesliga")) {
    score += 70;
  } else if (comp.includes("nations league") || comp.includes("world cup") || comp.includes("qualif")) {
    score += 65;
  } else if (comp.includes("europa") || comp.includes("conference")) {
    score += 55;
  } else if (comp.includes("championship") || comp.includes("eredivisie") || comp.includes("portugal")) {
    score += 35;
  } else {
    score += 15;
  }

  const prestigeTeams = [
    "arsenal", "chelsea", "manchester city", "liverpool", "manchester united", "tottenham", "newcastle", "aston villa",
    "real madrid", "barcelone", "barcelona", "atletico",
    "psg", "paris", "monaco", "marseille", "lyon", "lille",
    "bayern", "dortmund", "leverkusen", "leipzig",
    "inter", "milan", "juventus", "roma", "napoli",
    "france", "spain", "espagne", "england", "angleterre", "germany", "allemagne", "portugal", "italy", "italie", "brazil", "brésil", "argentina", "argentine",
  ];
  if (prestigeTeams.some((team) => teams.includes(team))) {
    score += 20;
  }

  const odd = parseFloat(prono.odds || "1.85");
  if (odd >= 1.5 && odd <= 2.2) {
    score += 18;
  } else if (odd >= 1.35 && odd <= 2.8) {
    score += 8;
  }

  score += Math.round((prono.confidencePercent || 80) / 5);
  return score;
}

/**
 * SMART SLOT ARBITRATION (75-minute Greedy Anti-Collision Window):
 * Ensures ZERO tweet overlap even when matches kick off at 20:45 vs 21:00!
 * - Premier League retains #1 priority.
 * - Matches already PUBLISHED or LIVE reserve their 75-minute time window.
 * - Competing matches within 75 minutes of a higher-priority match are marked SKIPPED_SLOT_DUPLICATE
 *   and NEVER trigger H-1 tweets, live goal tweets, or FT debriefs.
 */
export function applySmartSlotArbitration(): {
  totalSlots: number;
  retainedMatchesCount: number;
  skippedDuplicatesCount: number;
} {
  const trackedList = Array.from(trackedPredictionsMap.values()).filter(
    (m) => !isExpiredOldMatch(m.date, m.kickoffTime)
  );

  const candidates = trackedList.filter(
    (m) => m.status === "SCHEDULED" || m.status === "SKIPPED_SLOT_DUPLICATE"
  );

  // Mode PUBLISH_ALL: allow all upcoming matches (TweetQueue still enforces 60s anti-spam)
  if (botState.slotCollisionMode === "PUBLISH_ALL") {
    for (const match of candidates) {
      match.status = "SCHEDULED";
      match.isAutoSelectedSlot = true;
      match.slotKey = `${match.date} @ ${match.kickoffTime}`;
      match.slotSelectionReason = `⚡ Mode Tout Publier : programmé (${match.competition})`;
    }
    persistTrackedPredictions();
    return {
      totalSlots: candidates.length,
      retainedMatchesCount: candidates.length,
      skippedDuplicatesCount: 0,
    };
  }

  // Already active matches (PUBLISHED / LIVE) hold their 75-min windows
  const occupiedSlots: TrackedMatchPrediction[] = trackedList.filter(
    (m) => m.status === "PUBLISHED" || m.status === "LIVE"
  );

  // Rank candidates by priority score DESC (Premier League #1), tie-break by earlier kickoff
  candidates.sort((a, b) => {
    const scoreA = calculatePronoQualityScore({
      competition: a.competition,
      homeTeam: a.homeTeam,
      awayTeam: a.awayTeam,
      odds: a.odd,
    });
    const scoreB = calculatePronoQualityScore({
      competition: b.competition,
      homeTeam: b.homeTeam,
      awayTeam: b.awayTeam,
      odds: b.odd,
    });
    if (scoreB !== scoreA) return scoreB - scoreA;
    return (
      parseMatchDateTime(a.date, a.kickoffTime).totalDiffMinutes -
      parseMatchDateTime(b.date, b.kickoffTime).totalDiffMinutes
    );
  });

  let retainedMatchesCount = 0;
  let skippedDuplicatesCount = 0;

  for (const cand of candidates) {
    const conflict = occupiedSlots.find(
      (occ) =>
        getMinutesBetweenMatches(cand.date, cand.kickoffTime, occ.date, occ.kickoffTime) <
        ANTI_COLLISION_WINDOW_MINUTES
    );

    const slotKey = `${(cand.date || "Date").trim()} @ ${(cand.kickoffTime || "21:00").trim()}`;
    cand.slotKey = slotKey;

    if (conflict) {
      cand.status = "SKIPPED_SLOT_DUPLICATE";
      cand.isAutoSelectedSlot = false;
      cand.slotSelectionReason = `Écarté (fenêtre <75min) au profit de ${conflict.homeTeam} vs ${conflict.awayTeam} (${conflict.competition}, ${conflict.kickoffTime})`;
      skippedDuplicatesCount++;
    } else {
      cand.status = "SCHEDULED";
      cand.isAutoSelectedSlot = true;
      cand.slotSelectionReason = `👑 Retenu #1 créneau (${cand.kickoffTime}) · Priorité ${cand.competition || "Top Match"}`;
      occupiedSlots.push(cand);
      retainedMatchesCount++;
    }
  }

  persistTrackedPredictions();
  console.log(
    `[Smart Slot Arbitration] 🎯 ${retainedMatchesCount} créneau(x) retenu(s) (fenêtre anti-collision 75min), ${skippedDuplicatesCount} doublon(s) écarté(s).`
  );

  return {
    totalSlots: retainedMatchesCount,
    retainedMatchesCount,
    skippedDuplicatesCount,
  };
}

/**
 * Registers upcoming pronos and runs the 75-minute anti-collision slot selection.
 */
export async function selectAndScheduleSmartSlotMatches(
  customPronos?: SportyTraderProno[]
): Promise<{
  selectedMatches: TrackedMatchPrediction[];
  totalSlots: number;
  duplicatesAvoided: number;
  scheduledTweetsCount: number;
}> {
  let list = customPronos && customPronos.length > 0 ? customPronos : latestManagedPronos;
  if (!list || list.length === 0) {
    const scraped = await scrapeSportyTraderWithSource();
    list = scraped.pronos;
    latestManagedPronos = list;
    botState.lastSyncSource = scraped.source;
    botState.lastSyncMessage = scraped.message;
    botState.lastSyncDateParis = getParisNow().isoDate;
    persistBotState();
    persistManagedPronos();
  }

  // Register upcoming matches (skip already finished)
  const upcomingList = list.filter((item) => !isExpiredOldMatch(item.date, item.kickoffTime));
  for (const item of upcomingList) {
    const timing = parseMatchDateTime(item.date, item.kickoffTime);
    if (timing.isMatchFinished) continue;

    registerTrackedPrediction({
      id: item.id,
      homeTeam: item.homeTeam,
      awayTeam: item.awayTeam,
      competition: item.competition,
      date: item.date,
      kickoffTime: item.kickoffTime,
      prediction: item.prediction,
      odd: item.odds || "1.85",
      status: timing.isPastKickoff ? "LIVE" : "SCHEDULED",
    });
  }

  const arbitration = applySmartSlotArbitration();
  const selectedMatches = getTrackedPredictions().filter(
    (m) => m.status === "SCHEDULED" || m.status === "PUBLISHED" || m.status === "LIVE"
  );

  // Create H-1 scheduled tweet previews ONLY for retained matches
  for (const m of selectedMatches) {
    if (m.status !== "SCHEDULED") continue;
    const existingTweet = allManagedTweets.find(
      (t) => t.pronoId === m.id && t.type === "PRONO_H1"
    );
    if (!existingTweet) {
      const h1Text = generateH1TweetText({
        id: m.id,
        homeTeam: m.homeTeam,
        awayTeam: m.awayTeam,
        competition: m.competition,
        date: m.date,
        kickoffTime: m.kickoffTime,
        prediction: m.prediction,
        odds: m.odd,
        sourceUrl: "https://www.sportytrader.com/pronostics/football/",
      });
      allManagedTweets.unshift({
        id: `h1-${m.id}-${Date.now()}`,
        pronoId: m.id,
        matchTitle: `${m.homeTeam} vs ${m.awayTeam}`,
        homeTeam: m.homeTeam,
        awayTeam: m.awayTeam,
        competition: m.competition,
        date: m.date,
        kickoffTime: m.kickoffTime,
        type: "PRONO_H1",
        tweetText: h1Text,
        scheduledTimeLabel: `H-1h (${m.kickoffTime || "21:00"})`,
        status: "SCHEDULED",
        createdAt: Date.now(),
        odd: m.odd,
        prediction: m.prediction,
      });
    }
  }

  persistManagedTweets();

  addBotLog(
    "SELECTION",
    botState.slotCollisionMode === "PUBLISH_ALL"
      ? "⚡ Mode Tout Publier : Matchs programmés"
      : "🎯 Arbitrage Anti-Collision 75min (Priorité Premier League)",
    `${arbitration.retainedMatchesCount} match(s) retenu(s), ${arbitration.skippedDuplicatesCount} doublon(s) écarté(s) pour garantir zéro superposition.`,
    `${arbitration.retainedMatchesCount} Retenus`
  );

  return {
    selectedMatches,
    totalSlots: arbitration.totalSlots,
    duplicatesAvoided: arbitration.skippedDuplicatesCount,
    scheduledTweetsCount: allManagedTweets.length,
  };
}

/**
 * CORE AUTO-PILOT CYCLE:
 * 1. Publishes H-1 prediction (15..70 min before kickoff) ONLY for retained SCHEDULED matches.
 * 2. Scans live scores for goals & FT debriefs ONLY for retained/active matches (NEVER duplicates!).
 * 3. Publishes daily recap once per night around 23:30 Paris if matches finished today.
 */
export async function runAutoPilotCycle(): Promise<{
  h1PublishedCount: number;
  goalsDetected: number;
  finishedCount: number;
  dailyRecapSent: boolean;
  newTweets: ScheduledTweetRecord[];
}> {
  botState.lastAutoRunTimestamp = Date.now();
  persistBotState();

  const tracked = getTrackedPredictions();
  let h1PublishedCount = 0;
  let dailyRecapSent = false;
  const newTweets: ScheduledTweetRecord[] = [];

  // 1. Process H-1 pre-match publications ONLY if auto-pilot is enabled
  if (isAutoPilotEnabled()) {
    const dueCandidates: TrackedMatchPrediction[] = [];

    for (const pred of tracked) {
      if (pred.status !== "SCHEDULED" || pred.isQueued) continue;

      // Never publish H-1 for a match that has already kicked off
      if (isMatchInThePast(pred.date, pred.kickoffTime)) {
        pred.status = "LIVE";
        persistTrackedPredictions();
        continue;
      }

      if (isMatchDueForH1(pred.date, pred.kickoffTime)) {
        dueCandidates.push(pred);
      }
    }

    if (dueCandidates.length > 0) {
      dueCandidates.sort((a, b) => {
        const scoreA = calculatePronoQualityScore({
          competition: a.competition,
          homeTeam: a.homeTeam,
          awayTeam: a.awayTeam,
          odds: a.odd,
        });
        const scoreB = calculatePronoQualityScore({
          competition: b.competition,
          homeTeam: b.homeTeam,
          awayTeam: b.awayTeam,
          odds: b.odd,
        });
        return scoreB - scoreA;
      });

      const pred = dueCandidates[0];

      // Block any competing due matches within 75 min in ANTI_COLLISION mode
      if (botState.slotCollisionMode !== "PUBLISH_ALL") {
        for (let i = 1; i < dueCandidates.length; i++) {
          const competitor = dueCandidates[i];
          if (
            getMinutesBetweenMatches(
              pred.date,
              pred.kickoffTime,
              competitor.date,
              competitor.kickoffTime
            ) < ANTI_COLLISION_WINDOW_MINUTES
          ) {
            competitor.status = "SKIPPED_SLOT_DUPLICATE";
            competitor.isAutoSelectedSlot = false;
            competitor.slotSelectionReason = `Écarté (<75min) au profit de ${pred.homeTeam} vs ${pred.awayTeam} (${pred.competition})`;
          }
        }
      }

      let h1Tweet = allManagedTweets.find(
        (t) => t.pronoId === pred.id && t.type === "PRONO_H1"
      );

      if (!h1Tweet) {
        const text = generateH1TweetText({
          id: pred.id,
          homeTeam: pred.homeTeam,
          awayTeam: pred.awayTeam,
          competition: pred.competition,
          date: pred.date,
          kickoffTime: pred.kickoffTime,
          prediction: pred.prediction,
          odds: pred.odd,
          sourceUrl: "https://www.sportytrader.com/pronostics/football/",
        });
        h1Tweet = {
          id: `h1-${pred.id}-${Date.now()}`,
          pronoId: pred.id,
          matchTitle: `${pred.homeTeam} vs ${pred.awayTeam}`,
          homeTeam: pred.homeTeam,
          awayTeam: pred.awayTeam,
          competition: pred.competition,
          date: pred.date,
          kickoffTime: pred.kickoffTime,
          type: "PRONO_H1",
          tweetText: text,
          scheduledTimeLabel: `H-1h (${pred.kickoffTime || "21:00"})`,
          status: "SCHEDULED",
          createdAt: Date.now(),
          odd: pred.odd,
          prediction: pred.prediction,
        };
        allManagedTweets.unshift(h1Tweet);
      }

      const queued = enqueueTweet({
        tweetText: h1Tweet.tweetText,
        type: "PRONO_H1",
        matchTitle: `${pred.homeTeam} vs ${pred.awayTeam}`,
        priority: "NORMAL",
        metadata: {
          pronoId: pred.id,
          date: pred.date,
          kickoffTime: pred.kickoffTime,
        },
      });

      if (queued) {
        pred.isQueued = true;
        pred.publishedTweetText = h1Tweet.tweetText;
        persistTrackedPredictions();
        persistManagedTweets();
        h1PublishedCount++;
        newTweets.push(h1Tweet);

        addBotLog(
          "SCHEDULE",
          `📥 Prono H-1 mis en file : ${pred.homeTeam} vs ${pred.awayTeam}`,
          `Créneau ${pred.kickoffTime} (${pred.competition}). Envoi cadencé sur X sans superposition.`,
          "H-1 Enfilé"
        );
      }
    }
  }

  // 2. Process Live Goals & FT Recaps ONLY for retained matches
  let goalsDetected = 0;
  let finishedCount = 0;

  if (isAutoGoalAlertsEnabled() || isAutoPilotEnabled()) {
    const scoreResult = await checkAndProcessLiveGoalsAndFT();
    goalsDetected = scoreResult.goalsDetected;
    finishedCount = scoreResult.finishedCount;
    newTweets.push(...scoreResult.newTweets);
  }

  // 3. Automatic End-of-Day Recap at 23:30 Paris time (once per day, only if >= 1 match finished today)
  const parisNow = getParisNow();
  if (
    isAutoPilotEnabled() &&
    parisNow.hour === 23 &&
    parisNow.minute >= 30 &&
    botState.lastDailyRecapDateParis !== parisNow.isoDate
  ) {
    try {
      const finishedSummary = await getTodayFinishedMatchesSummary();
      if (finishedSummary.length > 0) {
        const recap = generateDailyRecapTweet(finishedSummary);
        const queued = enqueueTweet({
          tweetText: recap.tweetText,
          type: "DAILY_RECAP",
          matchTitle: `Bilan du jour (${parisNow.isoDate})`,
          priority: "LOW",
        });
        if (queued) {
          botState.lastDailyRecapDateParis = parisNow.isoDate;
          persistBotState();
          dailyRecapSent = true;
          addBotLog(
            "FT",
            `🌙 Bilan Quotidien mis en file (${recap.wonCount}/${recap.totalMatches})`,
            `Taux de réussite : ${recap.winRate}% (${recap.netProfit >= 0 ? "+" : ""}${recap.netProfit}u).`,
            "Bilan 23h30"
          );
        }
      }
    } catch (recapErr: any) {
      console.warn("[Auto-Daily-Recap] Warning:", recapErr?.message);
    }
  }

  return {
    h1PublishedCount,
    goalsDetected,
    finishedCount,
    dailyRecapSent,
    newTweets,
  };
}

/**
 * ALWAYS fetches fresh live matches from SportyTrader (with real ESPN Live + Gemini AI fallback).
 * Purges expired matches, merges fresh fixtures without clobbering published/live matches,
 * and applies strict 75-minute anti-collision slot arbitration.
 */
export async function syncSportyTraderAndGenerateTweets(
  rawContent?: string
): Promise<{
  newPronosCount: number;
  totalTweetsCount: number;
  source: ScrapeDataSource;
  sourceMessage: string;
  pronos: SportyTraderProno[];
  tweets: ScheduledTweetRecord[];
}> {
  // First purge expired matches (> 18h old)
  autoPurgeOldMatchesAndSyncFresh();

  let incomingPronos: SportyTraderProno[] = [];
  let source: ScrapeDataSource = "SPORTYTRADER_LIVE";
  let sourceMessage = "";

  if (rawContent && rawContent.trim().length > 10) {
    incomingPronos = parseSportyTraderInput(rawContent);
    source = incomingPronos.length > 0 ? "SPORTYTRADER_LIVE" : "EMPTY";
    sourceMessage =
      incomingPronos.length > 0
        ? `${incomingPronos.length} pronostic(s) importé(s) manuellement depuis SportyTrader.`
        : "Aucun match détecté dans le texte collé.";
  } else {
    const liveResult = await scrapeSportyTraderWithSource();
    incomingPronos = liveResult.pronos;
    source = liveResult.source;
    sourceMessage = liveResult.message;
  }

  // Merge fresh incoming pronos with existing non-expired managed pronos
  const pronosMap = new Map<string, SportyTraderProno>();
  for (const p of latestManagedPronos) {
    if (!isExpiredOldMatch(p.date, p.kickoffTime)) {
      pronosMap.set(makeMatchKey(p.homeTeam, p.awayTeam), p);
    }
  }

  let newCount = 0;
  for (const p of incomingPronos) {
    if (isExpiredOldMatch(p.date, p.kickoffTime)) continue;
    const key = makeMatchKey(p.homeTeam, p.awayTeam);
    if (!pronosMap.has(key) || !discoveredPronoIds.has(p.id)) {
      newCount++;
    }
    discoveredPronoIds.add(p.id);
    pronosMap.set(key, p);
  }

  const mergedList = Array.from(pronosMap.values());
  latestManagedPronos = mergedList;
  persistManagedPronos();

  botState.lastSyncSource = source;
  botState.lastSyncMessage = sourceMessage;
  botState.lastSyncDateParis = getParisNow().isoDate;
  persistBotState();

  // Register & arbitrate with 75-minute anti-collision
  await selectAndScheduleSmartSlotMatches(mergedList);

  addBotLog(
    "SCRAPE",
    source === "SPORTYTRADER_LIVE"
      ? "🔄 Synchronisation SportyTrader Live"
      : source === "ESPN_LIVE_AI"
      ? "📡 Synchronisation ESPN Live + Pronos IA"
      : "ℹ️ Synchronisation terminée (0 match trouvé)",
    sourceMessage,
    `${mergedList.length} Matchs`
  );

  return {
    newPronosCount: newCount,
    totalTweetsCount: allManagedTweets.length,
    source,
    sourceMessage,
    pronos: mergedList,
    tweets: [...allManagedTweets],
  };
}

/**
 * Checks real live scores ONLY for RETAINED / ACTIVE matches (strictly skips SKIPPED_SLOT_DUPLICATE!)
 * Enqueues Live Goal alerts & FT Debriefs as thread replies to the original H-1 tweet when available.
 */
export async function checkAndProcessLiveGoalsAndFT(): Promise<{
  goalsDetected: number;
  finishedCount: number;
  newTweets: ScheduledTweetRecord[];
  activeTrackedCount: number;
}> {
  const tracked = getTrackedPredictions();
  if (tracked.length === 0) {
    return {
      goalsDetected: 0,
      finishedCount: 0,
      newTweets: [],
      activeTrackedCount: 0,
    };
  }

  const liveScores = await fetchLiveScoresForLeagues();
  const newTweets: ScheduledTweetRecord[] = [];
  let goalsDetected = 0;
  let finishedCount = 0;

  for (const pred of tracked) {
    // STRICT ANTI-SUPERPOSITION GUARD: Never tweet goals or debriefs for discarded duplicate matches!
    if (pred.status === "SKIPPED_SLOT_DUPLICATE" || pred.isAutoSelectedSlot === false) {
      continue;
    }

    // Skip if FT debrief is already confirmed sent on X
    if (pred.status === "DEBRIEF_SENT" && pred.debriefTweetSent) {
      continue;
    }

    const matchScore = findMatchScore(pred.homeTeam, pred.awayTeam, liveScores);
    if (!matchScore) continue;

    pred.lastLiveMinute = matchScore.liveMinute || (matchScore.isFinished ? "FT" : "");

    // 1. LIVE GOAL DETECTION
    if (
      botState.isAutoGoalAlertsEnabled &&
      (matchScore.isLive ||
        (!matchScore.isFinished && (matchScore.scoreHome > 0 || matchScore.scoreAway > 0)))
    ) {
      if (pred.status === "SCHEDULED" || pred.status === "PUBLISHED") {
        pred.status = "LIVE";
      }

      // First time seeing this match live: establish baseline so we don't retroactively flood old goals
      if (!previousScoresMap.has(pred.id)) {
        previousScoresMap.set(pred.id, {
          scoreHome: matchScore.scoreHome,
          scoreAway: matchScore.scoreAway,
        });
        pred.scoreHome = matchScore.scoreHome;
        pred.scoreAway = matchScore.scoreAway;
        for (let h = 1; h <= matchScore.scoreHome; h++) {
          goalEventsHandled.add(`${pred.id}_${h}_0`);
        }
        for (let a = 1; a <= matchScore.scoreAway; a++) {
          goalEventsHandled.add(`${pred.id}_${matchScore.scoreHome}_${a}`);
        }
        persistHandledEvents();
        persistTrackedPredictions();
        continue;
      }

      const prevScore = previousScoresMap.get(pred.id)!;
      const homeGoalDiff = matchScore.scoreHome - prevScore.scoreHome;
      const awayGoalDiff = matchScore.scoreAway - prevScore.scoreAway;

      if (homeGoalDiff > 0 || awayGoalDiff > 0) {
        let simHome = prevScore.scoreHome;
        let simAway = prevScore.scoreAway;

        const goalsToEmit: Array<{
          stepHome: number;
          stepAway: number;
          scoringSide: "home" | "away";
          scorerName: string;
          minuteText: string;
        }> = [];

        for (let h = 0; h < homeGoalDiff; h++) {
          simHome++;
          const homeGoalsList = matchScore.goals?.filter((g) => g.team === "home") || [];
          const goalObj = homeGoalsList[simHome - 1] || matchScore.goals?.[matchScore.goals.length - 1];
          goalsToEmit.push({
            stepHome: simHome,
            stepAway: simAway,
            scoringSide: "home",
            scorerName: goalObj?.scorerName || pred.homeTeam,
            minuteText: goalObj?.minute || matchScore.liveMinute || "",
          });
        }

        for (let a = 0; a < awayGoalDiff; a++) {
          simAway++;
          const awayGoalsList = matchScore.goals?.filter((g) => g.team === "away") || [];
          const goalObj = awayGoalsList[simAway - 1] || matchScore.goals?.[matchScore.goals.length - 1];
          goalsToEmit.push({
            stepHome: simHome,
            stepAway: simAway,
            scoringSide: "away",
            scorerName: goalObj?.scorerName || pred.awayTeam,
            minuteText: goalObj?.minute || matchScore.liveMinute || "",
          });
        }

        for (const gEvent of goalsToEmit) {
          const goalEventKey = `${pred.id}_${gEvent.stepHome}_${gEvent.stepAway}`;

          if (!goalEventsHandled.has(goalEventKey)) {
            goalEventsHandled.add(goalEventKey);
            persistHandledEvents();
            goalsDetected++;

            const cleanScorer =
              gEvent.scorerName !== pred.homeTeam &&
              gEvent.scorerName !== pred.awayTeam &&
              gEvent.scorerName !== "Buteur" &&
              gEvent.scorerName !== "Goal"
                ? gEvent.scorerName
                : undefined;

            const goalTweetText = generateLiveGoalTweet(
              {
                homeTeam: pred.homeTeam,
                awayTeam: pred.awayTeam,
                prediction: pred.prediction,
                odds: pred.odd,
                competition: pred.competition,
              },
              {
                ...matchScore,
                scoreHome: gEvent.stepHome,
                scoreAway: gEvent.stepAway,
              },
              gEvent.scoringSide,
              gEvent.minuteText,
              cleanScorer
            );

            const goalTweet: ScheduledTweetRecord = {
              id: `goal-${pred.id}-${gEvent.stepHome}-${gEvent.stepAway}-${Date.now()}`,
              pronoId: pred.id,
              matchTitle: `⚽ BUT ! ${pred.homeTeam} ${gEvent.stepHome}-${gEvent.stepAway} ${pred.awayTeam}`,
              homeTeam: pred.homeTeam,
              awayTeam: pred.awayTeam,
              competition: pred.competition,
              date: pred.date,
              kickoffTime: pred.kickoffTime,
              type: "GOAL_LIVE",
              tweetText: goalTweetText,
              scheduledTimeLabel: `Live ${gEvent.minuteText || matchScore.liveMinute || "But !"}`,
              status: "READY",
              createdAt: Date.now(),
              odd: pred.odd,
              prediction: pred.prediction,
              scoreHome: gEvent.stepHome,
              scoreAway: gEvent.stepAway,
            };

            const queued = enqueueTweet({
              tweetText: goalTweetText,
              type: "GOAL_LIVE",
              matchTitle: `${pred.homeTeam} ${gEvent.stepHome}-${gEvent.stepAway} ${pred.awayTeam}`,
              inReplyToTweetId: pred.publishedTweetId,
              priority: "HIGH",
              metadata: {
                pronoId: pred.id,
                scoreHome: gEvent.stepHome,
                scoreAway: gEvent.stepAway,
                scorerName: cleanScorer,
                minuteText: gEvent.minuteText,
              },
            });

            if (queued) {
              goalTweet.status = "SCHEDULED";
              pred.isQueued = true;
            }

            allManagedTweets.unshift(goalTweet);
            newTweets.push(goalTweet);
          }
        }
      }
    }

    pred.scoreHome = matchScore.scoreHome;
    pred.scoreAway = matchScore.scoreAway;
    previousScoresMap.set(pred.id, {
      scoreHome: matchScore.scoreHome,
      scoreAway: matchScore.scoreAway,
    });
    persistHandledEvents();
    persistTrackedPredictions();

    // 2. FULL TIME (FT) DEBRIEF DETECTION — DO NOT mark DEBRIEF_SENT until TweetQueue confirms success!
    if (
      matchScore.isFinished &&
      !pred.debriefTweetSent &&
      !pred.isQueued &&
      !finishedMatchesHandled.has(pred.id)
    ) {
      const timing = parseMatchDateTime(pred.date, pred.kickoffTime);
      const isRelevant = timing.isToday || timing.totalDiffMinutes > -1440;
      if (!isRelevant) continue;

      const isWon = evaluatePredictionWon(
        pred.prediction,
        matchScore.scoreHome,
        matchScore.scoreAway,
        pred.homeTeam,
        pred.awayTeam
      );

      pred.finalScore = `${matchScore.scoreHome}-${matchScore.scoreAway}`;
      pred.scoreHome = matchScore.scoreHome;
      pred.scoreAway = matchScore.scoreAway;
      pred.isWon = isWon;

      const ftTweetText = generateResultTweetText(
        {
          homeTeam: pred.homeTeam,
          awayTeam: pred.awayTeam,
          competition: pred.competition,
          odds: pred.odd,
          prediction: pred.prediction,
        },
        matchScore.scoreHome,
        matchScore.scoreAway,
        isWon
      );

      pred.debriefTweetText = ftTweetText;

      const ftTweet: ScheduledTweetRecord = {
        id: `ft-${pred.id}-${Date.now()}`,
        pronoId: pred.id,
        matchTitle: `${pred.homeTeam} ${matchScore.scoreHome}-${matchScore.scoreAway} ${pred.awayTeam}`,
        homeTeam: pred.homeTeam,
        awayTeam: pred.awayTeam,
        competition: pred.competition,
        date: pred.date,
        kickoffTime: pred.kickoffTime,
        type: "RECAP_FT",
        tweetText: ftTweetText,
        scheduledTimeLabel: "Terminé (FT)",
        status: "SCHEDULED",
        createdAt: Date.now(),
        odd: pred.odd,
        prediction: pred.prediction,
        isWon,
        scoreHome: matchScore.scoreHome,
        scoreAway: matchScore.scoreAway,
      };

      const queued = enqueueTweet({
        tweetText: ftTweetText,
        type: "RECAP_FT",
        matchTitle: `${pred.homeTeam} ${matchScore.scoreHome}-${matchScore.scoreAway} ${pred.awayTeam}`,
        inReplyToTweetId: pred.publishedTweetId,
        priority: "NORMAL",
        metadata: {
          pronoId: pred.id,
          finalScore: pred.finalScore,
          isWon,
        },
      });

      if (queued) {
        pred.isQueued = true;
        finishedCount++;
        allManagedTweets.unshift(ftTweet);
        newTweets.push(ftTweet);
        persistTrackedPredictions();
        persistManagedTweets();

        addBotLog(
          "FT",
          `📥 Débrief FT mis en file : ${pred.homeTeam} ${pred.finalScore} ${pred.awayTeam}`,
          `Verdict : ${isWon ? "✅ GAGNÉ" : "❌ MANQUÉ"}. En attente de confirmation X.`,
          isWon ? "✅ GAGNÉ" : "❌ MANQUÉ"
        );
      }
    }
  }

  return {
    goalsDetected,
    finishedCount,
    newTweets,
    activeTrackedCount: tracked.filter((t) => t.status !== "SKIPPED_SLOT_DUPLICATE").length,
  };
}

/**
 * Collects all finished match results of RETAINED tracked predictions for the grand daily summary.
 */
export async function getTodayFinishedMatchesSummary(): Promise<
  Array<{
    prono: { homeTeam: string; awayTeam: string; prediction: string; odds?: string };
    scoreHome: number;
    scoreAway: number;
    isWon: boolean;
  }>
> {
  const tracked = getTrackedPredictions().filter((t) => t.status !== "SKIPPED_SLOT_DUPLICATE");
  const liveScores = await fetchLiveScoresForLeagues();
  const summary: Array<{
    prono: { homeTeam: string; awayTeam: string; prediction: string; odds?: string };
    scoreHome: number;
    scoreAway: number;
    isWon: boolean;
  }> = [];

  for (const pred of tracked) {
    const matchScore = findMatchScore(pred.homeTeam, pred.awayTeam, liveScores);
    if (matchScore && matchScore.isFinished) {
      const isWon = evaluatePredictionWon(
        pred.prediction,
        matchScore.scoreHome,
        matchScore.scoreAway,
        pred.homeTeam,
        pred.awayTeam
      );
      summary.push({
        prono: {
          homeTeam: pred.homeTeam,
          awayTeam: pred.awayTeam,
          prediction: pred.prediction,
          odds: pred.odd,
        },
        scoreHome: matchScore.scoreHome,
        scoreAway: matchScore.scoreAway,
        isWon,
      });
    } else if (
      (pred.status === "DEBRIEF_SENT" || pred.finalScore) &&
      pred.scoreHome !== undefined &&
      pred.scoreAway !== undefined
    ) {
      summary.push({
        prono: {
          homeTeam: pred.homeTeam,
          awayTeam: pred.awayTeam,
          prediction: pred.prediction,
          odds: pred.odd,
        },
        scoreHome: pred.scoreHome,
        scoreAway: pred.scoreAway,
        isWon:
          pred.isWon ??
          evaluatePredictionWon(
            pred.prediction,
            pred.scoreHome,
            pred.scoreAway,
            pred.homeTeam,
            pred.awayTeam
          ),
      });
    }
  }

  return summary;
}

export function getAllManagedTweets(): ScheduledTweetRecord[] {
  return [...allManagedTweets];
}

export function getManagedPronosList(): SportyTraderProno[] {
  return [...latestManagedPronos];
}

export function markTweetPublished(tweetId: string): boolean {
  const tweet = allManagedTweets.find((t) => t.id === tweetId);
  if (tweet) {
    tweet.status = "PUBLISHED";
    tweet.publishedAt = Date.now();
    persistManagedTweets();
    return true;
  }
  return false;
}

export async function trackAllPronos(): Promise<{ addedCount: number; totalTracked: number }> {
  let list = latestManagedPronos;
  if (list.length === 0) {
    const res = await syncSportyTraderAndGenerateTweets();
    list = res.pronos;
  }

  let addedCount = 0;
  for (const item of list) {
    const existing = Array.from(trackedPredictionsMap.values()).find(
      (p) => matchesTeam(p.homeTeam, item.homeTeam) && matchesTeam(p.awayTeam, item.awayTeam)
    );
    if (!existing) {
      registerTrackedPrediction({
        id: item.id,
        homeTeam: item.homeTeam,
        awayTeam: item.awayTeam,
        competition: item.competition,
        date: item.date,
        kickoffTime: item.kickoffTime,
        prediction: item.prediction,
        odd: item.odds || "1.85",
        status: "SCHEDULED",
      });
      addedCount++;
    }
  }

  applySmartSlotArbitration();
  return {
    addedCount,
    totalTracked: trackedPredictionsMap.size,
  };
}

export async function updateMatchLiveScoreManual(params: {
  matchId: string;
  scoreHome: number;
  scoreAway: number;
  isLive?: boolean;
  isFinished?: boolean;
  liveMinute?: string;
  scorerName?: string;
  scoringTeam?: "home" | "away";
  authToken?: string;
  ct0?: string;
  booster1AuthToken?: string;
  booster1Ct0?: string;
  booster2AuthToken?: string;
  booster2Ct0?: string;
}): Promise<{
  success: boolean;
  tracked?: TrackedMatchPrediction;
  liveResult?: LiveScoreResult;
  tweet?: ScheduledTweetRecord;
  publishResult?: any;
}> {
  if (params.authToken && params.ct0) {
    updateServerXCredentials({
      authToken: params.authToken,
      ct0: params.ct0,
      booster1AuthToken: params.booster1AuthToken,
      booster1Ct0: params.booster1Ct0,
      booster2AuthToken: params.booster2AuthToken,
      booster2Ct0: params.booster2Ct0,
    });
  }

  const tracked = findTrackedByIdOrKey(params.matchId);
  if (!tracked) {
    return { success: false };
  }

  // Allow explicit manual simulation even if a match was previously skipped
  if (tracked.status === "SKIPPED_SLOT_DUPLICATE") {
    tracked.status = "LIVE";
    tracked.isAutoSelectedSlot = true;
  }

  const prevH = tracked.scoreHome ?? 0;
  const prevA = tracked.scoreAway ?? 0;

  const goalsList: LiveScoreGoalEvent[] = [];
  if (params.scorerName) {
    goalsList.push({
      scorerName: params.scorerName,
      team: params.scoringTeam || (params.scoreHome > prevH ? "home" : "away"),
      minute: params.liveMinute || "LIVE",
    });
  }

  const liveResult = setManualMatchScore(tracked.homeTeam, tracked.awayTeam, {
    scoreHome: params.scoreHome,
    scoreAway: params.scoreAway,
    isLive: params.isLive !== undefined ? params.isLive : true,
    isFinished: params.isFinished !== undefined ? params.isFinished : false,
    liveMinute: params.liveMinute || (params.isFinished ? "FT" : "LIVE"),
    statusText: params.isFinished ? "Final" : "In Progress",
    league: tracked.competition,
    goals: goalsList.length > 0 ? goalsList : undefined,
  });

  tracked.scoreHome = params.scoreHome;
  tracked.scoreAway = params.scoreAway;
  tracked.lastLiveMinute = params.liveMinute || (params.isFinished ? "FT" : "LIVE");
  if (params.isFinished) {
    tracked.finalScore = `${params.scoreHome}-${params.scoreAway}`;
    tracked.isWon = evaluatePredictionWon(
      tracked.prediction,
      params.scoreHome,
      params.scoreAway,
      tracked.homeTeam,
      tracked.awayTeam
    );
  }

  previousScoresMap.set(tracked.id, { scoreHome: prevH, scoreAway: prevA });
  const goalEventKey = `${tracked.id}_${params.scoreHome}_${params.scoreAway}`;
  goalEventsHandled.delete(goalEventKey);

  const checkRes = await checkAndProcessLiveGoalsAndFT();
  let createdTweet = checkRes.newTweets.find((t) => t.pronoId === tracked.id);
  let pubResult: any = null;

  if (!createdTweet && (params.scoreHome > 0 || params.scoreAway > 0)) {
    const scoringSide: "home" | "away" =
      params.scoringTeam || (params.scoreHome > prevH ? "home" : "away");
    const tweetText = generateLiveGoalTweet(
      {
        homeTeam: tracked.homeTeam,
        awayTeam: tracked.awayTeam,
        prediction: tracked.prediction,
        odds: tracked.odd,
        competition: tracked.competition,
      },
      {
        homeTeam: tracked.homeTeam,
        awayTeam: tracked.awayTeam,
        scoreHome: params.scoreHome,
        scoreAway: params.scoreAway,
        isLive: true,
        isFinished: false,
        statusText: "In Progress",
        league: tracked.competition,
        liveMinute: params.liveMinute || "LIVE",
      },
      scoringSide,
      params.liveMinute,
      params.scorerName
    );

    createdTweet = {
      id: `goal-${tracked.id}-${params.scoreHome}-${params.scoreAway}-${Date.now()}`,
      pronoId: tracked.id,
      matchTitle: `⚽ BUT ! ${tracked.homeTeam} ${params.scoreHome}-${params.scoreAway} ${tracked.awayTeam}`,
      homeTeam: tracked.homeTeam,
      awayTeam: tracked.awayTeam,
      competition: tracked.competition,
      date: tracked.date,
      kickoffTime: tracked.kickoffTime,
      type: "GOAL_LIVE",
      tweetText,
      scheduledTimeLabel: `Live ${params.liveMinute || "But !"}`,
      status: "SCHEDULED",
      createdAt: Date.now(),
      odd: tracked.odd,
      prediction: tracked.prediction,
      scoreHome: params.scoreHome,
      scoreAway: params.scoreAway,
    };

    const queued = enqueueTweet({
      tweetText,
      type: "GOAL_LIVE",
      matchTitle: `${tracked.homeTeam} ${params.scoreHome}-${params.scoreAway} ${tracked.awayTeam}`,
      inReplyToTweetId: tracked.publishedTweetId,
      priority: "HIGH",
      metadata: {
        pronoId: tracked.id,
        scoreHome: params.scoreHome,
        scoreAway: params.scoreAway,
        scorerName: params.scorerName,
        minuteText: params.liveMinute,
      },
    });
    if (queued) {
      tracked.isQueued = true;
      pubResult = { success: true, message: "But enfilé avec succès (Anti-Superposition)" };
    }

    allManagedTweets.unshift(createdTweet);
    goalEventsHandled.add(goalEventKey);
    persistTrackedPredictions();
    persistManagedTweets();
    persistHandledEvents();
  }

  return { success: true, tracked, liveResult, tweet: createdTweet, publishResult: pubResult };
}

export async function simulateGoalForMatch(params: {
  matchId: string;
  scoringTeam: "home" | "away";
  scorerName?: string;
  minute?: string;
  authToken?: string;
  ct0?: string;
  booster1AuthToken?: string;
  booster1Ct0?: string;
  booster2AuthToken?: string;
  booster2Ct0?: string;
}): Promise<{ success: boolean; tweet?: ScheduledTweetRecord; message?: string; publishResult?: any }> {
  const tracked = findTrackedByIdOrKey(params.matchId);
  if (!tracked) {
    return { success: false, message: "Match non trouvé dans le suivi en direct." };
  }

  const currentScoreHome = tracked.scoreHome ?? 0;
  const currentScoreAway = tracked.scoreAway ?? 0;

  const newHomeScore = params.scoringTeam === "home" ? currentScoreHome + 1 : currentScoreHome;
  const newAwayScore = params.scoringTeam === "away" ? currentScoreAway + 1 : currentScoreAway;
  const minute = params.minute || `${Math.floor(Math.random() * 40) + 48}'`;

  const res = await updateMatchLiveScoreManual({
    matchId: tracked.id,
    scoreHome: newHomeScore,
    scoreAway: newAwayScore,
    isLive: true,
    isFinished: false,
    liveMinute: minute,
    scorerName: params.scorerName,
    scoringTeam: params.scoringTeam,
    authToken: params.authToken,
    ct0: params.ct0,
    booster1AuthToken: params.booster1AuthToken,
    booster1Ct0: params.booster1Ct0,
    booster2AuthToken: params.booster2AuthToken,
    booster2Ct0: params.booster2Ct0,
  });

  return {
    success: true,
    tweet: res.tweet,
    publishResult: res.publishResult,
    message: `⚽ But enregistré : ${tracked.homeTeam} ${newHomeScore}-${newAwayScore} ${tracked.awayTeam} (${minute})`,
  };
}

export async function simulateFTForMatch(params: {
  matchId: string;
  scoreHome?: number;
  scoreAway?: number;
}): Promise<{ success: boolean; tweet?: ScheduledTweetRecord; message?: string }> {
  const tracked = findTrackedByIdOrKey(params.matchId);
  if (!tracked) {
    return { success: false, message: "Match non trouvé dans le suivi en direct." };
  }

  if (tracked.status === "SKIPPED_SLOT_DUPLICATE") {
    tracked.status = "LIVE";
    tracked.isAutoSelectedSlot = true;
  }
  tracked.debriefTweetSent = false;
  tracked.isQueued = false;
  finishedMatchesHandled.delete(tracked.id);

  const finalHome = params.scoreHome !== undefined ? params.scoreHome : (tracked.scoreHome ?? 2);
  const finalAway = params.scoreAway !== undefined ? params.scoreAway : (tracked.scoreAway ?? 1);

  setManualMatchScore(tracked.homeTeam, tracked.awayTeam, {
    scoreHome: finalHome,
    scoreAway: finalAway,
    isLive: false,
    isFinished: true,
    liveMinute: "FT",
    statusText: "Final",
    league: tracked.competition,
  });

  const res = await checkAndProcessLiveGoalsAndFT();
  const createdTweet = res.newTweets.find(
    (t) => t.type === "RECAP_FT" && t.pronoId === tracked.id
  );

  return {
    success: true,
    tweet: createdTweet,
    message: `🏁 Fin de match simulée : ${tracked.homeTeam} ${finalHome}-${finalAway} ${tracked.awayTeam} (débrief en file)`,
  };
}

export async function dispatchAllPendingDebriefs(): Promise<{
  dispatchedCount: number;
  newTweets: ScheduledTweetRecord[];
}> {
  const checkRes = await checkAndProcessLiveGoalsAndFT();
  let dispatchedCount = checkRes.finishedCount;
  const newTweets = [...checkRes.newTweets];

  const tracked = getTrackedPredictions();
  const liveScores = await fetchLiveScoresForLeagues();

  for (const pred of tracked) {
    if (pred.status === "SKIPPED_SLOT_DUPLICATE" || pred.isAutoSelectedSlot === false) continue;
    if (pred.debriefTweetSent || pred.isQueued) continue;

    const matchScore = findMatchScore(pred.homeTeam, pred.awayTeam, liveScores);
    const timing = parseMatchDateTime(pred.date, pred.kickoffTime);
    const isFinished = matchScore?.isFinished || (timing.isPastKickoff && timing.totalDiffMinutes < -120);
    if (!isFinished) continue;

    // Only dispatch if we have a real score (avoid fake 0-0 debriefs when score unavailable)
    if (!matchScore && pred.scoreHome === undefined && pred.scoreAway === undefined) continue;

    const scoreHome = matchScore ? matchScore.scoreHome : (pred.scoreHome ?? 0);
    const scoreAway = matchScore ? matchScore.scoreAway : (pred.scoreAway ?? 0);
    const isWon = evaluatePredictionWon(
      pred.prediction,
      scoreHome,
      scoreAway,
      pred.homeTeam,
      pred.awayTeam
    );

    pred.finalScore = `${scoreHome}-${scoreAway}`;
    pred.scoreHome = scoreHome;
    pred.scoreAway = scoreAway;
    pred.isWon = isWon;

    const ftTweetText = generateResultTweetText(
      {
        homeTeam: pred.homeTeam,
        awayTeam: pred.awayTeam,
        competition: pred.competition,
        odds: pred.odd,
        prediction: pred.prediction,
      },
      scoreHome,
      scoreAway,
      isWon
    );
    pred.debriefTweetText = ftTweetText;

    const ftTweet: ScheduledTweetRecord = {
      id: `ft-${pred.id}-${Date.now()}`,
      pronoId: pred.id,
      matchTitle: `${pred.homeTeam} ${scoreHome}-${scoreAway} ${pred.awayTeam}`,
      homeTeam: pred.homeTeam,
      awayTeam: pred.awayTeam,
      competition: pred.competition,
      date: pred.date,
      kickoffTime: pred.kickoffTime,
      type: "RECAP_FT",
      tweetText: ftTweetText,
      scheduledTimeLabel: "Terminé (FT)",
      status: "SCHEDULED",
      createdAt: Date.now(),
      odd: pred.odd,
      prediction: pred.prediction,
      isWon,
      scoreHome,
      scoreAway,
    };

    const queued = enqueueTweet({
      tweetText: ftTweetText,
      type: "RECAP_FT",
      matchTitle: `${pred.homeTeam} ${scoreHome}-${scoreAway} ${pred.awayTeam}`,
      inReplyToTweetId: pred.publishedTweetId,
      priority: "NORMAL",
      metadata: {
        pronoId: pred.id,
        finalScore: pred.finalScore,
        isWon,
      },
    });

    if (queued) {
      pred.isQueued = true;
      dispatchedCount++;
      allManagedTweets.unshift(ftTweet);
      newTweets.push(ftTweet);
    }
  }

  persistTrackedPredictions();
  persistManagedTweets();

  return { dispatchedCount, newTweets };
}

export function getDebriefTweetTextForMatch(matchId: string): {
  tweetText: string;
  finalScore: string;
  isWon: boolean;
  scoreHome: number;
  scoreAway: number;
} | null {
  const pred = findTrackedByIdOrKey(matchId);
  if (!pred) return null;

  const scoreHome = pred.scoreHome ?? 0;
  const scoreAway = pred.scoreAway ?? 0;
  const isWon =
    pred.isWon !== undefined
      ? pred.isWon
      : evaluatePredictionWon(
          pred.prediction,
          scoreHome,
          scoreAway,
          pred.homeTeam,
          pred.awayTeam
        );

  const tweetText =
    pred.debriefTweetText ||
    generateResultTweetText(
      {
        homeTeam: pred.homeTeam,
        awayTeam: pred.awayTeam,
        competition: pred.competition,
        odds: pred.odd,
        prediction: pred.prediction,
      },
      scoreHome,
      scoreAway,
      isWon
    );

  return {
    tweetText,
    finalScore: pred.finalScore || `${scoreHome}-${scoreAway}`,
    isWon,
    scoreHome,
    scoreAway,
  };
}

export async function publishSingleDebriefNow(matchId: string): Promise<{
  success: boolean;
  message: string;
  tweetText: string;
  intentUrl: string;
  isWon: boolean;
}> {
  const pred = findTrackedByIdOrKey(matchId);
  if (!pred) {
    return {
      success: false,
      message: "Match non trouvé dans la liste.",
      tweetText: "",
      intentUrl: "",
      isWon: false,
    };
  }

  const debriefData = getDebriefTweetTextForMatch(pred.id);
  if (!debriefData) {
    return {
      success: false,
      message: "Impossible de générer le débrief pour ce match.",
      tweetText: "",
      intentUrl: "",
      isWon: false,
    };
  }

  const { tweetText, isWon, finalScore } = debriefData;
  const intentUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(tweetText)}`;

  const queued = enqueueTweet({
    tweetText,
    type: "RECAP_FT",
    matchTitle: `${pred.homeTeam} ${finalScore} ${pred.awayTeam}`,
    inReplyToTweetId: pred.publishedTweetId,
    priority: "HIGH",
    metadata: {
      pronoId: pred.id,
      finalScore,
      isWon,
    },
  });

  if (queued) {
    pred.isQueued = true;
    pred.debriefTweetText = tweetText;
    persistTrackedPredictions();
  }

  return {
    success: true,
    message: queued
      ? `✅ Débrief mis en file d'attente pour ${pred.homeTeam} vs ${pred.awayTeam}`
      : `ℹ️ Débrief déjà en file ou publié récemment.`,
    tweetText,
    intentUrl,
    isWon,
  };
}
