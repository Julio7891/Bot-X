#!/usr/bin/env node
/**
 * ⚽ FOOTBALL X-BOT PRO - TERMINAL CLI INTERFACE
 * 100% Free Autonomous Bot without paid Twitter/X API ($100/mo saved)
 * 
 * Run interactively: npm run cli
 * Run as daemon/background bot: npm run bot (or tsx scripts/cli.ts --daemon)
 */

import readline from "readline";
import fs from "fs";
import path from "path";
import dotenv from "dotenv";
import {
  testXCookies,
  updateServerXCredentials,
  getServerXCredentials,
  publishTweetToX,
  setPublishingMode,
  getPublishingMode,
  likeTweetWithAllAccounts,
  getCookieHealth,
} from "../server/xPublisher";
import {
  syncSportyTraderAndGenerateTweets,
  runAutoPilotCycle,
  getTrackedPredictions,
  getAllManagedTweets,
  setAutoPilotEnabled,
  unlockFailedUpcomingMatchesForRetry,
} from "../server/autoTweetPipeline";
import { processQueueTick } from "../server/tweetQueue";
import { getParisNow } from "../server/dateScheduler";

dotenv.config();

// ANSI color helpers
const colors = {
  reset: "\x1b[0m",
  bold: "\x1b[1m",
  dim: "\x1b[2m",
  green: "\x1b[32m",
  cyan: "\x1b[36m",
  yellow: "\x1b[33m",
  red: "\x1b[31m",
  blue: "\x1b[34m",
  magenta: "\x1b[35m",
  white: "\x1b[37m",
  bgGreen: "\x1b[42m\x1b[30m",
  bgBlue: "\x1b[44m\x1b[37m",
};

function banner() {
  console.clear();
  console.log(`
${colors.cyan}╔═══════════════════════════════════════════════════════════════════════╗
║   ⚽  ${colors.bold}${colors.white}FOOTBALL X-BOT PRO — TERMINAL CLI RUNNER${colors.reset}${colors.cyan}                    ║
║   ${colors.green}100% GRATUIT${colors.cyan} | ${colors.yellow}ZÉRO API TWITTER PAYANTE${colors.cyan} | ${colors.magenta}SESSION COOKIES WEB${colors.cyan}         ║
╚═══════════════════════════════════════════════════════════════════════╝${colors.reset}
`);
}

function prompt(rl: readline.Interface, questionText: string): Promise<string> {
  return new Promise((resolve) => {
    rl.question(questionText, (answer) => {
      resolve(answer.trim());
    });
  });
}

function formatStatusLine() {
  const creds = getServerXCredentials();
  const hasCookies = Boolean(creds.authToken && creds.ct0);
  const mode = getPublishingMode();
  const tracked = getTrackedPredictions();
  const scheduledCount = tracked.filter((t) => t.status === "SCHEDULED").length;
  const liveCount = tracked.filter((t) => t.status === "LIVE").length;
  const tweets = getAllManagedTweets();

  console.log(
    `${colors.dim}-----------------------------------------------------------------------${colors.reset}`
  );
  console.log(
    ` ${colors.bold}Compte X :${colors.reset} ${
      hasCookies
        ? `${colors.green}● CONNECTÉ (Cookies Web)${colors.reset}`
        : `${colors.red}○ NON CONFIGURÉ (Mode Simulation)${colors.reset}`
    }  |  ${colors.bold}Mode :${colors.reset} ${colors.yellow}${mode}${colors.reset}`
  );
  console.log(
    ` ${colors.bold}Matchs programmés :${colors.reset} ${colors.cyan}${scheduledCount}${colors.reset}  |  ${colors.bold}En direct :${colors.reset} ${colors.magenta}${liveCount}${colors.reset}  |  ${colors.bold}Tweets générés :${colors.reset} ${tweets.length}`
  );
  console.log(
    `${colors.dim}-----------------------------------------------------------------------${colors.reset}`
  );
}

/**
 * Interactive wizard to setup X cookies
 */
async function configureXCredentials(rl: readline.Interface) {
  banner();
  console.log(`${colors.bold}${colors.yellow}🔑 CONFIGURATION COMPTE X (100% GRATUIT - SANS API PAYANTE)${colors.reset}\n`);
  console.log(`${colors.dim}Pour publier sans payer l'abonnement Twitter ($100+/mois), nous utilisons${colors.reset}`);
  console.log(`${colors.dim}les cookies de session de votre compte X connecté sur navigateur :${colors.reset}\n`);
  console.log(`  ${colors.cyan}1.${colors.reset} Ouvrez ${colors.bold}https://x.com${colors.reset} dans Chrome, Edge ou Brave en étant connecté.`);
  console.log(`  ${colors.cyan}2.${colors.reset} Appuyez sur ${colors.bold}F12${colors.reset} (ou Clic droit -> Inspecter) puis onglet ${colors.bold}Application${colors.reset} (ou Stockage).`);
  console.log(`  ${colors.cyan}3.${colors.reset} Dans le menu gauche : ${colors.bold}Cookies${colors.reset} -> ${colors.bold}https://x.com${colors.reset}.`);
  console.log(`  ${colors.cyan}4.${colors.reset} Copiez la valeur de ${colors.bold}${colors.green}auth_token${colors.reset} et de ${colors.bold}${colors.green}ct0${colors.reset}.\n`);

  const currentCreds = getServerXCredentials();
  if (currentCreds.authToken) {
    console.log(`${colors.dim}Un auth_token actuel est déjà enregistré (${currentCreds.authToken.slice(0, 8)}...).${colors.reset}`);
  }

  const authToken = await prompt(
    rl,
    `${colors.bold}Collez votre cookie auth_token (ou Entrée pour conserver) : ${colors.reset}`
  );
  const ct0 = await prompt(
    rl,
    `${colors.bold}Collez votre cookie ct0 (ou Entrée pour conserver) : ${colors.reset}`
  );

  const newAuthToken = authToken || currentCreds.authToken || "";
  const newCt0 = ct0 || currentCreds.ct0 || "";

  if (!newAuthToken || !newCt0) {
    console.log(`\n${colors.red}❌ Les deux cookies auth_token et ct0 sont nécessaires.${colors.reset}`);
    await prompt(rl, `\nAppuyez sur Entrée pour revenir au menu...`);
    return;
  }

  console.log(`\n${colors.cyan}⏳ Test de connexion en cours auprès de x.com...${colors.reset}`);
  const testRes = await testXCookies(newAuthToken, newCt0);

  if (testRes.status === "OK") {
    updateServerXCredentials({
      authToken: newAuthToken,
      ct0: newCt0,
      publishingMode: "LIVE_COOKIES",
    });
    setPublishingMode("LIVE_COOKIES");
    unlockFailedUpcomingMatchesForRetry();
    console.log(`\n${colors.green}✅ SUCCÈS ! ${testRes.message}${colors.reset}`);
    if (testRes.username) {
      console.log(`${colors.green}Compte vérifié : @${testRes.username}${colors.reset}`);
    }
    console.log(`${colors.green}Mode de publication : LIVE_COOKIES (100% cookies gratuit)${colors.reset}`);
  } else {
    console.log(`\n${colors.yellow}⚠️ Le test direct a renvoyé : ${testRes.message}${colors.reset}`);
    console.log(`${colors.dim}Explication : ${testRes.explanation}${colors.reset}`);
    console.log(`${colors.dim}Solution : ${testRes.solution}${colors.reset}`);
    const saveAnyway = await prompt(
      rl,
      `Voulez-vous enregistrer ces cookies malgré tout ? (o/n) : `
    );
    if (saveAnyway.toLowerCase() === "o" || saveAnyway.toLowerCase() === "y") {
      updateServerXCredentials({
        authToken: newAuthToken,
        ct0: newCt0,
        publishingMode: "LIVE_COOKIES",
      });
      console.log(`${colors.green}✅ Cookies enregistrés en mode LIVE_COOKIES.${colors.reset}`);
    }
  }

  await prompt(rl, `\nAppuyez sur Entrée pour continuer...`);
}

/**
 * Configure booster accounts
 */
async function configureBoosterAccounts(rl: readline.Interface) {
  banner();
  console.log(`${colors.bold}${colors.magenta}🚀 COMPTES BOOSTERS SATELLITES (MULTI-LIKE AUTOMATIQUE)${colors.reset}\n`);
  console.log(`${colors.dim}Ces comptes secondaires likent automatiquement vos tweets dès leur publication.${colors.reset}`);
  console.log(`${colors.dim}Cela booste le tweet dans l'algorithme 'Pour Vous' et prévient le shadowban.${colors.reset}\n`);

  const creds = getServerXCredentials();
  console.log(`${colors.bold}Compte Booster #1 :${colors.reset}`);
  const b1Auth = await prompt(rl, `auth_token Booster 1 (actuel: ${creds.booster1AuthToken ? "Configuré" : "Vide"}) : `);
  const b1Ct0 = await prompt(rl, `ct0 Booster 1 : `);

  console.log(`\n${colors.bold}Compte Booster #2 (Optionnel) :${colors.reset}`);
  const b2Auth = await prompt(rl, `auth_token Booster 2 (actuel: ${creds.booster2AuthToken ? "Configuré" : "Vide"}) : `);
  const b2Ct0 = await prompt(rl, `ct0 Booster 2 : `);

  updateServerXCredentials({
    booster1AuthToken: b1Auth || creds.booster1AuthToken || "",
    booster1Ct0: b1Ct0 || creds.booster1Ct0 || "",
    booster2AuthToken: b2Auth || creds.booster2AuthToken || "",
    booster2Ct0: b2Ct0 || creds.booster2Ct0 || "",
  });

  console.log(`\n${colors.green}✅ Comptes boosters configurés avec succès !${colors.reset}`);
  await prompt(rl, `\nAppuyez sur Entrée pour continuer...`);
}

/**
 * Send a quick test tweet
 */
async function sendTestTweet(rl: readline.Interface) {
  banner();
  console.log(`${colors.bold}${colors.cyan}🧪 TEST DE PUBLICATION INSTANTANÉE SUR X${colors.reset}\n`);

  const defaultText = `⚽ Test du Football X-Bot Pro à ${new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })} ! Prêt pour les pronos du soir. #Football #Pronos`;
  console.log(`Texte par défaut :\n"${colors.white}${defaultText}${colors.reset}"\n`);

  const customText = await prompt(rl, `Personnaliser le texte (ou Entrée pour garder le texte test) : `);
  const textToSend = customText || defaultText;

  console.log(`\n${colors.cyan}⏳ Envoi du tweet via cookies de session...${colors.reset}`);
  const res = await publishTweetToX({ tweetText: textToSend });

  if (res.success) {
    console.log(`\n${colors.green}🎉 TWEET PUBLIÉ AVEC SUCCÈS !${colors.reset}`);
    if (res.tweetUrl) {
      console.log(`Lien du tweet : ${colors.blue}${res.tweetUrl}${colors.reset}`);
    }
    console.log(`Mode utilisé : ${colors.bold}${res.mode}${colors.reset}`);

    // Trigger auto-like if tweet ID returned
    if (res.tweetId) {
      console.log(`${colors.dim}Déclenchement du Multi-Like booster automatique...${colors.reset}`);
      await likeTweetWithAllAccounts(res.tweetId);
    }
  } else {
    console.log(`\n${colors.red}❌ Échec de publication : ${res.message}${colors.reset}`);
    if (res.error) console.log(`${colors.dim}Détails: ${res.error}${colors.reset}`);
  }

  await prompt(rl, `\nAppuyez sur Entrée pour continuer...`);
}

/**
 * Sync SportyTrader & schedule matches with Premier League priority
 */
async function syncAndSchedule(rl: readline.Interface) {
  banner();
  console.log(`${colors.bold}${colors.green}⚽ SYNCHRONISATION LIVE (SPORTYTRADER / ESPN + IA) & PLANIFICATION H-1${colors.reset}\n`);
  console.log(`${colors.cyan}⏳ Récupération des matchs du jour et arbitrage anti-collision (75 min)...${colors.reset}`);

  try {
    const syncRes = await syncSportyTraderAndGenerateTweets();
    const tracked = getTrackedPredictions();
    const retained = tracked.filter((t) => t.status !== "SKIPPED_SLOT_DUPLICATE");
    const skipped = tracked.filter((t) => t.status === "SKIPPED_SLOT_DUPLICATE");

    console.log(`\n${colors.bold}${colors.green}✔ PLANIFICATION TERMINÉE (${syncRes.source}) !${colors.reset}`);
    console.log(`  • Info source : ${colors.dim}${syncRes.sourceMessage}${colors.reset}`);
    console.log(`  • Matchs retenus (zéro superposition) : ${colors.bold}${retained.length}${colors.reset}`);
    console.log(`  • Doublons horaires (<75min) écartés : ${colors.bold}${skipped.length}${colors.reset}\n`);

    console.log(`${colors.bold}Aperçu des matchs programmés :${colors.reset}`);
    retained.slice(0, 8).forEach((m, idx) => {
      console.log(
        `  ${idx + 1}. [${m.date} à ${m.kickoffTime}] ${colors.bold}${m.homeTeam} vs ${m.awayTeam}${colors.reset} (${m.competition}) -> ${m.prediction} @ ${m.odd}`
      );
    });
  } catch (e: any) {
    console.log(`${colors.red}❌ Erreur de synchronisation : ${e.message}${colors.reset}`);
  }

  await prompt(rl, `\nAppuyez sur Entrée pour continuer...`);
}

/**
 * View queue and matches
 */
async function viewQueueAndMatches(rl: readline.Interface) {
  banner();
  console.log(`${colors.bold}${colors.cyan}📊 LISTE DES MATCHS ET STATUTS DU JOUR${colors.reset}\n`);

  const tracked = getTrackedPredictions();
  if (tracked.length === 0) {
    console.log(`${colors.yellow}Aucun match actuellement suivi. Lancez une synchronisation d'abord (Option 4).${colors.reset}`);
  } else {
    console.log(`${colors.bold}Matchs programmés ou en cours :${colors.reset}\n`);
    tracked.forEach((m, idx) => {
      const statusBadge =
        m.status === "PUBLISHED"
          ? `${colors.green}[PUBLIÉ]${colors.reset}`
          : m.status === "LIVE"
          ? `${colors.magenta}[EN DIRECT]${colors.reset}`
          : m.status === "SKIPPED_SLOT_DUPLICATE"
          ? `${colors.dim}[DOUBLON ÉCARTÉ]${colors.reset}`
          : `${colors.cyan}[PROGRAMMÉ H-1]${colors.reset}`;

      console.log(
        `  ${idx + 1}. ${statusBadge} ${m.date} à ${colors.bold}${m.kickoffTime}${colors.reset} : ${m.homeTeam} vs ${m.awayTeam} (${m.competition})`
      );
      if (m.scoreHome !== undefined && m.scoreAway !== undefined) {
        console.log(
          `     ${colors.dim}↳ Score: ${m.scoreHome} - ${m.scoreAway} (${m.lastLiveMinute || "En cours"})${colors.reset}`
        );
      } else if (m.finalScore) {
        console.log(
          `     ${colors.dim}↳ Score Final: ${m.finalScore}${colors.reset}`
        );
      }
    });
  }

  await prompt(rl, `\nAppuyez sur Entrée pour continuer...`);
}

/**
 * Toggle publishing mode
 */
async function togglePublishingMode(rl: readline.Interface) {
  banner();
  console.log(`${colors.bold}${colors.yellow}⚙️ SÉLECTION DU MODE DE PUBLICATION${colors.reset}\n`);
  console.log(`Mode actuel : ${colors.bold}${getPublishingMode()}${colors.reset}\n`);

  console.log(`  ${colors.bold}1.${colors.reset} LIVE_COOKIES : Publication réelle 100% gratuite via vos cookies auth_token + ct0`);
  console.log(`  ${colors.bold}2.${colors.reset} SIMULATION   : Mode test local (ne publie rien sur X)`);

  const choice = await prompt(rl, `\nVotre choix (1 ou 2) : `);
  if (choice === "1") {
    setPublishingMode("LIVE_COOKIES");
    console.log(`\n${colors.green}✔ Mode LIVE_COOKIES activé !${colors.reset}`);
  } else if (choice === "2") {
    setPublishingMode("SIMULATION");
    console.log(`\n${colors.yellow}✔ Mode SIMULATION activé !${colors.reset}`);
  }

  await prompt(rl, `\nAppuyez sur Entrée pour continuer...`);
}

/**
 * Run autonomous 24/7 daemon directly in terminal (auto re-sync every 30 min + 30s live cycle)
 */
async function runDaemonLoop() {
  banner();
  console.log(`${colors.bgGreen} 🤖 DÉMARRAGE DU BOT AUTONOME 24/7 (100% COOKIES, ZÉRO API PAYANTE) ${colors.reset}\n`);
  console.log(`${colors.dim}Automatisation complète en continu :${colors.reset}`);
  console.log(`  • ${colors.cyan}Sync Auto toutes les 30 min${colors.reset} : SportyTrader Live + fallback ESPN Live & IA`);
  console.log(`  • ${colors.cyan}Publication H-1h${colors.reset} : 1 match max par fenêtre de 75 min (zéro superposition)`);
  console.log(`  • ${colors.magenta}Détection Buts Live${colors.reset} : Réponse thread instantanée à chaque but`);
  console.log(`  • ${colors.yellow}Débrief Fin de Match & Bilan 23h30${colors.reset} : Validation automatique du prono\n`);
  console.log(`${colors.bold}Appuyez sur Ctrl+C à tout moment pour arrêter le bot.${colors.reset}\n`);
  console.log(`${colors.dim}-----------------------------------------------------------------------${colors.reset}`);

  setAutoPilotEnabled(true);

  // Verify X cookies on startup
  const creds = getServerXCredentials();
  if (creds.authToken && creds.ct0) {
    console.log(`[${new Date().toLocaleTimeString("fr-FR")}] 🔑 Vérification de la session X (cookies)...`);
    const testRes = await testXCookies(creds.authToken, creds.ct0);
    if (testRes.success) {
      console.log(`[${new Date().toLocaleTimeString("fr-FR")}] ${colors.green}✔ Connecté sur X ${testRes.username ? `(@${testRes.username})` : ""}${colors.reset}`);
    } else {
      console.log(`[${new Date().toLocaleTimeString("fr-FR")}] ${colors.red}⚠️ Alerte cookies X : ${testRes.message}${colors.reset}`);
      console.log(`   ${colors.dim}↳ ${testRes.solution}${colors.reset}`);
    }
  } else {
    console.log(`[${new Date().toLocaleTimeString("fr-FR")}] ${colors.yellow}⚠️ Aucun cookie X configuré (mode ${getPublishingMode()}). Lancez 'npm run cli' option 1.${colors.reset}`);
  }

  let lastSyncTs = 0;
  let lastSyncDate = "";

  const ensureFreshSync = async () => {
    const now = Date.now();
    const parisToday = getParisNow().isoDate;
    if (now - lastSyncTs >= 30 * 60 * 1000 || lastSyncDate !== parisToday || getTrackedPredictions().length === 0) {
      const nowStr = new Date().toLocaleTimeString("fr-FR");
      console.log(`[${nowStr}] 🔄 Synchronisation des matchs en cours...`);
      try {
        const res = await syncSportyTraderAndGenerateTweets();
        lastSyncTs = Date.now();
        lastSyncDate = parisToday;
        console.log(`[${nowStr}] ${colors.green}✔ Sync (${res.source}) : ${res.pronos.length} match(s). ${res.sourceMessage}${colors.reset}`);
      } catch (e: any) {
        console.warn(`[${nowStr}] ⚠️ Erreur sync :`, e.message);
      }
    }
  };

  await ensureFreshSync();

  let cycleIndex = 0;

  const cycle = async () => {
    cycleIndex++;
    const nowStr = new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
    try {
      await ensureFreshSync();
      const res = await runAutoPilotCycle();
      await processQueueTick();

      if (res.h1PublishedCount > 0) {
        console.log(`[${nowStr}] ${colors.green}🎯 H-1 ENFILÉ : ${res.h1PublishedCount} prono(s) !${colors.reset}`);
      }
      if (res.goalsDetected > 0) {
        console.log(`[${nowStr}] ${colors.magenta}⚽ BUT DÉTECTÉ : ${res.goalsDetected} alerte(s) live !${colors.reset}`);
      }
      if (res.finishedCount > 0) {
        console.log(`[${nowStr}] ${colors.yellow}🏁 FIN DE MATCH : ${res.finishedCount} débrief(s) !${colors.reset}`);
      }
      if (cycleIndex % 10 === 0) {
        const trackedMatches = getTrackedPredictions();
        const scheduled = trackedMatches.filter((t) => t.status === "SCHEDULED").length;
        const live = trackedMatches.filter((t) => t.status === "LIVE" || t.status === "PUBLISHED").length;
        const health = getCookieHealth();
        console.log(
          `[${nowStr}] ${colors.dim}● Veille active - ${scheduled} programmé(s), ${live} actif(s) | X: ${health.status}${health.username ? ` (@${health.username})` : ""}${colors.reset}`
        );
      }
    } catch (err: any) {
      console.error(`[${nowStr}] ${colors.red}❌ Erreur cycle auto-pilot :${colors.reset}`, err.message);
    }
  };

  await cycle();
  setInterval(cycle, 30_000);
}

/**
 * Main Interactive Menu
 */
async function main() {
  const args = process.argv.slice(2);
  if (args.includes("--daemon") || args.includes("-d") || args.includes("--start")) {
    await runDaemonLoop();
    return;
  }

  if (args.includes("--test")) {
    const creds = getServerXCredentials();
    console.log("Testing X cookies...");
    const res = await testXCookies(creds.authToken || "", creds.ct0 || "");
    console.log(res);
    process.exit(0);
  }

  if (args.includes("--sync")) {
    console.log("Syncing live matches...");
    const r = await syncSportyTraderAndGenerateTweets();
    console.log({
      source: r.source,
      message: r.sourceMessage,
      pronosCount: r.pronos.length,
    });
    process.exit(0);
  }

  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  while (true) {
    banner();
    formatStatusLine();

    console.log(`${colors.bold}MENU PRINCIPAL :${colors.reset}`);
    console.log(`  ${colors.green}1.${colors.reset} 🔑 Configurer le compte X principal ${colors.dim}(Cookies auth_token + ct0 gratuits)${colors.reset}`);
    console.log(`  ${colors.magenta}2.${colors.reset} 🚀 Configurer les comptes Boosters ${colors.dim}(Multi-Like anti-shadowban)${colors.reset}`);
    console.log(`  ${colors.cyan}3.${colors.reset} 🧪 Tester la publication d'un Tweet instantané sur X`);
    console.log(`  ${colors.yellow}4.${colors.reset} ⚽ Synchroniser SportyTrader & Planifier H-1 ${colors.dim}(Anti-collision)${colors.reset}`);
    console.log(`  ${colors.bold}5.${colors.reset} 🤖 Démarrer le Bot Autonome en direct ${colors.dim}(Veille continue H-1, Buts, FT)${colors.reset}`);
    console.log(`  ${colors.white}6.${colors.reset} 📊 Voir la liste des matchs suivis et la file d'attente`);
    console.log(`  ${colors.dim}7.${colors.reset} ⚙️ Changer le mode de publication ${colors.dim}(actuel: ${getPublishingMode()})${colors.reset}`);
    console.log(`  ${colors.red}8.${colors.reset} 🚪 Quitter`);

    const choice = await prompt(rl, `\n${colors.bold}Choisissez une option (1-8) : ${colors.reset}`);

    switch (choice) {
      case "1":
        await configureXCredentials(rl);
        break;
      case "2":
        await configureBoosterAccounts(rl);
        break;
      case "3":
        await sendTestTweet(rl);
        break;
      case "4":
        await syncAndSchedule(rl);
        break;
      case "5":
        rl.close();
        await runDaemonLoop();
        return;
      case "6":
        await viewQueueAndMatches(rl);
        break;
      case "7":
        await togglePublishingMode(rl);
        break;
      case "8":
      case "q":
      case "quit":
        console.log(`\n${colors.cyan}Au revoir ! Merci d'avoir utilisé Football X-Bot Pro.${colors.reset}\n`);
        rl.close();
        process.exit(0);
      default:
        console.log(`${colors.red}Option invalide.${colors.reset}`);
        await new Promise((r) => setTimeout(r, 800));
        break;
    }
  }
}

main().catch((e) => {
  console.error("Fatal error:", e);
  process.exit(1);
});
