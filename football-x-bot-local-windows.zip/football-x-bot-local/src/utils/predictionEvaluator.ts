export interface PredictionEvaluation {
  isWon: boolean;
  explanation: string;
  roiImpact: string;
  statusEmoji: "✅" | "❌";
}

/**
 * Normalizes French or raw market texts into clear, international English betting terms
 */
export function formatPredictionToEnglish(
  prediction: string,
  homeTeam: string = "",
  awayTeam: string = ""
): string {
  if (!prediction) return `${homeTeam || "Home"} to Win`;
  const p = prediction.trim();
  const pLower = p.toLowerCase();

  // Over / Under goals
  if (pLower.includes("over 2.5") || pLower.includes("+2.5") || pLower.includes("plus de 2.5") || pLower.includes("plus de 2,5")) {
    if (pLower.includes("barcelone") || pLower.includes("barcelona") || pLower.includes("victoire")) {
      return `${homeTeam || awayTeam || "Favorite"} Win & Over 2.5 Goals`;
    }
    return "Over 2.5 Goals";
  }
  if (pLower.includes("under 2.5") || pLower.includes("-2.5") || pLower.includes("moins de 2.5") || pLower.includes("moins de 2,5")) {
    return "Under 2.5 Goals";
  }
  if (pLower.includes("over 1.5") || pLower.includes("+1.5") || pLower.includes("plus de 1.5") || pLower.includes("plus de 1,5")) {
    return "Over 1.5 Goals";
  }
  if (pLower.includes("under 3.5") || pLower.includes("-3.5") || pLower.includes("moins de 3.5") || pLower.includes("moins de 3,5")) {
    return "Under 3.5 Goals";
  }
  if (pLower.includes("over 3.5") || pLower.includes("+3.5") || pLower.includes("plus de 3.5")) {
    return "Over 3.5 Goals";
  }

  // BTTS (Both Teams To Score)
  if (pLower.includes("les deux équipes marquent") || pLower.includes("les 2 équipes marquent") || pLower.includes("les 2 marquent") || pLower.includes("deux équipes marquent")) {
    if (pLower.includes("ou nul") || pLower.includes("or draw")) {
      return `${homeTeam || "Home"} or Draw & BTTS (Yes)`;
    }
    return "Both Teams to Score (BTTS - Yes)";
  }
  if (pLower.includes("btts")) {
    return "Both Teams to Score (BTTS)";
  }

  // Double Chance combinations
  if (pLower.includes("ou nul et les deux équipes marquent") || pLower.includes("ou nul & btts")) {
    const team = pLower.includes("atletico") ? "Atlético Madrid" : pLower.includes("milan") ? "AC Milan" : homeTeam || "Home";
    return `${team} or Draw & BTTS (Yes)`;
  }

  if (pLower.includes("ou nul et plus de 2") || pLower.includes("ou nul & over 2.5")) {
    const team = pLower.includes("milan") ? "AC Milan" : homeTeam || "Home";
    return `${team} or Draw & Over 2.5 Goals`;
  }

  if (pLower.includes("ou nul") || pLower.includes("ou n")) {
    if (homeTeam && pLower.includes(homeTeam.toLowerCase().slice(0, 4))) {
      return `${homeTeam} or Draw (1X)`;
    }
    if (awayTeam && pLower.includes(awayTeam.toLowerCase().slice(0, 4))) {
      return `${awayTeam} or Draw (X2)`;
    }
    return "Double Chance (1X)";
  }

  // 1X2 Win
  if (pLower.includes("victoire") || pLower.includes("gagne") || pLower.includes("win")) {
    if (homeTeam && pLower.includes(homeTeam.toLowerCase().slice(0, 4))) {
      if (pLower.includes("2+ buts") || pLower.includes("handicap")) {
        return `${homeTeam} to Win (-1.5 Handicap)`;
      }
      return `${homeTeam} to Win`;
    }
    if (awayTeam && pLower.includes(awayTeam.toLowerCase().slice(0, 4))) {
      if (pLower.includes("2+ buts") || pLower.includes("handicap")) {
        return `${awayTeam} to Win (-1.5 Handicap)`;
      }
      return `${awayTeam} to Win`;
    }
    if (pLower.includes("domicile") || p === "1") return `${homeTeam || "Home"} to Win`;
    if (pLower.includes("extérieur") || p === "2") return `${awayTeam || "Away"} to Win`;
  }

  if (pLower === "1" || pLower === "1x") return `${homeTeam || "Home"} to Win`;
  if (pLower === "2" || pLower === "x2") return `${awayTeam || "Away"} to Win`;
  if (pLower === "n" || pLower === "x" || pLower.includes("nul") || pLower.includes("draw")) return "Match Draw (X)";

  // Clean raw team gagne
  if (p.endsWith(" gagne")) {
    return `${p.replace(" gagne", "")} to Win`;
  }
  if (p.startsWith("Victoire de ") || p.startsWith("Victoire du ")) {
    return `${p.replace(/^Victoire d[eu]\s+/i, "")} to Win`;
  }
  if (p.startsWith("Victoire ")) {
    return `${p.replace(/^Victoire\s+/i, "")} to Win`;
  }

  return p;
}

/**
 * Accurately and strictly evaluates whether a prediction won or lost based on the final match score.
 * Handles all standard football market types in French and English.
 */
export function evaluatePredictionResult(
  prediction: string,
  scoreHome: number,
  scoreAway: number,
  homeTeamName: string = "",
  awayTeamName: string = "",
  odd: string = "1.80"
): PredictionEvaluation {
  const p = (prediction || "").toLowerCase().trim();
  const totalGoals = scoreHome + scoreAway;
  const parsedOdd = parseFloat(odd) || 1.8;
  const profit = (parsedOdd - 1).toFixed(2);

  const homeNorm = homeTeamName.toLowerCase().trim();
  const awayNorm = awayTeamName.toLowerCase().trim();

  let isWon = false;
  let explanation = "";

  // 1. Over / Under Goals
  if (p.includes("over 2.5") || p.includes("+2.5") || p.includes("plus de 2.5") || p.includes("plus de 2,5")) {
    isWon = totalGoals >= 3;
    explanation = isWon
      ? `Over 2.5 Goals verified (${totalGoals} goals scored)`
      : `Under 3 goals (${totalGoals} goals scored)`;
  } else if (p.includes("under 2.5") || p.includes("-2.5") || p.includes("moins de 2.5") || p.includes("moins de 2,5")) {
    isWon = totalGoals <= 2;
    explanation = isWon
      ? `Under 2.5 Goals verified (${totalGoals} goals scored)`
      : `Over 2 goals (${totalGoals} goals scored)`;
  } else if (p.includes("over 1.5") || p.includes("+1.5") || p.includes("plus de 1.5")) {
    isWon = totalGoals >= 2;
    explanation = isWon
      ? `Over 1.5 Goals verified (${totalGoals} goals)`
      : `Under 2 goals (${totalGoals} goal)`;
  } else if (p.includes("under 3.5") || p.includes("-3.5") || p.includes("moins de 3.5")) {
    isWon = totalGoals <= 3;
    explanation = isWon
      ? `Under 3.5 Goals verified (${totalGoals} goals)`
      : `High scoring game (${totalGoals} goals)`;
  } else if (p.includes("over 3.5") || p.includes("+3.5") || p.includes("plus de 3.5")) {
    isWon = totalGoals >= 4;
    explanation = isWon
      ? `Over 3.5 Goals verified (${totalGoals} goals)`
      : `Only ${totalGoals} goals scored`;
  }
  // 2. Both Teams To Score (BTTS / Les 2 marquent)
  else if (p.includes("btts") || p.includes("les 2 marquent") || p.includes("deux équipes marquent") || p.includes("les 2 équipes marquent")) {
    isWon = scoreHome > 0 && scoreAway > 0;
    explanation = isWon
      ? `Both teams scored (${scoreHome}-${scoreAway})`
      : `At least one team failed to score (${scoreHome}-${scoreAway})`;
  }
  // 3. Margin of victory (ex: gagne par 2+ buts)
  else if (p.includes("2+ buts") || p.includes("au moins 2 buts") || p.includes("2 buts d'écart") || p.includes("-1.5")) {
    if (p.includes("victoire") || p.includes("gagne") || p.includes("win")) {
      const isHomeWinning = scoreHome > scoreAway && (scoreHome - scoreAway) >= 2;
      const isAwayWinning = scoreAway > scoreHome && (scoreAway - scoreHome) >= 2;
      
      if (homeNorm && p.includes(homeNorm.slice(0, 4))) {
        isWon = isHomeWinning;
      } else if (awayNorm && p.includes(awayNorm.slice(0, 4))) {
        isWon = isAwayWinning;
      } else {
        isWon = isHomeWinning;
      }
      explanation = isWon
        ? `Won by ${Math.abs(scoreHome - scoreAway)} goals margin verified`
        : `Goal margin insufficient (${scoreHome}-${scoreAway})`;
    }
  }
  // 4. Double Chance 1X / 1N
  else if (p.includes("1x") || p.includes("1n") || (p.includes("ou nul") || p.includes("or draw")) && (homeNorm && p.includes(homeNorm.slice(0, 4)) || p.includes("domicile") || p.includes("home"))) {
    isWon = scoreHome >= scoreAway;
    explanation = isWon
      ? `Double chance 1X verified (${scoreHome}-${scoreAway})`
      : `Away win (${scoreHome}-${scoreAway})`;
  }
  // 5. Double Chance X2 / N2
  else if (p.includes("x2") || p.includes("n2") || (p.includes("ou nul") || p.includes("or draw")) && (awayNorm && p.includes(awayNorm.slice(0, 4)) || p.includes("extérieur") || p.includes("away"))) {
    isWon = scoreAway >= scoreHome;
    explanation = isWon
      ? `Double chance X2 verified (${scoreHome}-${scoreAway})`
      : `Home win (${scoreHome}-${scoreAway})`;
  }
  // 6. Double Chance 12 (No Draw)
  else if (p.includes("12") || p.includes("pas de nul") || p.includes("no draw")) {
    isWon = scoreHome !== scoreAway;
    explanation = isWon
      ? `No draw verified (${scoreHome}-${scoreAway})`
      : `Draw result (${scoreHome}-${scoreAway})`;
  }
  // 7. Draw No Bet (DNB)
  else if (p.includes("dnb") || p.includes("remboursé si nul") || p.includes("draw no bet")) {
    if (homeNorm && p.includes(homeNorm.slice(0, 4))) {
      isWon = scoreHome > scoreAway;
    } else {
      isWon = scoreHome >= scoreAway;
    }
    explanation = isWon
      ? `DNB won (${scoreHome}-${scoreAway})`
      : `DNB missed (${scoreHome}-${scoreAway})`;
  }
  // 8. 1X2 Standard
  else if (p === "1" || p.includes("victoire 1") || (homeNorm && (p.includes(`victoire ${homeNorm.slice(0, 5)}`) || p.includes(`${homeNorm.slice(0, 5)} gagne`) || p.includes(`${homeNorm.slice(0, 5)} to win`)))) {
    isWon = scoreHome > scoreAway;
    explanation = isWon
      ? `Home win confirmed (${scoreHome}-${scoreAway})`
      : `No home win (${scoreHome}-${scoreAway})`;
  } else if (p === "2" || p.includes("victoire 2") || (awayNorm && (p.includes(`victoire ${awayNorm.slice(0, 5)}`) || p.includes(`${awayNorm.slice(0, 5)} gagne`) || p.includes(`${awayNorm.slice(0, 5)} to win`)))) {
    isWon = scoreAway > scoreHome;
    explanation = isWon
      ? `Away win confirmed (${scoreHome}-${scoreAway})`
      : `No away win (${scoreHome}-${scoreAway})`;
  } else if (p === "n" || p === "x" || p.includes("match nul") || p.includes("nul") || p.includes("draw")) {
    isWon = scoreHome === scoreAway;
    explanation = isWon
      ? `Draw confirmed (${scoreHome}-${scoreAway})`
      : `No draw (${scoreHome}-${scoreAway})`;
  }
  // Default fallback based on team names mentioned in prediction
  else {
    if (homeNorm && p.includes(homeNorm.slice(0, 4)) && !p.includes(awayNorm.slice(0, 4))) {
      isWon = scoreHome > scoreAway;
      explanation = isWon ? `${homeTeamName} win` : `${homeTeamName} failed to win`;
    } else if (awayNorm && p.includes(awayNorm.slice(0, 4)) && !p.includes(homeNorm.slice(0, 4))) {
      isWon = scoreAway > scoreHome;
      explanation = isWon ? `${awayTeamName} win` : `${awayTeamName} failed to win`;
    } else {
      isWon = scoreHome >= scoreAway;
      explanation = `Final score ${scoreHome}-${scoreAway}`;
    }
  }

  return {
    isWon,
    explanation,
    roiImpact: isWon ? `+${profit}u` : "-1.00u",
    statusEmoji: isWon ? "✅" : "❌",
  };
}

/**
 * Builds the exact, high-impact Post-Match Result Tweet in English (< 270 chars) strictly faithful to the original prediction.
 */
export function buildFaithfulResultTweet(options: {
  homeTeam: string;
  awayTeam: string;
  league: string;
  scoreHome: number;
  scoreAway: number;
  initialPrediction: string;
  odd?: string;
  isWon?: boolean;
}): string {
  const {
    homeTeam,
    awayTeam,
    league,
    scoreHome,
    scoreAway,
    initialPrediction,
    odd = "1.85",
  } = options;

  const scoreStr = `${scoreHome}-${scoreAway}`;
  const evalResult = evaluatePredictionResult(
    initialPrediction,
    scoreHome,
    scoreAway,
    homeTeam,
    awayTeam,
    odd
  );

  const isWon = options.isWon !== undefined ? options.isWon : evalResult.isWon;
  const englishTip = formatPredictionToEnglish(initialPrediction, homeTeam, awayTeam);

  const triHome = getTrigram(homeTeam);
  const triAway = getTrigram(awayTeam);
  const cleanHomeTag = homeTeam.replace(/[^a-zA-Z0-9]/g, "");
  const cleanAwayTag = awayTeam.replace(/[^a-zA-Z0-9]/g, "");

  if (isWon) {
    return `🏁 FULL TIME | ${homeTeam} ${scoreStr} ${awayTeam}
🏆 ${league}

✅ GREEN & CASHED IN! (@${odd})
🎯 Our tip "${englishTip}" lands comfortably!

💰 Bankroll boosted (${evalResult.roiImpact}). Onto the next value bet! 🚀

#FootballTips #BettingTips #${triHome}${triAway} #${cleanHomeTag} #${cleanAwayTag}`;
  } else {
    return `🏁 FULL TIME | ${homeTeam} ${scoreStr} ${awayTeam}
🏆 ${league}

❌ TIP MISSED (${scoreStr})
Our tip "${englishTip}" didn't land this time.

100% transparency as always, back stronger on the next fixture! 📈

#FootballTips #BettingTips #${triHome}${triAway} #${cleanHomeTag} #${cleanAwayTag}`;
  }
}

/**
 * Helper to get 3-letter trigram
 */
export function getTrigram(team: string): string {
  const t = team.trim();
  if (t.toUpperCase() === "PSG" || t.toUpperCase() === "OM" || t.toUpperCase() === "OL") return t.toUpperCase();
  if (t.toLowerCase().includes("atletico") || t.toLowerCase().includes("atlético")) return "ATM";
  if (t.toLowerCase().includes("real")) return "RMA";
  if (t.toLowerCase().includes("milan")) return "MIL";
  if (t.toLowerCase().includes("manchester city") || t.toLowerCase().includes("man city")) return "MCI";
  if (t.toLowerCase().includes("manchester united") || t.toLowerCase().includes("man utd")) return "MUN";
  if (t.toLowerCase().includes("liverpool")) return "LIV";
  if (t.toLowerCase().includes("arsenal")) return "ARS";
  if (t.toLowerCase().includes("chelsea")) return "CHE";
  if (t.toLowerCase().includes("tottenham")) return "TOT";
  if (t.toLowerCase().includes("newcastle")) return "NEW";
  if (t.toLowerCase().includes("juventus") || t.toLowerCase().includes("juve")) return "JUV";
  if (t.toLowerCase().includes("barcelona") || t.toLowerCase().includes("barcelone")) return "BAR";
  if (t.toLowerCase().includes("bayern")) return "BAY";
  if (t.toLowerCase().includes("dortmund")) return "BVB";
  return t.slice(0, 3).charAt(0).toUpperCase() + t.slice(1, 3).toLowerCase();
}

/**
 * Builds the exact H-1h Pre-Match Prediction Tweet in English (< 270 chars).
 * Format:
 * 🔥 PREDICTION NEW vs LIV (17:30)
 * 🏆 Premier League · 23 Aug
 * 
 * ⚽ Match: Newcastle vs Liverpool
 * 🎯 Tip: Liverpool to Win
 * 📈 Odds: 1.90
 * ⚡ Confidence: 85%
 * 
 * #FootballTips #NEWLIV #Newcastle #Liverpool #BettingTips
 */
export function buildH1PredictionTweet(options: {
  homeTeam: string;
  awayTeam: string;
  league: string;
  kickoffTime: string;
  prediction: string;
  odd: string;
  predictedScore?: string;
  confidencePercent: number;
  keyReasoning?: string;
  date?: string;
}): string {
  const {
    homeTeam,
    awayTeam,
    league,
    kickoffTime,
    prediction,
    odd,
    confidencePercent,
    date,
  } = options;

  const triHome = getTrigram(homeTeam);
  const triAway = getTrigram(awayTeam);
  const cleanHomeTag = homeTeam.replace(/[^a-zA-Z0-9]/g, "");
  const cleanAwayTag = awayTeam.replace(/[^a-zA-Z0-9]/g, "");
  const conf = confidencePercent || 85;
  const englishTip = formatPredictionToEnglish(prediction, homeTeam, awayTeam);

  return `🔥 PREDICTION ${triHome} vs ${triAway} (${kickoffTime})
🏆 ${league}${date ? ` · ${date}` : ""}

⚽ Match: ${homeTeam} vs ${awayTeam}
🎯 Tip: ${englishTip}
📈 Odds: ${odd}
⚡ Confidence: ${conf}%

#FootballTips #${triHome}${triAway} #${cleanHomeTag} #${cleanAwayTag} #BettingTips`;
}
