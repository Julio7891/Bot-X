/**
 * Precise Football Match Kickoff & H-1h Time Scheduler
 */

const MONTH_MAP_FR: Record<string, number> = {
  janvier: 0,
  janv: 0,
  février: 1,
  fevrier: 1,
  fev: 1,
  mars: 2,
  mar: 2,
  avril: 3,
  avr: 3,
  mai: 4,
  juin: 5,
  juillet: 6,
  juil: 6,
  août: 7,
  aout: 7,
  septembre: 8,
  sept: 8,
  octobre: 9,
  oct: 9,
  novembre: 10,
  nov: 10,
  décembre: 11,
  decembre: 11,
  dec: 11,
};

export interface KickoffScheduleResult {
  kickoffTimestamp: number;
  h1Timestamp: number;
  isPastH1: boolean;
  isPastKickoff: boolean;
  isMatchFinished: boolean;
  kickoffTimeLabel: string;
  h1TimeLabel: string;
  formattedDepartureLabel: string;
}

export function parseKickoffAndH1Schedule(
  dateStr?: string,
  kickoffTimeStr?: string
): KickoffScheduleResult {
  const now = new Date();
  let matchYear = now.getFullYear();
  let matchMonth = now.getMonth();
  let matchDay = now.getDate();

  // 1. Extract Hours & Minutes
  let hours = 18;
  let minutes = 0;

  if (kickoffTimeStr) {
    const timeClean = kickoffTimeStr.trim().toLowerCase();
    const timeMatch = timeClean.match(/(\d{1,2})[:h](\d{2})/);
    if (timeMatch) {
      hours = parseInt(timeMatch[1], 10);
      minutes = parseInt(timeMatch[2], 10);
    } else {
      const singleNumMatch = timeClean.match(/(\d{1,2})/);
      if (singleNumMatch) {
        hours = parseInt(singleNumMatch[1], 10);
      }
    }
  }

  // 2. Extract Day & Month if date string exists
  if (dateStr) {
    const cleanDate = dateStr.trim().toLowerCase();

    if (cleanDate.includes("demain")) {
      const tomorrow = new Date(now.getTime() + 86400000);
      matchYear = tomorrow.getFullYear();
      matchMonth = tomorrow.getMonth();
      matchDay = tomorrow.getDate();
    } else if (cleanDate.includes("aujourd'hui") || cleanDate.includes("ce soir")) {
      matchYear = now.getFullYear();
      matchMonth = now.getMonth();
      matchDay = now.getDate();
    } else {
      // Look for format like "24 août 2026" or "23 août" or "2026-08-23" or "24/08/2026"
      const isoMatch = cleanDate.match(/(\d{4})-(\d{2})-(\d{2})/);
      const slashMatch = cleanDate.match(/(\d{1,2})\/(\d{1,2})(?:\/(\d{2,4}))?/);
      const frenchWordMatch = cleanDate.match(/(\d{1,2})\s+([a-zéûè]+)\.?(?:\s+(\d{4}))?/);

      if (isoMatch) {
        matchYear = parseInt(isoMatch[1], 10);
        matchMonth = parseInt(isoMatch[2], 10) - 1;
        matchDay = parseInt(isoMatch[3], 10);
      } else if (slashMatch) {
        matchDay = parseInt(slashMatch[1], 10);
        matchMonth = parseInt(slashMatch[2], 10) - 1;
        if (slashMatch[3]) {
          matchYear = slashMatch[3].length === 2 ? 2000 + parseInt(slashMatch[3], 10) : parseInt(slashMatch[3], 10);
        }
      } else if (frenchWordMatch) {
        matchDay = parseInt(frenchWordMatch[1], 10);
        const monthWord = frenchWordMatch[2];
        if (MONTH_MAP_FR[monthWord] !== undefined) {
          matchMonth = MONTH_MAP_FR[monthWord];
        }
        if (frenchWordMatch[3]) {
          matchYear = parseInt(frenchWordMatch[3], 10);
        }
      }
    }
  }

  // Construct match date object
  const kickoffDate = new Date(matchYear, matchMonth, matchDay, hours, minutes, 0, 0);
  let kickoffMs = kickoffDate.getTime();

  // If kickoff resulted in invalid date, fallback to today
  if (isNaN(kickoffMs)) {
    const fallbackDate = new Date();
    fallbackDate.setHours(hours, minutes, 0, 0);
    kickoffMs = fallbackDate.getTime();
  }

  // H-1h is strictly 60 minutes before kickoff
  const h1Ms = kickoffMs - 3600000;
  const nowMs = Date.now();

  const isPastH1 = nowMs >= h1Ms;
  const isPastKickoff = nowMs >= kickoffMs;
  const isMatchFinished = nowMs >= kickoffMs + 105 * 60 * 1000;

  const h1Date = new Date(h1Ms);
  const formattedH1Time = h1Date.toLocaleTimeString("fr-FR", {
    hour: "2-digit",
    minute: "2-digit",
  });

  const formattedKickoffTime = new Date(kickoffMs).toLocaleTimeString("fr-FR", {
    hour: "2-digit",
    minute: "2-digit",
  });

  let departureLabel = `H-1h (${formattedH1Time})`;
  if (isMatchFinished) {
    departureLabel = "Match Terminé (FT)";
  } else if (isPastKickoff) {
    departureLabel = "Match En Cours (Live)";
  } else if (isPastH1) {
    departureLabel = "Décollage Immédiat (H-1h dépassé)";
  }

  return {
    kickoffTimestamp: kickoffMs,
    h1Timestamp: h1Ms,
    isPastH1,
    isPastKickoff,
    isMatchFinished,
    kickoffTimeLabel: formattedKickoffTime,
    h1TimeLabel: formattedH1Time,
    formattedDepartureLabel: departureLabel,
  };
}
