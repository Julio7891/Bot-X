export function generateSportyTraderPythonScript(options: {
  authToken?: string;
  ct0?: string;
  appApiUrl?: string;
  autoPostToX?: boolean;
  intervalSeconds?: number;
}): string {
  const {
    authToken = "YOUR_AUTH_TOKEN_HERE",
    ct0 = "YOUR_CT0_COOKIE_HERE",
    appApiUrl = "http://localhost:3000",
    autoPostToX = true,
    intervalSeconds = 60,
  } = options;

  return `#!/usr/bin/env python3
"""
=============================================================================
🤖 SPORTYTRADER AUTO-WATCHER (SURVEILLANCE TOUTES LES 60 SECONDES)
=============================================================================
Ce script s'exécute en continu sur votre PC :
1. Visite https://www.sportytrader.com/pronostics/football/ toutes les 60 secondes
2. Détecte précisément la structure HTML SportyTrader des pronostics :
   - <a href="/pronostics/...">Pronostic Équipe1 Équipe2</a>
   - <p class="font-semibold">Conseil (ex: ASSE gagne par 2+ buts)</p>
   - <span class="tabular-nums">Cote (ex: 1.97)</span>
3. Dès qu'un NOUVEAU pronostic apparaît, Mistral AI le transforme en Tweet X (<270 car.)
4. Publie AUTOMATIQUEMENT le Tweet sur votre compte X (via Playwright / Cookies) !
=============================================================================
Prérequis (sur votre PC) :
pip install playwright requests
playwright install chromium
=============================================================================
Lancement :
python sportytrader_live_watcher.py
=============================================================================
"""

import os
import sys
import time
import json
import requests
from datetime import datetime
from playwright.sync_api import sync_playwright

# Configuration
SPORTYTRADER_URL = "https://www.sportytrader.com/pronostics/football/"
API_PARSE_URL = "${appApiUrl}/api/scraper/sportytrader-parse"
AUTH_TOKEN = "${authToken}"
CT0 = "${ct0}"
AUTO_POST_TO_X = ${autoPostToX ? "True" : "False"}
CHECK_INTERVAL_SECONDS = ${intervalSeconds}

# Mémoire des pronostics déjà publiés pour éviter les doublons
SEEN_PRONOS = set()


def post_tweet_to_x_via_playwright(browser, tweet_text):
    """Publie le tweet directement sur X avec vos cookies de session."""
    if not AUTH_TOKEN or AUTH_TOKEN == "YOUR_AUTH_TOKEN_HERE":
        print("⚠️ Pas de cookies X configurés. Tweet non posté automatiquement.")
        return False

    print(f"🚀 Publication automatique du Tweet sur X...")
    try:
        context = browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            viewport={"width": 1280, "height": 800}
        )
        context.add_cookies([
            {"name": "auth_token", "value": AUTH_TOKEN, "domain": ".x.com", "path": "/"},
            {"name": "ct0", "value": CT0, "domain": ".x.com", "path": "/"},
        ])
        page = context.new_page()
        page.goto("https://x.com/compose/post", wait_until="domcontentloaded", timeout=30000)
        time.sleep(3)

        box = page.locator('[data-testid="tweetTextarea_0"]').first
        box.wait_for(timeout=10000)
        box.click()
        box.fill(tweet_text)
        time.sleep(1)

        send_btn = page.locator('[data-testid="tweetButton"]').first
        send_btn.wait_for(timeout=5000)
        send_btn.click()
        time.sleep(4)

        print("✅ TWEET ENVOYÉ SUR X AVEC SUCCÈS !")
        page.close()
        context.close()
        return True
    except Exception as e:
        print(f"⚠️ Erreur lors de la publication directe sur X: {e}")
        return False


def scan_and_process_sportytrader(browser):
    """Scrape la page SportyTrader et extrait les cartes HTML spécifiques."""
    print(f"\\n[{datetime.now().strftime('%H:%M:%S')}] 🔍 Scan de SportyTrader ({SPORTYTRADER_URL})...")
    
    context = browser.new_context(
        user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        viewport={"width": 1280, "height": 800},
        locale="fr-FR"
    )
    page = context.new_page()

    try:
        page.goto(SPORTYTRADER_URL, wait_until="domcontentloaded", timeout=60000)
        time.sleep(4)
        page.evaluate("window.scrollBy(0, 1200)")
        time.sleep(2)

        # Extraction exacte des cartes SportyTrader ciblées
        # Structure : div.bg-gray-100 ou blocs de pronostics
        cards_data = page.evaluate("""() => {
            const results = [];
            // Sélectionne tous les conteneurs de pronos
            const links = Array.from(document.querySelectorAll('a[href*="/pronostics/"]'));
            
            links.forEach(a => {
                const href = a.getAttribute('href') || '';
                const matchName = a.innerText.replace(/^Pronostic\\s+/i, '').trim();
                
                // Recherche le parent conteneur
                const card = a.closest('.bg-gray-100') || a.closest('div');
                if (!card) return;

                const tipEl = card.querySelector('p.font-semibold') || card.querySelector('p');
                const oddEl = card.querySelector('span.tabular-nums') || card.querySelector('.font-bold');

                const tip = tipEl ? tipEl.innerText.trim() : '';
                const odd = oddEl ? oddEl.innerText.trim() : '1.80';

                if (matchName && tip && href.includes('/pronostics/')) {
                    results.push({
                        href,
                        matchName,
                        tip,
                        odd,
                        rawHtml: card.outerHTML
                    });
                }
            });
            return results;
        }""")

        page.close()
        context.close()

        print(f"📊 {len(cards_data)} cartes de pronostics détectées sur SportyTrader.")
        new_items = []
        for item in cards_data:
            key = f"{item['matchName']} - {item['tip']}"
            if key not in SEEN_PRONOS:
                SEEN_PRONOS.add(key)
                new_items.append(item)

        if not new_items:
            print("💤 Aucun nouveau pronostic depuis le dernier scan. En attente...")
            return

        print(f"🔥 {len(new_items)} NOUVEAU(X) PRONOSTIC(S) DÉCOUVERT(S) !")

        # Construction du HTML combiné pour Mistral AI
        combined_html = "\\n".join([item["rawHtml"] for item in new_items])

        # Envoi à Mistral AI pour formulation des Tweets
        print("🤖 [IA] Transformation immédiate en Tweets X viraux avec Mistral AI...")
        resp = requests.post(
            API_PARSE_URL,
            json={"rawContent": combined_html},
            timeout=45
        )

        if resp.status_code == 200:
            data = resp.json()
            tweets = data.get("scrapedPronos", [])
            print(f"🎉 {len(tweets)} Tweets générés avec succès !")

            for t in tweets:
                print("\\n" + "=" * 60)
                print(f"⚽ {t.get('homeTeam')} vs {t.get('awayTeam')}")
                print(f"🎯 Conseil SportyTrader : {t.get('predictionType')} @{t.get('estimatedOdd')}")
                print(f"📝 TWEET X ({len(t.get('tweetText', ''))} car.) :\\n")
                print(t.get("tweetText"))
                print("=" * 60)

                # Publication automatique sur X si activée
                if AUTO_POST_TO_X:
                    post_tweet_to_x_via_playwright(browser, t.get("tweetText"))
                    time.sleep(10)  # Pause entre 2 tweets

        else:
            print(f"⚠️ Erreur de l'API IA ({resp.status_code}): {resp.text}")

    except Exception as e:
        print(f"⚠️ Erreur lors du scan: {e}")
        try:
            page.close()
            context.close()
        except:
            pass


def main():
    print("=" * 65)
    print("⚡ SPORTYTRADER AUTO-WATCHER (1 MINUTE SCAN & AUTO TWEET)")
    print("=" * 65)
    print(f"⏱️ Intervalle de vérification : Toutes les {CHECK_INTERVAL_SECONDS} secondes")
    print(f"🚀 Publication automatique X : {'ACTIVÉE' if AUTO_POST_TO_X else 'DÉSACTIVÉE (Mode Aperçu)'}")
    print("=" * 65)

    with sync_playwright() as p:
        browser = p.chromium.launch(
            headless=False,
            args=["--disable-blink-features=AutomationControlled", "--no-sandbox"]
        )

        try:
            while True:
                scan_and_process_sportytrader(browser)
                print(f"⏳ Prochaine vérification dans {CHECK_INTERVAL_SECONDS}s... (Ctrl+C pour arrêter)")
                time.sleep(CHECK_INTERVAL_SECONDS)
        except KeyboardInterrupt:
            print("\\n🛑 Arrêt du watcher SportyTrader.")
        finally:
            browser.close()


if __name__ == "__main__":
    main()
`;
}
