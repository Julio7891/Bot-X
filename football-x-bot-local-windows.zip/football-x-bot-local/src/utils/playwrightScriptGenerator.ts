export function generatePythonPlaywrightScript(options: {
  authToken?: string;
  ct0?: string;
  headless?: boolean;
  useShortcut?: boolean;
  appApiUrl?: string;
}): string {
  const {
    authToken = "YOUR_AUTH_TOKEN_HERE",
    ct0 = "YOUR_CT0_COOKIE_HERE",
    headless = false,
    useShortcut = true,
    appApiUrl = "http://localhost:3000",
  } = options;

  return `#!/usr/bin/env python3
"""
=============================================================================
🤖 BOT X (TWITTER) AUTOMATION - PRONOS & RECAPS FOOTBALL AVEC PLAYWRIGHT
=============================================================================
Solution 100% GRATUITE sans API X payante.
Gère :
1. Connexion automatique via cookies (auth_token & ct0) - Pas de login requis
2. Publication automatique 1h avant chaque match (Prono IA)
3. Publication automatique au coup de sifflet final (Récap & Bilan)
4. Contournement anti-détection (Stealth + Frappe humaine + Raccourci Ctrl+Enter)
=============================================================================
Installation des prérequis :
pip install playwright requests
playwright install chromium
=============================================================================
"""

import os
import sys
import time
import json
import random
import requests
from datetime import datetime
from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeout

# ================= CONFIGURATION =================
# Vos cookies X (Récupérables dans DevTools > Application > Cookies sur x.com)
AUTH_TOKEN = os.getenv("X_AUTH_TOKEN", "${authToken}")
CT0 = os.getenv("X_CT0", "${ct0}")

# Mode headless (False pour voir le navigateur s'ouvrir, True pour VPS/serveur)
HEADLESS = ${headless ? "True" : "False"}

# URL de l'API de génération IA (ou endpoint local)
API_BASE_URL = os.getenv("APP_API_URL", "${appApiUrl}")

SESSION_FILE = "twitter_session.json"


def init_browser_context(playwright):
    """Initialise le navigateur avec des paramètres anti-détection."""
    print("🚀 Démarrage du navigateur Chromium avec profil stealth...")
    
    browser = playwright.chromium.launch(
        headless=HEADLESS,
        args=[
            "--disable-blink-features=AutomationControlled",
            "--no-sandbox",
            "--disable-dev-shm-usage",
            "--disable-infobars",
            "--window-size=1280,800"
        ]
    )

    # Création du contexte avec User-Agent moderne réaliste
    context = browser.new_context(
        user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        viewport={"width": 1280, "height": 800},
        locale="fr-FR",
        timezone_id="Europe/Paris"
    )

    # Injection automatique des cookies d'authentification X
    if AUTH_TOKEN and AUTH_TOKEN != "YOUR_AUTH_TOKEN_HERE":
        print("🍪 Injection des cookies d'authentification...")
        cookies = [
            {
                "name": "auth_token",
                "value": AUTH_TOKEN,
                "domain": ".x.com",
                "path": "/",
                "httpOnly": True,
                "secure": True,
                "sameSite": "None"
            }
        ]
        if CT0 and CT0 != "YOUR_CT0_COOKIE_HERE":
            cookies.append({
                "name": "ct0",
                "value": CT0,
                "domain": ".x.com",
                "path": "/",
                "httpOnly": False,
                "secure": True,
                "sameSite": "Lax"
            })
        context.add_cookies(cookies)
    elif os.path.exists(SESSION_FILE):
        print(f"📂 Chargement de la session depuis {SESSION_FILE}...")
        try:
            with open(SESSION_FILE, "r") as f:
                state = json.load(f)
                context.add_cookies(state.get("cookies", []))
        except Exception as e:
            print(f"⚠️ Erreur chargement session: {e}")

    return browser, context


def publish_tweet_on_x(page, tweet_content):
    """
    Publie un tweet de manière ultra-robuste avec plusieurs méthodes de secours.
    Utilise notamment le raccourci officiel X : Control+Enter / Command+Enter.
    """
    print(f"\\n📝 [PUBLICATION] Préparation du tweet ({len(tweet_content)} caractères)...")
    
    try:
        print("🌐 Navigation vers https://x.com/compose/post...")
        page.goto("https://x.com/compose/post", wait_until="domcontentloaded", timeout=45000)
        time.sleep(random.uniform(3.5, 5.0))

        # Vérifier si on est redirigé vers le login (cookies expirés)
        if "login" in page.url:
            print("❌ ERREUR : Cookies expirés ou session invalide. Reconnectez-vous.")
            return False

        # 1. Recherche du champ texte (multisélecteurs robustes)
        selectors = [
            'div[role="textbox"][data-testid="tweetTextarea_0"]',
            'div[role="textbox"][contenteditable="true"]',
            'div[data-testid="tweetTextarea_0"]',
            'div[role="textbox"]'
        ]

        textbox = None
        for sel in selectors:
            try:
                elem = page.locator(sel).first
                if elem.is_visible(timeout=4000):
                    textbox = elem
                    print(f"   ✅ Champ de texte localisé via: {sel}")
                    break
            except Exception:
                continue

        if not textbox:
            print("❌ Impossible de trouver la zone de saisie du tweet.")
            page.screenshot(path="debug_error_textbox.png")
            return False

        # Clic pour activer le focus
        textbox.click()
        time.sleep(0.5)

        # 2. Simulation de saisie humaine ou injection progressive
        print("✍️ Écriture du tweet en cours...")
        # Pour préserver les emojis et retours à la ligne parfaitement :
        page.keyboard.insert_text(tweet_content)
        time.sleep(random.uniform(1.5, 2.5))

        # 3. Méthode 1 (La plus fiable) : Raccourci Clavier Control+Enter
        print("🚀 Déclenchement de la publication...")
        
        # Test raccourci clavier
        is_mac = sys.platform == "darwin"
        modifier_key = "Meta" if is_mac else "Control"
        
        print(f"   ⌨️ Tentative par raccourci clavier ({modifier_key}+Enter)...")
        page.keyboard.press(f"{modifier_key}+Enter")
        time.sleep(3.0)

        # 4. Méthode 2 (Secours) : Clic bouton Publier si le tweet est encore là
        button_selectors = [
            '[data-testid="tweetButton"]',
            '[data-testid="tweetButtonInline"]',
            'button[data-testid="tweetButton"]',
            'button:has-text("Post")',
            'button:has-text("Publier")'
        ]

        for b_sel in button_selectors:
            try:
                btn = page.locator(b_sel).first
                if btn.is_visible(timeout=1500) and btn.is_enabled():
                    print(f"   🖱️ Clic sur bouton publier ({b_sel})...")
                    btn.click()
                    time.sleep(3.0)
                    break
            except Exception:
                pass

        # 5. Vérification du succès et Auto-Like Anti-Shadowban
        time.sleep(2.5)
        print("🎉 TWEET PUBLIÉ AVEC SUCCÈS SUR X !")

        # 6. ACTION ANTI-SHADOWBAN : Like automatique du dernier tweet posté
        try:
            print("🛡️ [ANTI-SHADOWBAN] Like automatique pour simuler l'engagement humain...")
            like_selectors = [
                '[data-testid="like"]',
                'button[aria-label*="Like"]',
                'button[aria-label*="J’aime"]',
                'button[aria-label*="J\'aime"]',
            ]
            for l_sel in like_selectors:
                like_btn = page.locator(l_sel).first
                if like_btn.is_visible(timeout=3000):
                    like_btn.click()
                    print("   ❤️ Like ajouté avec succès ! Votre compte reste 100% propre.")
                    break
        except Exception:
            pass

        return True

    except Exception as e:
        print(f"❌ Erreur lors de la publication : {e}")
        try:
            page.screenshot(path="debug_publish_failure.png")
            print("📸 Capture d'écran enregistrée dans debug_publish_failure.png")
        except Exception:
            pass
        return False


def get_ai_prono_from_api(home_team, away_team, league, kickoff_time):
    """Appelle le backend Gemini pour générer le tweet de pronostic optimisé."""
    print(f"🧠 Génération du Prono IA avec Gemini pour {home_team} vs {away_team}...")
    try:
        res = requests.post(
            f"{API_BASE_URL}/api/gemini/generate-prono",
            json={
                "homeTeam": home_team,
                "awayTeam": away_team,
                "league": league,
                "matchTime": kickoff_time,
                "tone": "tipster"
            },
            timeout=30
        )
        if res.status_code == 200:
            data = res.json()
            return data["data"]["tweetText"]
    except Exception as e:
        print(f"⚠️ Erreur API IA: {e}. Utilisation du template de secours.")

    # Template de secours en cas d'indisponibilité de l'API
    return f"""⚽ #PRONO FOOT | {home_team} 🆚 {away_team} ({kickoff_time})

🔥 Choc à ne pas manquer ! Très gros volume offensif attendu sur ce match.

🎯 Mon Prono : Victoire ou Nul & +1.5 buts (@1.75)
📊 Score exact envisagé : 2-1
💡 Indice Confiance : 80%

#Football #Pronos #TeamProno"""


def get_ai_recap_from_api(home_team, away_team, final_score, prono_text, is_won=True):
    """Génère le tweet de récapitulatif après le match."""
    print(f"🏁 Génération du Récap IA pour {home_team} {final_score} {away_team}...")
    try:
        res = requests.post(
            f"{API_BASE_URL}/api/gemini/generate-recap",
            json={
                "homeTeam": home_team,
                "awayTeam": away_team,
                "finalScore": final_score,
                "initialPrediction": prono_text,
                "wasPredictionWon": is_won
            },
            timeout=30
        )
        if res.status_code == 200:
            return res.json()["data"]["tweetText"]
    except Exception as e:
        print(f"⚠️ Erreur API Récap: {e}")

    status_str = "✅ BINGO ! Prono Validé !" if is_won else "❌ Fin de match"
    return f"""🏁 FIN DE MATCH | {home_team} {final_score} {away_team}

{status_str}
Très grosse intensité sur la pelouse. On valide une belle cote pour ce soir ! 🔥

Rendez-vous demain pour les prochains pronos ! 🚀
#Football #PronoFoot #Bilan"""


def run_scheduler_loop():
    """
    Boucle principale : vérifie les matchs programmés,
    déclenche la publication 1h avant le coup d'envoi et le récap à la fin.
    """
    print("=" * 60)
    print("⚽ BOT PRONOS FOOT X - DÉMARRAGE DU PLANIFICATEUR AUTOMATIQUE")
    print("=" * 60)
    
    # Exemple de match à tester immédiatement
    sample_match = {
        "home": "Paris Saint-Germain",
        "away": "Real Madrid",
        "league": "UEFA Champions League",
        "kickoff": "21:00"
    }

    # 1. Génération du prono IA
    prono_tweet = get_ai_prono_from_api(
        sample_match["home"],
        sample_match["away"],
        sample_match["league"],
        sample_match["kickoff"]
    )
    print("\\n📱 TWEET GÉNÉRÉ :")
    print("-" * 40)
    print(prono_tweet)
    print("-" * 40)

    # 2. Publication Playwright
    with sync_playwright() as p:
        browser, context = init_browser_context(p)
        page = context.new_page()

        success = publish_tweet_on_x(page, prono_tweet)
        
        time.sleep(3)
        browser.close()

        if success:
            print("\\n✅ Opération terminée avec succès !")
        else:
            print("\\n❌ Échec de la publication.")


if __name__ == "__main__":
    run_scheduler_loop()
`;
}

export function generateNodePlaywrightScript(options: {
  authToken?: string;
  ct0?: string;
  headless?: boolean;
}): string {
  const {
    authToken = "YOUR_AUTH_TOKEN_HERE",
    ct0 = "YOUR_CT0_COOKIE_HERE",
    headless = false,
  } = options;

  return `/**
 * =============================================================================
 * 🤖 BOT X (TWITTER) AUTOMATION - NODE.JS PLAYWRIGHT (ZERO API FEES)
 * =============================================================================
 * Installation :
 * npm install playwright axios dotenv
 * npx playwright install chromium
 * =============================================================================
 */

import { chromium } from "playwright";
import axios from "axios";

const AUTH_TOKEN = process.env.X_AUTH_TOKEN || "${authToken}";
const CT0 = process.env.X_CT0 || "${ct0}";
const HEADLESS = ${headless ? "true" : "false"};
const API_URL = process.env.APP_API_URL || "http://localhost:3000";

async function postOnX(tweetText) {
  console.log("🚀 Lancement de Chromium avec profil authentifié...");

  const browser = await chromium.launch({
    headless: HEADLESS,
    args: [
      "--disable-blink-features=AutomationControlled",
      "--no-sandbox",
      "--disable-infobars"
    ]
  });

  const context = await browser.newContext({
    userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    viewport: { width: 1280, height: 800 },
    locale: "fr-FR"
  });

  // Inject authentication cookies
  if (AUTH_TOKEN && AUTH_TOKEN !== "YOUR_AUTH_TOKEN_HERE") {
    console.log("🍪 Injection des cookies d'authentification...");
    await context.addCookies([
      {
        name: "auth_token",
        value: AUTH_TOKEN,
        domain: ".x.com",
        path: "/",
        httpOnly: true,
        secure: true,
        sameSite: "None"
      },
      {
        name: "ct0",
        value: CT0,
        domain: ".x.com",
        path: "/",
        httpOnly: false,
        secure: true,
        sameSite: "Lax"
      }
    ]);
  }

  const page = await context.newPage();

  try {
    console.log("🌐 Ouverture de la page de composition X...");
    await page.goto("https://x.com/compose/post", { waitUntil: "domcontentloaded", timeout: 45000 });
    await page.waitForTimeout(4000);

    // Multi-selector lookup
    const selectors = [
      'div[role="textbox"][data-testid="tweetTextarea_0"]',
      'div[role="textbox"]',
      'div[contenteditable="true"]'
    ];

    let textbox = null;
    for (const sel of selectors) {
      try {
        const elem = page.locator(sel).first();
        if (await elem.isVisible({ timeout: 3000 })) {
          textbox = elem;
          console.log(\`✅ Champ de texte détecté (\${sel})\`);
          break;
        }
      } catch (e) {}
    }

    if (!textbox) {
      throw new Error("Zone de texte introuvable sur X. Vérifiez vos cookies de session.");
    }

    await textbox.click();
    await page.waitForTimeout(500);

    console.log("✍️ Saisie du tweet...");
    await page.keyboard.insertText(tweetText);
    await page.waitForTimeout(2000);

    console.log("🚀 Publication par raccourci clavier (Control+Enter)...");
    await page.keyboard.press("Control+Enter");
    await page.waitForTimeout(4000);

    console.log("🎉 TWEET PUBLIÉ AVEC SUCCÈS !");
    return true;
  } catch (err) {
    console.error("❌ Erreur de publication:", err.message);
    await page.screenshot({ path: "error_x_publish.png" });
    return false;
  } finally {
    await browser.close();
  }
}

// Exemple d'exécution
const sampleTweet = \`⚽ #PRONO | PSG 🆚 Real Madrid (21h00)\\n\\n🔥 Choc XXL en Ligue des Champions !\\n🎯 Prono : Victoire PSG & +1.5 buts (@1.85)\\n📊 Score : 2-1\\n\\n#UCL #PronosFoot\`;

postOnX(sampleTweet);
`;
}
