import { FootballMatch, AirportFlightTweet, PublishedTweetLog, AutoPilotActivityEvent } from "../types";
import { calculateRealisticMarketOdds } from "./oddsEngine";

/**
 * Calculates the exact target takeoff timestamp for H-1h (60 minutes before kickoff).
 * If the match is in the past or in less than 2 minutes, schedules takeoff in a few seconds so it flies immediately.
 */
export function computeH1Departure(match: FootballMatch): {
  scheduledTimestamp: number;
  timeLabel: string;
  isImmediate: boolean;
} {
  const now = Date.now();
  let targetKickoffMs = match.kickoffTimestamp;

  // If no timestamp or unrealistic, parse from match.kickoffTime (e.g. "21:00", "18:30")
  if (!targetKickoffMs || targetKickoffMs < now - 86400000) {
    const timeParts = (match.kickoffTime || "21:00").match(/(\d{1,2})[h:](\d{2})/i);
    const d = new Date();
    if (timeParts) {
      d.setHours(parseInt(timeParts[1], 10), parseInt(timeParts[2], 10), 0, 0);
    } else {
      d.setHours(21, 0, 0, 0);
    }
    targetKickoffMs = d.getTime();
  }

  // Exact H-1h is 60 minutes before kickoff
  const targetH1Ms = targetKickoffMs - 60 * 60 * 1000;

  // If target H-1h is in the future (more than 15s from now)
  if (targetH1Ms > now + 15000) {
    const d = new Date(targetH1Ms);
    const timeStr = d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
    return {
      scheduledTimestamp: targetH1Ms,
      timeLabel: `H-1h (${timeStr})`,
      isImmediate: false,
    };
  }

  // If H-1h is already reached (e.g. match starts in 45 min or soon), schedule immediately in 10s
  return {
    scheduledTimestamp: now + 10000,
    timeLabel: `Immédiat (H-1h atteint)`,
    isImmediate: true,
  };
}

/**
 * Automatically creates an AirportFlightTweet for an upcoming match with diversified market odds.
 */
export function createAutoPronoFlight(
  match: FootballMatch,
  tone: "tipster" | "viral" | "expert" | "minimal" = "tipster"
): AirportFlightTweet {
  const oddsCalc = calculateRealisticMarketOdds(match.homeTeam, match.awayTeam, match.odds);
  const rec = oddsCalc.marketRecommendation;
  const departure = computeH1Departure(match);

  const cleanHomeTag = match.homeTeam.replace(/[^a-zA-Z0-9]/g, "");
  const cleanAwayTag = match.awayTeam.replace(/[^a-zA-Z0-9]/g, "");

  let tweetText = "";
  if (tone === "viral") {
    tweetText = `🚨 VALUE ALERT | ${match.homeTeam} vs ${match.awayTeam}\n🏆 ${match.league} (${match.kickoffTime})\n\n⚡ ${rec.reason.slice(0, 80)}\n\n💥 OUR TIP: ${rec.market} (@${rec.odd})\n📊 Projected Score: ${rec.predictedScore}\n🔥 Confidence: ${rec.confidence}%\n\n#FootballTips #${cleanHomeTag} #${cleanAwayTag} #BettingTips`;
  } else if (tone === "expert") {
    tweetText = `📊 #DATA & PREDICTION | ${match.homeTeam} vs ${match.awayTeam}\n🏆 ${match.league} · Kickoff ${match.kickoffTime}\n\n🔍 ${rec.reason.slice(0, 90)}\n\n🎯 Selection: ${rec.market} (@${rec.odd})\n📈 Model: Projected score ${rec.predictedScore} (Confidence ${rec.confidence}%)\n\n#FootballTips #${cleanHomeTag} #${cleanAwayTag} #BettingTips`;
  } else {
    tweetText = `⚽ #PREDICTION | ${match.homeTeam} vs ${match.awayTeam} (${match.kickoffTime})\n🏆 ${match.league}\n\n🔥 ${rec.reason.slice(0, 85)}\n\n🎯 Our Tip: ${rec.market} (@${rec.odd})\n📊 Projected Score: ${rec.predictedScore}\n💡 Confidence: ${rec.confidence}%\n\n#FootballTips #${cleanHomeTag} #${cleanAwayTag} #BettingTips`;
  }

  const flightCode = `FL-${Math.floor(1000 + Math.random() * 9000)}`;

  return {
    id: `flight-auto-${match.id}-${Date.now()}`,
    matchId: match.id,
    matchTitle: `${match.homeTeam} vs ${match.awayTeam}`,
    type: "PRONO_H1",
    tweetText: tweetText.trim(),
    flightCode,
    departureTime: departure.timeLabel,
    scheduledTimestamp: departure.scheduledTimestamp,
    scheduledTimeLabel: departure.timeLabel,
    isAutoScheduled: true,
    baggages: {
      match: `${match.homeTeam} vs ${match.awayTeam}`,
      prediction: rec.market,
      odd: rec.odd,
      confidence: rec.confidence,
      style: tone === "viral" ? "Viral / Punchy" : tone === "expert" ? "Analyste Stats" : "Tipster Pro",
    },
    status: "SCHEDULED",
    createdAt: Date.now(),
  };
}

/**
 * Automatically creates an AirportFlightTweet for a finished match (Post-match FT recap).
 */
export function createAutoRecapFlight(
  match: FootballMatch,
  tone: "tipster" | "viral" | "expert" | "minimal" = "tipster"
): AirportFlightTweet {
  const scoreHome = match.actualScore?.home ?? 2;
  const scoreAway = match.actualScore?.away ?? 1;
  const scoreString = `${scoreHome} - ${scoreAway}`;
  
  const scorersStr = match.goalScorers && match.goalScorers.length > 0
    ? `\n⚽ Buteurs : ${match.goalScorers.slice(0, 3).join(", ")}`
    : "";

  const cleanHomeTag = match.homeTeam.replace(/[^a-zA-Z0-9]/g, "");
  const cleanAwayTag = match.awayTeam.replace(/[^a-zA-Z0-9]/g, "");

  // Assess if prior prediction won based on final result
  const initialPrediction = match.pronoData?.predictionType || "Prono";
  const predLower = initialPrediction.toLowerCase();

  let isWon = true;
  if (predLower.includes("over 2.5") || predLower.includes("plus de 2.5")) {
    isWon = (scoreHome + scoreAway) >= 3;
  } else if (predLower.includes("under 2.5") || predLower.includes("moins de 2.5")) {
    isWon = (scoreHome + scoreAway) < 3;
  } else if (predLower.includes("btts") || predLower.includes("les 2") || predLower.includes("deux équipes")) {
    isWon = scoreHome > 0 && scoreAway > 0;
  } else if (predLower.includes("victoire") && predLower.includes(match.homeTeam.toLowerCase().slice(0, 5))) {
    isWon = scoreHome > scoreAway;
  } else if (predLower.includes("victoire") && predLower.includes(match.awayTeam.toLowerCase().slice(0, 5))) {
    isWon = scoreAway > scoreHome;
  } else if (predLower.includes("dnb 1") || predLower.includes("remboursé si nul")) {
    isWon = scoreHome >= scoreAway;
  }

  let tweetText = "";
  if (isWon) {
    tweetText = `🏁 FULL TIME | ${match.homeTeam} ${scoreString} ${match.awayTeam}\n\n✅ GREEN & CASHED IN!\n🎯 Our tip "${initialPrediction}" lands comfortably!${scorersStr}\n\n💰 Bankroll boosted. Onto the next fixture! 🚀\n\n#FootballTips #Winner #${cleanHomeTag} #${cleanAwayTag}`;
  } else {
    tweetText = `🏁 FULL TIME | ${match.homeTeam} ${scoreString} ${match.awayTeam}\n\n❌ TIP MISSED\nOur tip "${initialPrediction}" didn't land on this script.${scorersStr}\n\n100% transparency, back on the next match! 📈\n\n#FootballTips #BettingTips #${cleanHomeTag} #${cleanAwayTag}`;
  }

  const flightCode = `FL-FT-${Math.floor(1000 + Math.random() * 9000)}`;

  return {
    id: `flight-recap-${match.id}-${Date.now()}`,
    matchId: match.id,
    matchTitle: `${match.homeTeam} ${scoreString} ${match.awayTeam} (Fin de Match)`,
    type: "RECAP_FT",
    tweetText: tweetText.trim(),
    flightCode,
    departureTime: "Immédiat (Coup de sifflet final)",
    baggages: {
      match: `${match.homeTeam} vs ${match.awayTeam}`,
      prediction: `Score Final : ${scoreString} (${isWon ? "Validé ✅" : "Manqué ❌"})`,
      odd: match.odds?.home || "1.85",
      confidence: 99,
      style: "Bilan FT Post-Match",
    },
    status: "BOARDING",
    createdAt: Date.now(),
  };
}

/**
 * Checks if a match already has a prono flight queued in Airport or published in logs.
 */
export function hasMatchBeenPronoQueued(
  match: FootballMatch,
  flights: AirportFlightTweet[],
  logs: PublishedTweetLog[]
): boolean {
  const matchHome = match.homeTeam.toLowerCase().trim();
  const matchAway = match.awayTeam.toLowerCase().trim();

  const inFlights = flights.some((f) => {
    if (f.matchId && f.matchId === match.id && f.type === "PRONO_H1") return true;
    const title = f.matchTitle.toLowerCase();
    return title.includes(matchHome) && title.includes(matchAway) && f.type === "PRONO_H1";
  });

  if (inFlights) return true;

  const inLogs = logs.some((l) => {
    if (l.matchId && l.matchId === match.id && l.type === "PRONO_H1") return true;
    const title = l.matchTitle.toLowerCase();
    return title.includes(matchHome) && title.includes(matchAway) && l.type === "PRONO_H1";
  });

  return inLogs;
}

/**
 * Checks if a match already has a recap FT published or queued.
 */
export function hasMatchBeenRecapQueued(
  match: FootballMatch,
  flights: AirportFlightTweet[],
  logs: PublishedTweetLog[]
): boolean {
  const matchHome = match.homeTeam.toLowerCase().trim();
  const matchAway = match.awayTeam.toLowerCase().trim();

  const inFlights = flights.some((f) => {
    if (f.matchId && f.matchId === match.id && f.type === "RECAP_FT") return true;
    const title = f.matchTitle.toLowerCase();
    return title.includes(matchHome) && f.type === "RECAP_FT";
  });

  if (inFlights) return true;

  const inLogs = logs.some((l) => {
    if (l.matchId && l.matchId === match.id && l.type === "RECAP_FT") return true;
    const title = l.matchTitle.toLowerCase();
    return title.includes(matchHome) && l.type === "RECAP_FT";
  });

  return inLogs;
}
