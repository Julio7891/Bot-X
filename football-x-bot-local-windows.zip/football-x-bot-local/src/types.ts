export interface FootballMatch {
  id: string;
  league: string;
  leagueFlag?: string;
  leagueId?: string;
  homeTeam: string;
  awayTeam: string;
  homeLogo: string; // Emoji fallback or short tag
  awayLogo: string;
  homeLogoUrl?: string; // Real high-res crest URL
  awayLogoUrl?: string;
  kickoffTime: string; // HH:mm format, e.g. "21:00"
  kickoffDate: string; // e.g. "Aujourd'hui", "Demain", "2026-08-20"
  kickoffTimestamp: number; // unix timestamp in ms
  stadium?: string;
  liveMinute?: string; // e.g. "78'", "MT", "90+3'"
  matchClock?: string;
  odds: {
    home: string;
    draw: string;
    away: string;
    over25?: string;
    under25?: string;
    bttsYes?: string;
    bttsNo?: string;
    dnbHome?: string;
    dnbAway?: string;
  };
  formHome: string; // e.g. "V-V-N-V-D"
  formAway: string;
  keyStat?: string;
  sourceApi?: "ESPN" | "Football-Data" | "API-Football" | "TheSportsDB" | "Manual";
  status: "UPCOMING" | "READY_FOR_PRONO" | "PRONO_PUBLISHED" | "LIVE" | "FINISHED" | "RECAP_PUBLISHED";
  actualScore?: {
    home: number;
    away: number;
  };
  goalScorers?: string[];
  pronoData?: Partial<PronoResult>;
  recapData?: RecapResult;
}

export interface FootballApiConfig {
  provider: "espn" | "football-data" | "api-sports" | "thesportsdb";
  apiKey?: string;
  autoRefreshInterval: number; // in seconds (0 for off, 30, 60, 300)
  selectedCompetitions: string[];
}

export interface PronoResult {
  id: string;
  matchId: string;
  tweetText: string;
  predictionType: string;
  predictedScore: string;
  estimatedOdd: string;
  confidencePercent: number;
  keyReasoning: string;
  recommendedBet: string;
  safeAlternative?: string;
  generatedAt: string;
  publishedAt?: string;
  status: "DRAFT" | "SCHEDULED" | "PUBLISHED" | "FAILED";
}

export interface RecapResult {
  id: string;
  matchId: string;
  tweetText: string;
  summary: string;
  statusEmoji: string;
  roiImpact: string;
  isWon: boolean;
  finalScore: string;
  generatedAt: string;
  publishedAt?: string;
  status: "DRAFT" | "SCHEDULED" | "PUBLISHED" | "FAILED";
}

export interface PlaywrightConfig {
  sessionType: "cookies" | "storageState" | "credentials";
  authToken: string;
  ct0: string;
  headless: boolean;
  typingDelayMin: number;
  typingDelayMax: number;
  useShortcutPublish: boolean;
  autoPost1hBefore: boolean;
  autoPostRecap: boolean;
}

export interface PlaywrightLogStep {
  id: string;
  timestamp: string;
  stepName: string;
  status: "pending" | "running" | "success" | "warning" | "error";
  details: string;
  codeSnippet?: string;
}

export interface BotStats {
  totalPronosGenerated: number;
  totalPronosPublished: number;
  totalRecapsPublished: number;
  winCount: number;
  lossCount: number;
  winRate: number;
  estimatedUnitsProfit: number;
}

export interface PublishedTweetLog {
  id: string;
  matchId?: string;
  type: "PRONO_H1" | "RECAP_FT" | "SPECIAL" | "MANUAL_TEST";
  tweetText: string;
  matchTitle: string;
  publishedAt: string;
  tweetUrl?: string;
  status: "SUCCESS" | "FAILED" | "SIMULATED";
  mode: "real_x_api" | "simulation" | "web_intent" | "blocked_cloud_ip";
}

export interface AutoPilotConfig {
  isEnabled: boolean;
  autoPostPronoH1: boolean;
  autoPostRecapFT: boolean;
  intervalSeconds: number;
  tone: "tipster" | "viral" | "expert" | "minimal";
  requireReviewBeforePost: boolean;
}

export interface AirportFlightTweet {
  id: string;
  matchId?: string;
  matchTitle: string;
  type: "PRONO_H1" | "RECAP_FT" | "SPECIAL";
  tweetText: string;
  flightCode: string; // e.g. "FL-UCL-01"
  departureTime: string; // e.g. "H-1h (20:00)"
  scheduledTimestamp?: number; // timestamp in ms when scheduled to take off
  scheduledTimeLabel?: string; // e.g. "Aujourd'hui à 20:00"
  isAutoScheduled?: boolean;
  scheduleMethod?: "in_app" | "x_scheduler";
  baggages: {
    match: string;
    prediction: string;
    odd?: string;
    confidence?: number;
    hasImageCard?: boolean;
    style: string;
  };
  status: "READY" | "SCHEDULED" | "BOARDING" | "FLYING" | "LANDED" | "PUBLISHED" | "FAILED";
  createdAt: number;
  publishedUrl?: string;
  publishedAt?: string;
  publishError?: string;
  autoPublishAttempted?: boolean;
}

export interface AutoPilotActivityEvent {
  id: string;
  timestamp: string;
  type: "SYNC_MATCHES" | "AI_PRONO_GENERATED" | "FLIGHT_SCHEDULED_H1" | "TAKEOFF_H1" | "MATCH_FINISHED" | "RECAP_GENERATED" | "TAKEOFF_RECAP" | "INFO";
  title: string;
  description: string;
  matchTitle?: string;
  badge?: string;
}

export interface ScrapedPronoItem {
  id: string;
  homeTeam: string;
  awayTeam: string;
  league: string;
  leagueFlag?: string;
  kickoffTime: string;
  kickoffDate: string;
  predictionType: string;
  estimatedOdd: string;
  predictedScore: string;
  confidencePercent: number;
  keyReasoning: string;
  source: string;
  tweetText: string;
  isImported?: boolean;
}



