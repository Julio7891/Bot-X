import React from "react";
import { ShieldCheck, AlertTriangle, Clock, Terminal, Zap, CheckCircle2, Lock, Flame, Cpu } from "lucide-react";

export const BanPreventionGuide: React.FC = () => {
  return (
    <div className="bg-[#16161a] border border-slate-800 rounded-2xl shadow-xl overflow-hidden space-y-6">
      {/* Header */}
      <div className="p-6 border-b border-slate-800 bg-[#16161a]">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-amber-500/10 text-amber-400 rounded-xl border border-amber-500/20">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              Guide Anti-Ban & Bonnes Pratiques Playwright sur X
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Toutes les règles indispensables pour automatiser vos publications en toute sécurité sans risque de blocage de compte.
            </p>
          </div>
        </div>
      </div>

      <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Rule 1 */}
        <div className="p-4 bg-[#1c1c22] rounded-xl border border-slate-800 space-y-2">
          <div className="flex items-center gap-2 text-xs font-bold text-emerald-400">
            <CheckCircle2 className="w-4 h-4" />
            <span>1. Fréquence raisonnable (1 à 6 tweets / jour)</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Pour un compte de pronostics sportifs, publier 1h avant chaque match (2 à 4 pronos/jour) et le récap après le match (2 à 4 récaps/jour) est un rythme 100% naturel. Évitez de publier plus de 15 tweets en quelques minutes.
          </p>
        </div>

        {/* Rule 2 */}
        <div className="p-4 bg-[#1c1c22] rounded-xl border border-slate-800 space-y-2">
          <div className="flex items-center gap-2 text-xs font-bold text-indigo-400">
            <Clock className="w-4 h-4" />
            <span>2. Délais aléatoires (Jittering)</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Ne publiez pas à la seconde exacte fixe. Notre script intègre un micro-délai aléatoire (ex: <code>time.sleep(random.uniform(3.5, 7.0))</code>) pour simuler le comportement d'un utilisateur humain.
          </p>
        </div>

        {/* Rule 3 */}
        <div className="p-4 bg-[#1c1c22] rounded-xl border border-slate-800 space-y-2">
          <div className="flex items-center gap-2 text-xs font-bold text-amber-400">
            <Lock className="w-4 h-4" />
            <span>3. Utilisation exclusive des Cookies de Session</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Ne laissez jamais un script tenter de remplir le formulaire d'identifiant/mot de passe en boucle. L'injection des cookies <code>auth_token</code> et <code>ct0</code> évite les captchas Arkose et les défis de sécurité par SMS/Email.
          </p>
        </div>

        {/* Rule 4 */}
        <div className="p-4 bg-[#1c1c22] rounded-xl border border-slate-800 space-y-2">
          <div className="flex items-center gap-2 text-xs font-bold text-purple-400">
            <Cpu className="w-4 h-4" />
            <span>4. Flags Chromium Stealth</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            L'argument <code>--disable-blink-features=AutomationControlled</code> et un User-Agent récent masquent l'indicateur d'automatisation Playwright face aux algorithmes de détection de bot de X.
          </p>
        </div>

        {/* Rule 5: Anti-Shadowban & Like Automation */}
        <div className="p-4 bg-gradient-to-br from-rose-950/20 to-[#1c1c22] rounded-xl border border-rose-900/40 space-y-2 md:col-span-2">
          <div className="flex items-center gap-2 text-xs font-bold text-rose-400">
            <Flame className="w-4 h-4" />
            <span>5. Bouclier Anti-Shadowban : Auto-Like & Engagement Réel</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            X pénalise (shadowban/search suggestion ban) les comptes qui publient sans interagir. Notre système intègre désormais un <strong>Auto-Like immédiat</strong> sur vos propres publications et simule des lectures de flux pour signaler à l'algorithme un compte actif et sain. N'hésitez pas à liker aussi 2-3 tweets de football manuellement chaque jour pour un boost d'autorité maximal.
          </p>
        </div>
      </div>

      {/* Warning Box */}
      <div className="mx-6 mb-6 p-4 bg-amber-950/20 border border-amber-900/40 rounded-xl flex items-start gap-3">
        <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
        <div className="text-xs text-slate-300 space-y-1">
          <span className="font-bold text-amber-300">Astuce Pro pour la longévité de votre session :</span>
          <p className="text-slate-400 leading-relaxed">
            Ne cliquez jamais sur "Se déconnecter" dans le navigateur où vous avez extrait vos cookies. Si vous fermez simplement l'onglet, votre cookie <code>auth_token</code> reste valide pendant des mois entiers.
          </p>
        </div>
      </div>
    </div>
  );
};
