import React, { useState, useEffect } from "react";
import {
  Send,
  Copy,
  Check,
  Trash2,
  Edit3,
  Sparkles,
  PlaneTakeoff,
  Clock,
  CheckCircle2,
  XCircle,
  Flame,
  Layers,
  ArrowUpRight,
  TrendingUp,
  AlertCircle,
  ExternalLink,
  Zap,
  Radio,
  Power,
  ShieldCheck,
} from "lucide-react";
import { AirportFlightTweet } from "../types";

interface TweetsFeedViewProps {
  flights: AirportFlightTweet[];
  onPublishSingle: (flight: AirportFlightTweet) => Promise<any>;
  onPublishWebIntent?: (flight: AirportFlightTweet) => void;
  onDeleteFlight: (flightId: string) => void;
  onClearAll: () => void;
  onClearOldTweets?: () => void;
  onUpdateFlightText: (flightId: string, newText: string) => void;
  onShowToast: (msg: string) => void;
  onNavigateToMatches: () => void;
  isAutoPublishEnabled: boolean;
  onToggleAutoPublish: (enabled: boolean) => void;
  onRetryAllPending?: () => void;
  hasCookiesSet: boolean;
  onOpenCookiesModal: () => void;
}

export const TweetsFeedView: React.FC<TweetsFeedViewProps> = ({
  flights,
  onPublishSingle,
  onPublishWebIntent,
  onDeleteFlight,
  onClearAll,
  onClearOldTweets,
  onUpdateFlightText,
  onShowToast,
  onNavigateToMatches,
  isAutoPublishEnabled,
  onToggleAutoPublish,
  onRetryAllPending,
  hasCookiesSet,
  onOpenCookiesModal,
}) => {
  const [filterType, setFilterType] = useState<"ALL" | "PRONO_H1" | "RECAP_FT" | "PUBLISHED">("ALL");
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editedText, setEditedText] = useState("");
  const [publishingId, setPublishingId] = useState<string | null>(null);
  const [nowTimestamp, setNowTimestamp] = useState<number>(Date.now());
  const [queueStatus, setQueueStatus] = useState<{
    queueLength: number;
    isPublishing: boolean;
    minSpacingSeconds: number;
    secondsUntilNextAllowed: number;
    queuedItems?: Array<{ id: string; type: string; matchTitle?: string; priority: string }>;
  } | null>(null);

  // Real-time queue status fetcher
  useEffect(() => {
    const fetchQueue = async () => {
      try {
        const res = await fetch("/api/pipeline/queue-status");
        const data = await res.json();
        if (data.success) {
          setQueueStatus(data);
        }
      } catch {
        // ignore network hiccups
      }
    };
    fetchQueue();
    const interval = setInterval(fetchQueue, 3000);
    return () => clearInterval(interval);
  }, []);

  // Real-time ticking ticker every second for countdowns
  useEffect(() => {
    const timer = setInterval(() => {
      setNowTimestamp(Date.now());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const filteredFlights = flights.filter((f) => {
    if (filterType === "PRONO_H1") return f.type === "PRONO_H1" && f.status !== "PUBLISHED";
    if (filterType === "RECAP_FT") return f.type === "RECAP_FT" && f.status !== "PUBLISHED";
    if (filterType === "PUBLISHED") return f.status === "PUBLISHED" || f.status === "LANDED";
    return true;
  });

  const h1Count = flights.filter((f) => f.type === "PRONO_H1" && f.status !== "PUBLISHED").length;
  const recapCount = flights.filter((f) => f.type === "RECAP_FT" && f.status !== "PUBLISHED").length;
  const publishedCount = flights.filter((f) => f.status === "PUBLISHED" || f.status === "LANDED").length;

  const nextScheduledFlight = flights
    .filter((f) => f.status === "SCHEDULED" && f.scheduledTimestamp && f.scheduledTimestamp > nowTimestamp)
    .sort((a, b) => (a.scheduledTimestamp || 0) - (b.scheduledTimestamp || 0))[0];

  const formatCountdown = (targetMs?: number) => {
    if (!targetMs) return "Heure venue";
    const diff = targetMs - nowTimestamp;
    if (diff <= 0) return "🚀 Heure H-1h atteinte !";

    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((diff % (1000 * 60)) / 1000);

    if (hours > 0) {
      return `${hours}h ${minutes}m ${seconds}s`;
    }
    return `${minutes}m ${seconds.toString().padStart(2, "0")}s`;
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    onShowToast("📋 Tweet copié dans le presse-papier !");
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleStartEdit = (f: AirportFlightTweet) => {
    setEditingId(f.id);
    setEditedText(f.tweetText);
  };

  const handleSaveEdit = (flightId: string) => {
    onUpdateFlightText(flightId, editedText);
    setEditingId(null);
    onShowToast("💾 Tweet mis à jour !");
  };

  const handlePublish = async (f: AirportFlightTweet) => {
    setPublishingId(f.id);
    try {
      await onPublishSingle(f);
    } finally {
      setPublishingId(null);
    }
  };

  const handlePublishAllReady = async () => {
    const readyToPublish = flights.filter((f) => f.status === "READY" || f.status === "SCHEDULED");
    if (readyToPublish.length === 0) {
      onShowToast("ℹ️ Aucun tweet en attente d'envoi.");
      return;
    }

    onShowToast(`🚀 Envoi de ${readyToPublish.length} tweet(s)...`);
    for (const flight of readyToPublish) {
      await onPublishSingle(flight);
    }
  };

  const handleCopyAll = () => {
    if (filteredFlights.length === 0) return;
    const allText = filteredFlights
      .map((f, i) => `--- TWEET #${i + 1} (${f.type === "PRONO_H1" ? "AVANT-MATCH H-1h" : "RÉSULTAT FT"}) ---\n${f.tweetText}`)
      .join("\n\n");
    navigator.clipboard.writeText(allText);
    onShowToast(`📋 ${filteredFlights.length} tweets copiés dans le presse-papier !`);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner: Airport Terminal & Auto-Publish Engine */}
      <div className="bg-gradient-to-r from-emerald-950/70 via-[#16161a] to-indigo-950/60 border border-emerald-900/40 rounded-2xl p-5 shadow-xl relative overflow-hidden">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 relative z-10">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold flex items-center gap-1.5 font-mono">
                <PlaneTakeoff className="w-3.5 h-3.5 text-emerald-400" />
                Terminal X & Planificateur H-1h
              </span>

              {isAutoPublishEnabled ? (
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-xs font-bold flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  Auto-Publication H-1h : ACTIVE
                </span>
              ) : (
                <span className="px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/30 text-xs font-bold flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-amber-400" />
                  Auto-Publication : EN PAUSE
                </span>
              )}

              {hasCookiesSet ? (
                <span className="text-[11px] font-semibold text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded-full border border-emerald-800/50 flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-emerald-400" />
                  Compte X Connecté
                </span>
              ) : (
                <button
                  onClick={onOpenCookiesModal}
                  className="text-[11px] font-semibold text-amber-400 hover:text-amber-300 bg-amber-950/40 px-2 py-0.5 rounded-full border border-amber-800/50 flex items-center gap-1 cursor-pointer"
                >
                  <AlertCircle className="w-3 h-3" />
                  Connecter X (Cookies)
                </button>
              )}
            </div>

            <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              File d'Attente & Publication Automatique (H-1h & FT)
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              Les matchs programmés sont surveillés en continu. À <strong>H-1h pile</strong> avant le coup d'envoi, le robot déclenche automatiquement la publication sur X !
            </p>
          </div>

          {/* Right Controls: Auto-Publish Toggle & Actions */}
          <div className="flex flex-wrap items-center gap-3 w-full lg:w-auto justify-start lg:justify-end">
            {/* Auto-Publish Switch */}
            <button
              onClick={() => {
                const nextState = !isAutoPublishEnabled;
                onToggleAutoPublish(nextState);
              }}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition cursor-pointer border ${
                isAutoPublishEnabled
                  ? "bg-emerald-600 hover:bg-emerald-500 text-white border-emerald-400/50 shadow-lg shadow-emerald-950"
                  : "bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-600"
              }`}
            >
              <Power className="w-4 h-4" />
              <span>{isAutoPublishEnabled ? "Auto-Pilote : ON" : "Auto-Pilote : OFF"}</span>
            </button>

            {onRetryAllPending && flights.some((f) => f.status !== "PUBLISHED" && f.status !== "LANDED") && (
              <button
                onClick={onRetryAllPending}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-cyan-950/70 hover:bg-cyan-900/80 text-cyan-300 border border-cyan-500/40 text-xs font-bold transition cursor-pointer shadow-md"
                title="Débloque et relance immédiatement tous les tweets en attente"
              >
                <Zap className="w-3.5 h-3.5 text-cyan-400" />
                <span>⚡ Forcer Relance Auto</span>
              </button>
            )}

            {flights.length > 0 && (
              <>
                <button
                  onClick={handlePublishAllReady}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-emerald-600 hover:from-indigo-500 hover:to-emerald-500 text-white text-xs font-bold shadow-lg shadow-indigo-950/50 transition cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5 text-amber-300" />
                  <span>Tout Publier Maintenant</span>
                </button>

                <button
                  onClick={handleCopyAll}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#1c1c22] hover:bg-slate-800 text-slate-200 text-xs font-bold border border-slate-700 transition cursor-pointer"
                  title="Copier tous les tweets visibles"
                >
                  <Copy className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Copier ({filteredFlights.length})</span>
                </button>

                {onClearOldTweets && (
                  <button
                    onClick={onClearOldTweets}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-950/40 hover:bg-amber-900/50 text-amber-300 text-xs font-bold border border-amber-500/30 transition cursor-pointer"
                    title="Nettoyer les anciens matchs et vieux tweets terminés"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span>Purger Vieux Tweets</span>
                  </button>
                )}

                <button
                  onClick={onClearAll}
                  className="p-2 rounded-xl bg-rose-950/40 hover:bg-rose-900/50 text-rose-300 text-xs font-bold border border-rose-500/30 transition cursor-pointer"
                  title="Vider la file des tweets"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </>
            )}
          </div>
        </div>

        {/* Live Countdown Banner if next flight exists */}
        {nextScheduledFlight && nextScheduledFlight.scheduledTimestamp && (
          <div className="mt-4 pt-3 border-t border-emerald-900/40 flex flex-wrap items-center justify-between gap-3 text-xs bg-emerald-950/30 px-3 py-2 rounded-xl border border-emerald-800/40">
            <div className="flex items-center gap-2 text-emerald-300 font-semibold">
              <Clock className="w-4 h-4 text-emerald-400 animate-spin" />
              <span>
                Prochain tweet auto H-1h : <strong>{nextScheduledFlight.matchTitle}</strong>
              </span>
            </div>
            <div className="font-mono font-bold text-amber-300 bg-amber-950/60 px-2.5 py-1 rounded-lg border border-amber-500/30">
              ⏳ Décollage auto dans : {formatCountdown(nextScheduledFlight.scheduledTimestamp)}
            </div>
          </div>
        )}

        {/* Warning if cookies not configured */}
        {!hasCookiesSet && (
          <div className="mt-4 pt-3 border-t border-amber-800/40 flex flex-wrap items-center justify-between gap-3 text-xs bg-amber-950/40 px-4 py-3 rounded-xl border border-amber-500/40">
            <div className="flex items-center gap-2 text-amber-200">
              <AlertCircle className="w-5 h-5 text-amber-400 shrink-0" />
              <div>
                <strong className="block text-white">Connexion X requise pour la publication 100% automatique</strong>
                <span className="text-slate-300">Renseignez vos cookies auth_token + ct0 une seule fois pour que le robot publie directement sans demander de clic.</span>
              </div>
            </div>
            <button
              onClick={onOpenCookiesModal}
              className="px-3.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md transition cursor-pointer"
            >
              🔑 Connecter mon compte X (30s)
            </button>
          </div>
        )}

        {/* 🛡️ ANTI-SPAM & PACING QUEUE STATUS BANNER */}
        <div className="mt-4 pt-3 border-t border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-[#0d1218] p-3.5 rounded-xl border border-cyan-500/30">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-cyan-500/15 border border-cyan-500/30 text-cyan-400 shrink-0">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-black text-white">File d'Attente Anti-Spam (Zéro Publication Simultanée)</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                  Espacement garanti : {queueStatus?.minSpacingSeconds || 60}s
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Chaque tweet (Prono, But, Débrief FT) attend son tour pour ne jamais être publié en même temps.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-between sm:justify-end shrink-0">
            {queueStatus && queueStatus.secondsUntilNextAllowed > 0 ? (
              <span className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-mono font-bold">
                <Clock className="w-3.5 h-3.5 animate-spin" />
                Délai sécurité : {queueStatus.secondsUntilNextAllowed}s
              </span>
            ) : (
              <span className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                Espacement OK
              </span>
            )}

            <span className="px-2.5 py-1 rounded-lg bg-slate-800 border border-slate-700 text-slate-300 text-xs font-bold">
              En file : <strong className="text-cyan-400 font-mono">{queueStatus?.queueLength || 0}</strong>
            </span>
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center justify-between gap-3 mt-4 pt-3 border-t border-slate-800/80">
          <div className="flex items-center gap-2 bg-[#0e0e11] p-1 rounded-xl border border-slate-800 overflow-x-auto">
            <button
              onClick={() => setFilterType("ALL")}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition whitespace-nowrap ${
                filterType === "ALL" ? "bg-indigo-600 text-white shadow-md" : "text-slate-400 hover:text-white"
              }`}
            >
              Tous ({flights.length})
            </button>
            <button
              onClick={() => setFilterType("PRONO_H1")}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition whitespace-nowrap ${
                filterType === "PRONO_H1"
                  ? "bg-amber-600 text-white shadow-md"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              <Flame className="w-3.5 h-3.5 text-amber-300" />
              <span>🎯 Avant-Match H-1h ({h1Count})</span>
            </button>
            <button
              onClick={() => setFilterType("RECAP_FT")}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition whitespace-nowrap ${
                filterType === "RECAP_FT"
                  ? "bg-emerald-600 text-white shadow-md"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300" />
              <span>🏁 Résultats FT ({recapCount})</span>
            </button>
            <button
              onClick={() => setFilterType("PUBLISHED")}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition whitespace-nowrap ${
                filterType === "PUBLISHED"
                  ? "bg-teal-600 text-white shadow-md"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              <Check className="w-3.5 h-3.5 text-teal-300" />
              <span>✅ Déjà Publiés ({publishedCount})</span>
            </button>
          </div>

          <div className="text-xs text-slate-400 font-mono">
            {filteredFlights.length} affiché(s) sur {flights.length} au total
          </div>
        </div>
      </div>

      {/* Empty State */}
      {flights.length === 0 ? (
        <div className="bg-[#16161a] border border-slate-800 rounded-2xl p-12 text-center space-y-4 shadow-xl">
          <div className="w-16 h-16 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center mx-auto text-2xl">
            ⚽
          </div>
          <div className="space-y-1">
            <h3 className="text-base font-black text-white">Aucun tweet programmé dans la file</h3>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              Rendez-vous dans <strong>« 1. SportyTrader Pronos »</strong> pour sélectionner vos matchs. Ils seront programmés et publiés automatiquement à H-1h !
            </p>
          </div>
          <button
            onClick={onNavigateToMatches}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs shadow-lg shadow-emerald-950/50 transition cursor-pointer"
          >
            Choisir des Matchs SportyTrader ➔
          </button>
        </div>
      ) : (
        /* Tweet Cards Grid */
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {filteredFlights.map((f) => {
            const isH1 = f.type === "PRONO_H1";
            const isRecap = f.type === "RECAP_FT";
            const isEditing = editingId === f.id;
            const isWon = f.baggages?.prediction?.includes("Validé") || f.tweetText.includes("✅");
            const isPublished = f.status === "PUBLISHED" || f.status === "LANDED";
            const isScheduled = f.status === "SCHEDULED";
            const isFlying = f.status === "FLYING" || f.status === "BOARDING";
            const isTimeReached = f.scheduledTimestamp ? nowTimestamp >= f.scheduledTimestamp : true;

            return (
              <div
                key={f.id}
                className={`bg-[#16161a] border ${
                  isPublished
                    ? "border-teal-500/40 bg-[#121a18]"
                    : isH1
                    ? isTimeReached
                      ? "border-emerald-500/50 shadow-emerald-950/30"
                      : "border-amber-500/30"
                    : isWon
                    ? "border-emerald-500/40"
                    : "border-rose-500/30"
                } rounded-2xl p-5 shadow-xl flex flex-col justify-between space-y-4 transition hover:border-slate-700 relative`}
              >
                {/* Header (Type Badge, Match Title, Horaires) */}
                <div className="space-y-2.5 border-b border-slate-800/80 pb-3">
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <span
                      className={`px-2.5 py-1 rounded-lg text-xs font-black flex items-center gap-1.5 border ${
                        isPublished
                          ? "bg-teal-500/20 text-teal-300 border-teal-500/30"
                          : isH1
                          ? "bg-amber-500/20 text-amber-300 border-amber-500/30"
                          : isWon
                          ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/30"
                          : "bg-rose-500/20 text-rose-300 border-rose-500/30"
                      }`}
                    >
                      {isPublished ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-teal-400" />
                          <span>✅ PUBLIÉ SUR X {f.publishedAt ? `(${f.publishedAt})` : ""}</span>
                        </>
                      ) : isH1 ? (
                        <>
                          <Flame className="w-3.5 h-3.5 text-amber-400" />
                          <span>🎯 AVANT-MATCH (H-1h)</span>
                        </>
                      ) : (
                        <>
                          {isWon ? (
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                          ) : (
                            <XCircle className="w-3.5 h-3.5 text-rose-400" />
                          )}
                          <span>🏁 RÉSULTAT FT ({isWon ? "GAGNÉ ✅" : "MANQUÉ ❌"})</span>
                        </>
                      )}
                    </span>

                    {/* Schedule / Countdown status badge */}
                    {isPublished ? (
                      <span className="text-[11px] font-mono text-teal-300 px-2 py-0.5 rounded bg-teal-950/60 border border-teal-800/60 flex items-center gap-1">
                        <Check className="w-3 h-3 text-teal-400" />
                        Envoyé avec succès
                      </span>
                    ) : isScheduled && f.scheduledTimestamp && !isTimeReached ? (
                      <span className="text-[11px] font-mono text-amber-300 px-2 py-0.5 rounded bg-amber-950/50 border border-amber-800/60 flex items-center gap-1">
                        <Clock className="w-3 h-3 text-amber-400 animate-spin" />
                        Auto-décollage dans : {formatCountdown(f.scheduledTimestamp)}
                      </span>
                    ) : (
                      <span className="text-[11px] font-mono text-emerald-300 px-2 py-0.5 rounded bg-emerald-950/60 border border-emerald-800/60 flex items-center gap-1">
                        <Zap className="w-3 h-3 text-emerald-400" />
                        {f.departureTime || "Prêt au décollage"}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-black text-white truncate">{f.matchTitle}</h3>
                    {f.baggages?.odd && (
                      <span className="text-xs font-mono font-bold text-amber-300 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                        Cote @{f.baggages.odd}
                      </span>
                    )}
                  </div>

                  {/* Summary / Result Pill */}
                  {f.baggages?.prediction && (
                    <div className="text-xs text-slate-300 bg-[#0e0e11] p-2 rounded-lg border border-slate-800/80 flex items-center justify-between">
                      <span className="text-slate-400">Prono :</span>
                      <span className="font-bold text-emerald-400 truncate max-w-[260px]">
                        {f.baggages.prediction}
                      </span>
                    </div>
                  )}
                </div>

                {/* Tweet Body Preview */}
                <div className="space-y-1.5 flex-1">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-bold text-slate-400">Texte du Tweet pour X :</span>
                    <span
                      className={`font-mono ${
                        (isEditing ? editedText.length : f.tweetText.length) > 270
                          ? "text-rose-400 font-bold"
                          : "text-slate-500"
                      }`}
                    >
                      {isEditing ? editedText.length : f.tweetText.length}/280 car.
                    </span>
                  </div>

                  {isEditing ? (
                    <div className="space-y-2">
                      <textarea
                        value={editedText}
                        onChange={(e) => setEditedText(e.target.value)}
                        rows={6}
                        className="w-full bg-[#0e0e11] border border-indigo-500/50 rounded-xl p-3 text-xs text-slate-200 focus:outline-none font-mono resize-y"
                      />
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => setEditingId(null)}
                          className="px-2.5 py-1 rounded bg-[#1c1c22] text-slate-400 text-xs hover:text-white"
                        >
                          Annuler
                        </button>
                        <button
                          onClick={() => handleSaveEdit(f.id)}
                          className="px-3 py-1 rounded bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-500"
                        >
                          Enregistrer
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="p-3.5 bg-[#0d0d10] border border-slate-800/90 rounded-xl text-xs text-slate-300 font-mono whitespace-pre-line leading-relaxed shadow-inner">
                      {f.tweetText}
                    </div>
                  )}
                </div>

                {/* Actions Footer */}
                <div className="pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => handleCopy(f.tweetText, f.id)}
                      className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#1c1c22] hover:bg-slate-800 text-slate-300 text-xs transition cursor-pointer"
                      title="Copier"
                    >
                      {copiedId === f.id ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                      <span>{copiedId === f.id ? "Copié !" : "Copier"}</span>
                    </button>

                    <button
                      onClick={() => handleStartEdit(f)}
                      className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#1c1c22] hover:bg-slate-800 text-slate-400 hover:text-white text-xs transition cursor-pointer"
                      title="Modifier"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>Modifier</span>
                    </button>

                    <button
                      onClick={() => onDeleteFlight(f.id)}
                      className="p-1.5 rounded-lg bg-[#1c1c22] hover:bg-rose-950/40 text-slate-500 hover:text-rose-400 text-xs transition cursor-pointer"
                      title="Supprimer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="flex items-center gap-2 flex-wrap">
                    {/* Link to tweet on X if already published */}
                    {isPublished && f.publishedUrl && (
                      <a
                        href={f.publishedUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-teal-950/60 hover:bg-teal-900/60 text-teal-300 text-xs font-bold border border-teal-500/40 transition"
                      >
                        <ExternalLink className="w-3 h-3" />
                        <span>Voir sur X</span>
                      </a>
                    )}

                    {/* METHOD 1: 1-Click Instant X Web Intent (100% Guaranteed Zero-Config) */}
                    <a
                      href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(f.tweetText)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={() => {
                        if (onPublishWebIntent) {
                          onPublishWebIntent(f);
                        } else {
                          onShowToast("🚀 Ouverture de la fenêtre de publication X...");
                        }
                      }}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 text-white shadow-md shadow-sky-950/40 transition cursor-pointer"
                      title="Ouvre directement la fenêtre X avec votre tweet pré-rempli (fonctionne à 100% sans cookies)"
                    >
                      <ExternalLink className="w-3.5 h-3.5 text-sky-200" />
                      <span>⚡ Publier sur X (1 Clic)</span>
                    </a>

                    {/* METHOD 2: Direct Autonomous Cookies Publisher Button */}
                    <button
                      onClick={() => handlePublish(f)}
                      disabled={publishingId === f.id || isFlying}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold shadow-md transition cursor-pointer disabled:opacity-50 ${
                        isPublished
                          ? "bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700"
                          : "bg-[#1c1c22] hover:bg-emerald-950/50 text-emerald-400 border border-emerald-500/40 hover:border-emerald-400"
                      }`}
                      title="Publier en tâche de fond via vos cookies X"
                    >
                      <Send className="w-3.5 h-3.5 text-emerald-400" />
                      <span>
                        {publishingId === f.id || isFlying
                          ? "Envoi..."
                          : isPublished
                          ? "Republier (Cookies)"
                          : "🤖 Auto-Pilote"}
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
