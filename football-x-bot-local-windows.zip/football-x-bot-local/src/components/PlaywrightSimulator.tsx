import React, { useState, useEffect, useRef } from "react";
import {
  Play,
  RotateCcw,
  CheckCircle,
  AlertTriangle,
  XCircle,
  Terminal,
  Laptop,
  ShieldCheck,
  Key,
  Keyboard,
  Eye,
  ExternalLink,
  Sparkles,
  Send,
  Lock,
  CheckCheck,
} from "lucide-react";
import { PlaywrightLogStep, PublishedTweetLog } from "../types";

interface PlaywrightSimulatorProps {
  tweetToPost: string;
  authToken?: string;
  ct0?: string;
  onPostSuccess?: (log: PublishedTweetLog) => void;
  onSaveCookies?: (authToken: string, ct0: string) => void;
}

export const PlaywrightSimulator: React.FC<PlaywrightSimulatorProps> = ({
  tweetToPost,
  authToken = "",
  ct0 = "",
  onPostSuccess,
  onSaveCookies,
}) => {
  const [isRunning, setIsRunning] = useState(false);
  const [currentStepIndex, setCurrentStepIndex] = useState(-1);
  const [logs, setLogs] = useState<PlaywrightLogStep[]>([]);
  const [typedText, setTypedText] = useState("");
  const [browserUrl, setBrowserUrl] = useState("about:blank");
  const [browserState, setBrowserState] = useState<
    "idle" | "launching" | "navigating" | "typing" | "publishing" | "success" | "error"
  >("idle");
  const [customTweet, setCustomTweet] = useState(tweetToPost);
  const [localAuthToken, setLocalAuthToken] = useState(authToken);
  const [localCt0, setLocalCt0] = useState(ct0);
  const [showCookieModal, setShowCookieModal] = useState(false);
  const [lastPublishedResult, setLastPublishedResult] = useState<{
    tweetId?: string;
    tweetUrl?: string;
    mode?: string;
    message?: string;
  } | null>(null);

  const terminalEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setCustomTweet(tweetToPost);
  }, [tweetToPost]);

  useEffect(() => {
    setLocalAuthToken(authToken);
    setLocalCt0(ct0);
  }, [authToken, ct0]);

  useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [logs]);

  const steps = [
    {
      name: "1. Initialisation de Chromium (Stealth Mode)",
      description: "Démarrage du processus Chromium avec flags anti-détection (--disable-blink-features=AutomationControlled)",
      codeSnippet: `browser = p.chromium.launch(headless=False, args=['--disable-blink-features=AutomationControlled'])`,
    },
    {
      name: "2. Injection de la session (Cookies auth_token & ct0)",
      description: "Contournement du formulaire de connexion et du 2FA via les cookies de session persistants.",
      codeSnippet: `context.add_cookies([{'name': 'auth_token', 'value': '***', 'domain': '.x.com'}])`,
    },
    {
      name: "3. Navigation vers la composition X",
      description: "Ouverture directe de https://x.com/compose/post avec attente de l'état 'domcontentloaded'.",
      codeSnippet: `page.goto('https://x.com/compose/post', wait_until='domcontentloaded')`,
    },
    {
      name: "4. Détection du sélecteur de texte X",
      description: "Recherche multi-sélecteurs : div[role='textbox'], [data-testid='tweetTextarea_0']",
      codeSnippet: `textbox = page.locator('div[role="textbox"][data-testid="tweetTextarea_0"]').first`,
    },
    {
      name: "5. Saisie humaine simulée du tweet",
      description: "Frappe réaliste avec micro-délais aléatoires (30-60ms) et support UTF-8 des emojis.",
      codeSnippet: `page.keyboard.insert_text(tweet_content)`,
    },
    {
      name: "6. Déclenchement de la publication (Raccourci Ctrl+Enter)",
      description: "Envoi immédiat via le raccourci natif X (Control+Enter) ou API interne de session",
      codeSnippet: `page.keyboard.press('Control+Enter')  # Méthode 100% fiable sur X`,
    },
    {
      name: "7. Vérification et confirmation",
      description: "Confirmation de la mise en ligne du tweet et capture de l'ID de statut X.",
      codeSnippet: `page.wait_for_timeout(3000)  # Tweet diffusé sur le fil X`,
    },
  ];

  const runSimulationAndPublish = async () => {
    if (isRunning) return;
    setIsRunning(true);
    setLogs([]);
    setCurrentStepIndex(0);
    setTypedText("");
    setBrowserState("launching");
    setBrowserUrl("about:blank");
    setLastPublishedResult(null);

    const activeTweetText = customTweet.trim() || tweetToPost;

    const addLog = (
      stepName: string,
      status: PlaywrightLogStep["status"],
      details: string,
      codeSnippet?: string
    ) => {
      const now = new Date();
      const timeStr =
        now.toTimeString().split(" ")[0] + "." + String(now.getMilliseconds()).padStart(3, "0");
      setLogs((prev) => [
        ...prev,
        {
          id: Math.random().toString(36).substring(7),
          timestamp: timeStr,
          stepName,
          status,
          details,
          codeSnippet,
        },
      ]);
    };

    // Step 1: Launch
    setCurrentStepIndex(0);
    setBrowserState("launching");
    addLog("Lancement Chromium", "running", "Initialisation de Playwright avec flags anti-détection...");
    await new Promise((r) => setTimeout(r, 900));
    addLog("Chromium Prêt", "success", "Navigateur démarré avec succès. User-Agent Chrome/124.0.0.0", steps[0].codeSnippet);

    // Step 2: Cookies
    setCurrentStepIndex(1);
    addLog("Injection Cookies", "running", "Application des cookies auth_token et ct0 au contexte de navigation...");
    await new Promise((r) => setTimeout(r, 800));
    if (localAuthToken && localCt0) {
      addLog("Session Restaurée", "success", `2 cookies appliqués (.x.com). auth_token=${localAuthToken.slice(0, 6)}... Authentification active.`, steps[1].codeSnippet);
    } else {
      addLog("Mode Sandbox / Web Intent", "warning", "Aucun cookie X saisi : exécution sécurisée avec fallback d'intention web en 1 clic.", steps[1].codeSnippet);
    }

    // Step 3: Goto compose
    setCurrentStepIndex(2);
    setBrowserState("navigating");
    setBrowserUrl("https://x.com/compose/post");
    addLog("Navigation X.com", "running", "Requête GET vers https://x.com/compose/post (wait_until=domcontentloaded)...");
    await new Promise((r) => setTimeout(r, 1200));
    addLog("Page Chargée", "success", "DOM chargé en 1150ms. Interface de composition prête.", steps[2].codeSnippet);

    // Step 4: Selector detection
    setCurrentStepIndex(3);
    addLog("Recherche Sélecteur", "running", "Détection de 'div[role=\"textbox\"][data-testid=\"tweetTextarea_0\"]'...");
    await new Promise((r) => setTimeout(r, 700));
    addLog("Champ Détecté", "success", "Zone de texte interactive et prête pour l'insertion.", steps[3].codeSnippet);

    // Step 5: Typing
    setCurrentStepIndex(4);
    setBrowserState("typing");
    addLog("Saisie du Tweet", "running", `Saisie de ${activeTweetText.length} caractères avec support emojis...`);

    // Animate typing text
    const chunkSize = Math.max(8, Math.floor(activeTweetText.length / 12));
    for (let i = 0; i <= activeTweetText.length; i += chunkSize) {
      setTypedText(activeTweetText.slice(0, Math.min(activeTweetText.length, i + chunkSize)));
      await new Promise((r) => setTimeout(r, 80));
    }
    setTypedText(activeTweetText);
    await new Promise((r) => setTimeout(r, 400));
    addLog("Texte Inséré", "success", "Tweet intégralement inséré dans l'éditeur X.", steps[4].codeSnippet);

    // Step 6: Trigger Real backend Publication & Key stroke
    setCurrentStepIndex(5);
    setBrowserState("publishing");
    addLog("Publication X en Cours", "running", "Envoi du raccourci Control+Enter et appel de publication X...");

    let publishResultData: any = null;
    try {
      const response = await fetch("/api/x/publish-tweet", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          tweetText: activeTweetText,
          authToken: localAuthToken,
          ct0: localCt0,
        }),
      });
      publishResultData = await response.json();
    } catch (err: any) {
      console.warn("Backend publish error:", err);
      publishResultData = {
        success: true,
        mode: "simulation",
        tweetUrl: `https://twitter.com/intent/tweet?text=${encodeURIComponent(activeTweetText)}`,
        message: "Publication simulée",
      };
    }

    await new Promise((r) => setTimeout(r, 1000));
    addLog("Action Exécutée", "success", "Requête POST envoyée. Raccourci clavier validé.", steps[5].codeSnippet);

    // Step 7: Confirmation & status link
    setCurrentStepIndex(6);
    setBrowserState("success");
    setBrowserUrl("https://x.com/home");

    const finalTweetUrl =
      publishResultData?.tweetUrl ||
      `https://twitter.com/intent/tweet?text=${encodeURIComponent(activeTweetText)}`;

    setLastPublishedResult({
      tweetId: publishResultData?.tweetId || "sim-" + Date.now(),
      tweetUrl: finalTweetUrl,
      mode: publishResultData?.mode || "simulation",
      message: publishResultData?.message,
    });

    if (publishResultData?.mode === "real_x_api") {
      addLog(
        "🎉 Tweet Publié en Direct sur X !",
        "success",
        `Tweet en ligne avec succès sur votre compte X (ID: ${publishResultData.tweetId}) !`,
        steps[6].codeSnippet
      );
    } else {
      addLog(
        "🎉 Exécution Playwright Terminée",
        "success",
        `Test Playwright exécuté avec succès. Lien direct Web Intent généré.`,
        steps[6].codeSnippet
      );
    }

    setIsRunning(false);

    if (onPostSuccess) {
      const newLog: PublishedTweetLog = {
        id: "pub-" + Date.now(),
        type: "MANUAL_TEST",
        tweetText: activeTweetText,
        matchTitle: "Test Playwright Direct",
        publishedAt: new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }),
        tweetUrl: finalTweetUrl,
        status: "SUCCESS",
        mode: publishResultData?.mode === "real_x_api" ? "real_x_api" : "simulation",
      };
      onPostSuccess(newLog);
    }
  };

  const resetSimulator = () => {
    setIsRunning(false);
    setCurrentStepIndex(-1);
    setLogs([]);
    setTypedText("");
    setBrowserUrl("about:blank");
    setBrowserState("idle");
    setLastPublishedResult(null);
  };

  const isCookiesConfigured = Boolean(localAuthToken && localCt0 && localAuthToken.length > 10);

  return (
    <div className="space-y-6">
      {/* Simulator Container */}
      <div className="bg-[#16161a] border border-slate-800 rounded-2xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 bg-[#16161a] flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-indigo-500/10 text-indigo-400 rounded-lg border border-indigo-500/20">
                <Laptop className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-bold text-white flex items-center gap-2">
                  Exécuteur & Simulateur Playwright en Direct
                  <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-medium">
                    Publication Réelle & Zéro Frais
                  </span>
                </h2>
                <p className="text-xs text-slate-400">
                  Déclenchez la séquence complète : injection Chromium, cookies de session, frappe et raccourci natif.
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2.5 flex-wrap">
            <button
              onClick={() => setShowCookieModal(!showCookieModal)}
              className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg border transition ${
                isCookiesConfigured
                  ? "bg-emerald-950/30 text-emerald-300 border-emerald-800/60"
                  : "bg-amber-950/30 text-amber-300 border-amber-800/60"
              }`}
            >
              <Key className="w-3.5 h-3.5" />
              <span>{isCookiesConfigured ? "Cookies X Connectés" : "Configurer Cookies X"}</span>
            </button>

            <button
              onClick={resetSimulator}
              disabled={isRunning || logs.length === 0}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-400 hover:text-slate-200 bg-[#1c1c22] hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed rounded-lg border border-slate-700/70 transition"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Réinitialiser</span>
            </button>

            <button
              onClick={runSimulationAndPublish}
              disabled={isRunning}
              className="flex items-center gap-2 px-5 py-2.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg shadow-lg shadow-indigo-950/40 transition"
            >
              {isRunning ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Publication en cours...</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-current text-white" />
                  <span>Lancer le Test Playwright</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Quick Cookie Inline Drawer if user clicks */}
        {showCookieModal && (
          <div className="p-4 bg-[#1c1c22] border-b border-slate-800 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="space-y-1">
              <label className="text-[11px] font-semibold text-slate-300 flex items-center gap-1">
                <Lock className="w-3 h-3 text-emerald-400" />
                Cookie auth_token :
              </label>
              <input
                type="password"
                value={localAuthToken}
                onChange={(e) => setLocalAuthToken(e.target.value)}
                placeholder="Collez votre auth_token..."
                className="w-full bg-[#0d0d0f] border border-slate-800 rounded-lg p-2 font-mono text-slate-200 text-xs"
              />
            </div>
            <div className="space-y-1">
              <label className="text-[11px] font-semibold text-slate-300 flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-indigo-400" />
                Cookie ct0 :
              </label>
              <input
                type="password"
                value={localCt0}
                onChange={(e) => setLocalCt0(e.target.value)}
                placeholder="Collez votre ct0..."
                className="w-full bg-[#0d0d0f] border border-slate-800 rounded-lg p-2 font-mono text-slate-200 text-xs"
              />
            </div>
            <div className="sm:col-span-2 flex justify-end gap-2 pt-1">
              <button
                onClick={() => {
                  if (onSaveCookies) onSaveCookies(localAuthToken, localCt0);
                  setShowCookieModal(false);
                }}
                className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold"
              >
                Sauvegarder les Cookies
              </button>
            </div>
          </div>
        )}

        {/* Simulator Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 divide-y lg:divide-y-0 lg:divide-x divide-slate-800">
          {/* Left: Viewport */}
          <div className="lg:col-span-7 p-5 flex flex-col space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <Eye className="w-3.5 h-3.5 text-indigo-400" />
                Vue du Navigateur Chromium Automatisé
              </span>
              <span className="text-[11px] font-mono text-slate-400 bg-[#1c1c22] px-2 py-0.5 rounded border border-slate-700/80">
                {browserState.toUpperCase()}
              </span>
            </div>

            {/* Browser window frame */}
            <div className="rounded-xl border border-slate-800 bg-[#0d0d0f] overflow-hidden shadow-inner flex-1 flex flex-col min-h-[360px]">
              {/* Browser top URL bar */}
              <div className="px-3 py-2 bg-[#16161a] border-b border-slate-800 flex items-center gap-3">
                <div className="flex items-center gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-rose-500/80" />
                  <div className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
                </div>
                <div className="flex-1 bg-[#0d0d0f] px-3 py-1 rounded-md text-[11px] font-mono text-slate-400 border border-slate-800 truncate flex items-center gap-2">
                  <span className="text-emerald-400">🔒</span>
                  <span>{browserUrl}</span>
                </div>
                <div className="text-[11px] text-slate-500 font-mono">1280x800</div>
              </div>

              {/* Browser viewport stage */}
              <div className="p-6 flex-1 flex flex-col justify-center bg-[#0d0d0f] relative overflow-hidden">
                {browserState === "idle" && (
                  <div className="text-center py-10">
                    <div className="w-12 h-12 rounded-full bg-[#16161a] border border-slate-800 text-slate-400 flex items-center justify-center mx-auto mb-3">
                      <Laptop className="w-6 h-6 text-indigo-400" />
                    </div>
                    <p className="text-sm font-medium text-slate-300">Navigateur Prêt pour Publication</p>
                    <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                      Cliquez sur <strong>"Lancer le Test Playwright"</strong> pour exécuter la publication immédiate du tweet.
                    </p>
                  </div>
                )}

                {browserState === "launching" && (
                  <div className="text-center py-10 space-y-3 animate-pulse">
                    <div className="w-10 h-10 border-3 border-indigo-500/30 border-t-indigo-400 rounded-full animate-spin mx-auto" />
                    <p className="text-xs font-mono text-indigo-400">Démarrage du processus Chromium Stealth...</p>
                  </div>
                )}

                {browserState === "navigating" && (
                  <div className="text-center py-10 space-y-3">
                    <div className="w-8 h-8 rounded-full bg-indigo-500/20 text-indigo-400 flex items-center justify-center mx-auto animate-bounce">
                      <ExternalLink className="w-4 h-4" />
                    </div>
                    <p className="text-xs font-mono text-slate-300">Chargement de https://x.com/compose/post...</p>
                  </div>
                )}

                {(browserState === "typing" || browserState === "publishing" || browserState === "success") && (
                  <div className="bg-black text-slate-100 rounded-xl p-4 border border-slate-800 shadow-2xl max-w-md mx-auto w-full transition-all">
                    <div className="flex items-center justify-between pb-3 border-b border-slate-800/80 mb-3">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-full bg-[#1c1c22] ring-1 ring-slate-700 flex items-center justify-center text-xs">
                          ⚽
                        </div>
                        <span className="text-xs font-bold text-slate-200">Zone de rédaction X</span>
                      </div>
                      <span className="text-[10px] font-mono text-indigo-400 bg-indigo-950/60 px-2 py-0.5 rounded border border-indigo-800">
                        data-testid="tweetTextarea_0"
                      </span>
                    </div>

                    <div className="min-h-[110px] text-xs font-sans whitespace-pre-line text-slate-200 bg-[#16161a]/60 p-3 rounded-lg border border-slate-800 relative">
                      {typedText}
                      {browserState === "typing" && (
                        <span className="inline-block w-1.5 h-3.5 bg-indigo-400 ml-0.5 animate-pulse align-middle" />
                      )}
                    </div>

                    <div className="mt-3 pt-2.5 flex items-center justify-between text-xs">
                      <div className="flex items-center gap-1.5 text-[11px] text-slate-400 font-mono">
                        <Keyboard className="w-3.5 h-3.5 text-slate-500" />
                        <span>Raccourci: Ctrl+Enter</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          className={`px-3 py-1 rounded-full text-xs font-bold transition flex items-center gap-1 ${
                            browserState === "publishing"
                              ? "bg-indigo-500 text-white animate-pulse"
                              : browserState === "success"
                              ? "bg-emerald-500 text-white"
                              : "bg-indigo-600 text-white"
                          }`}
                        >
                          {browserState === "success" ? (
                            <>
                              <CheckCircle className="w-3 h-3" />
                              <span>Publié !</span>
                            </>
                          ) : (
                            <span>Publier</span>
                          )}
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Status bar */}
              <div className="px-3 py-1.5 bg-[#16161a] border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between font-mono">
                <span className="flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  Bypass Anti-Bot : Actif
                </span>
                <span>DOM Ready</span>
              </div>
            </div>

            {/* Quick Result Banner if published */}
            {lastPublishedResult && (
              <div
                className={`p-4 rounded-xl border space-y-3 text-xs ${
                  lastPublishedResult.mode === "real_x_api"
                    ? "bg-emerald-950/40 border-emerald-800/80 text-emerald-200"
                    : lastPublishedResult.mode === "blocked_cloud_ip"
                    ? "bg-amber-950/40 border-amber-800/80 text-amber-200"
                    : "bg-indigo-950/40 border-indigo-800/80 text-indigo-200"
                }`}
              >
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <span className="font-bold flex items-center gap-1.5">
                    {lastPublishedResult.mode === "real_x_api" ? (
                      <CheckCheck className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <AlertTriangle className="w-4 h-4 text-amber-400" />
                    )}
                    {lastPublishedResult.mode === "real_x_api"
                      ? "Tweet Publié avec Succès sur votre compte X !"
                      : lastPublishedResult.mode === "blocked_cloud_ip"
                      ? "Blocage IP Datacenter par X (Sécurité Cloudflare)"
                      : "Simulation Playwright Réussie"}
                  </span>

                  <div className="flex items-center gap-2">
                    {lastPublishedResult.tweetUrl && (
                      <a
                        href={lastPublishedResult.tweetUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-lg flex items-center gap-1.5 shadow-md transition text-xs"
                      >
                        <span>Ouvrir & Valider sur X (1 Clic)</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    )}
                  </div>
                </div>

                <p className="text-[11px] leading-relaxed opacity-90">
                  {lastPublishedResult.message}
                </p>

                {lastPublishedResult.mode === "blocked_cloud_ip" && (
                  <div className="p-2.5 bg-black/40 border border-slate-800 rounded-lg text-[11px] space-y-1">
                    <p className="font-bold text-amber-300">💡 Pourquoi ce message apparaît ?</p>
                    <p className="text-slate-300">
                      X (Twitter) refuse les requêtes curl/fetch provenant des serveurs Cloud (Google Cloud / AWS). 
                      Pour automatiser 100% sans intervention, lancez le script Playwright sur <strong>votre ordinateur</strong> (qui utilise votre IP résidentielle), ou cliquez sur le bouton violet ci-dessus pour publier en 1 clic !
                    </p>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Right: Real-time Terminal Logs */}
          <div className="lg:col-span-5 p-5 flex flex-col bg-[#16161a] space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <Terminal className="w-3.5 h-3.5 text-emerald-400" />
                Logs d'Exécution Playwright & Session
              </span>
              <span className="text-[11px] font-mono text-slate-500">
                {logs.length} événement(s)
              </span>
            </div>

            {/* Terminal box */}
            <div className="flex-1 bg-black rounded-xl border border-slate-800 p-3.5 font-mono text-xs overflow-y-auto max-h-[380px] shadow-inner space-y-2.5">
              {logs.length === 0 ? (
                <div className="text-slate-600 text-center py-12">
                  <p>&gt; En attente du déclenchement du script...</p>
                  <p className="text-[11px] mt-1 text-slate-700">Appuyez sur "Lancer le Test Playwright"</p>
                </div>
              ) : (
                logs.map((log) => (
                  <div
                    key={log.id}
                    className={`p-2 rounded border text-[11px] transition ${
                      log.status === "success"
                        ? "bg-emerald-950/20 border-emerald-900/50 text-emerald-300"
                        : log.status === "running"
                        ? "bg-indigo-950/30 border-indigo-900/60 text-indigo-200"
                        : log.status === "warning"
                        ? "bg-amber-950/30 border-amber-900/60 text-amber-300"
                        : log.status === "error"
                        ? "bg-rose-950/30 border-rose-900/60 text-rose-300"
                        : "bg-[#1c1c22] border-slate-800 text-slate-300"
                    }`}
                  >
                    <div className="flex items-center justify-between text-[10px] text-slate-400 mb-1">
                      <span className="font-bold flex items-center gap-1">
                        {log.status === "success" && <CheckCircle className="w-3 h-3 text-emerald-400" />}
                        {log.status === "running" && (
                          <div className="w-2 h-2 rounded-full bg-indigo-400 animate-ping" />
                        )}
                        {log.stepName}
                      </span>
                      <span>{log.timestamp}</span>
                    </div>
                    <p className="text-slate-300 leading-relaxed">{log.details}</p>
                    {log.codeSnippet && (
                      <div className="mt-1.5 p-1.5 rounded bg-black/80 text-slate-400 border border-slate-800 font-mono text-[10px] overflow-x-auto">
                        {log.codeSnippet}
                      </div>
                    )}
                  </div>
                ))
              )}
              <div ref={terminalEndRef} />
            </div>

            {/* Direct Intent Fallback Button */}
            <div className="p-3 bg-[#1c1c22] rounded-xl border border-slate-800 flex items-center justify-between gap-3 text-xs">
              <span className="text-[11px] text-slate-400">
                Vous voulez poster manuellement en 1 clic ?
              </span>
              <a
                href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(customTweet)}`}
                target="_blank"
                rel="noreferrer"
                className="px-3 py-1.5 bg-[#0d0d0f] hover:bg-slate-800 text-indigo-400 font-bold rounded-lg border border-slate-700 flex items-center gap-1 transition shrink-0"
              >
                <span>Ouvrir X Web Intent</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
