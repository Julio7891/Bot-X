import React, { useState, useEffect } from "react";
import {
  Globe,
  RefreshCw,
  Sparkles,
  Zap,
  CheckCircle2,
  Clock,
  ExternalLink,
  Percent,
  Code2,
  FileCode,
  Send,
  Sun,
  Moon,
  Flame,
  Radio,
  Share2,
  TrendingUp,
  Check,
  X,
  ClipboardPaste,
  FileText,
  ChevronDown,
  ChevronUp,
  Plus,
  Trash2,
  Edit2,
  Play,
  Layers,
  Trophy,
  AlertCircle,
  Activity,
  Brain,
  Copy,
  PlaneTakeoff,
} from "lucide-react";
import { AirportFlightTweet } from "../types";
import { buildH1PredictionTweet } from "../utils/predictionEvaluator";
import { parseKickoffAndH1Schedule } from "../utils/dateScheduler";

export interface ScrapedPronoItem {
  id: string;
  date: string;
  kickoffTime: string;
  competition: string;
  homeTeam: string;
  awayTeam: string;
  prediction: string;
  odds?: string;
  probability?: string;
  sourceUrl: string;
  predictedScore?: string;
  confidencePercent?: number;
  keyReasoning?: string;
}

interface SportyTraderScraperViewProps {
  pronos: ScrapedPronoItem[];
  onScrapeRefresh: () => Promise<void>;
  onUpdatePronos?: (newPronos: ScrapedPronoItem[]) => void;
  isScraping: boolean;
  onValidatePronoTweets: (h1Flight: AirportFlightTweet, resultFlight?: AirportFlightTweet) => void;
  onNavigateToTweets: () => void;
  onShowToast: (msg: string) => void;
  existingFlights: AirportFlightTweet[];
}

const TOP_COMPETITIONS = [
  "UEFA Champions League",
  "UEFA Europa League",
  "UEFA Conference League",
  "La Liga",
  "Carabao Cup",
  "Premier League",
  "Ligue 1",
  "Serie A",
  "Bundesliga",
  "Saudi Pro League",
];

export const SportyTraderScraperView: React.FC<SportyTraderScraperViewProps> = ({
  pronos,
  onScrapeRefresh,
  onUpdatePronos,
  isScraping,
  onValidatePronoTweets,
  onNavigateToTweets,
  onShowToast,
  existingFlights,
}) => {
  const [selectedComp, setSelectedComp] = useState<string>("ALL");
  const [showHtmlPasteModal, setShowHtmlPasteModal] = useState(false);
  const [pastedHtml, setPastedHtml] = useState("");
  const [isParsingHtml, setIsParsingHtml] = useState(false);
  const [isCheckingScores, setIsCheckingScores] = useState(false);
  const [lastScrapeTime, setLastScrapeTime] = useState<Date>(new Date());
  const [nextScrapeMinutes, setNextScrapeMinutes] = useState<number>(60);
  const [showEngagementHub, setShowEngagementHub] = useState<boolean>(false);

  // Daily Strategy Cycle State
  const [isAutoGoalAlerts, setIsAutoGoalAlerts] = useState<boolean>(true);
  const [showMorningModal, setShowMorningModal] = useState<boolean>(false);
  const [morningTweetText, setMorningTweetText] = useState<string>("");
  const [isPublishingMorning, setIsPublishingMorning] = useState<boolean>(false);

  const [showDailyRecapModal, setShowDailyRecapModal] = useState<boolean>(false);
  const [dailyRecapText, setDailyRecapText] = useState<string>("");
  const [dailyRecapStats, setDailyRecapStats] = useState<{
    wonCount: number;
    totalMatches: number;
    winRate: number;
    netProfit: number;
  }>({ wonCount: 0, totalMatches: 0, winRate: 0, netProfit: 0 });
  const [isPublishingRecap, setIsPublishingRecap] = useState<boolean>(false);
  const [isInlinePasteOpen, setIsInlinePasteOpen] = useState<boolean>(false);

  // Actively Tracked Matches (Matches published or chosen by user)
  const [trackedMatches, setTrackedMatches] = useState<Array<{
    id: string;
    homeTeam: string;
    awayTeam: string;
    competition: string;
    date?: string;
    kickoffTime?: string;
    prediction: string;
    odd: string;
    status: string;
    publishedAt?: number;
    finalScore?: string;
    isWon?: boolean;
    currentLiveScore?: {
      scoreHome: number;
      scoreAway: number;
      isLive: boolean;
      isFinished: boolean;
      liveMinute?: string;
    } | null;
  }>>([]);

  const [trackedFilterTab, setTrackedFilterTab] = useState<"ALL" | "LIVE" | "UPCOMING" | "FINISHED">("ALL");
  const [showAllPronos, setShowAllPronos] = useState<boolean>(false);
  const [isTrackingAll, setIsTrackingAll] = useState<boolean>(false);
  const [isSimulatingId, setIsSimulatingId] = useState<string | null>(null);

  // Modals for Custom Match & Score Edition
  const [showAddCustomModal, setShowAddCustomModal] = useState<boolean>(false);
  const [customForm, setCustomForm] = useState({
    homeTeam: "",
    awayTeam: "",
    competition: "Ligue 1",
    prediction: "Victoire Home",
    odd: "1.85",
    kickoffTime: "21:00",
    date: "Aujourd'hui",
    scoreHome: 0,
    scoreAway: 0,
    isLive: false,
    isFinished: false,
  });

  const [showEditScoreModal, setShowEditScoreModal] = useState<boolean>(false);
  const [editingTrackedMatch, setEditingTrackedMatch] = useState<any>(null);
  const [editScoreForm, setEditScoreForm] = useState({
    scoreHome: 0,
    scoreAway: 0,
    isLive: true,
    isFinished: false,
    liveMinute: "65'",
    scorerName: "",
    scoringTeam: "home" as "home" | "away",
  });

  // Modal: Instant Goal Alert Tweet Feedback & Direct X Publishing
  const [showGoalModal, setShowGoalModal] = useState<boolean>(false);
  const [goalTweetModalData, setGoalTweetModalData] = useState<{
    tweetText: string;
    matchTitle: string;
    isPublished: boolean;
    tweetId?: string;
    tweetUrl?: string;
    intentUrl?: string;
    message?: string;
  } | null>(null);

  const getClientCreds = () => ({
    authToken: localStorage.getItem("x_auth_token") || "",
    ct0: localStorage.getItem("x_ct0") || "",
    booster1AuthToken: localStorage.getItem("x_booster1_auth_token") || "",
    booster1Ct0: localStorage.getItem("x_booster1_ct0") || "",
    booster2AuthToken: localStorage.getItem("x_booster2_auth_token") || "",
    booster2Ct0: localStorage.getItem("x_booster2_ct0") || "",
  });

  const refreshTrackedPredictions = async () => {
    try {
      const res = await fetch("/api/pipeline/tracked-predictions");
      const data = await res.json();
      if (data.success && data.tracked) {
        setTrackedMatches(data.tracked);
      }
    } catch {
      // silent
    }
  };

  const handleTrackProno = async (item: ScrapedPronoItem) => {
    try {
      const res = await fetch("/api/pipeline/track-prediction", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: item.id,
          homeTeam: item.homeTeam,
          awayTeam: item.awayTeam,
          competition: item.competition,
          date: item.date,
          kickoffTime: item.kickoffTime,
          prediction: item.prediction,
          odd: item.odds || "1.85",
          status: "PUBLISHED",
        }),
      });
      const data = await res.json();
      if (data.success) {
        onShowToast(`📡 ${item.homeTeam} vs ${item.awayTeam} ajouté au suivi direct des buts & résultats !`);
        refreshTrackedPredictions();
      }
    } catch {
      onShowToast("⚠️ Erreur lors de l'ajout au suivi direct.");
    }
  };

  const handleUntrackMatch = async (id: string, matchTitle: string) => {
    try {
      const res = await fetch("/api/pipeline/untrack-prediction", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id }),
      });
      const data = await res.json();
      if (data.success) {
        onShowToast(`🗑️ ${matchTitle} retiré du suivi en direct.`);
        refreshTrackedPredictions();
      }
    } catch {
      onShowToast("⚠️ Erreur lors du retrait du suivi.");
    }
  };

  const handleTrackAllPronos = async () => {
    setIsTrackingAll(true);
    try {
      const res = await fetch("/api/pipeline/track-all-pronos", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });
      const data = await res.json();
      if (data.success) {
        onShowToast(`⚡ ${data.addedCount || 0} nouveaux matchs ajoutés au suivi en direct (${data.totalTracked} au total) !`);
        refreshTrackedPredictions();
      } else {
        onShowToast("⚠️ Impossible de suivre tous les matchs.");
      }
    } catch {
      onShowToast("⚠️ Erreur réseau.");
    } finally {
      setIsTrackingAll(false);
    }
  };

  const handleSimulateGoal = async (matchId: string, scoringTeam: "home" | "away", teamName: string) => {
    setIsSimulatingId(matchId);
    try {
      const creds = getClientCreds();
      const res = await fetch("/api/pipeline/simulate-goal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          matchId,
          scoringTeam,
          scorerName: `${teamName} Star`,
          minute: `${Math.floor(Math.random() * 35) + 50}'`,
          ...creds,
        }),
      });
      const data = await res.json();
      if (data.success) {
        if (data.tweet) {
          setGoalTweetModalData({
            tweetText: data.tweet.tweetText,
            matchTitle: data.tweet.matchTitle,
            isPublished: data.tweet.status === "PUBLISHED" || data.publishResult?.success,
            tweetId: data.publishResult?.tweetId,
            tweetUrl: data.publishResult?.tweetUrl,
            intentUrl: data.publishResult?.intentUrl || `https://twitter.com/intent/tweet?text=${encodeURIComponent(data.tweet.tweetText)}`,
            message: data.publishResult?.message || data.message,
          });
          setShowGoalModal(true);
        }
        onShowToast(data.message || `⚽ BUT DÉTECTÉ pour ${teamName} !`);
        refreshTrackedPredictions();
        refreshDailySummary();
      } else {
        onShowToast(`⚠️ ${data.message || "Erreur simulation but."}`);
      }
    } catch {
      onShowToast("⚠️ Erreur lors de la simulation de but.");
    } finally {
      setIsSimulatingId(null);
    }
  };

  const handleSimulateFT = async (matchId: string, scoreHome?: number, scoreAway?: number) => {
    setIsSimulatingId(matchId);
    try {
      const res = await fetch("/api/pipeline/simulate-ft", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          matchId,
          scoreHome,
          scoreAway,
        }),
      });
      const data = await res.json();
      if (data.success) {
        onShowToast(data.message || "🏁 Match terminé ! Débriefing FT et calcul de performance exécutés.");
        refreshTrackedPredictions();
        refreshDailySummary();
      } else {
        onShowToast(`⚠️ ${data.message || "Erreur débriefing FT."}`);
      }
    } catch {
      onShowToast("⚠️ Erreur lors de la simulation FT.");
    } finally {
      setIsSimulatingId(null);
    }
  };

  const handleOpenEditScore = (tm: any) => {
    setEditingTrackedMatch(tm);
    const live = tm.currentLiveScore;
    setEditScoreForm({
      scoreHome: live ? live.scoreHome : tm.scoreHome || 0,
      scoreAway: live ? live.scoreAway : tm.scoreAway || 0,
      isLive: live ? live.isLive : true,
      isFinished: live ? live.isFinished : false,
      liveMinute: live?.liveMinute || "60'",
      scorerName: "",
      scoringTeam: "home",
    });
    setShowEditScoreModal(true);
  };

  const handleSaveEditScore = async () => {
    if (!editingTrackedMatch) return;
    try {
      const creds = getClientCreds();
      const res = await fetch("/api/pipeline/update-live-score", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          matchId: editingTrackedMatch.id,
          scoreHome: editScoreForm.scoreHome,
          scoreAway: editScoreForm.scoreAway,
          isLive: editScoreForm.isLive,
          isFinished: editScoreForm.isFinished,
          liveMinute: editScoreForm.liveMinute,
          scorerName: editScoreForm.scorerName ? editScoreForm.scorerName.trim() : undefined,
          scoringTeam: editScoreForm.scoringTeam,
          ...creds,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setShowEditScoreModal(false);
        if (data.tweet) {
          setGoalTweetModalData({
            tweetText: data.tweet.tweetText,
            matchTitle: data.tweet.matchTitle,
            isPublished: data.tweet.status === "PUBLISHED" || data.publishResult?.success,
            tweetId: data.publishResult?.tweetId,
            tweetUrl: data.publishResult?.tweetUrl,
            intentUrl: data.publishResult?.intentUrl || `https://twitter.com/intent/tweet?text=${encodeURIComponent(data.tweet.tweetText)}`,
            message: data.publishResult?.message || "Tweet But généré",
          });
          setShowGoalModal(true);
        }
        const goalNotice = data.tweet ? " ⚽ Alerte But traitée !" : "";
        onShowToast(`✅ Score mis à jour : ${editingTrackedMatch.homeTeam} ${editScoreForm.scoreHome} - ${editScoreForm.scoreAway} ${editingTrackedMatch.awayTeam}${goalNotice}`);
        refreshTrackedPredictions();
        refreshDailySummary();
      } else {
        onShowToast("⚠️ Erreur lors de la mise à jour du score.");
      }
    } catch {
      onShowToast("⚠️ Erreur réseau lors de la mise à jour.");
    }
  };

  const handleSaveCustomMatch = async () => {
    if (!customForm.homeTeam.trim() || !customForm.awayTeam.trim()) {
      onShowToast("⚠️ Veuillez renseigner les équipes à domicile et à l'extérieur.");
      return;
    }

    try {
      const res = await fetch("/api/pipeline/track-prediction", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          homeTeam: customForm.homeTeam.trim(),
          awayTeam: customForm.awayTeam.trim(),
          competition: customForm.competition,
          prediction: customForm.prediction,
          odd: customForm.odd,
          kickoffTime: customForm.kickoffTime,
          date: customForm.date,
          status: "PUBLISHED",
        }),
      });
      const data = await res.json();
      if (data.success) {
        if (customForm.isLive || customForm.scoreHome > 0 || customForm.scoreAway > 0) {
          await fetch("/api/pipeline/update-live-score", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              matchId: data.tracked.id,
              scoreHome: customForm.scoreHome,
              scoreAway: customForm.scoreAway,
              isLive: customForm.isLive,
              isFinished: customForm.isFinished,
              liveMinute: customForm.isFinished ? "FT" : "LIVE",
            }),
          });
        }
        setShowAddCustomModal(false);
        setCustomForm({
          homeTeam: "",
          awayTeam: "",
          competition: "Ligue 1",
          prediction: "Victoire Home",
          odd: "1.85",
          kickoffTime: "21:00",
          date: "Aujourd'hui",
          scoreHome: 0,
          scoreAway: 0,
          isLive: false,
          isFinished: false,
        });
        onShowToast(`🎉 Match ${customForm.homeTeam} vs ${customForm.awayTeam} ajouté au suivi direct !`);
        refreshTrackedPredictions();
      }
    } catch {
      onShowToast("⚠️ Erreur lors de l'ajout du match personnalisé.");
    }
  };

  // Fetch auto-scraper status and daily cycle summary
  const refreshDailySummary = async () => {
    try {
      const res = await fetch("/api/pipeline/daily-summary");
      const data = await res.json();
      if (data.success) {
        if (data.morningTweet) setMorningTweetText(data.morningTweet);
        if (data.dailyRecap) {
          setDailyRecapText(data.dailyRecap.tweetText);
          setDailyRecapStats({
            wonCount: data.dailyRecap.wonCount || 0,
            totalMatches: data.dailyRecap.totalMatches || 0,
            winRate: data.dailyRecap.winRate || 0,
            netProfit: data.dailyRecap.netProfit || 0,
          });
        }
        if (typeof data.isAutoGoalAlertsEnabled === "boolean") {
          setIsAutoGoalAlerts(data.isAutoGoalAlertsEnabled);
        }
      }
    } catch (e) {
      // silent
    }
    refreshTrackedPredictions();
  };

  useEffect(() => {
    refreshDailySummary();
    const fetchStatus = async () => {
      try {
        const res = await fetch("/api/scraper/sportytrader/status");
        const data = await res.json();
        if (data.success) {
          if (data.lastScrapeTimestamp) {
            setLastScrapeTime(new Date(data.lastScrapeTimestamp));
          }
          if (data.nextScrapeTimestamp) {
            const mins = Math.max(1, Math.round((data.nextScrapeTimestamp - Date.now()) / 60000));
            setNextScrapeMinutes(mins);
          }
        }
      } catch (e) {
        // silent fallback
      }
    };

    fetchStatus();
    const interval = setInterval(() => {
      fetchStatus();
      refreshDailySummary();
    }, 10000); // 10s auto-refresh in UI
    return () => clearInterval(interval);
  }, []);

  const getMatchSchedule = (item: ScrapedPronoItem) => {
    return parseKickoffAndH1Schedule(item.date, item.kickoffTime);
  };

  // Match filtering
  const upcomingPronos = pronos.filter((item) => {
    const s = getMatchSchedule(item);
    return !s.isPastKickoff && !s.isMatchFinished;
  });

  const isAutoShowingAll = !showAllPronos && upcomingPronos.length === 0 && pronos.length > 0;
  const displayedSourcePronos = (showAllPronos || isAutoShowingAll) ? pronos : upcomingPronos;

  const filteredPronos = displayedSourcePronos.filter((item) => {
    if (selectedComp !== "ALL" && !item.competition.toLowerCase().includes(selectedComp.toLowerCase())) {
      return false;
    }
    return true;
  });

  const getPronoStatus = (pronoId: string) => {
    const hasH1 = existingFlights.some((f) => f.matchId === pronoId && f.type === "PRONO_H1");
    return { hasH1, isScheduled: hasH1 };
  };

  const handleToggleGoalAlerts = async () => {
    const newState = !isAutoGoalAlerts;
    setIsAutoGoalAlerts(newState);
    try {
      await fetch("/api/pipeline/toggle-goal-alerts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ enabled: newState }),
      });
      onShowToast(
        newState
          ? "⚽ Alertes Buts en Direct ACTIVÉES ! Le bot publie un tweet dès qu'un but est marqué."
          : "⏸️ Alertes Buts en Direct désactivées."
      );
    } catch (e) {
      onShowToast("⚠️ Erreur lors du basculement des alertes de buts.");
    }
  };

  const handlePublishMorningTweet = async () => {
    setIsPublishingMorning(true);
    try {
      const res = await fetch("/api/pipeline/publish-morning-announcement", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ customText: morningTweetText }),
      });
      const data = await res.json();
      if (data.success) {
        setShowMorningModal(false);
        onShowToast("☀️ Tweet d'Annonce du Matin publié avec succès sur X !");
      } else {
        onShowToast(`⚠️ ${data.message || "Erreur de publication sur X."}`);
      }
    } catch (e: any) {
      onShowToast("⚠️ Impossible de publier le tweet d'annonce.");
    } finally {
      setIsPublishingMorning(false);
    }
  };

  const handlePublishDailyRecap = async () => {
    setIsPublishingRecap(true);
    try {
      const res = await fetch("/api/pipeline/publish-daily-recap", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ customText: dailyRecapText }),
      });
      const data = await res.json();
      if (data.success) {
        setShowDailyRecapModal(false);
        onShowToast("🏁 Grand Tweet Bilan du Soir publié avec succès sur X !");
      } else {
        onShowToast(`⚠️ ${data.message || "Erreur de publication sur X."}`);
      }
    } catch (e: any) {
      onShowToast("⚠️ Impossible de publier le bilan.");
    } finally {
      setIsPublishingRecap(false);
    }
  };

  const handleCreateTweetForProno = (item: ScrapedPronoItem) => {
    const odd = item.odds || "1.90";
    const confidence = item.confidencePercent || parseInt(item.probability || "85", 10) || 85;
    const kickoff = item.kickoffTime || "17:30";

    const schedule = parseKickoffAndH1Schedule(item.date, kickoff);

    const h1TweetText = buildH1PredictionTweet({
      homeTeam: item.homeTeam,
      awayTeam: item.awayTeam,
      league: item.competition,
      kickoffTime: schedule.kickoffTimeLabel,
      prediction: item.prediction,
      odd,
      predictedScore: item.predictedScore || "1-2",
      confidencePercent: confidence,
      date: item.date,
      keyReasoning: item.keyReasoning || `Pronostic avec probabilité estimée à ${confidence}%.`,
    });

    const h1Flight: AirportFlightTweet = {
      id: `h1-${item.id}-${Date.now()}`,
      matchId: item.id,
      matchTitle: `${item.homeTeam} vs ${item.awayTeam}`,
      type: "PRONO_H1",
      tweetText: h1TweetText,
      flightCode: `H1-${item.homeTeam.slice(0, 3).toUpperCase()}`,
      departureTime: schedule.formattedDepartureLabel,
      scheduledTimestamp: schedule.isPastH1 ? Date.now() : schedule.h1Timestamp,
      scheduledTimeLabel: schedule.formattedDepartureLabel,
      isAutoScheduled: true,
      baggages: {
        match: `${item.homeTeam} vs ${item.awayTeam}`,
        prediction: item.prediction,
        odd,
        confidence,
        style: "Prono Avant-Match H-1h",
      },
      status: schedule.isPastH1 ? "READY" : "SCHEDULED",
      createdAt: Date.now(),
    };

    onValidatePronoTweets(h1Flight);
    if (schedule.isPastH1) {
      onShowToast(`✈️ Heure H-1h déjà atteinte pour ${item.homeTeam} vs ${item.awayTeam} : Tweet prêt à l'envoi immédiat !`);
    } else {
      onShowToast(`✈️ Match programmé dans l'Aéroport pour ${item.homeTeam} vs ${item.awayTeam} (Décollage prévu à ${schedule.h1TimeLabel}) !`);
    }
  };

  const calculateClientPronoScore = (p: ScrapedPronoItem): number => {
    let score = 0;
    const compLower = p.competition.toLowerCase();
    if (compLower.includes("champions")) score += 40;
    else if (compLower.includes("premier")) score += 30;
    else if (compLower.includes("ligue 1") || compLower.includes("la liga") || compLower.includes("serie a") || compLower.includes("bundesliga")) score += 20;

    const oddNum = parseFloat(p.odds || "1.8");
    if (oddNum >= 1.6 && oddNum <= 2.2) score += 20;
    score += (p.confidencePercent || 80) / 5;
    return score;
  };

  const handleGenerateSmartSlotTweets = () => {
    const slotsMap = new Map<string, ScrapedPronoItem[]>();
    for (const item of upcomingPronos) {
      const slotKey = `${(item.date || "today").trim()}_${(item.kickoffTime || "21:00").trim()}`;
      if (!slotsMap.has(slotKey)) {
        slotsMap.set(slotKey, []);
      }
      slotsMap.get(slotKey)!.push(item);
    }

    let scheduledCount = 0;
    let skippedDuplicatesCount = 0;

    for (const [_slotKey, matchGroup] of slotsMap.entries()) {
      matchGroup.sort((a, b) => calculateClientPronoScore(b) - calculateClientPronoScore(a));
      const topPick = matchGroup[0];
      const status = getPronoStatus(topPick.id);
      if (!status.isScheduled) {
        handleCreateTweetForProno(topPick);
        scheduledCount++;
      }
      skippedDuplicatesCount += matchGroup.length - 1;
    }

    if (scheduledCount > 0) {
      onShowToast(`🎯 ${scheduledCount} meilleurs matchs programmés (1 par créneau horaire, ${skippedDuplicatesCount} doublons évités) !`);
    } else {
      onShowToast("ℹ️ Les meilleurs matchs de chaque créneau horaire sont déjà programmés.");
    }
  };

  const handleScheduleAllPronos = () => {
    let count = 0;
    for (const item of upcomingPronos) {
      const status = getPronoStatus(item.id);
      if (!status.isScheduled) {
        handleCreateTweetForProno(item);
        count++;
      }
    }
    if (count > 0) {
      onShowToast(`🚀 ${count} matchs programmés à H-1h dans la file d'attente !`);
    } else {
      onShowToast("ℹ️ Tous les matchs à venir sont déjà programmés.");
    }
  };

  const handleCheckLiveScores = async () => {
    setIsCheckingScores(true);
    try {
      const res = await fetch("/api/scraper/sportytrader/check-live-scores", { method: "POST" });
      const data = await res.json();
      if (data.success) {
        let msg = "";
        if (data.goalsDetected > 0) {
          msg += `⚽ ${data.goalsDetected} but(s) en direct détecté(s) & tweeté(s) ! `;
        }
        if (data.finishedMatchesFound > 0) {
          msg += `🏁 ${data.finishedMatchesFound} match(s) terminé(s) débriefé(s) sur X !`;
        }
        if (!msg) {
          msg = "📡 Scores en direct scannés : aucun nouveau but ou match fini à l'instant.";
        }
        onShowToast(msg);
        refreshDailySummary();
      }
    } catch (e: any) {
      onShowToast("⚠️ Erreur lors de la vérification des scores.");
    } finally {
      setIsCheckingScores(false);
    }
  };

  const handleParseCustomHtml = async () => {
    if (!pastedHtml.trim()) return;
    setIsParsingHtml(true);
    try {
      const res = await fetch("/api/scraper/sportytrader/sync-pipeline", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rawHtml: pastedHtml }),
      });
      const data = await res.json();
      if (data.success) {
        setShowHtmlPasteModal(false);
        setPastedHtml("");
        if (data.pronos && data.pronos.length > 0 && onUpdatePronos) {
          onUpdatePronos(data.pronos);
        }
        await onScrapeRefresh();
        onShowToast(`🎉 ${data.newPronosCount || data.pronos?.length || 0} pronostics extraits avec succès !`);
      } else {
        onShowToast("⚠️ Erreur lors de l'extraction des données.");
      }
    } catch (e: any) {
      onShowToast("⚠️ Impossible d'analyser le contenu.");
    } finally {
      setIsParsingHtml(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* 🚀 STRATEGIC DAILY CYCLE BAR (Matin -> H-1h -> Live Goals -> FT Débrief -> Soirée Bilan) */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-indigo-500/30 rounded-2xl p-4 shadow-xl">
        <div className="flex items-center justify-between border-b border-indigo-500/20 pb-3 mb-3 flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-indigo-400 animate-pulse" />
            <h3 className="text-xs font-black uppercase tracking-wider text-indigo-300 flex items-center gap-1.5">
              <Flame className="w-4 h-4 text-amber-400" />
              Cycle Quotidien 100% Automatique & Stratégie X
            </h3>
          </div>
          <span className="text-[11px] text-slate-400">
            Publiez le bon contenu au moment parfait de la journée
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {/* 1. ☀️ Annonce du Matin */}
          <div className="bg-slate-950/80 border border-slate-800/80 hover:border-amber-500/50 rounded-xl p-3.5 flex flex-col justify-between space-y-3 transition">
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="px-2 py-0.5 bg-amber-500/10 text-amber-300 border border-amber-500/20 rounded-md text-[10px] font-black uppercase">
                  ☀️ Matin (09h - 11h)
                </span>
                <span className="text-[10px] text-slate-400 font-mono">1 Post / Jour</span>
              </div>
              <h4 className="text-xs font-bold text-white">Programme & Matchs du Soir</h4>
              <p className="text-[11px] text-slate-400 leading-tight">
                Annonce le récap des affiches analysées pour chauffer la communauté avant les matchs.
              </p>
            </div>

            <button
              onClick={() => {
                refreshDailySummary();
                setShowMorningModal(true);
              }}
              className="w-full py-2 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black rounded-lg text-xs flex items-center justify-center gap-1.5 shadow-md cursor-pointer transition"
            >
              <Sun className="w-3.5 h-3.5 fill-slate-950" />
              📢 Publier l'Annonce du Matin
            </button>
          </div>

          {/* 2. ⚽ Alertes Buts Live */}
          <div className="bg-slate-950/80 border border-slate-800/80 hover:border-emerald-500/50 rounded-xl p-3.5 flex flex-col justify-between space-y-3 transition">
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 rounded-md text-[10px] font-black uppercase flex items-center gap-1">
                  <span className={`w-1.5 h-1.5 rounded-full ${isAutoGoalAlerts ? "bg-emerald-400 animate-ping" : "bg-slate-500"}`} />
                  ⚽ Pendant les Matchs
                </span>
                <span className="text-[10px] text-emerald-400 font-bold">Auto-Poller 60s</span>
              </div>
              <h4 className="text-xs font-bold text-white">Alertes Buts en Direct</h4>
              <p className="text-[11px] text-slate-400 leading-tight">
                Détecte chaque but en temps réel et twitte instantanément avec impact sur le prono & auto-likes.
              </p>
            </div>

            <button
              onClick={handleToggleGoalAlerts}
              className={`w-full py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 border cursor-pointer transition ${
                isAutoGoalAlerts
                  ? "bg-emerald-950/80 border-emerald-500/50 text-emerald-300 hover:bg-emerald-900/60"
                  : "bg-slate-900 border-slate-800 text-slate-400 hover:text-white"
              }`}
            >
              <Radio className={`w-3.5 h-3.5 ${isAutoGoalAlerts ? "text-emerald-400 animate-pulse" : "text-slate-500"}`} />
              {isAutoGoalAlerts ? "🟢 Alertes Buts Live (Actives)" : "⚪ Activer Alertes Buts Live"}
            </button>
          </div>

          {/* 3. 🌙 Grand Bilan du Soir */}
          <div className="bg-slate-950/80 border border-slate-800/80 hover:border-indigo-500/50 rounded-xl p-3.5 flex flex-col justify-between space-y-3 transition">
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="px-2 py-0.5 bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 rounded-md text-[10px] font-black uppercase">
                  🌙 Soir (23h00 / Fin)
                </span>
                <span className="text-[10px] text-indigo-300 font-bold">Winrate & ROI</span>
              </div>
              <h4 className="text-xs font-bold text-white">Grand Bilan de la Journée</h4>
              <p className="text-[11px] text-slate-400 leading-tight">
                Calcule le % de réussite, total validés et bénéfice net pour clôturer la soirée en beauté.
              </p>
            </div>

            <button
              onClick={() => {
                refreshDailySummary();
                setShowDailyRecapModal(true);
              }}
              className="w-full py-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-black rounded-lg text-xs flex items-center justify-center gap-1.5 shadow-md cursor-pointer transition"
            >
              <Moon className="w-3.5 h-3.5" />
              🏁 Publier le Bilan du Soir
            </button>
          </div>
        </div>
      </div>

      {/* 🎯 CYCLE 3-POSTS PAR MATCH (PRONO H-1h ➔ CHAQUE BUT EN DIRECT ➔ DÉBRIEF FT) */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border-2 border-indigo-500/40 rounded-2xl p-4 sm:p-5 shadow-xl">
        <div className="flex items-center justify-between border-b border-indigo-500/20 pb-3 flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <h3 className="text-sm font-black uppercase tracking-wider text-white flex items-center gap-2">
              <Zap className="w-4 h-4 text-amber-400" />
              Cycle Automatique 3 Posts par Match
            </h3>
            <span className="px-2 py-0.5 bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 rounded-full text-[10px] font-black uppercase">
              100% Autonome & Anglais
            </span>
          </div>
          <span className="text-xs text-slate-400">
            Chaque match suivi génère automatiquement sa séquence complète de tweets
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-3 text-xs">
          {/* Étape 1 */}
          <div className="bg-slate-950/80 border border-indigo-500/30 rounded-xl p-3 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="px-2 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-500/40 rounded text-[10px] font-black uppercase">
                1. Post Prono (H-1h)
              </span>
              <Clock className="w-3.5 h-3.5 text-amber-400" />
            </div>
            <h4 className="font-bold text-white">Annonce & Conseil Avant-Match</h4>
            <p className="text-[11px] text-slate-400 leading-snug">
              Publié 1h avant le coup d'envoi avec le prono, la cote, l'indice de confiance et les hashtags officiels.
            </p>
          </div>

          {/* Étape 2 */}
          <div className="bg-slate-950/80 border border-emerald-500/30 rounded-xl p-3 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 rounded text-[10px] font-black uppercase">
                2. Post Chaque But (Live ⚽)
              </span>
              <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            </div>
            <h4 className="font-bold text-white">Alertes Buts en Direct</h4>
            <p className="text-[11px] text-slate-400 leading-snug">
              Détecte chaque but en temps réel, affiche le buteur, la minute, le score actuel et l'avancement du prono.
            </p>
          </div>

          {/* Étape 3 */}
          <div className="bg-slate-950/80 border border-purple-500/30 rounded-xl p-3 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="px-2 py-0.5 bg-purple-500/20 text-purple-300 border border-purple-500/40 rounded text-[10px] font-black uppercase">
                3. Post Débrief (Fin FT 🏁)
              </span>
              <Trophy className="w-3.5 h-3.5 text-purple-400" />
            </div>
            <h4 className="font-bold text-white">Bilan & Validation du Match</h4>
            <p className="text-[11px] text-slate-400 leading-snug">
              Dès le coup de sifflet final, analyse le score FT, affiche le statut GREEN / Perdu et le bilan de la cote.
            </p>
          </div>
        </div>
      </div>

      {/* 📡 ACTIVELY TRACKED MATCHES & REAL-TIME STATUS (LIVE GOALS & AUTO FT DEBRIEF) */}
      <div className="bg-slate-900/95 border-2 border-cyan-500/40 rounded-2xl p-5 shadow-2xl space-y-4">
        {/* Header with Title, Stats & Global Controls */}
        <div className="flex items-center justify-between border-b border-cyan-500/20 pb-4 flex-wrap gap-3">
          <div className="space-y-1">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="w-3 h-3 rounded-full bg-cyan-400 animate-pulse shadow-lg shadow-cyan-500/50" />
              <h3 className="text-sm font-black uppercase tracking-wider text-cyan-300 flex items-center gap-2">
                <Radio className="w-5 h-5 text-cyan-400" />
                Matchs Suivis en Direct ({trackedMatches.length})
              </h3>
              <span className="text-xs px-2.5 py-0.5 bg-cyan-950/90 border border-cyan-500/40 text-cyan-300 rounded-full font-bold">
                🎯 Alertes Buts & Débriefs FT Automatiques
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Ces matchs sont surveillés en temps réel : dès qu'un but est marqué ou que le match se termine, le robot génère et envoie l'alerte sur X.
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={handleTrackAllPronos}
              disabled={isTrackingAll}
              className="px-3.5 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white rounded-xl text-xs font-black flex items-center gap-1.5 shadow-md transition-all cursor-pointer disabled:opacity-50"
              title="Ajouter tous les pronostics SportyTrader au suivi en direct en 1 clic"
            >
              <Zap className="w-3.5 h-3.5" />
              {isTrackingAll ? "Ajout..." : "⚡ Suivre TOUS les Pronos"}
            </button>

            <button
              onClick={() => setShowAddCustomModal(true)}
              className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 border border-cyan-500/40 text-cyan-300 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5 text-cyan-400" />
              + Match Personnalisé
            </button>

            <button
              onClick={handleCheckLiveScores}
              disabled={isCheckingScores}
              className="px-3.5 py-2 bg-cyan-950 hover:bg-cyan-900 border border-cyan-500/50 text-cyan-200 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isCheckingScores ? "animate-spin text-cyan-400" : ""}`} />
              {isCheckingScores ? "Vérification..." : "Actualiser Direct"}
            </button>
          </div>
        </div>

        {/* Filter Tabs for Tracked Matches */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
          {(() => {
            const liveCount = trackedMatches.filter(
              (tm) => tm.currentLiveScore?.isLive || (tm.status === "LIVE" && !tm.currentLiveScore?.isFinished)
            ).length;
            const finishedCount = trackedMatches.filter(
              (tm) => tm.currentLiveScore?.isFinished || tm.status === "DEBRIEF_SENT"
            ).length;
            const upcomingCount = trackedMatches.length - liveCount - finishedCount;

            return (
              <>
                <button
                  onClick={() => setTrackedFilterTab("ALL")}
                  className={`px-3 py-1.5 rounded-lg font-bold transition-all whitespace-nowrap ${
                    trackedFilterTab === "ALL"
                      ? "bg-cyan-600 text-white shadow-sm"
                      : "bg-slate-950/80 text-slate-400 hover:text-slate-200 border border-slate-800"
                  }`}
                >
                  Tous ({trackedMatches.length})
                </button>
                <button
                  onClick={() => setTrackedFilterTab("LIVE")}
                  className={`px-3 py-1.5 rounded-lg font-bold transition-all whitespace-nowrap flex items-center gap-1.5 ${
                    trackedFilterTab === "LIVE"
                      ? "bg-amber-600 text-white shadow-sm"
                      : "bg-slate-950/80 text-amber-400/80 hover:text-amber-300 border border-slate-800"
                  }`}
                >
                  <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                  🔴 En Direct ({liveCount})
                </button>
                <button
                  onClick={() => setTrackedFilterTab("UPCOMING")}
                  className={`px-3 py-1.5 rounded-lg font-bold transition-all whitespace-nowrap ${
                    trackedFilterTab === "UPCOMING"
                      ? "bg-indigo-600 text-white shadow-sm"
                      : "bg-slate-950/80 text-slate-400 hover:text-slate-200 border border-slate-800"
                  }`}
                >
                  ⏳ Avant-Match ({upcomingCount})
                </button>
                <button
                  onClick={() => setTrackedFilterTab("FINISHED")}
                  className={`px-3 py-1.5 rounded-lg font-bold transition-all whitespace-nowrap ${
                    trackedFilterTab === "FINISHED"
                      ? "bg-emerald-600 text-white shadow-sm"
                      : "bg-slate-950/80 text-slate-400 hover:text-slate-200 border border-slate-800"
                  }`}
                >
                  🏁 Terminés / FT ({finishedCount})
                </button>
              </>
            );
          })()}
        </div>

        {/* Empty State */}
        {trackedMatches.length === 0 ? (
          <div className="bg-slate-950/70 border-2 border-dashed border-slate-800 rounded-xl p-6 text-center space-y-3">
            <Radio className="w-8 h-8 text-slate-600 mx-auto animate-pulse" />
            <p className="text-sm font-bold text-slate-300">
              Aucun match suivi en direct pour le moment
            </p>
            <p className="text-xs text-slate-400 max-w-lg mx-auto leading-relaxed">
              Pour suivre un match en direct et recevoir les <strong>Alertes Buts</strong> et le <strong>Débrief FT</strong> dès la fin du match :
            </p>
            <div className="flex items-center justify-center gap-3 pt-1 flex-wrap">
              <button
                onClick={handleTrackAllPronos}
                className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-bold flex items-center gap-2 cursor-pointer shadow-md"
              >
                <Zap className="w-3.5 h-3.5" />
                ⚡ Suivre TOUS les Pronostics ({pronos.length})
              </button>
              <button
                onClick={() => setShowAddCustomModal(true)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-500/40 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                Ajouter un match manuel
              </button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
            {trackedMatches
              .filter((tm) => {
                const live = tm.currentLiveScore;
                const isFinished = live?.isFinished || tm.status === "DEBRIEF_SENT";
                const isLive = live?.isLive || (tm.status === "LIVE" && !isFinished);
                if (trackedFilterTab === "LIVE") return isLive && !isFinished;
                if (trackedFilterTab === "FINISHED") return isFinished;
                if (trackedFilterTab === "UPCOMING") return !isLive && !isFinished;
                return true;
              })
              .map((tm) => {
                const live = tm.currentLiveScore;
                const isFinished = live?.isFinished || tm.status === "DEBRIEF_SENT";
                const isLive = live?.isLive || (tm.status === "LIVE" && !isFinished);
                const scoreHome = live !== undefined && live !== null ? live.scoreHome : tm.scoreHome ?? 0;
                const scoreAway = live !== undefined && live !== null ? live.scoreAway : tm.scoreAway ?? 0;
                const scoreDisplay = `${scoreHome} - ${scoreAway}`;
                const isOperating = isSimulatingId === tm.id;

                return (
                  <div
                    key={tm.id}
                    className={`p-4 rounded-xl border flex flex-col justify-between space-y-3 transition-all shadow-md ${
                      isFinished
                        ? tm.isWon
                          ? "bg-emerald-950/40 border-emerald-500/50 shadow-emerald-950/30"
                          : "bg-rose-950/30 border-rose-500/40 shadow-rose-950/30"
                        : isLive
                        ? "bg-amber-950/40 border-amber-500/50 shadow-amber-950/30 ring-1 ring-amber-500/30"
                        : "bg-slate-950/90 border-slate-800 hover:border-slate-700"
                    }`}
                  >
                    {/* Header: Competition & Status Badge */}
                    <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                      <span className="text-[11px] font-bold text-slate-300 truncate max-w-[130px]">
                        {tm.competition}
                      </span>

                      {isFinished ? (
                        <span
                          className={`text-[10px] px-2.5 py-0.5 rounded-full font-black border flex items-center gap-1 ${
                            tm.isWon
                              ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40"
                              : "bg-rose-500/20 text-rose-300 border-rose-500/40"
                          }`}
                        >
                          {tm.isWon ? "✅ GREEN (FT)" : "❌ MISSED (FT)"}
                        </span>
                      ) : isLive ? (
                        <span className="text-[10px] px-2.5 py-0.5 rounded-full font-black bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center gap-1.5">
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping" />
                          🔴 LIVE ({live?.liveMinute || "En cours"})
                        </span>
                      ) : (
                        <span className="text-[10px] px-2.5 py-0.5 rounded-full font-bold bg-slate-800 text-slate-300 border border-slate-700">
                          ⏳ Avant-Match {tm.kickoffTime ? `(${tm.kickoffTime})` : ""}
                        </span>
                      )}
                    </div>

                    {/* Teams & Current Score */}
                    <div className="flex items-center justify-between py-1 gap-2">
                      <div className="text-xs font-black text-white leading-snug">
                        <div>{tm.homeTeam}</div>
                        <div className="text-slate-400 font-medium text-[11px]">{tm.awayTeam}</div>
                      </div>
                      <div className="text-sm font-mono font-black text-cyan-300 px-3 py-1 bg-slate-900 rounded-lg border border-cyan-500/30 shadow-inner">
                        {scoreDisplay}
                      </div>
                    </div>

                    {/* Prono info */}
                    <div className="bg-slate-900/80 rounded-lg px-2.5 py-1.5 border border-slate-800/80 flex items-center justify-between text-[11px]">
                      <span className="text-slate-400">
                        Prono : <strong className="text-amber-300">{tm.prediction}</strong>
                      </span>
                      <span className="text-emerald-400 font-mono font-bold">@{tm.odd}</span>
                    </div>

                    {/* Interactive Live Controls on Match Card */}
                    <div className="pt-2 border-t border-slate-800/80 space-y-2">
                      <div className="flex items-center justify-between text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                        <span>Actions Direct</span>
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => handleOpenEditScore(tm)}
                            className="p-1 hover:bg-slate-800 text-slate-400 hover:text-cyan-300 rounded"
                            title="Modifier score manuellement"
                          >
                            <Edit2 className="w-3 h-3" />
                          </button>
                          <button
                            onClick={() => handleUntrackMatch(tm.id, `${tm.homeTeam} vs ${tm.awayTeam}`)}
                            className="p-1 hover:bg-rose-950 text-slate-500 hover:text-rose-400 rounded"
                            title="Retirer du suivi"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      </div>

                      {/* Goal Injection Buttons */}
                      <div className="grid grid-cols-2 gap-1.5">
                        <button
                          onClick={() => handleSimulateGoal(tm.id, "home", tm.homeTeam)}
                          disabled={isOperating}
                          className="px-2 py-1.5 bg-slate-800 hover:bg-emerald-950 hover:text-emerald-300 border border-slate-700 hover:border-emerald-500/50 text-slate-300 rounded-lg text-[10px] font-bold flex items-center justify-center gap-1 transition-all cursor-pointer disabled:opacity-50"
                          title={`Ajouter un but pour ${tm.homeTeam} et déclencher le tweet d'alerte`}
                        >
                          ⚽ +1 {tm.homeTeam.slice(0, 8)}
                        </button>
                        <button
                          onClick={() => handleSimulateGoal(tm.id, "away", tm.awayTeam)}
                          disabled={isOperating}
                          className="px-2 py-1.5 bg-slate-800 hover:bg-emerald-950 hover:text-emerald-300 border border-slate-700 hover:border-emerald-500/50 text-slate-300 rounded-lg text-[10px] font-bold flex items-center justify-center gap-1 transition-all cursor-pointer disabled:opacity-50"
                          title={`Ajouter un but pour ${tm.awayTeam} et déclencher le tweet d'alerte`}
                        >
                          ⚽ +1 {tm.awayTeam.slice(0, 8)}
                        </button>
                      </div>

                      {/* FT Finish Match Button */}
                      {!isFinished ? (
                        <button
                          onClick={() => handleSimulateFT(tm.id, scoreHome, scoreAway)}
                          disabled={isOperating}
                          className="w-full py-1.5 bg-gradient-to-r from-indigo-700 to-purple-700 hover:from-indigo-600 hover:to-purple-600 text-white rounded-lg text-[11px] font-black flex items-center justify-center gap-1.5 shadow-sm transition-all cursor-pointer disabled:opacity-50"
                        >
                          <Trophy className="w-3 h-3 text-amber-300" />
                          🏁 Terminer Match (Débrief FT Automatique)
                        </button>
                      ) : (
                        <div className="text-center py-1 text-[10px] text-cyan-300 font-semibold flex items-center justify-center gap-1 bg-cyan-950/60 rounded-md border border-cyan-500/30">
                          <CheckCircle2 className="w-3 h-3 text-cyan-400" />
                          Débrief FT Envoyé sur X
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
          </div>
        )}
      </div>

      {/* Top Banner Control */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <span className="flex h-2.5 w-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <h2 className="text-lg font-black text-white flex items-center gap-2">
              <Globe className="w-5 h-5 text-emerald-400" />
              Scraper SportyTrader Pronostics
            </h2>
            <span className="px-2.5 py-0.5 bg-emerald-950/80 text-emerald-300 border border-emerald-700/50 rounded-full text-[11px] font-bold flex items-center gap-1.5 shadow-sm">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
              Auto-Sync & Auto-Débrief FT Actifs ({upcomingPronos.length} Matchs à venir)
            </span>
          </div>
          <div className="flex items-center gap-3 text-xs text-slate-400 mt-1.5 flex-wrap">
            <span>Dernier scan : <strong className="text-slate-300">{lastScrapeTime.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</strong></span>
            <span>•</span>
            <span>Prochain scan : <strong className="text-emerald-400">dans ~{nextScrapeMinutes} min</strong></span>
            <span>•</span>
            <span className="text-emerald-300 font-semibold flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Débriefs FT publiés 100% automatiquement à la fin des matchs
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            onClick={() => setIsInlinePasteOpen(!isInlinePasteOpen)}
            className="px-3.5 py-2 bg-gradient-to-r from-emerald-700 to-teal-700 hover:from-emerald-600 hover:to-teal-600 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all shadow-md cursor-pointer"
            title="Ouvrir la zone pour copier/coller un texte ou HTML SportyTrader"
          >
            <ClipboardPaste className="w-4 h-4 text-emerald-200" />
            <span>Coller / Mettre à jour Matchs</span>
            {isInlinePasteOpen ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>

          <button
            onClick={handleCheckLiveScores}
            disabled={isCheckingScores}
            className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-cyan-300 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all border border-slate-700 disabled:opacity-50 cursor-pointer"
            title="Vérifier si des buts ont été marqués ou si des matchs sont terminés (FT)"
          >
            <Clock className={`w-3.5 h-3.5 ${isCheckingScores ? "animate-spin text-cyan-400" : ""}`} />
            {isCheckingScores ? "Vérification..." : "Vérifier Scores & Buts"}
          </button>

          <button
            onClick={onScrapeRefresh}
            disabled={isScraping}
            className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all border border-slate-700 disabled:opacity-50 cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isScraping ? "animate-spin text-emerald-400" : ""}`} />
            {isScraping ? "Scraping..." : "Actualiser"}
          </button>

          <button
            onClick={handleScheduleAllPronos}
            className="px-3.5 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-lg text-xs font-black flex items-center gap-1.5 shadow-lg shadow-emerald-950/40 transition-all cursor-pointer"
            title="Programmer tous les pronostics à H-1h dans l'Aéroport"
          >
            <PlaneTakeoff className="w-4 h-4" />
            Programmer TOUS H-1h
          </button>

          <button
            onClick={handleGenerateSmartSlotTweets}
            className="px-3.5 py-2 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 rounded-lg text-xs font-black flex items-center gap-1.5 shadow-lg shadow-amber-950/40 transition-all cursor-pointer"
            title="Sélectionne automatiquement le meilleur match pour chaque horaire (anti-doublon)"
          >
            <Zap className="w-4 h-4 fill-slate-950" />
            Auto-Sélection 1/créneau
          </button>
        </div>
      </div>

      {/* 📋 INLINE FAST COPY-PASTE SYNC DRAWER */}
      {isInlinePasteOpen && (
        <div className="bg-slate-900/95 border-2 border-emerald-500/40 rounded-2xl p-5 shadow-2xl space-y-3 transition-all animate-fadeIn">
          <div className="flex items-center justify-between border-b border-emerald-500/20 pb-3 flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-emerald-950 rounded-lg border border-emerald-500/30 text-emerald-400">
                <FileText className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-black text-white flex items-center gap-2">
                  Coller Texte ou HTML SportyTrader (Ajout & Mise à Jour Instantanés)
                </h3>
                <p className="text-[11px] text-slate-400">
                  Supporte les formats FR et EN, le texte copié/collé brut ou le code source HTML (F12).
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsInlinePasteOpen(false)}
              className="text-xs text-slate-400 hover:text-white px-2.5 py-1 bg-slate-800 rounded-md"
            >
              Fermer ✕
            </button>
          </div>

          <textarea
            value={pastedHtml}
            onChange={(e) => setPastedHtml(e.target.value)}
            placeholder="Copiez-collez ici le texte des matchs directement depuis SportyTrader (ex: '26 août 2026, 21:00 Monaco vs Zabrze Pronostic Monaco gagne Cote 1.68' ou le code source HTML)..."
            rows={5}
            className="w-full bg-slate-950 border border-slate-700/80 rounded-xl p-3.5 text-xs font-mono text-emerald-200 placeholder-slate-500 focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 shadow-inner"
          />

          <div className="flex items-center justify-between flex-wrap gap-2 pt-1">
            <div className="text-[11px] text-slate-400 flex items-center gap-2">
              <span className="px-2 py-0.5 bg-emerald-950 text-emerald-300 rounded border border-emerald-800/40 font-mono">
                {pastedHtml.trim() ? `${pastedHtml.length} caractères détectés` : "En attente de texte..."}
              </span>
              <span>Fusionne automatiquement les nouveaux matchs et met à jour les existants.</span>
            </div>

            <div className="flex items-center gap-2">
              {pastedHtml.trim() && (
                <button
                  onClick={() => setPastedHtml("")}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold"
                >
                  Effacer
                </button>
              )}
              <button
                onClick={handleParseCustomHtml}
                disabled={isParsingHtml || !pastedHtml.trim()}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-black flex items-center gap-2 shadow-lg shadow-emerald-950/50 disabled:opacity-50 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" />
                {isParsingHtml ? "Analyse & Fusion en cours..." : "⚡ Synchroniser & Ajouter les Matchs"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* League Filter Tabs & View Mode Switch */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
          <button
            onClick={() => setSelectedComp("ALL")}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all whitespace-nowrap ${
              selectedComp === "ALL"
                ? "bg-emerald-600 text-white shadow-sm"
                : "bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800"
            }`}
          >
            Tous les championnats ({displayedSourcePronos.length})
          </button>
          {TOP_COMPETITIONS.map((c) => {
            const count = displayedSourcePronos.filter((p) => p.competition.toLowerCase().includes(c.toLowerCase())).length;
            if (count === 0 && selectedComp !== c) return null;
            return (
              <button
                key={c}
                onClick={() => setSelectedComp(c)}
                className={`px-3 py-1.5 rounded-lg font-bold transition-all whitespace-nowrap flex items-center gap-1.5 ${
                  selectedComp === c
                    ? "bg-emerald-600 text-white shadow-sm"
                    : "bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800"
                }`}
              >
                <span>{c}</span>
                <span className="text-[10px] px-1.5 py-0.2 bg-black/40 rounded-full font-mono">{count}</span>
              </button>
            );
          })}
        </div>

        {/* View Mode Toggle: Upcoming vs All */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
          <button
            onClick={() => setShowAllPronos(false)}
            className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
              !showAllPronos && !isAutoShowingAll
                ? "bg-emerald-600 text-white shadow-sm"
                : "text-slate-400 hover:text-white"
            }`}
          >
            À venir ({upcomingPronos.length})
          </button>
          <button
            onClick={() => setShowAllPronos(true)}
            className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
              showAllPronos || isAutoShowingAll
                ? "bg-emerald-600 text-white shadow-sm"
                : "text-slate-400 hover:text-white"
            }`}
          >
            Tous les matchs ({pronos.length})
          </button>
        </div>
      </div>

      {/* Notice when auto showing all matches because upcoming is 0 */}
      {isAutoShowingAll && (
        <div className="bg-slate-900/60 border border-slate-800 text-slate-400 px-4 py-2.5 rounded-xl text-xs flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Radio className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>
              Les matchs du jour sont en cours ou terminés. Affichage des <strong>{pronos.length} matchs récents et en direct</strong> avec suivi automatique des scores et bilans.
            </span>
          </div>
          <button
            onClick={() => setShowAddCustomModal(true)}
            className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-[11px] font-semibold whitespace-nowrap cursor-pointer transition-colors"
          >
            + Ajouter un match
          </button>
        </div>
      )}

      {/* Pronos Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredPronos.map((item) => {
          const status = getPronoStatus(item.id);
          const oddVal = item.odds || "1.9";
          const confVal = item.confidencePercent || 85;

          const isTracked = trackedMatches.some(
            (tm) =>
              tm.id === item.id ||
              (tm.homeTeam.toLowerCase().includes(item.homeTeam.toLowerCase().slice(0, 4)) &&
                tm.awayTeam.toLowerCase().includes(item.awayTeam.toLowerCase().slice(0, 4)))
          );

          const trackedMatchObj = trackedMatches.find(
            (tm) =>
              tm.id === item.id ||
              (tm.homeTeam.toLowerCase().includes(item.homeTeam.toLowerCase().slice(0, 4)) &&
                tm.awayTeam.toLowerCase().includes(item.awayTeam.toLowerCase().slice(0, 4)))
          );

          return (
            <div
              key={item.id}
              className={`border rounded-xl p-4 flex flex-col justify-between transition-all shadow-md group ${
                isTracked
                  ? "bg-cyan-950/20 border-cyan-500/40 ring-1 ring-cyan-500/20"
                  : "bg-slate-900/90 border-slate-800/80 hover:border-slate-700"
              }`}
            >
              <div className="space-y-3">
                {/* Header: Date, Hour & Status Badge */}
                <div className="flex items-center justify-between border-b border-slate-800/80 pb-2.5">
                  <div>
                    <span className="text-[11px] font-bold text-white flex items-center gap-1">
                      <Clock className="w-3 h-3 text-emerald-400" />
                      {item.date}, {item.kickoffTime}
                    </span>
                    <span className="text-[10px] text-slate-400 block font-medium">
                      {item.competition}
                    </span>
                  </div>

                  {isTracked ? (
                    <span className="text-[10px] px-2 py-0.5 bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 rounded-full font-black flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
                      Suivi en Direct
                    </span>
                  ) : (
                    <span className="text-[10px] px-2 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-full font-bold">
                      À Venir (H-1h)
                    </span>
                  )}
                </div>

                {/* Match Affiche */}
                <div className="py-1">
                  <div className="text-center font-black text-sm text-slate-100 flex items-center justify-center gap-2">
                    <span className="text-emerald-300">{item.homeTeam}</span>
                    <span className="text-xs text-slate-500 font-mono">VS</span>
                    <span className="text-emerald-300">{item.awayTeam}</span>
                  </div>
                  {trackedMatchObj?.currentLiveScore && (
                    <div className="text-center text-xs font-mono font-bold text-cyan-300 mt-1">
                      Score : {trackedMatchObj.currentLiveScore.scoreHome} - {trackedMatchObj.currentLiveScore.scoreAway}
                    </div>
                  )}
                </div>

                {/* Pronostic Card Box */}
                <div className="bg-slate-950/80 border border-slate-800 rounded-lg p-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block">
                        🎯 Conseil SportyTrader
                      </span>
                      <span className="text-xs font-black text-amber-300">
                        {item.prediction}
                      </span>
                    </div>
                    <div className="bg-emerald-950/60 border border-emerald-500/30 px-2.5 py-1 rounded-md text-center">
                      <span className="text-[9px] text-slate-400 block uppercase font-bold">Cote</span>
                      <span className="text-xs font-black text-emerald-400 font-mono">@{oddVal}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-1 border-t border-slate-800/60 text-[11px] text-slate-400">
                    <span className="flex items-center gap-1">
                      <Percent className="w-3 h-3 text-cyan-400" />
                      Confiance : <strong className="text-slate-200">{confVal}%</strong>
                    </span>
                    <span className="flex items-center gap-1 font-mono text-[10px] text-slate-400">
                      Score proj. : <strong className="text-slate-200">{item.predictedScore || "2-1"}</strong>
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2 mt-3 flex-wrap">
                <a
                  href={item.sourceUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[10px] text-slate-400 hover:text-slate-200 flex items-center gap-1 transition-colors"
                >
                  <ExternalLink className="w-3 h-3" />
                  Fiche
                </a>

                <div className="flex items-center gap-1.5 flex-wrap">
                  {/* Direct Live Track Button */}
                  {isTracked ? (
                    <button
                      onClick={() => handleUntrackMatch(item.id, `${item.homeTeam} vs ${item.awayTeam}`)}
                      className="px-2.5 py-1.5 bg-cyan-950/80 hover:bg-rose-950/60 border border-cyan-500/40 hover:border-rose-500/40 text-cyan-300 hover:text-rose-300 rounded-lg text-xs font-bold flex items-center gap-1 transition-all cursor-pointer"
                      title="Retirer du suivi direct"
                    >
                      <CheckCircle2 className="w-3 h-3 text-cyan-400" />
                      Suivi Actif
                    </button>
                  ) : (
                    <button
                      onClick={() => handleTrackProno(item)}
                      className="px-2.5 py-1.5 bg-slate-800 hover:bg-cyan-950 border border-slate-700 hover:border-cyan-500/50 text-cyan-300 rounded-lg text-xs font-bold flex items-center gap-1 transition-all cursor-pointer shadow-sm"
                      title="Ajouter au suivi en direct (Alertes Buts & Débrief FT)"
                    >
                      <Radio className="w-3 h-3 text-cyan-400" />
                      + Suivre en Direct
                    </button>
                  )}

                  {/* Program H-1h Tweet Button */}
                  {status.isScheduled ? (
                    <button
                      onClick={onNavigateToTweets}
                      className="px-2.5 py-1.5 bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 rounded-lg text-xs font-bold flex items-center gap-1 hover:bg-emerald-900/60 transition-all cursor-pointer"
                    >
                      <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                      ✈️ H-1h Prêt
                    </button>
                  ) : (
                    <button
                      onClick={() => handleCreateTweetForProno(item)}
                      className="px-3 py-1.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-lg text-xs font-bold flex items-center gap-1 shadow-sm transition-all cursor-pointer"
                    >
                      <Zap className="w-3 h-3" />
                      + H-1h
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {filteredPronos.length === 0 && (
        <div className="bg-slate-900/40 border border-slate-800/80 rounded-xl p-8 text-center space-y-3">
          <Globe className="w-10 h-10 text-slate-600 mx-auto" />
          <h3 className="text-sm font-bold text-slate-300">
            {selectedComp !== "ALL"
              ? `Aucun match pour ${selectedComp}`
              : "Aucun match à afficher pour cette sélection"}
          </h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            {selectedComp !== "ALL"
              ? `Aucun pronostic n'a été trouvé pour le filtre "${selectedComp}".`
              : "Tous les matchs analysés sont suivis automatiquement en direct pour les alertes de but et bilans de fin de match."}
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            {selectedComp !== "ALL" && (
              <button
                onClick={() => setSelectedComp("ALL")}
                className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition-all cursor-pointer shadow-sm"
              >
                🌍 Voir tous les championnats ({pronos.length})
              </button>
            )}
            {!showAllPronos && pronos.length > 0 && (
              <button
                onClick={() => setShowAllPronos(true)}
                className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-bold transition-all cursor-pointer"
              >
                📋 Afficher tous les matchs ({pronos.length})
              </button>
            )}
            {pronos.length === 0 && (
              <button
                onClick={onScrapeRefresh}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition-all cursor-pointer shadow-sm"
              >
                ⚡ Synchroniser SportyTrader
              </button>
            )}
            <button
              onClick={() => setShowAddCustomModal(true)}
              className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold cursor-pointer transition-colors"
            >
              + Ajouter un match personnalisé
            </button>
          </div>
        </div>
      )}

      {/* ☀️ MODAL: ANNONCE DU MATIN */}
      {showMorningModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-amber-500/40 rounded-2xl max-w-xl w-full p-6 space-y-4 shadow-2xl animate-in fade-in">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Sun className="w-5 h-5 text-amber-400" />
                <h3 className="text-base font-black text-white">
                  ☀️ Tweet Annonce du Programme Matinal
                </h3>
              </div>
              <button
                onClick={() => setShowMorningModal(false)}
                className="text-slate-400 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-400">
              Ce tweet est généré automatiquement avec les meilleurs matchs de la journée pour annoncer votre programme de pronostics et chauffer votre audience.
            </p>

            <textarea
              value={morningTweetText}
              onChange={(e) => setMorningTweetText(e.target.value)}
              rows={9}
              className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-lg p-3 text-xs font-sans text-slate-200 leading-relaxed focus:outline-none"
            />

            <div className="flex items-center justify-between pt-2">
              <button
                onClick={() => {
                  navigator.clipboard.writeText(morningTweetText);
                  onShowToast("📋 Texte copié !");
                }}
                className="px-3 py-2 bg-slate-800 text-slate-300 hover:text-white rounded-lg text-xs font-semibold cursor-pointer"
              >
                Copier le texte
              </button>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowMorningModal(false)}
                  className="px-4 py-2 bg-slate-800 text-slate-400 hover:text-white rounded-lg text-xs font-semibold"
                >
                  Fermer
                </button>
                <button
                  onClick={handlePublishMorningTweet}
                  disabled={isPublishingMorning || !morningTweetText.trim()}
                  className="px-4 py-2 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black rounded-lg text-xs flex items-center gap-1.5 shadow-md disabled:opacity-50 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  {isPublishingMorning ? "Publication..." : "Envoyer sur X Direct"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 🌙 MODAL: GRAND BILAN DU SOIR */}
      {showDailyRecapModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-indigo-500/40 rounded-2xl max-w-xl w-full p-6 space-y-4 shadow-2xl animate-in fade-in">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Moon className="w-5 h-5 text-indigo-400" />
                <h3 className="text-base font-black text-white">
                  🌙 Grand Tweet Bilan de la Journée
                </h3>
              </div>
              <button
                onClick={() => setShowDailyRecapModal(false)}
                className="text-slate-400 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            {/* Quick Stats Grid */}
            <div className="grid grid-cols-3 gap-2 bg-slate-950 p-3 rounded-xl border border-slate-800 text-center">
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Validés</span>
                <span className="text-sm font-black text-emerald-400 font-mono">
                  {dailyRecapStats.wonCount} / {dailyRecapStats.totalMatches}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Réussite</span>
                <span className="text-sm font-black text-cyan-400 font-mono">
                  {dailyRecapStats.winRate}%
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Bénéfice</span>
                <span className={`text-sm font-black font-mono ${dailyRecapStats.netProfit >= 0 ? "text-emerald-400" : "text-rose-400"}`}>
                  {dailyRecapStats.netProfit >= 0 ? `+${dailyRecapStats.netProfit}u` : `${dailyRecapStats.netProfit}u`}
                </span>
              </div>
            </div>

            <textarea
              value={dailyRecapText}
              onChange={(e) => setDailyRecapText(e.target.value)}
              rows={9}
              className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-lg p-3 text-xs font-sans text-slate-200 leading-relaxed focus:outline-none"
            />

            <div className="flex items-center justify-between pt-2">
              <button
                onClick={() => {
                  navigator.clipboard.writeText(dailyRecapText);
                  onShowToast("📋 Texte copié !");
                }}
                className="px-3 py-2 bg-slate-800 text-slate-300 hover:text-white rounded-lg text-xs font-semibold cursor-pointer"
              >
                Copier le texte
              </button>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowDailyRecapModal(false)}
                  className="px-4 py-2 bg-slate-800 text-slate-400 hover:text-white rounded-lg text-xs font-semibold"
                >
                  Fermer
                </button>
                <button
                  onClick={handlePublishDailyRecap}
                  disabled={isPublishingRecap || !dailyRecapText.trim()}
                  className="px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-black rounded-lg text-xs flex items-center gap-1.5 shadow-md disabled:opacity-50 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  {isPublishingRecap ? "Publication..." : "Envoyer sur X Direct"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Coller HTML / Texte SportyTrader */}
      {showHtmlPasteModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <FileCode className="w-5 h-5 text-emerald-400" />
                <h3 className="text-base font-bold text-white">
                  Coller le texte brut ou code HTML SportyTrader
                </h3>
              </div>
              <button
                onClick={() => setShowHtmlPasteModal(false)}
                className="text-slate-400 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              Collez le code HTML inspecté (F12) <strong>OU</strong> simplement le texte copié/collé directement depuis la page des pronostics SportyTrader. Le parseur extrait instantanément tous les matchs, cotes, heures et prédictions.
            </p>

            <textarea
              value={pastedHtml}
              onChange={(e) => setPastedHtml(e.target.value)}
              placeholder="Collez ici votre code HTML F12 ou le texte brut copié de la page SportyTrader..."
              rows={8}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs font-mono text-slate-300 focus:outline-none focus:border-emerald-500"
            />

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setShowHtmlPasteModal(false)}
                className="px-4 py-2 bg-slate-800 text-slate-300 rounded-lg text-xs font-semibold hover:bg-slate-700"
              >
                Annuler
              </button>
              <button
                onClick={handleParseCustomHtml}
                disabled={isParsingHtml || !pastedHtml.trim()}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold flex items-center gap-2 disabled:opacity-50 cursor-pointer"
              >
                {isParsingHtml ? "Extraction..." : "Analyser & Extraire les Pronos"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ➕ MODAL: AJOUTER UN MATCH PERSONNALISÉ AU SUIVI DIRECT */}
      {showAddCustomModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border-2 border-cyan-500/40 rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl animate-in fade-in">
            <div className="flex items-center justify-between border-b border-cyan-500/20 pb-3">
              <div className="flex items-center gap-2">
                <Radio className="w-5 h-5 text-cyan-400" />
                <h3 className="text-base font-bold text-white">
                  Ajouter un Match au Suivi en Direct
                </h3>
              </div>
              <button
                onClick={() => setShowAddCustomModal(false)}
                className="text-slate-400 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              Ajoutez n'importe quelle affiche (ex: Barça vs PSG, Real Madrid vs Bayern) pour que le bot surveille automatiquement les buts en direct et publie le débrief de fin de match.
            </p>

            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="text-[11px] font-bold text-slate-300 block mb-1">Équipe Domicile *</label>
                  <input
                    type="text"
                    value={customForm.homeTeam}
                    onChange={(e) => setCustomForm({ ...customForm, homeTeam: e.target.value })}
                    placeholder="ex: Barcelone"
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-white focus:outline-none focus:border-cyan-400 font-bold"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-slate-300 block mb-1">Équipe Extérieur *</label>
                  <input
                    type="text"
                    value={customForm.awayTeam}
                    onChange={(e) => setCustomForm({ ...customForm, awayTeam: e.target.value })}
                    placeholder="ex: PSG"
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-white focus:outline-none focus:border-cyan-400 font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="text-[11px] font-bold text-slate-300 block mb-1">Compétition</label>
                  <input
                    type="text"
                    value={customForm.competition}
                    onChange={(e) => setCustomForm({ ...customForm, competition: e.target.value })}
                    placeholder="ex: Ligue des Champions"
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-400"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-slate-300 block mb-1">Coup d'envoi</label>
                  <input
                    type="text"
                    value={customForm.kickoffTime}
                    onChange={(e) => setCustomForm({ ...customForm, kickoffTime: e.target.value })}
                    placeholder="ex: 21:00"
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-400 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="text-[11px] font-bold text-slate-300 block mb-1">Pronostic Conseillé *</label>
                  <input
                    type="text"
                    value={customForm.prediction}
                    onChange={(e) => setCustomForm({ ...customForm, prediction: e.target.value })}
                    placeholder="ex: Barcelone gagne"
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-amber-300 font-bold focus:outline-none focus:border-cyan-400"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-slate-300 block mb-1">Cote</label>
                  <input
                    type="text"
                    value={customForm.odd}
                    onChange={(e) => setCustomForm({ ...customForm, odd: e.target.value })}
                    placeholder="ex: 1.85"
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-emerald-400 font-mono font-bold focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              {/* Live Status Controls */}
              <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3 space-y-2.5">
                <span className="text-[11px] font-bold text-cyan-300 uppercase tracking-wider block">
                  Score & Statut Initial
                </span>
                <div className="grid grid-cols-2 gap-3 items-center">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-300 font-bold">Score Domicile:</span>
                    <input
                      type="number"
                      min={0}
                      value={customForm.scoreHome}
                      onChange={(e) => setCustomForm({ ...customForm, scoreHome: parseInt(e.target.value) || 0 })}
                      className="w-16 bg-slate-900 border border-slate-700 rounded-lg p-1.5 text-center text-xs font-mono font-bold text-cyan-300"
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-300 font-bold">Score Extérieur:</span>
                    <input
                      type="number"
                      min={0}
                      value={customForm.scoreAway}
                      onChange={(e) => setCustomForm({ ...customForm, scoreAway: parseInt(e.target.value) || 0 })}
                      className="w-16 bg-slate-900 border border-slate-700 rounded-lg p-1.5 text-center text-xs font-mono font-bold text-cyan-300"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-4 pt-1">
                  <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-300">
                    <input
                      type="checkbox"
                      checked={customForm.isLive}
                      onChange={(e) => setCustomForm({ ...customForm, isLive: e.target.checked })}
                      className="rounded border-slate-700 text-cyan-500 focus:ring-0"
                    />
                    <span>🔴 Le match est déjà en direct</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-300">
                    <input
                      type="checkbox"
                      checked={customForm.isFinished}
                      onChange={(e) => setCustomForm({ ...customForm, isFinished: e.target.checked })}
                      className="rounded border-slate-700 text-emerald-500 focus:ring-0"
                    />
                    <span>🏁 Le match est déjà terminé</span>
                  </label>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setShowAddCustomModal(false)}
                className="px-4 py-2 bg-slate-800 text-slate-300 rounded-lg text-xs font-semibold hover:bg-slate-700 cursor-pointer"
              >
                Annuler
              </button>
              <button
                onClick={handleSaveCustomMatch}
                disabled={!customForm.homeTeam.trim() || !customForm.awayTeam.trim()}
                className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-bold flex items-center gap-2 disabled:opacity-50 cursor-pointer shadow-md shadow-cyan-950/50"
              >
                <Plus className="w-3.5 h-3.5" />
                Ajouter au Suivi Direct
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ✏️ MODAL: MODIFIER LE SCORE & STATUT D'UN MATCH EN DIRECT */}
      {showEditScoreModal && editingTrackedMatch && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border-2 border-cyan-500/40 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl animate-in fade-in">
            <div className="flex items-center justify-between border-b border-cyan-500/20 pb-3">
              <div className="flex items-center gap-2">
                <Edit2 className="w-5 h-5 text-cyan-400" />
                <h3 className="text-base font-bold text-white">
                  Modifier le Score & Statut Direct
                </h3>
              </div>
              <button
                onClick={() => setShowEditScoreModal(false)}
                className="text-slate-400 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-center">
              <div className="text-xs text-slate-400 font-bold">{editingTrackedMatch.competition}</div>
              <div className="text-sm font-black text-white mt-1">
                {editingTrackedMatch.homeTeam} vs {editingTrackedMatch.awayTeam}
              </div>
              <div className="text-xs text-amber-300 mt-1">
                Prono : {editingTrackedMatch.prediction} (@{editingTrackedMatch.odd})
              </div>
            </div>

            <div className="space-y-4">
              {/* Score controls */}
              <div className="flex items-center justify-center gap-4 bg-slate-950/80 p-4 rounded-xl border border-slate-800">
                <div className="text-center space-y-1">
                  <span className="text-[11px] font-bold text-slate-300 block">{editingTrackedMatch.homeTeam}</span>
                  <input
                    type="number"
                    min={0}
                    value={editScoreForm.scoreHome}
                    onChange={(e) => setEditScoreForm({ ...editScoreForm, scoreHome: parseInt(e.target.value) || 0 })}
                    className="w-16 h-12 text-xl font-black font-mono text-cyan-300 bg-slate-900 border border-slate-700 rounded-lg text-center focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <span className="text-lg font-black text-slate-600">:</span>

                <div className="text-center space-y-1">
                  <span className="text-[11px] font-bold text-slate-300 block">{editingTrackedMatch.awayTeam}</span>
                  <input
                    type="number"
                    min={0}
                    value={editScoreForm.scoreAway}
                    onChange={(e) => setEditScoreForm({ ...editScoreForm, scoreAway: parseInt(e.target.value) || 0 })}
                    className="w-16 h-12 text-xl font-black font-mono text-cyan-300 bg-slate-900 border border-slate-700 rounded-lg text-center focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              {/* Match Minute & Scorer Name */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] font-bold text-slate-300 block mb-1">Minute de Jeu</label>
                  <input
                    type="text"
                    value={editScoreForm.liveMinute}
                    onChange={(e) => setEditScoreForm({ ...editScoreForm, liveMinute: e.target.value })}
                    placeholder="ex: 65', 78'..."
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-slate-300 block mb-1">Buteur (Optionnel)</label>
                  <input
                    type="text"
                    value={editScoreForm.scorerName}
                    onChange={(e) => setEditScoreForm({ ...editScoreForm, scorerName: e.target.value })}
                    placeholder="ex: Cherki, Barcola..."
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-white focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              {editScoreForm.scorerName ? (
                <div>
                  <label className="text-[11px] font-bold text-slate-300 block mb-1">Équipe du buteur</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setEditScoreForm({ ...editScoreForm, scoringTeam: "home" })}
                      className={`py-1.5 px-2 rounded-lg text-xs font-bold border ${
                        editScoreForm.scoringTeam === "home"
                          ? "bg-cyan-950 border-cyan-500 text-cyan-300"
                          : "bg-slate-900 border-slate-700 text-slate-400"
                      }`}
                    >
                      {editingTrackedMatch.homeTeam}
                    </button>
                    <button
                      type="button"
                      onClick={() => setEditScoreForm({ ...editScoreForm, scoringTeam: "away" })}
                      className={`py-1.5 px-2 rounded-lg text-xs font-bold border ${
                        editScoreForm.scoringTeam === "away"
                          ? "bg-cyan-950 border-cyan-500 text-cyan-300"
                          : "bg-slate-900 border-slate-700 text-slate-400"
                      }`}
                    >
                      {editingTrackedMatch.awayTeam}
                    </button>
                  </div>
                </div>
              ) : null}

              {/* Status checkboxes */}
              <div className="space-y-2 bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs">
                <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                  <input
                    type="checkbox"
                    checked={editScoreForm.isLive}
                    onChange={(e) => setEditScoreForm({ ...editScoreForm, isLive: e.target.checked })}
                    className="rounded border-slate-700 text-cyan-500 focus:ring-0"
                  />
                  <span>🔴 Match actuellement en cours (Actif en direct)</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                  <input
                    type="checkbox"
                    checked={editScoreForm.isFinished}
                    onChange={(e) => setEditScoreForm({ ...editScoreForm, isFinished: e.target.checked })}
                    className="rounded border-slate-700 text-emerald-500 focus:ring-0"
                  />
                  <span>🏁 Match terminé (FT - Déclenche le calcul et le débrief)</span>
                </label>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setShowEditScoreModal(false)}
                className="px-4 py-2 bg-slate-800 text-slate-300 rounded-lg text-xs font-semibold hover:bg-slate-700 cursor-pointer"
              >
                Annuler
              </button>
              <button
                onClick={handleSaveEditScore}
                className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-bold flex items-center gap-2 cursor-pointer shadow-md shadow-cyan-950/50"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                Enregistrer le Score
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: LIVE GOAL TWEET CONFIRMATION & DIRECT ACTION */}
      {showGoalModal && goalTweetModalData && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-cyan-500/50 rounded-2xl max-w-lg w-full p-5 space-y-4 shadow-2xl shadow-cyan-950/80 animate-in fade-in zoom-in duration-150">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <span className="text-xl">⚽</span>
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    Alerte But en Direct Déclenchée !
                  </h3>
                  <p className="text-[11px] text-cyan-400 font-medium">{goalTweetModalData.matchTitle}</p>
                </div>
              </div>
              <button
                onClick={() => setShowGoalModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Status Pill */}
            <div className="flex items-center justify-between bg-slate-950 px-3.5 py-2.5 rounded-xl border border-slate-800">
              <span className="text-xs text-slate-400">Statut de publication sur X :</span>
              {goalTweetModalData.isPublished ? (
                <span className="flex items-center gap-1.5 text-xs font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-800/80 px-2.5 py-1 rounded-full">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Publié avec succès sur X !
                </span>
              ) : (
                <span className="flex items-center gap-1.5 text-xs font-bold text-amber-400 bg-amber-950/60 border border-amber-800/80 px-2.5 py-1 rounded-full">
                  <Clock className="w-3.5 h-3.5" /> Prêt / Vérification session X
                </span>
              )}
            </div>

            {/* Tweet preview box */}
            <div>
              <label className="text-[11px] font-bold text-slate-400 block mb-1.5 uppercase tracking-wider">
                Contenu du Tweet envoyé
              </label>
              <div className="bg-slate-950 border border-slate-800 rounded-xl p-3.5 text-xs text-slate-200 whitespace-pre-wrap font-sans leading-relaxed">
                {goalTweetModalData.tweetText}
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-between pt-2">
              <button
                onClick={() => {
                  navigator.clipboard.writeText(goalTweetModalData.tweetText);
                  onShowToast("📋 Texte du tweet copié dans le presse-papier !");
                }}
                className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
              >
                <Copy className="w-3.5 h-3.5" /> Copier le texte
              </button>

              <div className="flex items-center gap-2">
                <a
                  href={goalTweetModalData.intentUrl || `https://twitter.com/intent/tweet?text=${encodeURIComponent(goalTweetModalData.tweetText)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="px-4 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white rounded-lg text-xs font-bold flex items-center gap-2 cursor-pointer shadow-md shadow-cyan-950/50"
                >
                  <Send className="w-3.5 h-3.5" />
                  {goalTweetModalData.isPublished ? "Voir sur X (Twitter)" : "Poster / Vérifier sur X"}
                </a>
                <button
                  onClick={() => setShowGoalModal(false)}
                  className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold cursor-pointer"
                >
                  Fermer
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
