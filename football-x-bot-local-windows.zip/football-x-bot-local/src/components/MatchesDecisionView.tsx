import React, { useState } from "react";
import {
  RefreshCw,
  Sparkles,
  Zap,
  CheckCircle2,
  SlidersHorizontal,
  Flame,
  ArrowRight,
  TrendingUp,
  Clock,
  Radio,
  Plus,
  Layers,
  ChevronRight,
  Trophy,
} from "lucide-react";
import { FootballMatch, AirportFlightTweet } from "../types";
import {
  evaluatePredictionResult,
  buildFaithfulResultTweet,
  buildH1PredictionTweet,
} from "../utils/predictionEvaluator";
import { parseKickoffAndH1Schedule } from "../utils/dateScheduler";

interface MatchesDecisionViewProps {
  matches: FootballMatch[];
  onRefreshApi: () => Promise<void>;
  isRefreshing: boolean;
  onValidateMatchTweets: (h1Flight: AirportFlightTweet, resultFlight: AirportFlightTweet) => void;
  onNavigateToTweets: () => void;
  onShowToast: (msg: string) => void;
  existingFlights: AirportFlightTweet[];
}

export const MatchesDecisionView: React.FC<MatchesDecisionViewProps> = ({
  matches,
  onRefreshApi,
  isRefreshing,
  onValidateMatchTweets,
  onNavigateToTweets,
  onShowToast,
  existingFlights,
}) => {
  const [selectedLeague, setSelectedLeague] = useState<string>("ALL");
  const [filterStatus, setFilterStatus] = useState<"ALL" | "LIVE" | "UPCOMING" | "FINISHED">("ALL");
  const [generatingMatchId, setGeneratingMatchId] = useState<string | null>(null);

  // Local state for customized predictions per match
  const [matchPredictions, setMatchPredictions] = useState<
    Record<
      string,
      {
        prediction: string;
        odd: string;
        predictedScore: string;
        confidence: number;
        reasoning?: string;
        simulatedScoreHome?: number;
        simulatedScoreAway?: number;
      }
    >
  >({});

  // Distinct leagues
  const leagues = Array.from(new Set(matches.map((m) => m.league).filter(Boolean)));

  const filteredMatches = matches.filter((m) => {
    if (selectedLeague !== "ALL" && m.league !== selectedLeague) return false;
    if (filterStatus === "LIVE" && m.status !== "LIVE") return false;
    if (filterStatus === "UPCOMING" && m.status !== "UPCOMING" && m.status !== "READY_FOR_PRONO") return false;
    if (filterStatus === "FINISHED" && m.status !== "FINISHED") return false;
    return true;
  });

  // Helper to check if a match already has tweets generated
  const getMatchTweetStatus = (matchId: string) => {
    const hasH1 = existingFlights.some((f) => f.matchId === matchId && f.type === "PRONO_H1");
    const hasRecap = existingFlights.some((f) => f.matchId === matchId && f.type === "RECAP_FT");
    return { hasH1, hasRecap, isFullyReady: hasH1 && hasRecap };
  };

  // Get current prediction config for a match (or default)
  const getPronoState = (match: FootballMatch) => {
    if (matchPredictions[match.id]) {
      return matchPredictions[match.id];
    }
    // Default smart suggestion
    const homeOdd = parseFloat(match.odds?.home || "2.10");
    const awayOdd = parseFloat(match.odds?.away || "3.20");

    let defaultPred = `${match.homeTeam} to Win`;
    let defaultOdd = match.odds?.home || "2.05";
    let defaultScore = "2-1";

    if (homeOdd < 1.6) {
      defaultPred = `${match.homeTeam} to Win (-1.5 Handicap)`;
      defaultOdd = "1.95";
      defaultScore = "3-0";
    } else if (awayOdd < 1.8) {
      defaultPred = `${match.awayTeam} to Win`;
      defaultOdd = match.odds?.away || "1.75";
      defaultScore = "1-2";
    } else if (match.odds?.over25 && parseFloat(match.odds.over25) < 1.85) {
      defaultPred = "Over 2.5 Goals";
      defaultOdd = match.odds.over25;
      defaultScore = "2-2";
    } else {
      defaultPred = `${match.homeTeam} or Draw (1X)`;
      defaultOdd = "1.45";
      defaultScore = "1-1";
    }

    return {
      prediction: match.pronoData?.predictionType || defaultPred,
      odd: match.pronoData?.estimatedOdd || defaultOdd,
      predictedScore: match.pronoData?.predictedScore || defaultScore,
      confidence: match.pronoData?.confidencePercent || 84,
      reasoning: match.pronoData?.keyReasoning || `Statistical edge in favor of ${match.homeTeam} with consistent attacking momentum.`,
      simulatedScoreHome: match.actualScore?.home ?? 2,
      simulatedScoreAway: match.actualScore?.away ?? 1,
    };
  };

  const setPronoForMatch = (
    matchId: string,
    updates: Partial<{
      prediction: string;
      odd: string;
      predictedScore: string;
      confidence: number;
      reasoning?: string;
      simulatedScoreHome?: number;
      simulatedScoreAway?: number;
    }>
  ) => {
    setMatchPredictions((prev) => {
      const current = prev[matchId] || getPronoState(matches.find((m) => m.id === matchId)!);
      return {
        ...prev,
        [matchId]: { ...current, ...updates },
      };
    });
  };

  // Generate with AI from backend API
  const handleAiGenerateMatch = async (match: FootballMatch) => {
    setGeneratingMatchId(match.id);
    try {
      const res = await fetch("/api/ai/generate-prono", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          homeTeam: match.homeTeam,
          awayTeam: match.awayTeam,
          league: match.league,
          matchTime: match.kickoffTime,
          odds: match.odds,
          formHome: match.formHome,
          formAway: match.formAway,
          keyStat: match.keyStat,
        }),
      });

      const json = await res.json();
      if (json.success && json.data) {
        const d = json.data;
        setPronoForMatch(match.id, {
          prediction: d.predictionType || d.recommendedBet,
          odd: d.estimatedOdd || "1.85",
          predictedScore: d.predictedScore || "2-1",
          confidence: d.confidencePercent || 85,
          reasoning: d.keyReasoning || "Analyse statistique et dynamique de forme.",
        });
        onShowToast(`✨ Prono IA généré pour ${match.homeTeam} vs ${match.awayTeam} !`);
      } else {
        onShowToast("⚠️ Génération IA en mode heuristique.");
      }
    } catch (e: any) {
      onShowToast("⚡ Prono calculé via le moteur statistique.");
    } finally {
      setGeneratingMatchId(null);
    }
  };

  // Validate the match and produce BOTH tweets (H-1h and Result FT)
  const handleValidateMatch = (match: FootballMatch) => {
    const prono = getPronoState(match);

    // 1. Tweet H-1h
    const h1TweetText = buildH1PredictionTweet({
      homeTeam: match.homeTeam,
      awayTeam: match.awayTeam,
      league: match.league,
      kickoffTime: match.kickoffTime,
      prediction: prono.prediction,
      odd: prono.odd,
      predictedScore: prono.predictedScore,
      confidencePercent: prono.confidence,
      keyReasoning: prono.reasoning,
    });

    const schedule = parseKickoffAndH1Schedule(match.kickoffDate, match.kickoffTime);

    const h1Flight: AirportFlightTweet = {
      id: `tweet-h1-${match.id}-${Date.now()}`,
      matchId: match.id,
      matchTitle: `${match.homeTeam} vs ${match.awayTeam}`,
      type: "PRONO_H1",
      tweetText: h1TweetText,
      flightCode: `H1-${match.homeTeam.slice(0, 3).toUpperCase()}`,
      departureTime: schedule.formattedDepartureLabel,
      scheduledTimestamp: schedule.isPastH1 ? Date.now() : schedule.h1Timestamp,
      scheduledTimeLabel: schedule.formattedDepartureLabel,
      isAutoScheduled: true,
      baggages: {
        match: `${match.homeTeam} vs ${match.awayTeam}`,
        prediction: prono.prediction,
        odd: prono.odd,
        confidence: prono.confidence,
        style: "Avant-Match H-1h",
      },
      status: schedule.isPastH1 ? "READY" : "SCHEDULED",
      createdAt: Date.now(),
    };

    // 2. Tweet Résultat FT (ONLY IF MATCH IS REALLY FINISHED WITH ACTUAL SCORE)
    let resultFlight: AirportFlightTweet | undefined = undefined;

    if (match.status === "FINISHED" && match.actualScore) {
      const scoreHome = match.actualScore.home;
      const scoreAway = match.actualScore.away;

      const evalResult = evaluatePredictionResult(
        prono.prediction,
        scoreHome,
        scoreAway,
        match.homeTeam,
        match.awayTeam,
        prono.odd
      );

      const resultTweetText = buildFaithfulResultTweet({
        homeTeam: match.homeTeam,
        awayTeam: match.awayTeam,
        league: match.league,
        scoreHome,
        scoreAway,
        initialPrediction: prono.prediction,
        odd: prono.odd,
        isWon: evalResult.isWon,
      });

      resultFlight = {
        id: `tweet-recap-${match.id}-${Date.now()}`,
        matchId: match.id,
        matchTitle: `${match.homeTeam} vs ${match.awayTeam} (Fin de Match)`,
        type: "RECAP_FT",
        tweetText: resultTweetText,
        flightCode: `FT-${match.homeTeam.slice(0, 3).toUpperCase()}`,
        departureTime: "Fin de Match (FT)",
        scheduledTimestamp: Date.now(),
        scheduledTimeLabel: "Fin de Match",
        isAutoScheduled: true,
        baggages: {
          match: `${match.homeTeam} vs ${match.awayTeam}`,
          prediction: `Score ${scoreHome}-${scoreAway} (${evalResult.isWon ? "Validé ✅" : "Manqué ❌"})`,
          odd: prono.odd,
          confidence: 99,
          style: evalResult.isWon ? "Bilan Positif ✅" : "Bilan Négatif ❌",
        },
        status: "READY",
        createdAt: Date.now() + 1,
      };
    }

    onValidateMatchTweets(h1Flight, resultFlight);
    if (resultFlight) {
      onShowToast(`🚀 Tweet Bilan FT généré avec le vrai score pour ${match.homeTeam} vs ${match.awayTeam} !`);
    } else {
      onShowToast(`🚀 Tweet H-1h préparé pour ${match.homeTeam} vs ${match.awayTeam} !`);
    }
  };

  // Generate ALL matches in 1 click
  const handleValidateAllMatches = () => {
    let count = 0;
    filteredMatches.forEach((m) => {
      handleValidateMatch(m);
      count++;
    });
    onShowToast(`⚡ ${count} Tweets H-1h générés pour tous les matchs sélectionnés !`);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner: Control Center & APIs */}
      <div className="bg-gradient-to-r from-slate-900 via-[#16161a] to-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-xs font-bold flex items-center gap-1.5">
                <Radio className="w-3 h-3 text-indigo-400 animate-pulse" />
                2 APIs Actives (ESPN & Football-Data)
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold">
                {matches.length} Matchs Disponibles
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white">
              Sélection des Matchs & Décisions de Pronos
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 max-w-2xl">
              Choisissez vos pronostics. Pour chaque match validé, l'application prépare <strong>automatiquement les 2 Tweets</strong> : le tweet <strong>H-1h</strong> (Avant-match) et le tweet <strong>Résultat FT</strong> (Bilan fidèle au prono).
            </p>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex items-center gap-2.5">
            <button
              onClick={onRefreshApi}
              disabled={isRefreshing}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#1c1c22] hover:bg-slate-800 text-slate-200 text-xs font-bold border border-slate-700 transition disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-indigo-400 ${isRefreshing ? "animate-spin" : ""}`} />
              <span>{isRefreshing ? "Sync 2 APIs..." : "Actualiser les Scores"}</span>
            </button>

            <button
              onClick={handleValidateAllMatches}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-emerald-600 hover:from-indigo-500 hover:to-emerald-500 text-white text-xs font-black shadow-lg shadow-indigo-950/40 transition active:scale-95 cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>Tout Valider en 1 Clic</span>
            </button>
          </div>
        </div>

        {/* Filter Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 mt-5 pt-4 border-t border-slate-800/80">
          {/* Status Tabs */}
          <div className="flex items-center gap-1.5 bg-[#0e0e11] p-1 rounded-xl border border-slate-800">
            <button
              onClick={() => setFilterStatus("ALL")}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                filterStatus === "ALL" ? "bg-indigo-600 text-white shadow-md" : "text-slate-400 hover:text-white"
              }`}
            >
              Tous ({matches.length})
            </button>
            <button
              onClick={() => setFilterStatus("LIVE")}
              className={`px-3 py-1 rounded-lg text-xs font-bold flex items-center gap-1 transition ${
                filterStatus === "LIVE" ? "bg-rose-600 text-white shadow-md" : "text-slate-400 hover:text-white"
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-rose-400 animate-ping" />
              En Direct ({matches.filter((m) => m.status === "LIVE").length})
            </button>
            <button
              onClick={() => setFilterStatus("UPCOMING")}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                filterStatus === "UPCOMING" ? "bg-indigo-600 text-white shadow-md" : "text-slate-400 hover:text-white"
              }`}
            >
              À Venir ({matches.filter((m) => m.status === "UPCOMING" || m.status === "READY_FOR_PRONO").length})
            </button>
            <button
              onClick={() => setFilterStatus("FINISHED")}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                filterStatus === "FINISHED" ? "bg-indigo-600 text-white shadow-md" : "text-slate-400 hover:text-white"
              }`}
            >
              Terminés ({matches.filter((m) => m.status === "FINISHED").length})
            </button>
          </div>

          {/* League Filter */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 font-semibold">Ligue :</span>
            <select
              value={selectedLeague}
              onChange={(e) => setSelectedLeague(e.target.value)}
              className="bg-[#0e0e11] border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
            >
              <option value="ALL">Toutes les compétitions</option>
              {leagues.map((l) => (
                <option key={l} value={l}>
                  {l}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Match Cards List */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {filteredMatches.map((match) => {
          const prono = getPronoState(match);
          const tweetStatus = getMatchTweetStatus(match.id);
          const isLive = match.status === "LIVE";
          const isFinished = match.status === "FINISHED";

          return (
            <div
              key={match.id}
              className={`bg-[#16161a] border ${
                tweetStatus.isFullyReady
                  ? "border-emerald-500/40 bg-emerald-950/10"
                  : isLive
                  ? "border-rose-500/40"
                  : "border-slate-800"
              } rounded-2xl p-5 shadow-xl flex flex-col justify-between space-y-4 transition hover:border-slate-700`}
            >
              {/* Header Match (League, Time, Status) */}
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                <div className="flex items-center gap-2">
                  <span className="text-base">{match.leagueFlag || "⚽"}</span>
                  <span className="text-xs font-black text-slate-200">{match.league}</span>
                </div>

                <div className="flex items-center gap-2">
                  {isLive ? (
                    <span className="px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 text-[11px] font-black flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                      DIRECT {match.liveMinute || "65'"}
                    </span>
                  ) : isFinished ? (
                    <span className="px-2.5 py-0.5 rounded-full bg-slate-800 text-slate-300 text-[11px] font-bold">
                      TERMINÉ (FT)
                    </span>
                  ) : (
                    <span className="px-2.5 py-0.5 rounded-md bg-[#1c1c22] border border-slate-700 text-slate-300 text-[11px] font-mono font-bold flex items-center gap-1">
                      <Clock className="w-3 h-3 text-amber-400" />
                      {match.kickoffTime}
                    </span>
                  )}

                  {tweetStatus.isFullyReady && (
                    <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-400 text-[11px] font-bold flex items-center gap-1 border border-emerald-500/30">
                      <CheckCircle2 className="w-3 h-3" />
                      2 Tweets Prêts
                    </span>
                  )}
                </div>
              </div>

              {/* Match Teams & Live Score Display */}
              <div className="flex items-center justify-between py-2">
                {/* Home */}
                <div className="flex items-center gap-3 w-5/12">
                  <div className="text-2xl">{match.homeLogo || "🔴"}</div>
                  <div>
                    <h3 className="text-sm font-black text-white truncate">{match.homeTeam}</h3>
                    <div className="text-[11px] text-slate-400 font-mono">Forme: {match.formHome || "V-V-N"}</div>
                  </div>
                </div>

                {/* Center: Score or VS */}
                <div className="text-center w-2/12">
                  {match.actualScore ? (
                    <div className="flex flex-col items-center">
                      <div className="px-3 py-1 rounded-xl bg-[#0e0e11] border border-slate-800 text-base font-black text-white font-mono">
                        {match.actualScore.home} - {match.actualScore.away}
                      </div>
                      <span className="text-[10px] text-slate-400 mt-0.5">Score réel</span>
                    </div>
                  ) : (
                    <span className="text-xs font-black text-amber-400 bg-amber-500/10 px-2 py-1 rounded-lg border border-amber-500/20">
                      VS
                    </span>
                  )}
                </div>

                {/* Away */}
                <div className="flex items-center justify-end gap-3 w-5/12 text-right">
                  <div>
                    <h3 className="text-sm font-black text-white truncate">{match.awayTeam}</h3>
                    <div className="text-[11px] text-slate-400 font-mono">Forme: {match.formAway || "N-D-V"}</div>
                  </div>
                  <div className="text-2xl">{match.awayLogo || "⚪"}</div>
                </div>
              </div>

              {/* Odds from API */}
              <div className="p-3 bg-[#0e0e11] rounded-xl border border-slate-800/80 flex items-center justify-between text-xs">
                <span className="text-slate-400 text-[11px] font-semibold">Cotes API :</span>
                <div className="flex items-center gap-2 font-mono">
                  <button
                    onClick={() =>
                      setPronoForMatch(match.id, {
                        prediction: `Victoire ${match.homeTeam} (1)`,
                        odd: match.odds?.home || "2.10",
                      })
                    }
                    className={`px-2 py-1 rounded-lg border transition ${
                      prono.prediction.includes(match.homeTeam)
                        ? "bg-indigo-600 text-white border-indigo-400 font-bold"
                        : "bg-[#1c1c22] text-slate-300 border-slate-700 hover:border-slate-500"
                    }`}
                  >
                    1 @{match.odds?.home || "2.10"}
                  </button>
                  <button
                    onClick={() =>
                      setPronoForMatch(match.id, {
                        prediction: `${match.homeTeam} to Win (1)`,
                        odd: match.odds?.home || "2.10",
                      })
                    }
                    className={`px-2 py-1 rounded-lg border transition ${
                      prono.prediction.includes(match.homeTeam)
                        ? "bg-indigo-600 text-white border-indigo-400 font-bold"
                        : "bg-[#1c1c22] text-slate-300 border-slate-700 hover:border-slate-500"
                    }`}
                  >
                    1 @{match.odds?.home || "2.10"}
                  </button>
                  <button
                    onClick={() =>
                      setPronoForMatch(match.id, {
                        prediction: "Match Draw (X)",
                        odd: match.odds?.draw || "3.40",
                      })
                    }
                    className={`px-2 py-1 rounded-lg border transition ${
                      prono.prediction.includes("Draw") || prono.prediction.includes("Nul")
                        ? "bg-indigo-600 text-white border-indigo-400 font-bold"
                        : "bg-[#1c1c22] text-slate-300 border-slate-700 hover:border-slate-500"
                    }`}
                  >
                    X @{match.odds?.draw || "3.40"}
                  </button>
                  <button
                    onClick={() =>
                      setPronoForMatch(match.id, {
                        prediction: `${match.awayTeam} to Win (2)`,
                        odd: match.odds?.away || "3.20",
                      })
                    }
                    className={`px-2 py-1 rounded-lg border transition ${
                      prono.prediction.includes(match.awayTeam)
                        ? "bg-indigo-600 text-white border-indigo-400 font-bold"
                        : "bg-[#1c1c22] text-slate-300 border-slate-700 hover:border-slate-500"
                    }`}
                  >
                    2 @{match.odds?.away || "3.20"}
                  </button>
                </div>
              </div>

              {/* Decision Section (Prediction Selector) */}
              <div className="bg-[#111115] border border-slate-800 rounded-xl p-3.5 space-y-2.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-300 flex items-center gap-1.5">
                    <Flame className="w-3.5 h-3.5 text-amber-400" />
                    Tip Selected (English) :
                  </span>
                  <button
                    onClick={() => handleAiGenerateMatch(match)}
                    disabled={generatingMatchId === match.id}
                    className="text-[11px] text-amber-300 hover:text-amber-200 font-bold flex items-center gap-1 transition"
                  >
                    <Sparkles className={`w-3 h-3 ${generatingMatchId === match.id ? "animate-spin" : ""}`} />
                    <span>{generatingMatchId === match.id ? "Analyzing AI..." : "AI Smart Suggest"}</span>
                  </button>
                </div>

                {/* Prono Input Fields */}
                <div className="grid grid-cols-12 gap-2">
                  <input
                    type="text"
                    value={prono.prediction}
                    onChange={(e) => setPronoForMatch(match.id, { prediction: e.target.value })}
                    placeholder="E.g. Liverpool to Win, Over 2.5 Goals, BTTS..."
                    className="col-span-8 bg-[#0e0e11] border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-emerald-400 font-bold focus:outline-none focus:border-indigo-500"
                  />
                  <div className="col-span-4 flex items-center gap-1 bg-[#0e0e11] border border-slate-800 rounded-lg px-2 py-1.5">
                    <span className="text-[11px] text-slate-500 font-mono">@</span>
                    <input
                      type="text"
                      value={prono.odd}
                      onChange={(e) => setPronoForMatch(match.id, { odd: e.target.value })}
                      placeholder="1.85"
                      className="w-full bg-transparent text-xs text-amber-300 font-mono font-bold focus:outline-none"
                    />
                  </div>
                </div>

                {/* Quick Quick Market Pills */}
                <div className="flex flex-wrap items-center gap-1.5 pt-1">
                  <button
                    onClick={() =>
                      setPronoForMatch(match.id, {
                        prediction: "Over 2.5 Goals",
                        odd: match.odds?.over25 || "1.85",
                      })
                    }
                    className="text-[10px] px-2 py-0.5 rounded bg-[#1c1c22] hover:bg-slate-800 text-slate-300 border border-slate-700 transition"
                  >
                    Over 2.5 (@{match.odds?.over25 || "1.85"})
                  </button>
                  <button
                    onClick={() =>
                      setPronoForMatch(match.id, {
                        prediction: "Both Teams to Score (BTTS - Yes)",
                        odd: match.odds?.bttsYes || "1.75",
                      })
                    }
                    className="text-[10px] px-2 py-0.5 rounded bg-[#1c1c22] hover:bg-slate-800 text-slate-300 border border-slate-700 transition"
                  >
                    BTTS (@{match.odds?.bttsYes || "1.75"})
                  </button>
                  <button
                    onClick={() =>
                      setPronoForMatch(match.id, {
                        prediction: `${match.homeTeam} or Draw (1X)`,
                        odd: "1.40",
                      })
                    }
                    className="text-[10px] px-2 py-0.5 rounded bg-[#1c1c22] hover:bg-slate-800 text-slate-300 border border-slate-700 transition"
                  >
                    Double Chance 1X
                  </button>
                </div>
              </div>

              {/* Action Button: Validate & Generate Tweet */}
              <div className="flex items-center justify-between gap-3 pt-2">
                {tweetStatus.hasH1 ? (
                  <button
                    onClick={onNavigateToTweets}
                    className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 text-xs font-bold transition"
                  >
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Tweet H-1h Prêt · Voir dans la File ➔</span>
                  </button>
                ) : (
                  <button
                    onClick={() => handleValidateMatch(match)}
                    className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 via-indigo-500 to-emerald-600 hover:from-indigo-500 hover:to-emerald-500 text-white text-xs font-black shadow-lg shadow-indigo-950/50 transition active:scale-98 cursor-pointer"
                  >
                    <Zap className="w-4 h-4 text-amber-300" />
                    <span>{match.status === "FINISHED" ? "Générer le Bilan FT (Score Réel)" : "Générer le Tweet (H-1h)"}</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
