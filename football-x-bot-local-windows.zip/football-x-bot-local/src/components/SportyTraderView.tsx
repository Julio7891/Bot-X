import React, { useState, useEffect } from "react";
import {
  Globe,
  Sparkles,
  PlaneTakeoff,
  Copy,
  Check,
  Send,
  Download,
  Terminal,
  ExternalLink,
  RefreshCw,
  AlertCircle,
  FileCode,
  ShieldCheck,
  Flame,
  CheckCircle2,
  TrendingUp,
  Cpu,
  Clock,
  Play,
  Square,
  Radio,
  Zap,
} from "lucide-react";
import { ScrapedPronoItem, AirportFlightTweet } from "../types";
import { generateSportyTraderPythonScript } from "../utils/sportyTraderScraperScript";

interface SportyTraderViewProps {
  authToken: string;
  ct0: string;
  onImportToAirport: (flight: AirportFlightTweet) => void;
  onImportAllToAirport: (flights: AirportFlightTweet[]) => void;
  onPublishDirectly: (flight: AirportFlightTweet) => Promise<any>;
  onShowToast: (msg: string) => void;
}

// User exact HTML snippets for 1-click loading and testing
const USER_EXACT_HTML_SNIPPETS = `<div class="bg-gray-100 my-2 p-2 rounded-md ">
    <div class="grid grid-cols-12 space-x-2">
        <div class=" col-span-9 text-left leading-5">
            <a href="/pronostics/saint-etienne-grenoble-foot-367039/" class="text-sm" data-trans="tips.our.tip.card %homeTeam% %awayTeam%">Pronostic Saint Étienne Grenoble Foot</a>
            <p class="text-left font-semibold">L'AS Saint-Étienne gagne par au moins 2 buts d'écart</p>
        </div>
        <div class=" col-span-3 flex flex-col justify-center items-center bg-white p-0.5 rounded-md ">
            <span class="text-sm">Cote</span>
            <span class="font-bold tabular-nums tracking-tight">1.97</span>
        </div>
    </div>
    <div class="flex text-sm justify-center items-center cursor-pointer underline mt-1" data-trans="tips.in.details">En détails</div>
</div>

<div class="bg-gray-100 my-2 p-2 rounded-md ">
    <div class="grid grid-cols-12 space-x-2">
        <div class=" col-span-9 text-left leading-5">
            <a href="/pronostics/borussia-dortmund-bayern-munich-367024/" class="text-sm" data-trans="tips.our.tip.card %homeTeam% %awayTeam%">Pronostic Borussia Dortmund Bayern Munich</a>
            <p class="text-left font-semibold">Bayern Munich gagne</p>
        </div>
        <div class=" col-span-3 flex flex-col justify-center items-center bg-white p-0.5 rounded-md ">
            <span class="text-sm">Cote</span>
            <span class="font-bold tabular-nums tracking-tight">1.58</span>
        </div>
    </div>
    <div class="flex text-sm justify-center items-center cursor-pointer underline mt-1" data-trans="tips.in.details">En détails</div>
</div>

<div class="bg-gray-100 my-2 p-2 rounded-md ">
    <div class="grid grid-cols-12 space-x-2">
        <div class=" col-span-9 text-left leading-5">
            <a href="/pronostics/atletico-madrid-villarreal-cf-367364/" class="text-sm" data-trans="tips.our.tip.card %homeTeam% %awayTeam%">Pronostic Atlético Madrid Villarreal CF</a>
            <p class="text-left font-semibold">Atlético ou nul et les deux équipes marquent</p>
        </div>
        <div class=" col-span-3 flex flex-col justify-center items-center bg-white p-0.5 rounded-md ">
            <span class="text-sm">Cote</span>
            <span class="font-bold tabular-nums tracking-tight">2</span>
        </div>
    </div>
    <div class="flex text-sm justify-center items-center cursor-pointer underline mt-1" data-trans="tips.in.details">En détails</div>
</div>`;

export const SportyTraderView: React.FC<SportyTraderViewProps> = ({
  authToken,
  ct0,
  onImportToAirport,
  onImportAllToAirport,
  onPublishDirectly,
  onShowToast,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<"ai_parser" | "python_scraper">("ai_parser");
  const [rawText, setRawText] = useState(USER_EXACT_HTML_SNIPPETS);
  const [customInstructions, setCustomInstructions] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [copiedScript, setCopiedScript] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editedTweets, setEditedTweets] = useState<Record<string, string>>({});
  const [importedIds, setImportedIds] = useState<Record<string, boolean>>({});

  // 60-second live watcher states
  const [isLiveWatching, setIsLiveWatching] = useState(false);
  const [secondsUntilNextScan, setSecondsUntilNextScan] = useState(60);
  const [autoSendToAirport, setAutoSendToAirport] = useState(true);
  const [scanHistoryCount, setScanHistoryCount] = useState(0);

  const [pronos, setPronos] = useState<ScrapedPronoItem[]>([
    {
      id: "st-exact-1",
      homeTeam: "Saint-Étienne",
      awayTeam: "Grenoble Foot",
      league: "Ligue 2",
      leagueFlag: "🇫🇷",
      kickoffTime: "20:45",
      kickoffDate: "Ce soir",
      predictionType: "Saint-Étienne to Win (-1.5 Handicap)",
      estimatedOdd: "1.97",
      predictedScore: "3-1",
      confidencePercent: 84,
      keyReasoning: "Strong home performance at Geoffroy-Guichard against a fragile away side.",
      source: "SportyTrader HTML",
      tweetText: "🔥 MATCH OF THE DAY | ASSE vs Grenoble (20:45)\n🇫🇷 Ligue 2\n\n💡 Dominant home form and potent offensive transitions.\n\n🎯 Tip: ASSE to Win by 2+ Goals (@1.97)\n📊 Projected Score: 3-1\n🔥 Confidence: 84%\n\n#ASSEGF38 #ASSE #FootballTips #BettingTips",
    },
    {
      id: "st-exact-2",
      homeTeam: "Borussia Dortmund",
      awayTeam: "Bayern Munich",
      league: "Bundesliga",
      leagueFlag: "🇩🇪",
      kickoffTime: "18:30",
      kickoffDate: "Ce week-end",
      predictionType: "Bayern Munich to Win",
      estimatedOdd: "1.58",
      predictedScore: "1-3",
      confidencePercent: 88,
      keyReasoning: "Decisive Der Klassiker fixture with Bayern's superior finishing power.",
      source: "SportyTrader HTML",
      tweetText: "⚔️ DER KLASSIKER | Dortmund vs Bayern Munich (18:30)\n🇩🇪 Bundesliga\n\n💡 Bayern consistently ruthless in major German derbies.\n\n🎯 Tip: Bayern Munich to Win (@1.58)\n📊 Projected Score: 1-3\n🔥 Confidence: 88%\n\n#BVBFCB #Bundesliga #MiaSanMia #FootballTips #BettingTips",
    },
    {
      id: "st-exact-3",
      homeTeam: "Atlético Madrid",
      awayTeam: "Villarreal CF",
      league: "La Liga",
      leagueFlag: "🇪🇸",
      kickoffTime: "21:00",
      kickoffDate: "Ce soir",
      predictionType: "Atlético or Draw & Both Teams To Score",
      estimatedOdd: "2.00",
      predictedScore: "2-1",
      confidencePercent: 82,
      keyReasoning: "Metropolitano stronghold with both sides dangerous on counters.",
      source: "SportyTrader HTML",
      tweetText: "💥 LA LIGA CLASH | Atlético vs Villarreal (21:00)\n🇪🇸 La Liga\n\n💡 Solid home record for Atleti with Villarreal scoring consistently on the road.\n\n🎯 Tip: 1X & BTTS (Yes) (@2.00)\n📊 Projected Score: 2-1\n🔥 Confidence: 82%\n\n#AtletiVillarreal #AupaAtleti #FootballTips #BettingTips",
    },
  ]);

  const pythonScript = generateSportyTraderPythonScript({
    authToken,
    ct0,
    appApiUrl: window.location.origin,
    autoPostToX: true,
    intervalSeconds: 60,
  });

  // 60-second automated interval timer
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;

    if (isLiveWatching) {
      interval = setInterval(() => {
        setSecondsUntilNextScan((prev) => {
          if (prev <= 1) {
            // Trigger automatic extraction
            handleExtractWithAI(undefined, true);
            setScanHistoryCount((c) => c + 1);
            return 60;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      setSecondsUntilNextScan(60);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isLiveWatching, rawText]);

  const handleExtractWithAI = async (textToUse?: string, isAutoBackground = false) => {
    setIsLoading(true);
    try {
      const payloadText = textToUse !== undefined ? textToUse : rawText;
      const res = await fetch("/api/scraper/sportytrader-parse", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          rawContent: payloadText,
          customInstructions,
        }),
      });

      const data = await res.json();
      if (data.success && Array.isArray(data.scrapedPronos) && data.scrapedPronos.length > 0) {
        setPronos(data.scrapedPronos);
        onShowToast(`🎉 ${data.scrapedPronos.length} pronostics SportyTrader convertis en Tweets !`);

        // If auto-send to Airport is enabled in live watching mode
        if (isAutoBackground && autoSendToAirport) {
          const flights = data.scrapedPronos.map((p: ScrapedPronoItem) => convertPronoToFlight(p));
          onImportAllToAirport(flights);
          onShowToast(`🛫 ${flights.length} tweets SportyTrader envoyés automatiquement à l'Aéroport !`);
        }
      } else {
        if (!isAutoBackground) {
          onShowToast("⚠️ Aucun pronostic trouvé. Vérifiez le code HTML SportyTrader.");
        }
      }
    } catch (e: any) {
      if (!isAutoBackground) {
        onShowToast(`❌ Erreur: ${e?.message || "Échec de l'extraction"}`);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyTweet = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    onShowToast("📋 Tweet copié dans le presse-papier !");
    setTimeout(() => setCopiedId(null), 2000);
  };

  const convertPronoToFlight = (p: ScrapedPronoItem): AirportFlightTweet => {
    const tweetContent = editedTweets[p.id] || p.tweetText;
    return {
      id: `flight-st-${p.id}-${Date.now()}`,
      matchTitle: `${p.homeTeam} vs ${p.awayTeam}`,
      type: "PRONO_H1",
      tweetText: tweetContent,
      flightCode: `ST-${Math.floor(1000 + Math.random() * 9000)}`,
      departureTime: `H-1h (${p.kickoffTime || "20:45"})`,
      scheduledTimestamp: Date.now() + 1800000,
      scheduledTimeLabel: `H-1h (${p.kickoffTime || "20:45"})`,
      isAutoScheduled: true,
      baggages: {
        match: `${p.homeTeam} vs ${p.awayTeam}`,
        prediction: p.predictionType,
        odd: p.estimatedOdd,
        confidence: p.confidencePercent,
        style: "SportyTrader HTML IA",
      },
      status: "READY",
      createdAt: Date.now(),
    };
  };

  const handleSendSingleToAirport = (p: ScrapedPronoItem) => {
    const flight = convertPronoToFlight(p);
    onImportToAirport(flight);
    setImportedIds((prev) => ({ ...prev, [p.id]: true }));
    onShowToast(`🛫 Prono ${p.homeTeam} vs ${p.awayTeam} expédié à l'Aéroport !`);
  };

  const handleSendAllToAirport = () => {
    const flights = pronos.map((p) => convertPronoToFlight(p));
    onImportAllToAirport(flights);
    const newImports: Record<string, boolean> = {};
    pronos.forEach((p) => {
      newImports[p.id] = true;
    });
    setImportedIds(newImports);
    onShowToast(`🚀 ${flights.length} pronostics SportyTrader importés dans l'Aéroport !`);
  };

  const handleCopyScript = () => {
    navigator.clipboard.writeText(pythonScript);
    setCopiedScript(true);
    onShowToast("🐍 Script Python copié !");
    setTimeout(() => setCopiedScript(false), 2000);
  };

  const handleDownloadScript = () => {
    const blob = new Blob([pythonScript], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "sportytrader_live_watcher.py";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    onShowToast("💾 sportytrader_live_watcher.py téléchargé !");
  };

  return (
    <div className="space-y-6">
      {/* Hero Banner SportyTrader */}
      <div className="bg-gradient-to-r from-emerald-950/70 via-[#16161a] to-indigo-950/70 border border-emerald-500/30 rounded-2xl p-6 relative overflow-hidden shadow-xl">
        <div className="absolute right-0 top-0 w-80 h-full bg-radial from-emerald-500/10 to-transparent pointer-events-none" />

        <div className="flex flex-wrap items-center justify-between gap-4 relative z-10">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[11px] font-black uppercase tracking-wider flex items-center gap-1">
                <Globe className="w-3 h-3 text-emerald-400" />
                Scraper SportyTrader & IA
              </span>
              <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[11px] font-bold flex items-center gap-1">
                <Clock className="w-3 h-3 text-amber-400" />
                Vérification Toutes les 60s
              </span>
              <span className="px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[11px] font-bold">
                Mistral AI Engine
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
              Scraper SportyTrader HTML & Publication Auto X
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-3xl leading-relaxed">
              Détecte les blocs de pronostics SportyTrader (<code>div.bg-gray-100</code>, <code>p.font-semibold</code>, <code>span.tabular-nums</code>). Dès qu'un pronostic est identifié, Mistral AI le formate en <strong>Tweet percutant (&lt; 270 car.)</strong> et l'envoie sur votre compte X ou vers l'Aéroport !
            </p>
          </div>

          {/* Live Watcher Controller Card */}
          <div className="bg-[#111115] border border-emerald-500/40 rounded-2xl p-4 shadow-2xl flex flex-col items-end gap-3">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <div
                  className={`w-3 h-3 rounded-full ${
                    isLiveWatching ? "bg-emerald-400 animate-ping" : "bg-slate-600"
                  }`}
                />
                <span className="text-xs font-black text-slate-200">
                  {isLiveWatching ? "🤖 SCANNER AUTO ACTIF" : "SCANNER AUTO EN PAUSE"}
                </span>
              </div>

              <button
                onClick={() => {
                  setIsLiveWatching(!isLiveWatching);
                  if (!isLiveWatching) {
                    onShowToast("⚡ Scanner SportyTrader activé (recherche toutes les 60 secondes)");
                  } else {
                    onShowToast("🛑 Scanner SportyTrader mis en pause");
                  }
                }}
                className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl font-bold text-xs shadow-lg transition ${
                  isLiveWatching
                    ? "bg-rose-600 hover:bg-rose-500 text-white"
                    : "bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-950/50"
                }`}
              >
                {isLiveWatching ? (
                  <>
                    <Square className="w-3.5 h-3.5" />
                    <span>Stopper</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5" />
                    <span>Lancer (60s)</span>
                  </>
                )}
              </button>
            </div>

            {isLiveWatching && (
              <div className="flex items-center gap-3 text-xs text-slate-300 font-mono">
                <span className="text-amber-400 flex items-center gap-1">
                  <RefreshCw className="w-3 h-3 animate-spin text-amber-400" />
                  Prochain scan dans : <strong>{secondsUntilNextScan}s</strong>
                </span>
                <span className="text-slate-500">|</span>
                <span className="text-emerald-400">Scans effectués : {scanHistoryCount}</span>
              </div>
            )}
          </div>
        </div>

        {/* Tab switchers */}
        <div className="flex items-center gap-2 mt-6 pt-4 border-t border-slate-800/80">
          <button
            onClick={() => setActiveSubTab("ai_parser")}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition ${
              activeSubTab === "ai_parser"
                ? "bg-emerald-600 text-white shadow-lg shadow-emerald-950/50"
                : "bg-[#1c1c22] text-slate-400 hover:text-white"
            }`}
          >
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>1. Extracteur HTML & IA (Navigateur Web)</span>
          </button>
          <button
            onClick={() => setActiveSubTab("python_scraper")}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition ${
              activeSubTab === "python_scraper"
                ? "bg-emerald-600 text-white shadow-lg shadow-emerald-950/50"
                : "bg-[#1c1c22] text-slate-400 hover:text-white"
            }`}
          >
            <Terminal className="w-4 h-4 text-emerald-300" />
            <span>2. Script Python Watcher (1 min / Playwright sur PC)</span>
          </button>
        </div>
      </div>

      {/* SUB-TAB 1: AI PARSER & HTML EXTRACTOR */}
      {activeSubTab === "ai_parser" && (
        <div className="space-y-6">
          {/* Input Box */}
          <div className="bg-[#16161a] border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-lg border border-emerald-500/20">
                  <FileCode className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">
                    Code HTML / Cartes SportyTrader détectées
                  </h3>
                  <p className="text-xs text-slate-400">
                    Collez directement les balises HTML <code>&lt;div class="bg-gray-100"&gt;</code> ou le texte de SportyTrader.
                  </p>
                </div>
              </div>

              {/* Sample loader */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setRawText(USER_EXACT_HTML_SNIPPETS);
                    handleExtractWithAI(USER_EXACT_HTML_SNIPPETS);
                  }}
                  className="px-3 py-1.5 rounded-lg bg-emerald-950/50 hover:bg-emerald-900/60 border border-emerald-500/30 text-emerald-300 text-xs font-bold transition flex items-center gap-1.5"
                >
                  <Zap className="w-3.5 h-3.5 text-amber-400" />
                  <span>Charger ASSE, Dortmund, Atlético (Vos HTML)</span>
                </button>
                <button
                  onClick={() => setRawText("")}
                  className="px-3 py-1.5 rounded-lg bg-[#1c1c22] hover:bg-slate-800 text-slate-400 text-xs transition"
                >
                  Effacer
                </button>
              </div>
            </div>

            <textarea
              value={rawText}
              onChange={(e) => setRawText(e.target.value)}
              placeholder="Collez ici le code HTML de SportyTrader ou le texte des pronostics..."
              rows={6}
              className="w-full bg-[#0e0e11] border border-slate-800 rounded-xl p-3 text-xs text-emerald-300/90 focus:outline-none focus:border-emerald-500 transition font-mono resize-y"
            />

            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              <div className="flex items-center gap-3">
                <input
                  type="text"
                  value={customInstructions}
                  onChange={(e) => setCustomInstructions(e.target.value)}
                  placeholder="Instructions de ton (ex: tipster pro, emojis chauds, #SportyTrader...)"
                  className="bg-[#0e0e11] border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-300 focus:outline-none focus:border-emerald-500 w-72 sm:w-80"
                />

                <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={autoSendToAirport}
                    onChange={(e) => setAutoSendToAirport(e.target.checked)}
                    className="rounded border-slate-700 text-emerald-600 focus:ring-emerald-500 bg-[#0e0e11]"
                  />
                  <span>Expédier auto à l'Aéroport H-1h</span>
                </label>
              </div>

              <button
                onClick={() => handleExtractWithAI()}
                disabled={isLoading}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-500 to-indigo-600 hover:from-emerald-500 hover:to-indigo-500 text-white font-black text-xs shadow-lg shadow-emerald-950/50 transition cursor-pointer disabled:opacity-50"
              >
                {isLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-amber-300" />
                    <span>Mistral AI extrait les cartes SportyTrader...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-amber-300" />
                    <span>Extraire & Tourner en Tweets X</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Results Section */}
          <div className="space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  Pronostics SportyTrader Prêts pour X
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold">
                    {pronos.length} Matchs Analysés
                  </span>
                </h3>
              </div>

              {pronos.length > 0 && (
                <button
                  onClick={handleSendAllToAirport}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white font-bold text-xs shadow-lg shadow-indigo-950/40 transition cursor-pointer"
                >
                  <PlaneTakeoff className="w-4 h-4 text-amber-300" />
                  <span>🛫 Tout Importer dans l'Aéroport ({pronos.length})</span>
                </button>
              )}
            </div>

            {/* Prono Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {pronos.map((p) => {
                const currentTweet = editedTweets[p.id] || p.tweetText;
                const isEditing = editingId === p.id;
                const isImported = importedIds[p.id];

                return (
                  <div
                    key={p.id}
                    className={`bg-[#16161a] border ${
                      isImported ? "border-emerald-500/50 bg-emerald-950/10" : "border-slate-800"
                    } rounded-2xl p-5 shadow-xl space-y-4 transition flex flex-col justify-between`}
                  >
                    {/* Top: Match & Meta */}
                    <div className="space-y-3">
                      <div className="flex items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
                        <div className="flex items-center gap-2">
                          <span className="text-sm">{p.leagueFlag || "⚽"}</span>
                          <span className="text-xs font-bold text-slate-300">{p.league}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-[11px] px-2 py-0.5 rounded-md bg-[#1c1c22] border border-slate-700 text-slate-300 font-mono">
                            {p.kickoffTime || "20:45"}
                          </span>
                          <span className="text-[11px] px-2 py-0.5 rounded-md bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold">
                            SportyTrader
                          </span>
                        </div>
                      </div>

                      {/* Match Header */}
                      <div className="flex items-center justify-between">
                        <h4 className="text-sm font-black text-white truncate">
                          {p.homeTeam} <span className="text-amber-400 font-normal">vs</span> {p.awayTeam}
                        </h4>
                        <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-black shrink-0">
                          <Flame className="w-3.5 h-3.5 text-amber-400" />
                          <span>{p.confidencePercent}%</span>
                        </div>
                      </div>

                      {/* Prediction Pill & Stat */}
                      <div className="p-3 bg-[#0e0e11] rounded-xl border border-slate-800 space-y-1.5">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-slate-400">Conseil SportyTrader :</span>
                          <span className="font-black text-emerald-400 flex items-center gap-1">
                            🎯 {p.predictionType} <span className="text-amber-300">(@{p.estimatedOdd})</span>
                          </span>
                        </div>
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-slate-400">Score envisagé :</span>
                          <span className="font-mono font-bold text-slate-200">{p.predictedScore}</span>
                        </div>
                        <p className="text-[11px] text-slate-400 pt-1 border-t border-slate-800/60 leading-relaxed italic">
                          "{p.keyReasoning}"
                        </p>
                      </div>

                      {/* Tweet Preview */}
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="font-bold text-slate-400 flex items-center gap-1">
                            <span>📝 Tweet Généré pour X</span>
                          </span>
                          <span
                            className={`font-mono ${
                              currentTweet.length > 270 ? "text-rose-400 font-bold" : "text-slate-500"
                            }`}
                          >
                            {currentTweet.length}/280
                          </span>
                        </div>

                        {isEditing ? (
                          <textarea
                            value={currentTweet}
                            onChange={(e) =>
                              setEditedTweets({ ...editedTweets, [p.id]: e.target.value })
                            }
                            rows={5}
                            className="w-full bg-[#0e0e11] border border-indigo-500/50 rounded-xl p-3 text-xs text-slate-200 focus:outline-none font-mono"
                          />
                        ) : (
                          <div className="p-3 bg-[#0d0d10] border border-slate-800/90 rounded-xl text-xs text-slate-300 font-mono whitespace-pre-line leading-relaxed shadow-inner">
                            {currentTweet}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Bottom Action Bar */}
                    <div className="pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => handleCopyTweet(currentTweet, p.id)}
                          className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#1c1c22] hover:bg-slate-800 text-slate-300 text-xs transition"
                          title="Copier le texte"
                        >
                          {copiedId === p.id ? (
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                          <span>{copiedId === p.id ? "Copié !" : "Copier"}</span>
                        </button>

                        <button
                          onClick={() => setEditingId(isEditing ? null : p.id)}
                          className="px-2.5 py-1.5 rounded-lg bg-[#1c1c22] hover:bg-slate-800 text-slate-400 text-xs transition"
                        >
                          {isEditing ? "Valider" : "Éditer"}
                        </button>
                      </div>

                      <div className="flex items-center gap-2">
                        {/* 1-Clic Web Intent */}
                        <a
                          href={`https://x.com/intent/tweet?text=${encodeURIComponent(currentTweet)}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#1c1c22] hover:bg-slate-800 text-slate-200 text-xs font-bold border border-slate-700 transition"
                        >
                          <Send className="w-3.5 h-3.5 text-indigo-400" />
                          <span>1-Clic X</span>
                        </a>

                        {/* Send to Airport */}
                        <button
                          onClick={() => handleSendSingleToAirport(p)}
                          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition shadow-md ${
                            isImported
                              ? "bg-emerald-600/30 text-emerald-300 border border-emerald-500/30"
                              : "bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-950/40"
                          }`}
                        >
                          {isImported ? (
                            <>
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                              <span>À l'Aéroport</span>
                            </>
                          ) : (
                            <>
                              <PlaneTakeoff className="w-3.5 h-3.5 text-amber-300" />
                              <span>🛫 Expédier</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 2: PYTHON LIVE WATCHER FOR LOCAL PC */}
      {activeSubTab === "python_scraper" && (
        <div className="bg-[#16161a] border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-5">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-xl border border-emerald-500/20">
                <Radio className="w-6 h-6 animate-pulse text-emerald-400" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  Auto-Watcher Python (Surveillance toutes les 60s & Publication X)
                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-semibold">
                    100% Autonome sur PC
                  </span>
                </h3>
                <p className="text-xs text-slate-400">
                  Ce script tourne en tâche de fond sur votre ordinateur : il visite SportyTrader toutes les 60s, extrait les cartes <code>div.bg-gray-100</code>, convertit avec Mistral AI et poste immédiatement le tweet sur X !
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleCopyScript}
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold bg-[#1c1c22] hover:bg-slate-800 text-slate-200 rounded-xl border border-slate-700 transition"
              >
                {copiedScript ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Copié !</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copier le Script</span>
                  </>
                )}
              </button>

              <button
                onClick={handleDownloadScript}
                className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl shadow-lg shadow-emerald-950/40 transition"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Télécharger (sportytrader_live_watcher.py)</span>
              </button>
            </div>
          </div>

          {/* Quick Guide */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 bg-[#1c1c22] rounded-xl border border-slate-800 space-y-1">
              <div className="text-xs font-bold text-emerald-400">1. Installer Playwright</div>
              <div className="bg-[#0e0e11] p-2 rounded text-[11px] font-mono text-slate-300">
                pip install playwright requests<br />
                playwright install chromium
              </div>
            </div>

            <div className="p-4 bg-[#1c1c22] rounded-xl border border-slate-800 space-y-1">
              <div className="text-xs font-bold text-indigo-400">2. Lancer la Surveillance 60s</div>
              <div className="bg-[#0e0e11] p-2 rounded text-[11px] font-mono text-slate-300">
                python sportytrader_live_watcher.py
              </div>
            </div>

            <div className="p-4 bg-[#1c1c22] rounded-xl border border-slate-800 space-y-1">
              <div className="text-xs font-bold text-amber-400">3. Détection & Envoi Auto</div>
              <p className="text-[11px] text-slate-400">
                Dès qu'un nouveau match apparaît sur SportyTrader, il est formaté en Tweet X et publié directement !
              </p>
            </div>
          </div>

          {/* Code Viewer */}
          <div className="relative">
            <pre className="bg-[#0e0e11] border border-slate-800 rounded-xl p-4 text-xs font-mono text-slate-300 overflow-x-auto max-h-96 leading-relaxed">
              {pythonScript}
            </pre>
          </div>
        </div>
      )}
    </div>
  );
};
