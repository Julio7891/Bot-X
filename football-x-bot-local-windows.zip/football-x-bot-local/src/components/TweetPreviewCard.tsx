import React, { useState } from "react";
import { MessageCircle, Repeat2, Heart, Share, BarChart2, Bookmark, CheckCircle2, Copy, Check, Sparkles } from "lucide-react";

interface TweetPreviewCardProps {
  tweetText: string;
  authorName?: string;
  authorHandle?: string;
  authorAvatar?: string;
  createdAt?: string;
  isVerified?: boolean;
  onCopy?: () => void;
  title?: string;
  badgeText?: string;
  badgeColor?: string;
}

export const TweetPreviewCard: React.FC<TweetPreviewCardProps> = ({
  tweetText,
  authorName = "AI Pronos Football ⚽",
  authorHandle = "ai_pronos_foot",
  authorAvatar = "https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=120&auto=format&fit=crop&q=80",
  createdAt = "Il y a 2 min",
  isVerified = true,
  onCopy,
  title,
  badgeText,
  badgeColor = "bg-emerald-500/10 text-emerald-600 border-emerald-500/20",
}) => {
  const [copied, setCopied] = useState(false);
  const maxChars = 280;
  const charCount = tweetText.length;
  const remaining = maxChars - charCount;
  const isOver = remaining < 0;

  const handleCopy = () => {
    navigator.clipboard.writeText(tweetText);
    setCopied(true);
    if (onCopy) onCopy();
    setTimeout(() => setCopied(false), 2000);
  };

  // Calculate circular progress percentage
  const progressPercent = Math.min(100, Math.max(0, (charCount / maxChars) * 100));
  const strokeDashoffset = 100 - progressPercent;

  let progressColor = "text-emerald-500";
  if (charCount > 250 && charCount <= 270) progressColor = "text-amber-500";
  if (charCount > 270) progressColor = "text-rose-500";

  return (
    <div className="bg-[#16161a] text-slate-100 rounded-2xl border border-slate-800 shadow-xl overflow-hidden">
      {/* Card Header */}
      <div className="px-5 py-3 border-b border-slate-800/80 bg-[#16161a] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-indigo-500 animate-pulse" />
          <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
            {title || "Aperçu Direct X (Twitter)"}
          </span>
          {badgeText && (
            <span className={`text-[11px] px-2 py-0.5 rounded-full border font-medium ${badgeColor}`}>
              {badgeText}
            </span>
          )}
        </div>
        <div className="flex items-center gap-3">
          {/* Character counter gauge */}
          <div className="flex items-center gap-1.5 bg-[#0d0d0f] px-2.5 py-1 rounded-full border border-slate-800">
            <svg className="w-4 h-4 -rotate-90" viewBox="0 0 36 36">
              <circle
                cx="18"
                cy="18"
                r="15"
                fill="none"
                className="stroke-slate-800"
                strokeWidth="3"
              />
              <circle
                cx="18"
                cy="18"
                r="15"
                fill="none"
                className={`${progressColor} transition-all duration-300`}
                strokeWidth="3.5"
                strokeDasharray="100"
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
              />
            </svg>
            <span className={`text-xs font-mono font-medium ${isOver ? "text-rose-400 font-bold" : "text-slate-300"}`}>
              {charCount}/{maxChars}
            </span>
          </div>

          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 text-xs font-medium bg-[#1c1c22] hover:bg-slate-800 active:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-lg border border-slate-700/80 transition"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400">Copié !</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-slate-400" />
                <span>Copier</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Tweet Body (Authentic X styling) */}
      <div className="p-5">
        <div className="flex items-start gap-3">
          <img
            src={authorAvatar}
            alt={authorName}
            className="w-10 h-10 rounded-full object-cover ring-2 ring-slate-800 shrink-0"
          />
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 truncate">
                <span className="font-bold text-white text-sm hover:underline cursor-pointer">
                  {authorName}
                </span>
                {isVerified && (
                  <svg className="w-4 h-4 text-indigo-400 shrink-0" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M22.5 12.5c0-1.58-.875-2.95-2.148-3.6.154-.435.238-.905.238-1.4 0-2.21-1.79-4-4-4-.495 0-.965.084-1.4.238C14.55 2.475 13.18 1.6 11.6 1.6c-1.58 0-2.95.875-3.6 2.148-.435-.154-.905-.238-1.4-.238-2.21 0-4 1.79-4 4 0 .495.084.965.238 1.4C1.575 9.55.7 10.92.7 12.5c0 1.58.875 2.95 2.148 3.6-.154.435-.238.905-.238 1.4 0 2.21 1.79 4 4 4 .495 0 .965-.084 1.4-.238 1.15 1.273 2.52 2.148 4.1 2.148 1.58 0 2.95-.875 3.6-2.148.435.154.905.238 1.4.238 2.21 0 4-1.79 4-4 0-.495-.084-.965-.238-1.4 1.273-1.15 2.148-2.52 2.148-4.1zm-11.7 4.3l-3.8-3.8 1.4-1.4 2.4 2.4 6.4-6.4 1.4 1.4-7.8 7.8z" />
                  </svg>
                )}
                <span className="text-slate-400 text-xs truncate">@{authorHandle}</span>
                <span className="text-slate-500 text-xs">·</span>
                <span className="text-slate-500 text-xs shrink-0">{createdAt}</span>
              </div>
            </div>

            {/* Content with whitespace formatting and highlighting */}
            <div className="mt-2.5 text-[14.5px] leading-relaxed text-slate-100 whitespace-pre-line font-sans break-words selection:bg-indigo-600 selection:text-white">
              {tweetText.split(/(\s+|#\w+|@\w+)/).map((part, index) => {
                if (part.startsWith("#")) {
                  return (
                    <span key={index} className="text-indigo-400 hover:underline cursor-pointer">
                      {part}
                    </span>
                  );
                }
                if (part.startsWith("@")) {
                  return (
                    <span key={index} className="text-indigo-400 hover:underline cursor-pointer">
                      {part}
                    </span>
                  );
                }
                return part;
              })}
            </div>

            {/* Tweet Action Bar (Mock) */}
            <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-slate-400 max-w-md">
              <button className="flex items-center gap-1.5 hover:text-indigo-400 transition group text-xs">
                <div className="p-1.5 rounded-full group-hover:bg-indigo-500/10">
                  <MessageCircle className="w-4 h-4" />
                </div>
                <span>24</span>
              </button>
              <button className="flex items-center gap-1.5 hover:text-emerald-400 transition group text-xs">
                <div className="p-1.5 rounded-full group-hover:bg-emerald-500/10">
                  <Repeat2 className="w-4 h-4" />
                </div>
                <span>48</span>
              </button>
              <button className="flex items-center gap-1.5 hover:text-rose-400 transition group text-xs">
                <div className="p-1.5 rounded-full group-hover:bg-rose-500/10">
                  <Heart className="w-4 h-4" />
                </div>
                <span>192</span>
              </button>
              <button className="flex items-center gap-1.5 hover:text-indigo-400 transition group text-xs">
                <div className="p-1.5 rounded-full group-hover:bg-indigo-500/10">
                  <BarChart2 className="w-4 h-4" />
                </div>
                <span>5.4K</span>
              </button>
              <div className="flex items-center gap-1">
                <button className="p-1.5 rounded-full hover:bg-slate-800 hover:text-slate-200 transition text-xs">
                  <Bookmark className="w-4 h-4" />
                </button>
                <button className="p-1.5 rounded-full hover:bg-slate-800 hover:text-slate-200 transition text-xs">
                  <Share className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
