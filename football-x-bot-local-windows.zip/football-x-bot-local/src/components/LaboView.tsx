import React, { useState, useMemo } from "react";
import {
  Sparkles,
  FlaskConical,
  PackageCheck,
  Plane,
  ArrowRight,
  Plus,
  CheckCircle2,
  Tag,
  Clock,
  Target,
} from "lucide-react";
import { FootballMatch, AirportFlightTweet } from "../types";
import { calculateRealisticMarketOdds } from "../utils/oddsEngine";

interface LaboViewProps {
  matches: FootballMatch[];
  selectedMatch: FootballMatch | null;
  onSelectMatch: (match: FootballMatch) => void;
  onAddMatchClick: () => void;
  onSendToAirport: (flight: AirportFlightTweet) => void;
  onNavigateToAirport: () => void;
}

export const LaboView: React.FC<LaboViewProps> = ({
  matches,
  selectedMatch,
  onSelectMatch,
  onAddMatchClick,
  onSendToAirport,
  onNavigateToAirport,
}) => {
  const [activeType, setActiveType] = useState<"PRONO_H1" | "RECAP_FT" | "SPECIAL">("PRONO_H1");
  const [tone, setTone] = useState<"tipster" | "expert" | "viral">("tipster");
  const [targetMarket, setTargetMarket] = useState<"auto" | "btts" | "over25" | "under25" | "dc" | "dnb" | "1x2" | "handicap">("auto");
  const [tweetText, setTweetText] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedLeagueFilter, setSelectedLeagueFilter] = useState("ALL");
  const [sentSuccessNotice, setSentSuccessNotice] = useState(false);

  const activeMatch = selectedMatch || matches[0] || null;

  // Real-time market odds computed with bookmaker models
  const marketOdds = useMemo(() => {
    if (!activeMatch) return null;
    return calculateRealisticMarketOdds(activeMatch.homeTeam, activeMatch.awayTeam, activeMatch.odds);
  }, [activeMatch]);

  // Prono state variables
  const [predictionType, setPredictionType] = useState("Victoire Domicile & +1.5 buts");
  const [predictedScore, setPredictedScore] = useState("2 - 1");
  const [estimatedOdd, setEstimatedOdd] = useState("1.85");
  const [confidence, setConfidence] = useState(82);

  // Initialize or update tweet draft when match changes
  React.useEffect(() => {
    if (activeMatch && marketOdds) {
      if (activeMatch.pronoData) {
        setTweetText(activeMatch.pronoData.tweetText);
        setPredictionType(activeMatch.pronoData.predictionType);
        setPredictedScore(activeMatch.pronoData.predictedScore);
        setEstimatedOdd(activeMatch.pronoData.estimatedOdd);
        setConfidence(activeMatch.pronoData.confidencePercent);
      } else {
        generateFallbackProno(activeMatch);
      }
    }
  }, [activeMatch?.id]);

  const generateWithAI = async () => {
    if (!activeMatch || !marketOdds) return;
    setIsGenerating(true);

    try {
      if (activeType === "PRONO_H1") {
        const res = await fetch("/api/gemini/generate-prono", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            homeTeam: activeMatch.homeTeam,
            awayTeam: activeMatch.awayTeam,
            league: activeMatch.league,
            matchTime: activeMatch.kickoffTime,
            odds: {
              home: marketOdds.home1X2,
              draw: marketOdds.draw1X2,
              away: marketOdds.away1X2,
              over25: marketOdds.over25,
              under25: marketOdds.under25,
              bttsYes: marketOdds.bttsYes,
              bttsNo: marketOdds.bttsNo,
              dnbHome: marketOdds.dnbHome,
              dnbAway: marketOdds.dnbAway,
            },
            formHome: activeMatch.formHome,
            formAway: activeMatch.formAway,
            keyStat: activeMatch.keyStat,
            tone: tone,
            targetMarket: targetMarket,
          }),
        });

        const data = await res.json();
        const prono = data.data || data;

        if (prono.tweetText) {
          setTweetText(prono.tweetText);
          if (prono.predictionType) setPredictionType(prono.predictionType);
          if (prono.predictedScore) setPredictedScore(prono.predictedScore);
          if (prono.estimatedOdd) setEstimatedOdd(prono.estimatedOdd);
          if (prono.confidencePercent) setConfidence(prono.confidencePercent);
        } else {
          generateFallbackProno(activeMatch);
        }
      } else if (activeType === "RECAP_FT") {
        const finalScore = activeMatch.actualScore
          ? `${activeMatch.actualScore.home}-${activeMatch.actualScore.away}`
          : "2-1";

        const res = await fetch("/api/gemini/generate-recap", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            homeTeam: activeMatch.homeTeam,
            awayTeam: activeMatch.awayTeam,
            league: activeMatch.league,
            finalScore: finalScore,
            pronoBet: predictionType || "Victoire Domicile",
            isWon: true,
            odd: estimatedOdd || "1.85",
            tone: tone,
          }),
        });

        const data = await res.json();
        const recap = data.data || data;
        if (recap.tweetText) {
          setTweetText(recap.tweetText);
        } else {
          generateFallbackRecap(activeMatch, finalScore);
        }
      } else {
        setTweetText(
          `🔥 STATS & VALUE TIP | ${activeMatch.homeTeam} vs ${activeMatch.awayTeam}\n\n⚡ ${activeMatch.keyStat || "Two high intensity teams with strong tactical setups."}\n🎯 Value Pick: ${marketOdds.marketRecommendation.market} (@${marketOdds.marketRecommendation.odd})\n📊 Projected Score: ${marketOdds.marketRecommendation.predictedScore}\n\n#${activeMatch.homeTeam.replace(/\s+/g, "")} #${activeMatch.awayTeam.replace(/\s+/g, "")} #FootballTips #BettingTips`
        );
      }
    } catch (e) {
      if (activeType === "PRONO_H1") generateFallbackProno(activeMatch);
      else generateFallbackRecap(activeMatch, "2-1");
    } finally {
      setIsGenerating(false);
    }
  };

  const generateFallbackProno = (match: FootballMatch) => {
    const oddsCalc = calculateRealisticMarketOdds(match.homeTeam, match.awayTeam, match.odds);
    const rec = oddsCalc.marketRecommendation;

    const text = `⚽ #PREDICTION | ${match.homeTeam} vs ${match.awayTeam} (${match.kickoffTime})\n🏆 ${match.league}\n\n🔥 ${rec.reason.slice(0, 80)}\n\n🎯 Tip: ${rec.market} (@${rec.odd})\n📊 Projected Score: ${rec.predictedScore}\n💡 Confidence: ${rec.confidence}%\n\n#FootballTips #${match.homeTeam.replace(/[^a-zA-Z0-9]/g, "")} #${match.awayTeam.replace(/[^a-zA-Z0-9]/g, "")} #BettingTips`;
    setTweetText(text);
    setPredictionType(rec.market);
    setEstimatedOdd(rec.odd);
    setPredictedScore(rec.predictedScore);
    setConfidence(rec.confidence);
  };

  const generateFallbackRecap = (match: FootballMatch, score: string) => {
    const text = `🏁 FULL TIME | ${match.homeTeam} ${score} ${match.awayTeam} ✅\n\n🎯 Tip Verified: ${predictionType || "Win"} (@${estimatedOdd || "1.80"})\n💰 Bankroll profit cashed in!\n\n👏 Great result, onto the next fixture!\n#FootballTips #Winner #${match.homeTeam.replace(/[^a-zA-Z0-9]/g, "")}`;
    setTweetText(text);
  };

  // Quick select specific market & auto update odd
  const handleSelectMarketOption = (marketKey: typeof targetMarket, label: string, odd: string, score: string) => {
    setTargetMarket(marketKey);
    setPredictionType(label);
    setEstimatedOdd(odd);
    setPredictedScore(score);
  };

  const handlePackAndSendToAirport = () => {
    if (!activeMatch || !tweetText.trim()) return;

    const flightId = `FL-${Date.now().toString().slice(-4)}`;
    const newFlight: AirportFlightTweet = {
      id: `flight-${Date.now()}`,
      matchId: activeMatch.id,
      matchTitle: `${activeMatch.homeTeam} vs ${activeMatch.awayTeam}`,
      type: activeType,
      tweetText: tweetText.trim(),
      flightCode: flightId,
      departureTime:
        activeType === "PRONO_H1"
          ? `H-1h (${activeMatch.kickoffTime})`
          : activeType === "RECAP_FT"
          ? `Fin de Match (${activeMatch.kickoffTime})`
          : "Immédiat",
      baggages: {
        match: `${activeMatch.homeTeam} vs ${activeMatch.awayTeam}`,
        prediction: predictionType,
        odd: estimatedOdd,
        confidence: confidence,
        style: tone === "tipster" ? "Tipster Pro" : tone === "viral" ? "Viral / Punchy" : "Analyste Stats",
      },
      status: "READY",
      createdAt: Date.now(),
    };

    onSendToAirport(newFlight);
    setSentSuccessNotice(true);
    setTimeout(() => setSentSuccessNotice(false), 4000);
  };

  const filteredMatches = matches.filter((m) => {
    if (selectedLeagueFilter === "ALL") return true;
    return m.league.toLowerCase().includes(selectedLeagueFilter.toLowerCase());
  });

  const charCount = tweetText.length;
  const isOverLimit = charCount > 280;

  return (
    <div className="space-y-6">
      {/* Top Banner: Lab Explanation */}
      <div className="bg-gradient-to-r from-indigo-950/60 via-[#16161a] to-emerald-950/40 border border-indigo-900/40 rounded-2xl p-5 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative z-10">
          <div className="flex items-center gap-3.5">
            <div className="p-3 bg-indigo-600/20 text-indigo-400 rounded-2xl border border-indigo-500/30 shadow-inner">
              <FlaskConical className="w-7 h-7 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-black text-white tracking-tight">
                  Le Laboratoire de Préparation des Tweets
                </h1>
                <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-mono">
                  Étape 1 & 2
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1 max-w-2xl leading-relaxed">
                Générez des <strong>vrais pronostics diversifiés</strong> (BTTS, Over/Under, Buteurs, DNB, Handicap) avec des <strong>cotes réelles et calculées</strong> pour votre compte X.
              </p>
            </div>
          </div>

          <button
            onClick={onNavigateToAirport}
            className="flex items-center gap-2 px-4 py-2.5 bg-[#1c1c22] hover:bg-slate-800 text-slate-200 hover:text-white rounded-xl border border-slate-700 text-xs font-bold transition shadow-md whitespace-nowrap"
          >
            <Plane className="w-4 h-4 text-emerald-400" />
            <span>Voir l'Aéroport & la Piste</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Success Notification Alert */}
      {sentSuccessNotice && (
        <div className="p-4 bg-emerald-950/50 border border-emerald-500/40 rounded-2xl flex items-center justify-between gap-4 animate-bounce text-xs text-emerald-200">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-500/20 rounded-xl text-emerald-400">
              <PackageCheck className="w-5 h-5" />
            </div>
            <div>
              <p className="font-bold text-white text-sm">
                📦 Bagages enregistrés & Tweet envoyé à l'Aéroport avec succès !
              </p>
              <p className="text-emerald-300/80 text-[11px]">
                Le tweet est maintenant positionné sur la piste de décollage, prêt pour l'envol en 1 clic.
              </p>
            </div>
          </div>

          <button
            onClick={onNavigateToAirport}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-lg shadow-emerald-950/50 transition"
          >
            <Plane className="w-3.5 h-3.5" />
            <span>Aller Décoller 🛫</span>
          </button>
        </div>
      )}

      {/* Main 2-Column Workstation */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Match Selection (Col 5) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-[#16161a] border border-slate-800 rounded-2xl p-4 shadow-xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-indigo-600/20 text-indigo-400 font-bold text-xs flex items-center justify-center border border-indigo-500/30">
                  1
                </span>
                <h2 className="text-sm font-bold text-white">Choisir le Match du Jour</h2>
              </div>
              <button
                onClick={onAddMatchClick}
                className="flex items-center gap-1 px-2.5 py-1 bg-[#1c1c22] hover:bg-slate-800 text-indigo-400 hover:text-indigo-300 rounded-lg text-xs font-semibold border border-slate-700 transition"
              >
                <Plus className="w-3 h-3" />
                <span>Ajouter</span>
              </button>
            </div>

            {/* League Quick Filters */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
              {[
                { id: "ALL", label: "Tous" },
                { id: "Champions", label: "🇪🇺 LDC" },
                { id: "Ligue 1", label: "🇫🇷 L1" },
                { id: "Premier", label: "🇬🇧 PL" },
                { id: "Liga", label: "🇪🇸 Liga" },
                { id: "Serie A", label: "🇮🇹 Serie A" },
              ].map((filter) => (
                <button
                  key={filter.id}
                  onClick={() => setSelectedLeagueFilter(filter.id)}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold whitespace-nowrap transition ${
                    selectedLeagueFilter === filter.id
                      ? "bg-indigo-600 text-white"
                      : "bg-[#1c1c22] text-slate-400 hover:text-slate-200"
                  }`}
                >
                  {filter.label}
                </button>
              ))}
            </div>

            {/* Match Cards List */}
            <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
              {filteredMatches.map((match) => {
                const isSelected = activeMatch?.id === match.id;
                const matchOdds = calculateRealisticMarketOdds(match.homeTeam, match.awayTeam, match.odds);

                return (
                  <div
                    key={match.id}
                    onClick={() => onSelectMatch(match)}
                    className={`p-3.5 rounded-xl border cursor-pointer transition relative group ${
                      isSelected
                        ? "bg-indigo-950/40 border-indigo-500 text-white shadow-lg shadow-indigo-950/40"
                        : "bg-[#1c1c22] border-slate-800/80 text-slate-300 hover:border-slate-700 hover:bg-[#202028]"
                    }`}
                  >
                    <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1.5 font-medium">
                      <span className="flex items-center gap-1 text-indigo-300 font-semibold">
                        🏆 {match.league}
                      </span>
                      <span className="flex items-center gap-1 font-mono text-slate-300">
                        <Clock className="w-3 h-3 text-slate-400" />
                        {match.kickoffTime}
                      </span>
                    </div>

                    <div className="flex items-center justify-between gap-2">
                      <div className="space-y-1 flex-1">
                        <div className="flex items-center justify-between pr-2">
                          <span className="font-bold text-xs text-white group-hover:text-indigo-300 transition">
                            {match.homeTeam}
                          </span>
                          <span className="text-[10px] text-emerald-400 font-mono font-bold bg-[#0d0d0f] px-1.5 py-0.5 rounded border border-slate-800">
                            1: @{matchOdds.home1X2}
                          </span>
                        </div>
                        <div className="flex items-center justify-between pr-2">
                          <span className="font-bold text-xs text-white group-hover:text-indigo-300 transition">
                            {match.awayTeam}
                          </span>
                          <span className="text-[10px] text-emerald-400 font-mono font-bold bg-[#0d0d0f] px-1.5 py-0.5 rounded border border-slate-800">
                            2: @{matchOdds.away1X2}
                          </span>
                        </div>
                      </div>

                      <div className="text-right">
                        {isSelected ? (
                          <span className="px-2 py-1 bg-indigo-600 text-white font-bold text-[10px] rounded-md shadow-sm">
                            Sélectionné ✓
                          </span>
                        ) : (
                          <span className="text-[10px] text-slate-500 group-hover:text-slate-300">
                            Choisir 👉
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Quick market tags preview */}
                    <div className="flex items-center gap-2 mt-2 pt-1.5 border-t border-slate-800/60 text-[10px] text-slate-400">
                      <span>Nul : <strong>@{matchOdds.draw1X2}</strong></span>
                      <span>·</span>
                      <span>Over 2.5 : <strong>@{matchOdds.over25}</strong></span>
                      <span>·</span>
                      <span>BTTS : <strong>@{matchOdds.bttsYes}</strong></span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Tweet Generator & Packaging Station (Col 7) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-[#16161a] border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-emerald-600/20 text-emerald-400 font-bold text-xs flex items-center justify-center border border-emerald-500/30">
                  2
                </span>
                <h2 className="text-sm font-bold text-white">Générer & Formater le Tweet IA</h2>
              </div>

              {/* Type Switcher */}
              <div className="flex items-center gap-1 bg-[#0d0d0f] p-1 rounded-xl border border-slate-800 text-xs">
                <button
                  onClick={() => setActiveType("PRONO_H1")}
                  className={`px-3 py-1 rounded-lg font-bold transition flex items-center gap-1 ${
                    activeType === "PRONO_H1"
                      ? "bg-indigo-600 text-white"
                      : "text-slate-400 hover:text-slate-200"
                  }`}
                >
                  <Sparkles className="w-3 h-3" />
                  <span>Prono (H-1h)</span>
                </button>
                <button
                  onClick={() => setActiveType("RECAP_FT")}
                  className={`px-3 py-1 rounded-lg font-bold transition flex items-center gap-1 ${
                    activeType === "RECAP_FT"
                      ? "bg-emerald-600 text-white"
                      : "text-slate-400 hover:text-slate-200"
                  }`}
                >
                  <CheckCircle2 className="w-3 h-3" />
                  <span>Bilan (Fin de Match)</span>
                </button>
                <button
                  onClick={() => setActiveType("SPECIAL")}
                  className={`px-3 py-1 rounded-lg font-bold transition ${
                    activeType === "SPECIAL"
                      ? "bg-amber-600 text-white"
                      : "text-slate-400 hover:text-slate-200"
                  }`}
                >
                  <span>Stats & VIP</span>
                </button>
              </div>
            </div>

            {/* Target Match & Comprehensive Real Odds Grid */}
            {activeMatch && marketOdds && (
              <div className="space-y-2.5">
                <div className="p-3 bg-[#1c1c22] rounded-xl border border-slate-800/80 flex items-center justify-between text-xs flex-wrap gap-2">
                  <span className="text-slate-300 font-semibold flex items-center gap-1.5">
                    ⚽ Match ciblé :{" "}
                    <strong className="text-white font-bold">
                      {activeMatch.homeTeam} 🆚 {activeMatch.awayTeam}
                    </strong>{" "}
                    ({activeMatch.league} · {activeMatch.kickoffTime})
                  </span>
                  <span className="text-[11px] font-mono text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/20">
                    Cotes Bookmakers Calibrées
                  </span>
                </div>

                {/* Interactive Market Odds Selector Chips */}
                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-300 flex items-center gap-1">
                    <Target className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Choisir le Marché pour l'Analyse IA (Cotes Réelles) :</span>
                  </label>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 text-xs font-mono">
                    <button
                      type="button"
                      onClick={() => handleSelectMarketOption("auto", marketOdds.marketRecommendation.market, marketOdds.marketRecommendation.odd, marketOdds.marketRecommendation.predictedScore)}
                      className={`p-2 rounded-lg border text-left transition flex flex-col justify-between ${
                        targetMarket === "auto"
                          ? "bg-indigo-600/30 border-indigo-500 text-white shadow-md shadow-indigo-950/40"
                          : "bg-[#0d0d0f] border-slate-800 text-slate-300 hover:border-slate-700"
                      }`}
                    >
                      <span className="text-[10px] text-indigo-400 font-sans font-bold flex items-center gap-1">
                        ⚡ Value IA Auto
                      </span>
                      <span className="font-bold text-emerald-400 text-[11px] mt-0.5">@{marketOdds.marketRecommendation.odd}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleSelectMarketOption("btts", "Les 2 Équipes Marquent (BTTS - Oui)", marketOdds.bttsYes, "2 - 2")}
                      className={`p-2 rounded-lg border text-left transition flex flex-col justify-between ${
                        targetMarket === "btts"
                          ? "bg-indigo-600/30 border-indigo-500 text-white shadow-md shadow-indigo-950/40"
                          : "bg-[#0d0d0f] border-slate-800 text-slate-300 hover:border-slate-700"
                      }`}
                    >
                      <span className="text-[10px] text-slate-300 font-sans font-bold">🎯 BTTS (Les 2)</span>
                      <span className="font-bold text-emerald-400 text-[11px] mt-0.5">Oui @{marketOdds.bttsYes}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleSelectMarketOption("over25", "Plus de 2.5 Buts dans le match", marketOdds.over25, "2 - 1")}
                      className={`p-2 rounded-lg border text-left transition flex flex-col justify-between ${
                        targetMarket === "over25"
                          ? "bg-indigo-600/30 border-indigo-500 text-white shadow-md shadow-indigo-950/40"
                          : "bg-[#0d0d0f] border-slate-800 text-slate-300 hover:border-slate-700"
                      }`}
                    >
                      <span className="text-[10px] text-slate-300 font-sans font-bold">📈 Over 2.5 Buts</span>
                      <span className="font-bold text-emerald-400 text-[11px] mt-0.5">@{marketOdds.over25}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleSelectMarketOption("under25", "Moins de 2.5 Buts (Match Fermé)", marketOdds.under25, "1 - 0")}
                      className={`p-2 rounded-lg border text-left transition flex flex-col justify-between ${
                        targetMarket === "under25"
                          ? "bg-indigo-600/30 border-indigo-500 text-white shadow-md shadow-indigo-950/40"
                          : "bg-[#0d0d0f] border-slate-800 text-slate-300 hover:border-slate-700"
                      }`}
                    >
                      <span className="text-[10px] text-slate-300 font-sans font-bold">📉 Under 2.5 Buts</span>
                      <span className="font-bold text-emerald-400 text-[11px] mt-0.5">@{marketOdds.under25}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleSelectMarketOption("dnb", `${activeMatch.homeTeam} Remboursé si Nul (DNB 1)`, marketOdds.dnbHome, "2 - 1")}
                      className={`p-2 rounded-lg border text-left transition flex flex-col justify-between ${
                        targetMarket === "dnb"
                          ? "bg-indigo-600/30 border-indigo-500 text-white shadow-md shadow-indigo-950/40"
                          : "bg-[#0d0d0f] border-slate-800 text-slate-300 hover:border-slate-700"
                      }`}
                    >
                      <span className="text-[10px] text-slate-300 font-sans font-bold">🛡️ DNB 1 (Sécurité)</span>
                      <span className="font-bold text-emerald-400 text-[11px] mt-0.5">@{marketOdds.dnbHome}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleSelectMarketOption("1x2", `Victoire Sèche ${activeMatch.homeTeam}`, marketOdds.home1X2, "2 - 0")}
                      className={`p-2 rounded-lg border text-left transition flex flex-col justify-between ${
                        targetMarket === "1x2"
                          ? "bg-indigo-600/30 border-indigo-500 text-white shadow-md shadow-indigo-950/40"
                          : "bg-[#0d0d0f] border-slate-800 text-slate-300 hover:border-slate-700"
                      }`}
                    >
                      <span className="text-[10px] text-slate-300 font-sans font-bold">⚽ 1X2 Victoire 1</span>
                      <span className="font-bold text-emerald-400 text-[11px] mt-0.5">@{marketOdds.home1X2}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleSelectMarketOption("dc", `Double Chance ${activeMatch.homeTeam} ou Nul (1X)`, marketOdds.doubleChance1X, "1 - 1")}
                      className={`p-2 rounded-lg border text-left transition flex flex-col justify-between ${
                        targetMarket === "dc"
                          ? "bg-indigo-600/30 border-indigo-500 text-white shadow-md shadow-indigo-950/40"
                          : "bg-[#0d0d0f] border-slate-800 text-slate-300 hover:border-slate-700"
                      }`}
                    >
                      <span className="text-[10px] text-slate-300 font-sans font-bold truncate">🛡️ Double Chance 1X</span>
                      <span className="font-bold text-emerald-400 text-[11px] mt-0.5">@{marketOdds.doubleChance1X}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleSelectMarketOption("handicap", `Victoire ${activeMatch.homeTeam} Handicap (-1.5)`, marketOdds.handicapHomeMinus1, "3 - 0")}
                      className={`p-2 rounded-lg border text-left transition flex flex-col justify-between ${
                        targetMarket === "handicap"
                          ? "bg-indigo-600/30 border-indigo-500 text-white shadow-md shadow-indigo-950/40"
                          : "bg-[#0d0d0f] border-slate-800 text-slate-300 hover:border-slate-700"
                      }`}
                    >
                      <span className="text-[10px] text-slate-300 font-sans font-bold">⚡ Handicap (-1.5)</span>
                      <span className="font-bold text-emerald-400 text-[11px] mt-0.5">@{marketOdds.handicapHomeMinus1}</span>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Style & AI Generate Button Row */}
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
              <div className="sm:col-span-6 flex items-center gap-2">
                <label className="text-xs text-slate-400 font-medium whitespace-nowrap">Style :</label>
                <select
                  value={tone}
                  onChange={(e: any) => setTone(e.target.value)}
                  className="w-full bg-[#0d0d0f] border border-slate-800 rounded-xl px-3 py-2 text-xs font-bold text-slate-200 focus:outline-none focus:border-indigo-500"
                >
                  <option value="tipster">💼 Tipster Pro (Cotes, Confiance, Clean)</option>
                  <option value="viral">🔥 Viral & Punchy (Emojis, Fort Impact)</option>
                  <option value="expert">📊 Analyste Stats (xG, Séries, Tactique)</option>
                </select>
              </div>

              <div className="sm:col-span-6">
                <button
                  onClick={generateWithAI}
                  disabled={isGenerating || !activeMatch}
                  className="w-full flex items-center justify-center gap-2 px-4 py-2 text-xs font-black text-white bg-gradient-to-r from-amber-600 via-orange-500 to-indigo-600 hover:from-amber-500 hover:to-indigo-500 active:scale-[0.99] rounded-xl shadow-lg shadow-amber-950/50 transition disabled:opacity-50 cursor-pointer"
                >
                  <Sparkles className={`w-4 h-4 ${isGenerating ? "animate-spin text-white" : "text-amber-200"}`} />
                  <span>{isGenerating ? "Mistral AI analyse le match..." : "✨ Générer avec Mistral AI"}</span>
                </button>
              </div>
            </div>

            {/* Tweet Text Area */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                  <Tag className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Contenu du Tweet Prêt pour X</span>
                </label>
                <span
                  className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
                    isOverLimit
                      ? "bg-rose-500/20 text-rose-400 border border-rose-500/40 animate-pulse"
                      : charCount > 240
                      ? "bg-amber-500/20 text-amber-300"
                      : "bg-emerald-500/10 text-emerald-400"
                  }`}
                >
                  {charCount} / 280 car. {isOverLimit ? "❌ Trop long" : "✅ Parfait"}
                </span>
              </div>

              <textarea
                value={tweetText}
                onChange={(e) => setTweetText(e.target.value)}
                rows={7}
                placeholder="Le texte généré de votre tweet apparaîtra ici..."
                className="w-full bg-[#0d0d0f] border border-slate-800 rounded-xl p-3.5 text-xs sm:text-sm font-sans text-slate-100 placeholder-slate-600 focus:outline-none focus:border-indigo-500 leading-relaxed shadow-inner"
              />

              {/* Quick Emojis & Snippets Toolbar */}
              <div className="flex items-center gap-1.5 flex-wrap pt-1">
                <span className="text-[10px] text-slate-500">Ajout rapide :</span>
                {["⚽", "🔥", "🎯", "📊", "💰", "✅", "🚀", "🏆", "#FootballTips", "#BettingTips", "#UCL"].map((item) => (
                  <button
                    key={item}
                    type="button"
                    onClick={() => setTweetText((prev) => prev + " " + item)}
                    className="px-2 py-0.5 bg-[#1c1c22] hover:bg-slate-800 text-slate-300 hover:text-white rounded text-[11px] font-mono border border-slate-800 transition"
                  >
                    {item}
                  </button>
                ))}
              </div>
            </div>

            {/* Step 3: Baggage Inspection & Send to Airport */}
            <div className="p-4 bg-gradient-to-b from-[#1c1c22] to-[#141418] border border-slate-800 rounded-xl space-y-3.5 mt-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-amber-600/20 text-amber-400 font-bold text-xs flex items-center justify-center border border-amber-500/30">
                    3
                  </span>
                  <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                    Emballage des Bagages du Tweet
                  </h3>
                </div>
                <span className="text-[10px] font-semibold text-slate-400 font-mono">
                  3 Bagages Enregistrés
                </span>
              </div>

              {/* 3 Baggage Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
                <div className="p-2.5 bg-[#0d0d0f] rounded-lg border border-slate-800 space-y-1">
                  <span className="text-[10px] text-indigo-400 font-bold block">🧳 Bagage 1 : Match</span>
                  <p className="font-semibold text-slate-200 truncate">
                    {activeMatch?.homeTeam || "Match"} vs {activeMatch?.awayTeam || ""}
                  </p>
                  <span className="text-[10px] text-slate-400">{activeMatch?.kickoffTime || "21:00"}</span>
                </div>

                <div className="p-2.5 bg-[#0d0d0f] rounded-lg border border-slate-800 space-y-1">
                  <span className="text-[10px] text-emerald-400 font-bold block">🧳 Bagage 2 : Prono & Cote</span>
                  <p className="font-semibold text-slate-200 truncate">{predictionType}</p>
                  <span className="text-[10px] text-emerald-400 font-mono font-bold">Cote @{estimatedOdd}</span>
                </div>

                <div className="p-2.5 bg-[#0d0d0f] rounded-lg border border-slate-800 space-y-1">
                  <span className="text-[10px] text-amber-400 font-bold block">🧳 Bagage 3 : Format & Session</span>
                  <p className="font-semibold text-slate-200">Prêt au Décollage</p>
                  <span className="text-[10px] text-slate-400">Authentifié X</span>
                </div>
              </div>

              {/* Big Action Button: PACK & SEND TO AIRPORT */}
              <button
                onClick={handlePackAndSendToAirport}
                disabled={!tweetText.trim() || isOverLimit}
                className="w-full py-3 px-4 bg-gradient-to-r from-emerald-600 via-emerald-500 to-indigo-600 hover:from-emerald-500 hover:to-indigo-500 active:scale-[0.99] text-white font-black rounded-xl shadow-xl shadow-emerald-950/50 flex items-center justify-center gap-2.5 transition text-xs sm:text-sm disabled:opacity-50 cursor-pointer"
              >
                <PackageCheck className="w-5 h-5 text-amber-300" />
                <span>📦 Valider les Bagages & Transférer à l'Aéroport</span>
                <Plane className="w-4 h-4 text-white" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
