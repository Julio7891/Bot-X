import React, { useState } from "react";
import {
  Zap,
  Radio,
  Clock,
  CheckCircle2,
  Sparkles,
  Plane,
  RotateCw,
  Trophy,
  ChevronDown,
  ChevronUp,
  Activity,
  ShieldCheck,
  Send,
} from "lucide-react";
import { AutoPilotActivityEvent, AirportFlightTweet, PublishedTweetLog } from "../types";

interface AutoPilotLiveFeedProps {
  isEnabled: boolean;
  isSyncing: boolean;
  events: AutoPilotActivityEvent[];
  scheduledFlightsCount: number;
  publishedCount: number;
  nextScheduledFlight?: AirportFlightTweet | null;
  onForceAutoScan: () => void;
  onSimulateMatchFinished: () => void;
  onToggleAutoPilot: () => void;
}

export const AutoPilotLiveFeed: React.FC<AutoPilotLiveFeedProps> = ({
  isEnabled,
  isSyncing,
  events,
  scheduledFlightsCount,
  publishedCount,
  nextScheduledFlight,
  onForceAutoScan,
  onSimulateMatchFinished,
  onToggleAutoPilot,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const getEventIcon = (type: AutoPilotActivityEvent["type"]) => {
    switch (type) {
      case "AI_PRONO_GENERATED":
        return <Sparkles className="w-3.5 h-3.5 text-amber-300" />;
      case "FLIGHT_SCHEDULED_H1":
        return <Clock className="w-3.5 h-3.5 text-indigo-400" />;
      case "TAKEOFF_H1":
        return <Plane className="w-3.5 h-3.5 text-emerald-400" />;
      case "MATCH_FINISHED":
        return <Trophy className="w-3.5 h-3.5 text-yellow-400" />;
      case "RECAP_GENERATED":
        return <Sparkles className="w-3.5 h-3.5 text-emerald-400" />;
      case "TAKEOFF_RECAP":
        return <Send className="w-3.5 h-3.5 text-emerald-400" />;
      case "SYNC_MATCHES":
        return <Radio className="w-3.5 h-3.5 text-sky-400" />;
      default:
        return <Activity className="w-3.5 h-3.5 text-slate-400" />;
    }
  };

  return (
    <div className="bg-[#16161a] border border-slate-800 rounded-2xl overflow-hidden shadow-2xl transition-all">
      {/* Top Main Status Bar */}
      <div className="p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 bg-gradient-to-r from-[#1c1c24] via-[#16161a] to-[#121c18]">
        {/* Status indicator & info */}
        <div className="flex items-center gap-3.5">
          <div
            className={`p-2.5 sm:p-3 rounded-2xl border flex items-center justify-center ${
              isEnabled
                ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-400 shadow-lg shadow-emerald-950/50"
                : "bg-amber-500/10 border-amber-500/30 text-amber-400"
            }`}
          >
            <Zap className={`w-5 h-5 ${isEnabled ? "animate-bounce" : ""}`} />
          </div>

          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span
                className={`text-xs font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full border ${
                  isEnabled
                    ? "bg-emerald-950/60 text-emerald-300 border-emerald-500/40 font-mono"
                    : "bg-amber-950/60 text-amber-300 border-amber-500/40 font-mono"
                }`}
              >
                {isEnabled ? "🟢 Mode 100% Autonome Actif (Zéro-Touch)" : "⏸️ Auto-Pilote en Pause"}
              </span>

              {isSyncing && (
                <span className="text-[10px] text-sky-400 bg-sky-950/40 px-2 py-0.5 rounded-full border border-sky-800/50 flex items-center gap-1 font-mono animate-pulse">
                  <RotateCw className="w-3 h-3 animate-spin" />
                  Scan API en cours...
                </span>
              )}
            </div>

            <p className="text-xs text-slate-300 mt-1 font-sans">
              {isEnabled
                ? "Le robot scanne les matchs, génère les pronos IA, programme l'Aéroport à H-1h et tweete les bilans dès le coup de sifflet final."
                : "Activez le mode autonome pour que tous les tweets soient générés et publiés automatiquement."}
            </p>
          </div>
        </div>

        {/* Quick Actions and Stats */}
        <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap shrink-0">
          <div className="hidden lg:flex items-center gap-3 bg-[#0d0d0f] px-3.5 py-2 rounded-xl border border-slate-800 text-xs">
            <div className="text-center">
              <span className="text-[10px] text-slate-500 block uppercase font-bold">Vols H-1h</span>
              <span className="font-mono font-bold text-indigo-400">{scheduledFlightsCount}</span>
            </div>
            <div className="w-[1px] h-6 bg-slate-800" />
            <div className="text-center">
              <span className="text-[10px] text-slate-500 block uppercase font-bold">Tweets Publiés</span>
              <span className="font-mono font-bold text-emerald-400">{publishedCount}</span>
            </div>
          </div>

          <button
            onClick={onForceAutoScan}
            disabled={isSyncing}
            title="Relancer un scan immédiat des matchs"
            className="flex items-center gap-1.5 px-3 py-2 bg-[#1c1c22] hover:bg-slate-800 text-slate-200 hover:text-white rounded-xl text-xs font-bold border border-slate-700 transition"
          >
            <RotateCw className={`w-3.5 h-3.5 ${isSyncing ? "animate-spin text-indigo-400" : "text-indigo-400"}`} />
            <span className="hidden sm:inline">Scanner</span>
          </button>

          <button
            onClick={onSimulateMatchFinished}
            title="Tester la détection d'un match terminé et l'envoi immédiat du tweet bilan"
            className="flex items-center gap-1.5 px-3 py-2 bg-gradient-to-r from-amber-600/30 to-emerald-600/30 hover:from-amber-600/40 hover:to-emerald-600/40 text-amber-200 rounded-xl text-xs font-bold border border-amber-500/40 transition shadow-sm"
          >
            <Trophy className="w-3.5 h-3.5 text-yellow-400" />
            <span>Tester Fin de Match (FT)</span>
          </button>

          <button
            onClick={() => setIsExpanded((prev) => !prev)}
            className="flex items-center gap-1 px-3 py-2 bg-[#1c1c22] hover:bg-slate-800 text-slate-300 hover:text-white rounded-xl text-xs font-semibold border border-slate-800 transition"
          >
            <span>Journal Live ({events.length})</span>
            {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Next Scheduled Highlight Bar */}
      {nextScheduledFlight && (
        <div className="px-5 py-2.5 bg-[#121216] border-t border-slate-800/80 flex items-center justify-between text-xs flex-wrap gap-2">
          <div className="flex items-center gap-2 text-slate-300">
            <Clock className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
            <span>Prochain décollage automatique :</span>
            <strong className="text-white font-bold">{nextScheduledFlight.matchTitle}</strong>
            <span className="text-[11px] font-mono text-indigo-300 bg-indigo-950/60 px-2 py-0.5 rounded border border-indigo-800/50">
              {nextScheduledFlight.scheduledTimeLabel || nextScheduledFlight.departureTime}
            </span>
          </div>

          <span className="text-[11px] text-emerald-400 font-mono font-bold flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Surveillance continue active
          </span>
        </div>
      )}

      {/* Expandable Live Events Activity Feed */}
      {isExpanded && (
        <div className="p-4 sm:p-5 border-t border-slate-800 bg-[#0d0d0f] space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5 text-emerald-400" />
              <span>Journal d'Activité en Temps Réel de l'Auto-Pilote</span>
            </h4>
            <span className="text-[10px] text-slate-500 font-mono">Derniers événements automatisés</span>
          </div>

          <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
            {events.length === 0 ? (
              <div className="text-center py-6 text-slate-500 text-xs font-sans">
                Le robot vient d'être initialisé. Les événements d'analyse, programmation et décollage s'afficheront ici en direct.
              </div>
            ) : (
              events.map((evt) => (
                <div
                  key={evt.id}
                  className="p-2.5 bg-[#16161a] border border-slate-800/80 rounded-xl flex items-start justify-between gap-3 text-xs"
                >
                  <div className="flex items-start gap-2.5 min-w-0">
                    <div className="p-1.5 bg-[#0d0d0f] rounded-lg border border-slate-800 mt-0.5">
                      {getEventIcon(evt.type)}
                    </div>
                    <div className="space-y-0.5 min-w-0">
                      <p className="font-bold text-white leading-snug">{evt.title}</p>
                      <p className="text-[11px] text-slate-400 leading-relaxed font-sans">{evt.description}</p>
                    </div>
                  </div>

                  <span className="text-[10px] font-mono text-slate-500 shrink-0 bg-[#0d0d0f] px-2 py-0.5 rounded border border-slate-800">
                    {evt.timestamp}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};
