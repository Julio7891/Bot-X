import React, { useState, useEffect } from "react";
import {
  Plane,
  PlaneTakeoff,
  PlaneLanding,
  CheckCircle2,
  Sparkles,
  ExternalLink,
  Trash2,
  RotateCcw,
  Zap,
  Radio,
  Clock,
  ArrowRight,
  ShieldCheck,
  AlertCircle,
  FlaskConical,
  Flame,
  FileCode,
  Download,
  Calendar,
  Timer,
  Play,
  Check,
  X,
  BellRing,
  Share2,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { AirportFlightTweet, PublishedTweetLog } from "../types";

interface AeroportViewProps {
  flights: AirportFlightTweet[];
  publishedLogs: PublishedTweetLog[];
  authToken: string;
  ct0: string;
  isAutoPilotActive: boolean;
  onToggleAutoPilot: () => void;
  onRemoveFlight: (flightId: string) => void;
  onPublishFlight: (flight: AirportFlightTweet) => Promise<any>;
  onScheduleFlight: (flightId: string, timestamp: number, label: string) => void;
  onCancelScheduleFlight: (flightId: string) => void;
  onNavigateToLabo: () => void;
  onSimulateMatchFinished?: () => void;
  isPostMatchAutoActive?: boolean;
  onTogglePostMatchAuto?: () => void;
}

export const AeroportView: React.FC<AeroportViewProps> = ({
  flights,
  publishedLogs,
  authToken,
  ct0,
  isAutoPilotActive,
  onToggleAutoPilot,
  onRemoveFlight,
  onPublishFlight,
  onScheduleFlight,
  onCancelScheduleFlight,
  onNavigateToLabo,
  onSimulateMatchFinished,
  isPostMatchAutoActive = true,
  onTogglePostMatchAuto,
}) => {
  const [flyingFlightId, setFlyingFlightId] = useState<string | null>(null);
  const [successAnimationFlight, setSuccessAnimationFlight] = useState<AirportFlightTweet | null>(null);
  const [lastLaunchedUrl, setLastLaunchedUrl] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<"runway" | "scheduled" | "history">("runway");

  // Modal / Scheduler state
  const [schedulingFlight, setSchedulingFlight] = useState<AirportFlightTweet | null>(null);
  const [customDateTime, setCustomDateTime] = useState<string>("");
  const [nowTimestamp, setNowTimestamp] = useState<number>(Date.now());

  // Real-time ticking timer for countdowns
  useEffect(() => {
    const timer = setInterval(() => {
      setNowTimestamp(Date.now());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleLaunchFlight = async (flight: AirportFlightTweet) => {
    setFlyingFlightId(flight.id);
    setSuccessAnimationFlight(flight);

    try {
      const result = await onPublishFlight(flight);
      if (result?.success && result?.tweetUrl) {
        setLastLaunchedUrl(result.tweetUrl);
      } else {
        const intent = `https://twitter.com/intent/tweet?text=${encodeURIComponent(flight.tweetText)}`;
        window.open(intent, "_blank", "noopener,noreferrer,width=600,height=650");
        setLastLaunchedUrl(intent);
      }
    } catch (err) {
      const intent = `https://twitter.com/intent/tweet?text=${encodeURIComponent(flight.tweetText)}`;
      window.open(intent, "_blank", "noopener,noreferrer,width=600,height=650");
      setLastLaunchedUrl(intent);
    } finally {
      setTimeout(() => {
        setFlyingFlightId(null);
      }, 2500);
    }
  };

  const handleOpenScheduleModal = (flight: AirportFlightTweet) => {
    setSchedulingFlight(flight);
    // Set default datetime to in 15 mins or departure time
    const in15m = new Date(Date.now() + 15 * 60000);
    const localIso = new Date(in15m.getTime() - in15m.getTimezoneOffset() * 60000)
      .toISOString()
      .slice(0, 16);
    setCustomDateTime(localIso);
  };

  const handleApplySchedulePreset = (minutesFromNow: number, labelPrefix: string) => {
    if (!schedulingFlight) return;
    const targetMs = Date.now() + minutesFromNow * 60000;
    const targetDate = new Date(targetMs);
    const label = `${labelPrefix} (${targetDate.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })})`;
    onScheduleFlight(schedulingFlight.id, targetMs, label);
    setSchedulingFlight(null);
  };

  const handleApplyCustomSchedule = () => {
    if (!schedulingFlight || !customDateTime) return;
    const targetDate = new Date(customDateTime);
    const targetMs = targetDate.getTime();
    if (isNaN(targetMs) || targetMs <= Date.now()) {
      alert("Veuillez sélectionner une date et heure future.");
      return;
    }
    const label = `Prévu le ${targetDate.toLocaleDateString("fr-FR", { day: "numeric", month: "short" })} à ${targetDate.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}`;
    onScheduleFlight(schedulingFlight.id, targetMs, label);
    setSchedulingFlight(null);
  };

  const handleOpenXOfficialScheduler = (flight: AirportFlightTweet) => {
    // Open X compose with tweet text
    const url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(flight.tweetText)}`;
    window.open(url, "_blank");
  };

  const formatCountdown = (targetMs?: number) => {
    if (!targetMs) return "Heure venue";
    const diff = targetMs - nowTimestamp;
    if (diff <= 0) return "🚀 Prêt au décollage imminent !";

    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((diff % (1000 * 60)) / 1000);

    if (hours > 0) {
      return `Décollage dans ${hours}h ${minutes}m ${seconds}s`;
    }
    return `Décollage dans ${minutes}m ${seconds}s`;
  };

  const readyFlights = flights.filter((f) => f.status === "READY" || f.status === "BOARDING");
  const scheduledFlights = flights.filter((f) => f.status === "SCHEDULED");

  return (
    <div className="space-y-6 relative">
      {/* Top Banner: Airport Terminal */}
      <div className="bg-gradient-to-r from-emerald-950/70 via-[#16161a] to-indigo-950/60 border border-emerald-900/40 rounded-2xl p-5 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative z-10">
          <div className="flex items-center gap-3.5">
            <div className="p-3 bg-emerald-600/20 text-emerald-400 rounded-2xl border border-emerald-500/30 shadow-inner">
              <PlaneTakeoff className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-xl font-black text-white tracking-tight">
                  L'Aéroport des Tweets (Terminal X)
                </h1>
                <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-mono">
                  Piste de Décollage 1-Clic & Programmation
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1 max-w-2xl leading-relaxed">
                Décollez en <strong>1 clic immédiat</strong> ou <strong>programmez l'envol</strong> à l'heure précise.
                Dès qu'un match est terminé, le score final est détecté et le tweet de bilan est propulsé automatiquement !
              </p>
            </div>
          </div>

          {/* Quick Dual Radar Toggles: Auto-Pilot & Post-Match Auto */}
          <div className="flex items-center gap-2 flex-wrap">
            {/* Post-Match Auto Toggle */}
            {onTogglePostMatchAuto && (
              <div className="flex items-center gap-2 bg-[#0d0d0f] px-3 py-2 rounded-xl border border-slate-800 text-xs">
                <div className="text-left">
                  <span className="text-[11px] font-bold text-white flex items-center gap-1">
                    🏁 Bilan Score Auto
                  </span>
                  <span className="text-[9px] text-slate-400">Poste dès que le match est FT</span>
                </div>
                <button
                  onClick={onTogglePostMatchAuto}
                  className={`px-2.5 py-1 text-[11px] font-bold rounded-lg transition cursor-pointer ${
                    isPostMatchAutoActive
                      ? "bg-indigo-600 text-white shadow-md shadow-indigo-950"
                      : "bg-slate-800 text-slate-400 hover:text-white"
                  }`}
                >
                  {isPostMatchAutoActive ? "ON ✓" : "OFF"}
                </button>
              </div>
            )}

            {/* Auto-Pilot H-1h */}
            <div className="flex items-center gap-2 bg-[#0d0d0f] px-3 py-2 rounded-xl border border-slate-800 text-xs">
              <Zap className={`w-3.5 h-3.5 ${isAutoPilotActive ? "text-amber-400 animate-pulse" : "text-slate-500"}`} />
              <div className="text-left">
                <span className="text-[11px] font-bold text-white block">Auto-Pilote H-1h</span>
                <span className="text-[9px] text-slate-400">Envol planifié</span>
              </div>
              <button
                onClick={onToggleAutoPilot}
                className={`px-2.5 py-1 text-[11px] font-bold rounded-lg transition cursor-pointer ${
                  isAutoPilotActive
                    ? "bg-emerald-600 text-white shadow-md shadow-emerald-950"
                    : "bg-slate-800 text-slate-400 hover:text-white"
                }`}
              >
                {isAutoPilotActive ? "ACTIF ✓" : "OFF"}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* LIVE POST-MATCH AUTOMATIC RADAR BANNER */}
      <div className="p-3.5 bg-[#16161a] border border-slate-800/80 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2.5">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
          <span className="font-semibold text-slate-200">
            📡 <strong>Radar API Live connecté</strong> : Détection automatique des scores finaux activée.
          </span>
        </div>

        {onSimulateMatchFinished && (
          <button
            onClick={onSimulateMatchFinished}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#1c1c22] hover:bg-slate-800 text-indigo-400 hover:text-indigo-300 rounded-lg text-xs font-bold border border-slate-700 transition cursor-pointer"
            title="Simule un score final pour tester l'envoi automatique du tweet de fin de match"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>🧪 Tester le Post-Match Auto (Score Final)</span>
          </button>
        )}
      </div>

      {/* FLYING TAKEOFF ANIMATION OVERLAY */}
      <AnimatePresence>
        {flyingFlightId && successAnimationFlight && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md"
          >
            <div className="bg-[#16161a] border border-emerald-500/50 rounded-3xl p-8 max-w-lg w-full text-center shadow-2xl shadow-emerald-950/80 relative overflow-hidden space-y-6">
              {/* Background Runway Grid Lights */}
              <div className="absolute inset-0 opacity-10 bg-[linear-gradient(to_right,#10b981_1px,transparent_1px),linear-gradient(to_bottom,#10b981_1px,transparent_1px)] bg-[size:24px_24px]" />

              {/* Animated Plane Rocket Taking Off */}
              <motion.div
                initial={{ x: -150, y: 50, scale: 0.8, rotate: -15 }}
                animate={{ x: 0, y: -20, scale: 1.2, rotate: 10 }}
                transition={{ duration: 1.2, ease: "easeOut" }}
                className="relative z-10 flex items-center justify-center"
              >
                <div className="w-24 h-24 rounded-3xl bg-gradient-to-tr from-emerald-600 to-indigo-600 p-1 shadow-2xl shadow-emerald-500/50 flex items-center justify-center">
                  <PlaneTakeoff className="w-14 h-14 text-white" />
                </div>
              </motion.div>

              {/* Jet Thruster Fire / Smoke Effect */}
              <div className="relative z-10 space-y-2">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-mono font-bold animate-pulse">
                  🚀 DÉCOLLAGE EN COURS · VOL #{successAnimationFlight.flightCode}
                </div>
                <h2 className="text-2xl font-black text-white">
                  Tweet en Plein Vol vers X !
                </h2>
                <p className="text-xs text-slate-300 max-w-sm mx-auto leading-relaxed">
                  Les bagages (cotes, analyse, hashtags) ont été embarqués avec succès.
                  Le tweet atterrit directement sur votre fil X (Twitter).
                </p>
              </div>

              {/* Boarding Pass Preview */}
              <div className="p-3 bg-[#0d0d0f] rounded-xl border border-slate-800 text-left text-xs font-mono text-slate-300 space-y-1 relative z-10">
                <div className="flex items-center justify-between text-[10px] text-slate-400">
                  <span>DESTINATION : X.COM</span>
                  <span>MATCH : {successAnimationFlight.matchTitle}</span>
                </div>
                <p className="text-white font-sans text-xs line-clamp-2 italic">
                  "{successAnimationFlight.tweetText}"
                </p>
              </div>

              {/* Direct Open Button */}
              {lastLaunchedUrl && (
                <div className="pt-2 relative z-10">
                  <a
                    href={lastLaunchedUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center justify-center gap-2 w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs shadow-lg transition"
                  >
                    <span>👉 Voir mon Tweet en Direct sur X</span>
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* SCHEDULING MODAL */}
      <AnimatePresence>
        {schedulingFlight && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[#16161a] border border-indigo-500/40 rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-5 relative text-slate-200"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 bg-indigo-600/20 text-indigo-400 rounded-xl border border-indigo-500/30">
                    <Calendar className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white">Programmer l'Envol du Tweet</h3>
                    <p className="text-[11px] text-slate-400 font-mono">Vol #{schedulingFlight.flightCode}</p>
                  </div>
                </div>
                <button
                  onClick={() => setSchedulingFlight(null)}
                  className="p-1 text-slate-500 hover:text-white rounded-lg transition"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Match and Tweet Text Recall */}
              <div className="p-3 bg-[#0d0d0f] rounded-xl border border-slate-800 text-xs space-y-1">
                <div className="text-[10px] text-indigo-400 font-bold">MATCH CIBLÉ</div>
                <div className="font-semibold text-white">{schedulingFlight.matchTitle}</div>
                <div className="text-slate-400 line-clamp-2 italic text-[11px] mt-1">
                  "{schedulingFlight.tweetText}"
                </div>
              </div>

              {/* Quick Presets */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-300 block">
                  Choix rapide de programmation :
                </label>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => handleApplySchedulePreset(15, "Dans 15 min")}
                    className="p-2.5 bg-[#1c1c22] hover:bg-indigo-950/60 hover:border-indigo-500/60 border border-slate-800 rounded-xl font-semibold text-left transition flex items-center justify-between cursor-pointer"
                  >
                    <span>⚡ Dans 15 min</span>
                    <span className="text-[10px] text-slate-500">+15m</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleApplySchedulePreset(30, "Dans 30 min")}
                    className="p-2.5 bg-[#1c1c22] hover:bg-indigo-950/60 hover:border-indigo-500/60 border border-slate-800 rounded-xl font-semibold text-left transition flex items-center justify-between cursor-pointer"
                  >
                    <span>⏱️ Dans 30 min</span>
                    <span className="text-[10px] text-slate-500">+30m</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleApplySchedulePreset(60, "Dans 1 heure")}
                    className="p-2.5 bg-[#1c1c22] hover:bg-indigo-950/60 hover:border-indigo-500/60 border border-slate-800 rounded-xl font-semibold text-left transition flex items-center justify-between cursor-pointer"
                  >
                    <span>🕒 Dans 1 heure</span>
                    <span className="text-[10px] text-slate-500">+1h</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleApplySchedulePreset(120, "Dans 2 heures")}
                    className="p-2.5 bg-[#1c1c22] hover:bg-indigo-950/60 hover:border-indigo-500/60 border border-slate-800 rounded-xl font-semibold text-left transition flex items-center justify-between cursor-pointer"
                  >
                    <span>⏳ Dans 2 heures</span>
                    <span className="text-[10px] text-slate-500">+2h</span>
                  </button>
                </div>
              </div>

              {/* Custom Date / Time Picker */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-300 block">
                  Ou choisir une Date & Heure précise :
                </label>
                <input
                  type="datetime-local"
                  value={customDateTime}
                  onChange={(e) => setCustomDateTime(e.target.value)}
                  className="w-full bg-[#0d0d0f] border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              {/* Action Buttons */}
              <div className="space-y-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={handleApplyCustomSchedule}
                  className="w-full py-2.5 px-4 bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white font-bold rounded-xl text-xs shadow-lg shadow-indigo-950/50 flex items-center justify-center gap-2 transition cursor-pointer"
                >
                  <Timer className="w-4 h-4 text-amber-300" />
                  <span>⏰ Valider la Programmation Automatique</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    handleOpenXOfficialScheduler(schedulingFlight);
                    setSchedulingFlight(null);
                  }}
                  className="w-full py-2 px-4 bg-[#1c1c22] hover:bg-slate-800 text-slate-300 hover:text-white rounded-xl text-xs font-semibold border border-slate-700 flex items-center justify-center gap-1.5 transition cursor-pointer"
                >
                  <ExternalLink className="w-3.5 h-3.5 text-indigo-400" />
                  <span>📅 Programmer directement sur l'outil officiel X</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Runway Status / Tabs Navigation */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-2 bg-[#16161a] p-1 rounded-xl border border-slate-800 text-xs">
          <button
            onClick={() => setActiveTab("runway")}
            className={`px-4 py-2 rounded-lg font-bold flex items-center gap-2 transition cursor-pointer ${
              activeTab === "runway"
                ? "bg-indigo-600 text-white shadow-md"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            <PlaneTakeoff className="w-4 h-4" />
            <span>Piste de Décollage ({readyFlights.length})</span>
          </button>

          <button
            onClick={() => setActiveTab("scheduled")}
            className={`px-4 py-2 rounded-lg font-bold flex items-center gap-2 transition cursor-pointer ${
              activeTab === "scheduled"
                ? "bg-amber-600 text-white shadow-md"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            <Timer className="w-4 h-4" />
            <span>Vols Programmés ({scheduledFlights.length})</span>
            {scheduledFlights.length > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-white/20 text-[10px]">
                {scheduledFlights.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab("history")}
            className={`px-4 py-2 rounded-lg font-bold flex items-center gap-2 transition cursor-pointer ${
              activeTab === "history"
                ? "bg-emerald-600 text-white shadow-md"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            <PlaneLanding className="w-4 h-4" />
            <span>Vols Atterris / Publiés ({publishedLogs.length})</span>
          </button>
        </div>

        <button
          onClick={onNavigateToLabo}
          className="flex items-center gap-2 px-4 py-2 bg-[#1c1c22] hover:bg-slate-800 text-indigo-400 hover:text-indigo-300 rounded-xl border border-slate-700 text-xs font-bold transition shadow-sm cursor-pointer"
        >
          <FlaskConical className="w-3.5 h-3.5" />
          <span>+ Préparer un nouveau tweet au Labo</span>
        </button>
      </div>

      {/* TAB 1 : RUNWAY (PISTE DE DÉCOLLAGE IMMÉDIATE) */}
      {activeTab === "runway" && (
        <div className="space-y-4">
          {readyFlights.length === 0 ? (
            /* Empty Runway State */
            <div className="bg-[#16161a] border border-slate-800 rounded-2xl p-10 text-center space-y-4 shadow-xl">
              <div className="w-16 h-16 rounded-2xl bg-indigo-600/10 text-indigo-400 border border-indigo-500/20 flex items-center justify-center mx-auto">
                <Plane className="w-8 h-8 opacity-60" />
              </div>
              <div className="space-y-1">
                <h3 className="text-base font-bold text-white">Aucun tweet en attente sur la piste</h3>
                <p className="text-xs text-slate-400 max-w-md mx-auto">
                  Rendez-vous dans <strong>Le Labo</strong> pour choisir un match, générer le tweet avec l'IA Gemini
                  et enregistrer ses bagages !
                </p>
              </div>
              <button
                onClick={onNavigateToLabo}
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs shadow-lg shadow-indigo-950/50 transition cursor-pointer"
              >
                <FlaskConical className="w-4 h-4" />
                <span>Ouvrir Le Labo & Préparer un Tweet</span>
              </button>
            </div>
          ) : (
            /* List of Ready Flight Boarding Passes */
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {readyFlights.map((flight) => (
                <div
                  key={flight.id}
                  className="bg-[#16161a] border border-slate-800 hover:border-slate-700 rounded-2xl p-5 shadow-xl space-y-4 relative overflow-hidden transition group"
                >
                  {/* Top Runway Header of the Ticket */}
                  <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 bg-emerald-500/10 text-emerald-400 rounded-lg border border-emerald-500/20">
                        <PlaneTakeoff className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="font-mono text-xs font-black text-white">
                          VOL #{flight.flightCode}
                        </span>
                        <span className="text-[10px] text-slate-400 ml-2">
                          Départ : {flight.departureTime}
                        </span>
                      </div>
                    </div>

                    <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                      🟢 Prêt au Décollage
                    </span>
                  </div>

                  {/* Baggage Overview Pills */}
                  <div className="grid grid-cols-3 gap-2 text-xs">
                    <div className="p-2 bg-[#0d0d0f] rounded-lg border border-slate-800">
                      <span className="text-[9px] text-slate-400 font-bold block">🧳 MATCH</span>
                      <p className="font-semibold text-slate-200 truncate text-[11px]">
                        {flight.baggages.match}
                      </p>
                    </div>
                    <div className="p-2 bg-[#0d0d0f] rounded-lg border border-slate-800">
                      <span className="text-[9px] text-slate-400 font-bold block">🎯 PRONO & COTE</span>
                      <p className="font-semibold text-emerald-400 truncate text-[11px]">
                        @{flight.baggages.odd || "1.80"}
                      </p>
                    </div>
                    <div className="p-2 bg-[#0d0d0f] rounded-lg border border-slate-800">
                      <span className="text-[9px] text-slate-400 font-bold block">✨ STYLE</span>
                      <p className="font-semibold text-indigo-300 truncate text-[11px]">
                        {flight.baggages.style}
                      </p>
                    </div>
                  </div>

                  {/* Tweet Content Display Box */}
                  <div className="p-3.5 bg-[#0d0d0f] rounded-xl border border-slate-800/80 text-xs text-slate-200 leading-relaxed font-sans whitespace-pre-wrap">
                    {flight.tweetText}
                  </div>

                  {/* Action Row: Programmer + 1-Click Launch */}
                  <div className="flex items-center justify-between gap-2 pt-1 flex-wrap">
                    <button
                      onClick={() => onRemoveFlight(flight.id)}
                      className="p-2.5 text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-xl border border-slate-800 transition"
                      title="Supprimer de la piste"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => handleOpenScheduleModal(flight)}
                      className="py-2.5 px-3 bg-[#1c1c22] hover:bg-slate-800 text-amber-300 hover:text-amber-200 border border-slate-700 font-bold rounded-xl text-xs flex items-center gap-1.5 transition cursor-pointer shadow-sm"
                    >
                      <Timer className="w-3.5 h-3.5" />
                      <span>⏰ Programmer l'Envol</span>
                    </button>

                    <button
                      onClick={() => handleLaunchFlight(flight)}
                      disabled={Boolean(flyingFlightId)}
                      className="flex-1 py-2.5 px-4 bg-gradient-to-r from-emerald-600 via-emerald-500 to-indigo-600 hover:from-emerald-500 hover:to-indigo-500 active:scale-[0.99] text-white font-black rounded-xl shadow-xl shadow-emerald-950/50 flex items-center justify-center gap-2 text-xs transition cursor-pointer min-w-[170px]"
                    >
                      <PlaneTakeoff className="w-4 h-4 text-amber-300 animate-bounce" />
                      <span>🚀 DÉCOLLAGE EN 1 CLIC</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 2 : SCHEDULED (VOLS PROGRAMMÉS) */}
      {activeTab === "scheduled" && (
        <div className="space-y-4">
          {scheduledFlights.length === 0 ? (
            <div className="bg-[#16161a] border border-slate-800 rounded-2xl p-10 text-center space-y-4 shadow-xl">
              <div className="w-16 h-16 rounded-2xl bg-amber-600/10 text-amber-400 border border-amber-500/20 flex items-center justify-center mx-auto">
                <Timer className="w-8 h-8 opacity-60" />
              </div>
              <div className="space-y-1">
                <h3 className="text-base font-bold text-white">Aucun vol programmé</h3>
                <p className="text-xs text-slate-400 max-w-md mx-auto">
                  Dans la piste de décollage, cliquez sur <strong>« ⏰ Programmer l'Envol »</strong> pour définir l'heure exacte de publication sur votre compte !
                </p>
              </div>
              <button
                onClick={() => setActiveTab("runway")}
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-xl text-xs shadow-lg shadow-amber-950/50 transition cursor-pointer"
              >
                <PlaneTakeoff className="w-4 h-4" />
                <span>Voir les Vols sur la Piste</span>
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {scheduledFlights.map((flight) => (
                <div
                  key={flight.id}
                  className="bg-[#16161a] border border-amber-500/40 hover:border-amber-500/70 rounded-2xl p-5 shadow-xl space-y-4 relative overflow-hidden transition"
                >
                  {/* Scheduled Header */}
                  <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 bg-amber-500/10 text-amber-400 rounded-lg border border-amber-500/20 animate-pulse">
                        <Timer className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="font-mono text-xs font-black text-white">
                          VOL PROGRAMMÉ #{flight.flightCode}
                        </span>
                        <span className="text-[10px] text-amber-300 ml-2 font-semibold">
                          {flight.scheduledTimeLabel || "Planifié"}
                        </span>
                      </div>
                    </div>

                    <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      🟡 En Attente
                    </span>
                  </div>

                  {/* Countdown Timer Display */}
                  <div className="p-3 bg-gradient-to-r from-amber-950/40 to-[#0d0d0f] rounded-xl border border-amber-500/30 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-amber-400 animate-spin" />
                      <span className="font-bold text-amber-200 font-mono">
                        {formatCountdown(flight.scheduledTimestamp)}
                      </span>
                    </div>
                    <span className="text-[10px] text-slate-400">Auto-Envol activé</span>
                  </div>

                  {/* Tweet Content */}
                  <div className="p-3.5 bg-[#0d0d0f] rounded-xl border border-slate-800/80 text-xs text-slate-200 leading-relaxed font-sans whitespace-pre-wrap">
                    {flight.tweetText}
                  </div>

                  {/* Actions: Modify, Cancel or Launch Now */}
                  <div className="flex items-center justify-between gap-2 pt-1 flex-wrap">
                    <button
                      onClick={() => onCancelScheduleFlight(flight.id)}
                      className="px-3 py-2 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-xl border border-slate-800 text-xs font-semibold transition cursor-pointer"
                    >
                      Annuler la programmation
                    </button>

                    <button
                      onClick={() => handleOpenScheduleModal(flight)}
                      className="px-3 py-2 bg-[#1c1c22] hover:bg-slate-800 text-slate-200 rounded-xl border border-slate-700 text-xs font-semibold transition cursor-pointer"
                    >
                      Modifier l'heure
                    </button>

                    <button
                      onClick={() => handleLaunchFlight(flight)}
                      disabled={Boolean(flyingFlightId)}
                      className="flex-1 py-2 px-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition cursor-pointer"
                    >
                      <PlaneTakeoff className="w-3.5 h-3.5" />
                      <span>Décoller Immédiatement</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 3 : HISTORY (VOLS ATTERRIS & PUBLIÉS) */}
      {activeTab === "history" && (
        <div className="bg-[#16161a] border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <PlaneLanding className="w-4 h-4 text-emerald-400" />
              <span>Journal de Bord des Vols Atterris sur X ({publishedLogs.length})</span>
            </h3>
          </div>

          {publishedLogs.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-400">
              Aucun vol n'a encore été enregistré. Lancez votre premier tweet depuis la piste de décollage !
            </div>
          ) : (
            <div className="space-y-3">
              {publishedLogs.map((log) => (
                <div
                  key={log.id}
                  className="p-4 bg-[#1c1c22] rounded-xl border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs"
                >
                  <div className="space-y-1 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white">{log.matchTitle}</span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {log.publishedAt}
                      </span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                        Atterri ✓
                      </span>
                    </div>
                    <p className="text-slate-300 line-clamp-2 italic">{log.tweetText}</p>
                  </div>

                  {log.tweetUrl && (
                    <a
                      href={log.tweetUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="px-3 py-1.5 bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 font-bold rounded-lg border border-indigo-500/30 flex items-center gap-1.5 whitespace-nowrap transition"
                    >
                      <span>Vérifier sur X.com</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
