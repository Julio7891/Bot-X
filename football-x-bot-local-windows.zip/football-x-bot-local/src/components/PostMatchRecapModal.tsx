import React, { useState } from "react";
import { X, Trophy, CheckCircle, XCircle, Wand2, Send, AlertCircle, TrendingUp } from "lucide-react";
import { FootballMatch, RecapResult } from "../types";
import { TweetPreviewCard } from "./TweetPreviewCard";

interface PostMatchRecapModalProps {
  match: FootballMatch;
  isOpen: boolean;
  onClose: () => void;
  onSaveRecap: (matchId: string, recap: RecapResult) => void;
  onSendToSimulator: (tweetText: string) => void;
}

export const PostMatchRecapModal: React.FC<PostMatchRecapModalProps> = ({
  match,
  isOpen,
  onClose,
  onSaveRecap,
  onSendToSimulator,
}) => {
  const [homeScore, setHomeScore] = useState<number>(match.actualScore?.home ?? 2);
  const [awayScore, setAwayScore] = useState<number>(match.actualScore?.away ?? 1);
  const [scorers, setScorers] = useState("");
  const [wasWon, setWasWon] = useState<boolean>(true);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedRecap, setGeneratedRecap] = useState<RecapResult | null>(
    match.recapData || null
  );
  const [editedTweetText, setEditedTweetText] = useState(
    match.recapData?.tweetText || ""
  );
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleGenerate = async () => {
    setIsGenerating(true);
    setErrorMsg(null);
    try {
      const finalScoreStr = `${homeScore} - ${awayScore}`;
      const res = await fetch("/api/gemini/generate-recap", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          homeTeam: match.homeTeam,
          awayTeam: match.awayTeam,
          league: match.league,
          finalScore: finalScoreStr,
          scorers,
          initialPrediction: match.pronoData?.predictionType || "Prono initial",
          wasPredictionWon: wasWon,
          keyMatchFacts: `Score final ${finalScoreStr}`,
        }),
      });

      const json = await res.json();
      if (json.data) {
        const recap: RecapResult = {
          id: "recap-" + Date.now(),
          matchId: match.id,
          tweetText: json.data.tweetText,
          summary: json.data.summary || "Bilan de match",
          statusEmoji: json.data.statusEmoji || (wasWon ? "✅" : "❌"),
          roiImpact: json.data.roiImpact || (wasWon ? "+0.85u" : "-1.00u"),
          isWon: wasWon,
          finalScore: finalScoreStr,
          generatedAt: new Date().toISOString(),
          status: "SCHEDULED",
        };
        setGeneratedRecap(recap);
        setEditedTweetText(recap.tweetText);
      } else if (json.fallbackTweet) {
        const recap: RecapResult = {
          id: "recap-" + Date.now(),
          matchId: match.id,
          tweetText: json.fallbackTweet,
          summary: "Bilan de fin de match",
          statusEmoji: wasWon ? "✅" : "❌",
          roiImpact: wasWon ? "+0.85u" : "-1.00u",
          isWon: wasWon,
          finalScore: finalScoreStr,
          generatedAt: new Date().toISOString(),
          status: "SCHEDULED",
        };
        setGeneratedRecap(recap);
        setEditedTweetText(recap.tweetText);
      } else {
        throw new Error(json.error || "Erreur de génération");
      }
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || "Erreur lors de la génération du récap");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSave = () => {
    if (!generatedRecap) return;
    const finalRecap: RecapResult = {
      ...generatedRecap,
      tweetText: editedTweetText,
      finalScore: `${homeScore} - ${awayScore}`,
      isWon: wasWon,
    };
    onSaveRecap(match.id, finalRecap);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#16161a] border border-slate-800 rounded-2xl w-full max-w-4xl shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 bg-[#16161a] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-lg border border-emerald-500/20">
              <Trophy className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                Générateur de Récapitulatif Fin de Match (Coup de Sifflet Final)
              </h2>
              <p className="text-xs text-slate-400">
                {match.homeTeam} vs {match.awayTeam} · Bilan du Prono & Résultat
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 max-h-[78vh] overflow-y-auto">
          {/* Left: Score Input & Status */}
          <div className="lg:col-span-5 space-y-4">
            {/* Score input box */}
            <div className="p-4 bg-[#1c1c22] rounded-xl border border-slate-800 space-y-3">
              <div className="text-xs font-semibold text-slate-300">Score Final du Match</div>
              <div className="flex items-center justify-center gap-4 py-2">
                <div className="text-center">
                  <div className="text-xs font-bold text-slate-300 mb-1 truncate max-w-[100px]">{match.homeTeam}</div>
                  <input
                    type="number"
                    min="0"
                    max="20"
                    value={homeScore}
                    onChange={(e) => setHomeScore(parseInt(e.target.value) || 0)}
                    className="w-16 h-14 text-2xl font-mono font-bold text-center bg-[#0d0d0f] border border-slate-750 border-slate-800 rounded-xl text-white focus:border-emerald-500 focus:outline-none"
                  />
                </div>
                <div className="text-xl font-bold text-slate-500 pt-5">-</div>
                <div className="text-center">
                  <div className="text-xs font-bold text-slate-300 mb-1 truncate max-w-[100px]">{match.awayTeam}</div>
                  <input
                    type="number"
                    min="0"
                    max="20"
                    value={awayScore}
                    onChange={(e) => setAwayScore(parseInt(e.target.value) || 0)}
                    className="w-16 h-14 text-2xl font-mono font-bold text-center bg-[#0d0d0f] border border-slate-750 border-slate-800 rounded-xl text-white focus:border-emerald-500 focus:outline-none"
                  />
                </div>
              </div>
            </div>

            {/* Prono Result Toggle */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">
                Résultat du Pronostic initial
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setWasWon(true)}
                  className={`p-3 rounded-xl border flex items-center justify-center gap-2 transition ${
                    wasWon
                      ? "bg-emerald-950/40 border-emerald-500 text-emerald-300 ring-1 ring-emerald-500/50"
                      : "bg-[#1c1c22] border-slate-800 text-slate-400 hover:text-slate-200"
                  }`}
                >
                  <CheckCircle className="w-4 h-4 text-emerald-400" />
                  <span className="text-xs font-bold">Prono GAGNÉ ✅</span>
                </button>
                <button
                  type="button"
                  onClick={() => setWasWon(false)}
                  className={`p-3 rounded-xl border flex items-center justify-center gap-2 transition ${
                    !wasWon
                      ? "bg-rose-950/40 border-rose-500 text-rose-300 ring-1 ring-rose-500/50"
                      : "bg-[#1c1c22] border-slate-800 text-slate-400 hover:text-slate-200"
                  }`}
                >
                  <XCircle className="w-4 h-4 text-rose-400" />
                  <span className="text-xs font-bold">Prono PERDU ❌</span>
                </button>
              </div>
            </div>

            {/* Match notes / details */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">
                Faits de match / Dynamique collective (Optionnel)
              </label>
              <input
                type="text"
                value={scorers}
                onChange={(e) => setScorers(e.target.value)}
                placeholder="Ex: Domination territoriale nette, match très rythmé..."
                className="w-full bg-[#0d0d0f] border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-emerald-500"
              />
            </div>

            {/* Generate Button */}
            <button
              onClick={handleGenerate}
              disabled={isGenerating}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl shadow-lg shadow-emerald-950/40 transition"
            >
              {isGenerating ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Rédaction du Récapitulatif...</span>
                </>
              ) : (
                <>
                  <Wand2 className="w-4 h-4" />
                  <span>Générer le Tweet Récap avec IA</span>
                </>
              )}
            </button>

            {errorMsg && (
              <div className="p-3 bg-rose-950/30 border border-rose-900/50 rounded-xl text-rose-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}
          </div>

          {/* Right: Preview & Editable */}
          <div className="lg:col-span-7 space-y-4">
            <div className="space-y-2">
              <label className="text-xs font-semibold text-slate-300">
                Texte du Récapitulatif de Fin de Match
              </label>
              <textarea
                value={editedTweetText}
                onChange={(e) => setEditedTweetText(e.target.value)}
                placeholder="Cliquez sur 'Générer le Tweet Récap'..."
                rows={5}
                className="w-full bg-[#0d0d0f] border border-slate-800 rounded-xl p-3 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-emerald-500 font-sans leading-relaxed resize-none shadow-inner"
              />
            </div>

            {editedTweetText ? (
              <TweetPreviewCard
                tweetText={editedTweetText}
                title="Aperçu Récapitulatif sur X"
                badgeText={wasWon ? "✅ Prono Validé" : "❌ Prono Manqué"}
                badgeColor={
                  wasWon
                    ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                    : "bg-rose-500/10 text-rose-400 border-rose-500/20"
                }
              />
            ) : (
              <div className="p-8 border border-dashed border-slate-800 rounded-2xl text-center text-slate-500 text-xs bg-[#1c1c22]">
                <Trophy className="w-8 h-8 mx-auto mb-2 text-slate-600" />
                <span>L'aperçu du récap apparaîtra ici après la génération.</span>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-800 bg-[#16161a] flex items-center justify-between">
          <button
            onClick={() => {
              if (editedTweetText) {
                onSendToSimulator(editedTweetText);
                onClose();
              }
            }}
            disabled={!editedTweetText}
            className="px-3 py-2 text-xs font-medium text-emerald-300 bg-emerald-950/40 hover:bg-emerald-900/50 border border-emerald-800/80 disabled:opacity-40 rounded-xl transition flex items-center gap-1.5"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Tester dans le Simulateur</span>
          </button>

          <button
            onClick={handleSave}
            disabled={!editedTweetText}
            className="px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 rounded-xl shadow-lg shadow-emerald-950/40 transition flex items-center gap-1.5"
          >
            <CheckCircle className="w-4 h-4" />
            <span>Enregistrer & Valider le Bilan</span>
          </button>
        </div>
      </div>
    </div>
  );
};
