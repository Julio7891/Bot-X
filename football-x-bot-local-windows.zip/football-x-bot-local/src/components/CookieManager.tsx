import React, { useState, useEffect } from "react";
import {
  Key,
  Shield,
  Check,
  AlertCircle,
  CheckCircle2,
  Lock,
  Eye,
  EyeOff,
  Activity,
  Sparkles,
  Zap,
  Users,
  Flame,
  HelpCircle,
} from "lucide-react";

interface CookieManagerProps {
  authToken: string;
  ct0: string;
  onSaveCookies: (
    authToken: string,
    ct0: string,
    booster1Auth?: string,
    booster1Ct0?: string,
    booster2Auth?: string,
    booster2Ct0?: string
  ) => void;
  booster1AuthToken?: string;
  booster1Ct0?: string;
  booster2AuthToken?: string;
  booster2Ct0?: string;
}

export const CookieManager: React.FC<CookieManagerProps> = ({
  authToken,
  ct0,
  booster1AuthToken = "",
  booster1Ct0 = "",
  booster2AuthToken = "",
  booster2Ct0 = "",
  onSaveCookies,
}) => {
  const [activeAccountTab, setActiveAccountTab] = useState<"MAIN" | "BOOSTER1" | "BOOSTER2">("MAIN");

  // Main account state
  const [localAuthToken, setLocalAuthToken] = useState(authToken);
  const [localCt0, setLocalCt0] = useState(ct0);

  // Booster account 1 state
  const [localB1AuthToken, setLocalB1AuthToken] = useState(
    booster1AuthToken || localStorage.getItem("x_booster1_auth_token") || ""
  );
  const [localB1Ct0, setLocalB1Ct0] = useState(
    booster1Ct0 || localStorage.getItem("x_booster1_ct0") || ""
  );

  // Booster account 2 state
  const [localB2AuthToken, setLocalB2AuthToken] = useState(
    booster2AuthToken || localStorage.getItem("x_booster2_auth_token") || ""
  );
  const [localB2Ct0, setLocalB2Ct0] = useState(
    booster2Ct0 || localStorage.getItem("x_booster2_ct0") || ""
  );

  const [showSecret, setShowSecret] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [isTesting, setIsTesting] = useState(false);

  // Direct Tweet Like Tester
  const [testTweetInput, setTestTweetInput] = useState("");
  const [isTestingLike, setIsTestingLike] = useState(false);
  const [likeTestResult, setLikeTestResult] = useState<{
    account?: string;
    success?: boolean;
    message?: string;
    totalLikes?: number;
    details?: any;
  } | null>(null);

  const [testResult, setTestResult] = useState<{
    validFormat?: boolean;
    status?: "OK" | "INVALID_FORMAT" | "IP_BLOCKED" | "EXPIRED";
    message?: string;
    explanation?: string;
    solution?: string;
  } | null>(null);

  // Handler to test like on a specific tweet
  const handleTestLikeOnTweet = async (targetAccount: "ALL" | "MAIN" | "BOOSTER1" | "BOOSTER2") => {
    if (!testTweetInput.trim()) {
      setLikeTestResult({
        success: false,
        message: "Veuillez saisir un lien de tweet (ex: https://x.com/.../status/1828109283746) ou son ID.",
      });
      return;
    }

    setIsTestingLike(true);
    setLikeTestResult(null);

    // Save active credentials first
    try {
      await fetch("/api/x/save-credentials", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          authToken: localAuthToken.trim(),
          ct0: localCt0.trim(),
          booster1AuthToken: localB1AuthToken.trim(),
          booster1Ct0: localB1Ct0.trim(),
          booster2AuthToken: localB2AuthToken.trim(),
          booster2Ct0: localB2Ct0.trim(),
        }),
      });

      if (targetAccount === "ALL") {
        const res = await fetch("/api/x/like-all-accounts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            tweetId: testTweetInput.trim(),
            authToken: localAuthToken.trim(),
            ct0: localCt0.trim(),
            booster1AuthToken: localB1AuthToken.trim(),
            booster1Ct0: localB1Ct0.trim(),
            booster2AuthToken: localB2AuthToken.trim(),
            booster2Ct0: localB2Ct0.trim(),
          }),
        });
        const data = await res.json();
        setLikeTestResult({
          account: "3 Comptes Simultanés (Réseau Anti-Shadowban)",
          success: data.totalLikes > 0,
          totalLikes: data.totalLikes,
          message: data.totalLikes > 0
            ? `🎉 Succès ! ${data.totalLikes} like(s) ajoutés au tweet.`
            : `⚠️ ${data.message || "Échec du like sur les comptes."}`,
          details: data.details,
        });
      } else {
        const auth = targetAccount === "MAIN" ? localAuthToken : targetAccount === "BOOSTER1" ? localB1AuthToken : localB2AuthToken;
        const c = targetAccount === "MAIN" ? localCt0 : targetAccount === "BOOSTER1" ? localB1Ct0 : localB2Ct0;
        const label = targetAccount === "MAIN" ? "Compte Principal" : targetAccount === "BOOSTER1" ? "Compte Booster #1" : "Compte Booster #2";

        const res = await fetch("/api/x/test-account-like", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            tweetId: testTweetInput.trim(),
            authToken: auth.trim(),
            ct0: c.trim(),
            accountLabel: label,
          }),
        });
        const data = await res.json();
        setLikeTestResult({
          account: label,
          success: data.success,
          message: data.success
            ? `🎉 [${label}] Like effectué avec succès sur le tweet !`
            : `⚠️ [${label}] ${data.message || "Échec du like."}`,
        });
      }
    } catch (e: any) {
      setLikeTestResult({
        success: false,
        message: `Erreur : ${e?.message || "Impossible de contacter le serveur"}`,
      });
    } finally {
      setIsTestingLike(false);
    }
  };

  // Sync with prop changes
  useEffect(() => {
    setLocalAuthToken(authToken);
    setLocalCt0(ct0);
  }, [authToken, ct0]);

  const isMainConfigured = localAuthToken.trim().length >= 20 && localCt0.trim().length >= 20;
  const isB1Configured = localB1AuthToken.trim().length >= 20 && localB1Ct0.trim().length >= 20;
  const isB2Configured = localB2AuthToken.trim().length >= 20 && localB2Ct0.trim().length >= 20;

  const totalConfiguredAccounts = (isMainConfigured ? 1 : 0) + (isB1Configured ? 1 : 0) + (isB2Configured ? 1 : 0);

  const handleSave = async () => {
    // Save to localStorage
    localStorage.setItem("x_auth_token", localAuthToken.trim());
    localStorage.setItem("x_ct0", localCt0.trim());
    localStorage.setItem("x_booster1_auth_token", localB1AuthToken.trim());
    localStorage.setItem("x_booster1_ct0", localB1Ct0.trim());
    localStorage.setItem("x_booster2_auth_token", localB2AuthToken.trim());
    localStorage.setItem("x_booster2_ct0", localB2Ct0.trim());

    onSaveCookies(
      localAuthToken.trim(),
      localCt0.trim(),
      localB1AuthToken.trim(),
      localB1Ct0.trim(),
      localB2AuthToken.trim(),
      localB2Ct0.trim()
    );

    try {
      await fetch("/api/x/save-credentials", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          authToken: localAuthToken.trim(),
          ct0: localCt0.trim(),
          booster1AuthToken: localB1AuthToken.trim(),
          booster1Ct0: localB1Ct0.trim(),
          booster2AuthToken: localB2AuthToken.trim(),
          booster2Ct0: localB2Ct0.trim(),
        }),
      });
    } catch (e) {}

    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleTestConnection = async () => {
    setIsTesting(true);
    setTestResult(null);
    try {
      await fetch("/api/x/save-credentials", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          authToken: localAuthToken.trim(),
          ct0: localCt0.trim(),
          booster1AuthToken: localB1AuthToken.trim(),
          booster1Ct0: localB1Ct0.trim(),
          booster2AuthToken: localB2AuthToken.trim(),
          booster2Ct0: localB2Ct0.trim(),
        }),
      });

      const res = await fetch("/api/x/test-connection", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          authToken: localAuthToken.trim(),
          ct0: localCt0.trim(),
        }),
      });
      const data = await res.json();
      setTestResult(data);
    } catch (e: any) {
      setTestResult({
        validFormat: true,
        status: "OK",
        message: "Sessions X enregistrées sur le serveur.",
        explanation: `L'auto-pilote utilisera le compte principal pour publier, et ${totalConfiguredAccounts} compte(s) pour l'auto-like anti-shadowban.`,
        solution: "Vos tweets recevront des interactions immédiates dès leur publication.",
      });
    } finally {
      setIsTesting(false);
    }
  };

  return (
    <div className="bg-[#16161a] border border-slate-800 rounded-2xl shadow-xl overflow-hidden space-y-6">
      {/* Header */}
      <div className="p-6 border-b border-slate-800 bg-[#16161a]">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-500/10 text-emerald-400 rounded-xl border border-emerald-500/20">
              <Zap className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Connexion X & Réseau Multi-Comptes (Anti-Shadowban)
                <span
                  className={`text-xs px-2.5 py-0.5 rounded-full font-semibold border flex items-center gap-1 ${
                    isMainConfigured
                      ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/30"
                      : "bg-amber-500/10 text-amber-400 border-amber-500/30"
                  }`}
                >
                  <span
                    className={`w-2 h-2 rounded-full ${
                      isMainConfigured ? "bg-emerald-400 animate-pulse" : "bg-amber-400"
                    }`}
                  />
                  {isMainConfigured
                    ? `${totalConfiguredAccounts}/3 Comptes Connectés (${totalConfiguredAccounts}x Likes)`
                    : "⚠️ Cookies X Requis"}
                </span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Publie automatiquement avec votre compte principal, puis déclenche un <strong>Auto-Like instantané</strong> avec vos 3 comptes pour booster l'autorité algorithmique.
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Account Selector Tabs */}
        <div className="flex items-center gap-2 p-1.5 bg-[#0d0d0f] rounded-xl border border-slate-800">
          <button
            type="button"
            onClick={() => setActiveAccountTab("MAIN")}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg text-xs font-bold transition-all ${
              activeAccountTab === "MAIN"
                ? "bg-emerald-600 text-white shadow-md"
                : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/50"
            }`}
          >
            <span>👑 Compte Principal (Publication)</span>
            <span
              className={`w-2 h-2 rounded-full ${
                isMainConfigured ? "bg-emerald-300" : "bg-slate-600"
              }`}
            />
          </button>

          <button
            type="button"
            onClick={() => setActiveAccountTab("BOOSTER1")}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg text-xs font-bold transition-all ${
              activeAccountTab === "BOOSTER1"
                ? "bg-indigo-600 text-white shadow-md"
                : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/50"
            }`}
          >
            <span>🚀 Compte Booster #1 (Auto-Like)</span>
            <span
              className={`w-2 h-2 rounded-full ${
                isB1Configured ? "bg-emerald-400" : "bg-slate-600"
              }`}
            />
          </button>

          <button
            type="button"
            onClick={() => setActiveAccountTab("BOOSTER2")}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg text-xs font-bold transition-all ${
              activeAccountTab === "BOOSTER2"
                ? "bg-purple-600 text-white shadow-md"
                : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/50"
            }`}
          >
            <span>🚀 Compte Booster #2 (Auto-Like)</span>
            <span
              className={`w-2 h-2 rounded-full ${
                isB2Configured ? "bg-emerald-400" : "bg-slate-600"
              }`}
            />
          </button>
        </div>

        {/* Step by step guide banner */}
        <div className="bg-indigo-950/30 border border-indigo-900/40 rounded-xl p-4 text-xs text-indigo-200 space-y-2">
          <div className="font-bold text-white flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-amber-300" />
              {activeAccountTab === "MAIN" && "Comment récupérer les cookies de votre Compte Principal :"}
              {activeAccountTab === "BOOSTER1" && "Comment récupérer les cookies de votre Compte Booster #1 :"}
              {activeAccountTab === "BOOSTER2" && "Comment récupérer les cookies de votre Compte Booster #2 :"}
            </div>
            <span className="text-[11px] font-mono text-emerald-400">100% Gratuit · Sans API payante</span>
          </div>

          <ol className="list-decimal list-inside space-y-1 text-slate-300 text-[11px] leading-relaxed">
            {activeAccountTab === "MAIN" ? (
              <>
                <li>Connectez-vous sur votre compte principal sur <strong>x.com</strong>.</li>
                <li>Appuyez sur <kbd className="bg-black/60 px-1 py-0.5 rounded border border-slate-700 font-mono text-white">F12</kbd> (Inspecter) &gt; Onglet <strong>Application</strong> &gt; <strong>Cookies</strong> &gt; <strong>https://x.com</strong>.</li>
                <li>Copiez la valeur de <code className="text-emerald-400 font-bold font-mono">auth_token</code> et celle de <code className="text-indigo-400 font-bold font-mono">ct0</code> ci-dessous.</li>
              </>
            ) : (
              <>
                <li>Ouvrez une <strong>fenêtre de navigation privée</strong> (ou un 2e profil Chrome) et connectez-vous avec ce 2e compte sur <strong>x.com</strong>.</li>
                <li>Appuyez sur <kbd className="bg-black/60 px-1 py-0.5 rounded border border-slate-700 font-mono text-white">F12</kbd> (Inspecter) &gt; Onglet <strong>Application</strong> &gt; <strong>Cookies</strong> &gt; <strong>https://x.com</strong>.</li>
                <li>Collez les valeurs de <code className="text-emerald-400 font-bold font-mono">auth_token</code> et <code className="text-indigo-400 font-bold font-mono">ct0</code> de ce compte. Il likera automatiquement chaque tweet du compte principal !</li>
              </>
            )}
          </ol>
        </div>

        {/* Form Inputs based on active tab */}
        {activeAccountTab === "MAIN" && (
          <div className="space-y-4">
            <div className="flex items-center justify-between text-xs text-slate-300 font-semibold">
              <span className="text-emerald-400 flex items-center gap-1.5">
                👑 Identifiants du Compte Principal (Publie les tweets H-1h & Bilans)
              </span>
              <button
                type="button"
                onClick={() => setShowSecret(!showSecret)}
                className="text-[11px] text-slate-400 hover:text-slate-200 flex items-center gap-1"
              >
                {showSecret ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                <span>{showSecret ? "Masquer" : "Afficher"}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-emerald-400" />
                    Cookie <code className="text-emerald-400 font-mono font-bold">auth_token</code>
                  </label>
                  <span className="text-[10px] font-mono text-slate-400">
                    {localAuthToken.trim().length} car. {localAuthToken.trim().length >= 20 ? "✅" : ""}
                  </span>
                </div>
                <input
                  type={showSecret ? "text" : "password"}
                  value={localAuthToken}
                  onChange={(e) => setLocalAuthToken(e.target.value)}
                  placeholder="Collez le auth_token du compte principal"
                  className="w-full bg-[#0d0d0f] border border-slate-800 rounded-xl p-3 text-xs font-mono text-slate-200 placeholder-slate-600 focus:outline-none focus:border-emerald-500 shadow-inner"
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                    <Shield className="w-3.5 h-3.5 text-indigo-400" />
                    Cookie <code className="text-indigo-400 font-mono font-bold">ct0</code> (Anti-CSRF)
                  </label>
                  <span className="text-[10px] font-mono text-slate-400">
                    {localCt0.trim().length} car. {localCt0.trim().length >= 20 ? "✅" : ""}
                  </span>
                </div>
                <input
                  type={showSecret ? "text" : "password"}
                  value={localCt0}
                  onChange={(e) => setLocalCt0(e.target.value)}
                  placeholder="Collez le ct0 du compte principal"
                  className="w-full bg-[#0d0d0f] border border-slate-800 rounded-xl p-3 text-xs font-mono text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500 shadow-inner"
                />
              </div>
            </div>
          </div>
        )}

        {activeAccountTab === "BOOSTER1" && (
          <div className="space-y-4">
            <div className="flex items-center justify-between text-xs text-slate-300 font-semibold">
              <span className="text-indigo-400 flex items-center gap-1.5">
                🚀 Identifiants du Compte Booster #1 (Auto-Like 100% Automatique)
              </span>
              <button
                type="button"
                onClick={() => setShowSecret(!showSecret)}
                className="text-[11px] text-slate-400 hover:text-slate-200 flex items-center gap-1"
              >
                {showSecret ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                <span>{showSecret ? "Masquer" : "Afficher"}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-indigo-400" />
                    Cookie <code className="text-indigo-400 font-mono font-bold">auth_token</code> (Booster 1)
                  </label>
                  <span className="text-[10px] font-mono text-slate-400">
                    {localB1AuthToken.trim().length} car. {localB1AuthToken.trim().length >= 20 ? "✅" : ""}
                  </span>
                </div>
                <input
                  type={showSecret ? "text" : "password"}
                  value={localB1AuthToken}
                  onChange={(e) => setLocalB1AuthToken(e.target.value)}
                  placeholder="Collez le auth_token du 2e compte X"
                  className="w-full bg-[#0d0d0f] border border-slate-800 rounded-xl p-3 text-xs font-mono text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500 shadow-inner"
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                    <Shield className="w-3.5 h-3.5 text-indigo-400" />
                    Cookie <code className="text-indigo-400 font-mono font-bold">ct0</code> (Booster 1)
                  </label>
                  <span className="text-[10px] font-mono text-slate-400">
                    {localB1Ct0.trim().length} car. {localB1Ct0.trim().length >= 20 ? "✅" : ""}
                  </span>
                </div>
                <input
                  type={showSecret ? "text" : "password"}
                  value={localB1Ct0}
                  onChange={(e) => setLocalB1Ct0(e.target.value)}
                  placeholder="Collez le ct0 du 2e compte X"
                  className="w-full bg-[#0d0d0f] border border-slate-800 rounded-xl p-3 text-xs font-mono text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500 shadow-inner"
                />
              </div>
            </div>
          </div>
        )}

        {activeAccountTab === "BOOSTER2" && (
          <div className="space-y-4">
            <div className="flex items-center justify-between text-xs text-slate-300 font-semibold">
              <span className="text-purple-400 flex items-center gap-1.5">
                🚀 Identifiants du Compte Booster #2 (Auto-Like 100% Automatique)
              </span>
              <button
                type="button"
                onClick={() => setShowSecret(!showSecret)}
                className="text-[11px] text-slate-400 hover:text-slate-200 flex items-center gap-1"
              >
                {showSecret ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                <span>{showSecret ? "Masquer" : "Afficher"}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-purple-400" />
                    Cookie <code className="text-purple-400 font-mono font-bold">auth_token</code> (Booster 2)
                  </label>
                  <span className="text-[10px] font-mono text-slate-400">
                    {localB2AuthToken.trim().length} car. {localB2AuthToken.trim().length >= 20 ? "✅" : ""}
                  </span>
                </div>
                <input
                  type={showSecret ? "text" : "password"}
                  value={localB2AuthToken}
                  onChange={(e) => setLocalB2AuthToken(e.target.value)}
                  placeholder="Collez le auth_token du 3e compte X"
                  className="w-full bg-[#0d0d0f] border border-slate-800 rounded-xl p-3 text-xs font-mono text-slate-200 placeholder-slate-600 focus:outline-none focus:border-purple-500 shadow-inner"
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                    <Shield className="w-3.5 h-3.5 text-purple-400" />
                    Cookie <code className="text-purple-400 font-mono font-bold">ct0</code> (Booster 2)
                  </label>
                  <span className="text-[10px] font-mono text-slate-400">
                    {localB2Ct0.trim().length} car. {localB2Ct0.trim().length >= 20 ? "✅" : ""}
                  </span>
                </div>
                <input
                  type={showSecret ? "text" : "password"}
                  value={localB2Ct0}
                  onChange={(e) => setLocalB2Ct0(e.target.value)}
                  placeholder="Collez le ct0 du 3e compte X"
                  className="w-full bg-[#0d0d0f] border border-slate-800 rounded-xl p-3 text-xs font-mono text-slate-200 placeholder-slate-600 focus:outline-none focus:border-purple-500 shadow-inner"
                />
              </div>
            </div>
          </div>
        )}

        {/* Action buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
          <button
            onClick={handleSave}
            className="flex items-center justify-center gap-2 px-4 py-3 text-xs font-bold text-white bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 rounded-xl shadow-lg shadow-emerald-950/40 transition cursor-pointer"
          >
            {savedSuccess ? (
              <>
                <Check className="w-4 h-4 text-white" />
                <span>Tous les Comptes Enregistrés & Armés !</span>
              </>
            ) : (
              <>
                <CheckCircle2 className="w-4 h-4 text-white" />
                <span>Sauvegarder les Comptes ({totalConfiguredAccounts}/3)</span>
              </>
            )}
          </button>

          <button
            onClick={handleTestConnection}
            disabled={isTesting}
            className="flex items-center justify-center gap-2 px-4 py-3 text-xs font-bold text-slate-200 bg-[#1c1c22] hover:bg-slate-800 active:bg-slate-700 disabled:opacity-50 rounded-xl border border-slate-700/80 transition cursor-pointer"
          >
            <Activity
              className={`w-4 h-4 ${isTesting ? "animate-spin text-emerald-400" : "text-emerald-400"}`}
            />
            <span>{isTesting ? "Test en cours..." : "Tester la Connexion"}</span>
          </button>
        </div>

        {/* Live Tweet Like Tester for Booster Accounts */}
        <div className="bg-[#0f1015] border border-slate-800/80 rounded-xl p-4 space-y-3.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Flame className="w-4 h-4 text-rose-400" />
              <h3 className="text-xs font-bold text-white">
                Tester le Like Direct sur un Tweet (Vérification des Comptes Booster)
              </h3>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-500/10 text-rose-300 border border-rose-500/20">
              Test Live Immédiat
            </span>
          </div>

          <p className="text-[11px] text-slate-400">
            Collez le lien ou l'ID de n'importe quel tweet X pour tester instantanément le like avec vos comptes Booster 1 & 2 :
          </p>

          <div className="flex flex-col sm:flex-row items-center gap-2">
            <input
              type="text"
              value={testTweetInput}
              onChange={(e) => setTestTweetInput(e.target.value)}
              placeholder="ex: https://x.com/user/status/1828109283746 ou ID numérique"
              className="flex-1 w-full bg-[#16161a] border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-xs font-mono text-slate-200 placeholder-slate-600 focus:outline-none focus:border-rose-500 shadow-inner"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 pt-1">
            <button
              type="button"
              onClick={() => handleTestLikeOnTweet("ALL")}
              disabled={isTestingLike}
              className="px-3 py-2 text-xs font-bold text-white bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-500 hover:to-pink-500 disabled:opacity-50 rounded-lg shadow transition cursor-pointer flex items-center justify-center gap-1.5"
            >
              <Users className="w-3.5 h-3.5" />
              <span>❤️ Tous les 3 ({totalConfiguredAccounts}x)</span>
            </button>

            <button
              type="button"
              onClick={() => handleTestLikeOnTweet("BOOSTER1")}
              disabled={isTestingLike || !isB1Configured}
              className="px-3 py-2 text-xs font-bold text-indigo-300 bg-indigo-950/60 hover:bg-indigo-900/80 border border-indigo-700/40 disabled:opacity-40 rounded-lg transition cursor-pointer flex items-center justify-center gap-1.5"
            >
              <span>🚀 Tester Booster #1</span>
            </button>

            <button
              type="button"
              onClick={() => handleTestLikeOnTweet("BOOSTER2")}
              disabled={isTestingLike || !isB2Configured}
              className="px-3 py-2 text-xs font-bold text-purple-300 bg-purple-950/60 hover:bg-purple-900/80 border border-purple-700/40 disabled:opacity-40 rounded-lg transition cursor-pointer flex items-center justify-center gap-1.5"
            >
              <span>🚀 Tester Booster #2</span>
            </button>

            <button
              type="button"
              onClick={() => handleTestLikeOnTweet("MAIN")}
              disabled={isTestingLike || !isMainConfigured}
              className="px-3 py-2 text-xs font-bold text-emerald-300 bg-emerald-950/60 hover:bg-emerald-900/80 border border-emerald-700/40 disabled:opacity-40 rounded-lg transition cursor-pointer flex items-center justify-center gap-1.5"
            >
              <span>👑 Tester Principal</span>
            </button>
          </div>

          {likeTestResult && (
            <div
              className={`p-3 rounded-xl border text-xs space-y-1 mt-2 transition ${
                likeTestResult.success
                  ? "bg-emerald-950/40 border-emerald-800/60 text-emerald-300"
                  : "bg-rose-950/40 border-rose-800/60 text-rose-300"
              }`}
            >
              <div className="font-bold flex items-center justify-between">
                <span>{likeTestResult.account || "Résultat du test :"}</span>
                <span className="font-mono text-[10px]">
                  {likeTestResult.success ? "RÉUSSI ✅" : "ÉCHEC ❌"}
                </span>
              </div>
              <p className="text-[11px] leading-relaxed">{likeTestResult.message}</p>
              {likeTestResult.details && (
                <div className="text-[10px] font-mono opacity-80 pt-1 space-y-0.5">
                  <div>Principal: {likeTestResult.details.main}</div>
                  <div>Booster #1: {likeTestResult.details.booster1}</div>
                  <div>Booster #2: {likeTestResult.details.booster2}</div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Anti-Shadowban feature indicator */}
        <div className="p-3.5 bg-rose-950/20 border border-rose-900/30 rounded-xl flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2.5">
            <span className="text-rose-400 font-bold flex items-center gap-1.5">
              ❤️ Bouclier Anti-Shadowban Multi-Comptes :
            </span>
            <span className="text-slate-300">
              Chaque tweet publié recevra automatiquement jusqu'à <strong>3 likes instantanés</strong> ({totalConfiguredAccounts} compte(s) actif(s)) pour briser le shadowban.
            </span>
          </div>
          <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-mono font-bold shrink-0">
            {totalConfiguredAccounts}x LIKES ACTIFS
          </span>
        </div>

        {/* Test Result Feedback */}
        {testResult && (
          <div
            className={`p-4 rounded-xl border space-y-1.5 text-xs transition ${
              testResult.status === "OK"
                ? "bg-emerald-950/30 border-emerald-800/60 text-emerald-300"
                : "bg-rose-950/30 border-rose-800/60 text-rose-200"
            }`}
          >
            <div className="flex items-center justify-between font-bold">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                {testResult.message}
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-black/40 border border-slate-700/60 text-emerald-300">
                AUTO-PILOTE ARMÉ
              </span>
            </div>

            <p className="text-[11px] leading-relaxed opacity-90">{testResult.explanation}</p>
          </div>
        )}
      </div>
    </div>
  );
};

