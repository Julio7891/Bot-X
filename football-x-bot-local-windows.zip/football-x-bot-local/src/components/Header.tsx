import React from "react";
import {
  PlaneTakeoff,
  Key,
  Radio,
  Sparkles,
  Flame,
  CheckCircle2,
} from "lucide-react";

export type NavTab = "sportytrader" | "matches" | "tweets";

interface HeaderProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  readyTweetsCount: number;
  onOpenCookiesModal: () => void;
  hasCookiesSet: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onSelectTab,
  readyTweetsCount,
  onOpenCookiesModal,
  hasCookiesSet,
}) => {
  return (
    <header className="bg-[#16161a] border-b border-slate-800 sticky top-0 z-40 backdrop-blur-md bg-opacity-95 shadow-xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-indigo-600 p-0.5 shadow-lg shadow-emerald-950 flex items-center justify-center">
              <div className="w-full h-full bg-[#16161a] rounded-[10px] flex items-center justify-center text-lg">
                ⚽
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-black text-sm sm:text-base text-white tracking-tight">
                  SportyTrader Auto-Prono Bot
                </span>
                <span className="text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  Scraper Cheerio
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-sans hidden sm:block">
                Scraping SportyTrader ➔ Tweets H-1h & Résultats Fin de Match
              </p>
            </div>
          </div>

          {/* Navigation */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => onSelectTab("sportytrader")}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
                activeTab === "sportytrader"
                  ? "bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-lg shadow-emerald-950/60 border border-emerald-500/50"
                  : "bg-[#1c1c22] text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-700/80"
              }`}
            >
              <Radio className={`w-4 h-4 ${activeTab === "sportytrader" ? "text-white" : "text-emerald-400"}`} />
              <span>1. SportyTrader Pronos</span>
            </button>

            <button
              onClick={() => onSelectTab("tweets")}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
                activeTab === "tweets"
                  ? "bg-gradient-to-r from-indigo-600 to-emerald-600 text-white shadow-lg shadow-indigo-950/60 border border-indigo-500/50"
                  : "bg-[#1c1c22] text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-700/80"
              }`}
            >
              <PlaneTakeoff className={`w-4 h-4 ${activeTab === "tweets" ? "text-white" : "text-emerald-400"}`} />
              <span>2. File des Tweets (H-1h & FT)</span>
              {readyTweetsCount > 0 && (
                <span
                  className={`px-2 py-0.5 text-[10px] font-black rounded-full border ${
                    activeTab === "tweets"
                      ? "bg-white/20 text-white border-white/30"
                      : "bg-emerald-500/20 text-emerald-300 border-emerald-500/30 animate-pulse"
                  }`}
                >
                  {readyTweetsCount}
                </span>
              )}
            </button>

            {/* Cookies X / Settings button */}
            <button
              onClick={onOpenCookiesModal}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#1c1c22] hover:bg-slate-800 text-slate-400 hover:text-slate-200 text-xs font-semibold border border-slate-800 transition ml-1"
              title="Configurer les identifiants / cookies de session X"
            >
              <Key className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden md:inline">Connexion X</span>
              <span
                className={`w-2 h-2 rounded-full ${
                  hasCookiesSet ? "bg-emerald-400" : "bg-amber-500"
                }`}
              />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

