import React, { useState } from "react";
import { X, Copy, Check, Sparkles, MessageCircle, ExternalLink, Globe, Bot } from "lucide-react";

interface BioManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onShowToast: (msg: string) => void;
}

export const BioManagerModal: React.FC<BioManagerModalProps> = ({
  isOpen,
  onClose,
  onShowToast,
}) => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!isOpen) return null;

  const BIO_TEMPLATES = [
    {
      id: "bio-1",
      title: "🔥 Bio Virale & Commerciale (Recommandée)",
      category: "Conversion Directe DM",
      tag: "Best-Seller",
      bio: `⚽ Pronostics Football Analyste IA & Data | Top Ligues 🇪🇺\n🎯 Value Bets & Analyses H-1h vérifiées\n📩 Besoin d'un Bot X sur-mesure / Automatisation ? DM ouvert`,
      dmPitch: `Salut ! Tu souhaites automatiser ton compte X pour publier tes pronos ou tes analyses en 100% pilote automatique (H-1h + Bilans scores réels) ? Dis-moi ce dont tu as besoin !`,
    },
    {
      id: "bio-2",
      title: "🚀 Bio SaaS / Agence d'Automatisation",
      category: "Prise de Commande & Business",
      tag: "Professionnel",
      bio: `🤖 Algorithme autonome de pronostics sportifs (100% IA & Live Data)\n📈 +85% de fiabilité sur les créneaux majeurs\n💼 Automatisez votre propre compte X sur-mesure 👉 DM`,
      dmPitch: `Hello ! On conçoit des bots autonomes comme celui-ci pour des tipsters, créateurs et agences. On peut connecter votre SportyTrader, vos cookies X et votre stratégie. Envoyez votre projet en DM !`,
    },
    {
      id: "bio-3",
      title: "💎 Bio Minimaliste & Haute Autorité",
      category: "Épurée & Percutante",
      tag: "Minimaliste",
      bio: `⚡ Smart Football Tips · UEFA & Top 5 Leagues\n📊 Data Driven · Auto-Pilot Engine\n📩 Automatisation de compte sur-mesure ➔ DM`,
      dmPitch: `Bienvenue ! Contactez-moi directement en message privé pour commander votre propre bot X autonome personnalisé.`,
    },
  ];

  const handleCopy = (text: string, key: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    onShowToast(`📋 ${label} copié dans le presse-papier !`);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-[#16161a] border border-slate-800 w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-6 border-b border-slate-800 flex items-center justify-between bg-[#16161a]">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-gradient-to-tr from-amber-500/20 to-orange-500/20 text-amber-400 rounded-xl border border-amber-500/30">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Bio X & Monétisation (Prendre des Commandes en DM)
              </h2>
              <p className="text-xs text-slate-400">
                Transformez les 200+ vues de vos tweets en clients pour vendre vos bots d'automatisation sur-mesure.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Growth Milestone Banner */}
          <div className="p-4 bg-gradient-to-r from-emerald-950/60 to-slate-900 border border-emerald-500/30 rounded-xl flex items-center gap-3">
            <div className="text-2xl">🚀</div>
            <div className="text-xs text-slate-300 space-y-0.5">
              <div className="font-bold text-white flex items-center gap-2">
                <span>Succès confirmé : +200 vues sur votre premier tweet !</span>
                <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 rounded-full text-[10px] font-mono">Top Traction</span>
              </div>
              <p className="text-slate-400">
                En affichant un appel à l'action clair dans votre bio (<span className="text-amber-300 font-semibold">« Automatisation sur-mesure = DM »</span>), chaque vue devient une opportunité de vente directe ou future commande de site SaaS.
              </p>
            </div>
          </div>

          {/* Templates list */}
          <div className="space-y-4">
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-400">
              Modèles de Bio X Prêts à Copier :
            </h3>

            {BIO_TEMPLATES.map((tpl) => (
              <div
                key={tpl.id}
                className="bg-[#0e0e12] border border-slate-800 hover:border-slate-700 rounded-xl p-4 space-y-3 transition"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-white">{tpl.title}</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                      {tpl.tag}
                    </span>
                  </div>
                  <button
                    onClick={() => handleCopy(tpl.bio, `${tpl.id}-bio`, "Texte de Bio")}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white transition shadow-sm"
                  >
                    {copiedKey === `${tpl.id}-bio` ? (
                      <Check className="w-3.5 h-3.5" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                    <span>{copiedKey === `${tpl.id}-bio` ? "Copié !" : "Copier la Bio"}</span>
                  </button>
                </div>

                <div className="p-3 bg-black/50 border border-slate-800/80 rounded-lg text-xs text-slate-200 font-sans whitespace-pre-line leading-relaxed">
                  {tpl.bio}
                </div>

                {/* Auto DM script */}
                <div className="pt-2 border-t border-slate-800/60 flex items-center justify-between text-[11px] text-slate-400">
                  <span className="flex items-center gap-1">
                    <MessageCircle className="w-3 h-3 text-amber-400" />
                    Réponse type pour vos prospects en DM :
                  </span>
                  <button
                    onClick={() => handleCopy(tpl.dmPitch, `${tpl.id}-dm`, "Message type DM")}
                    className="text-indigo-400 hover:text-indigo-300 font-semibold underline cursor-pointer"
                  >
                    {copiedKey === `${tpl.id}-dm` ? "Copié !" : "Copier message type"}
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Future Roadmap / SaaS note */}
          <div className="p-4 bg-indigo-950/20 border border-indigo-800/30 rounded-xl text-xs text-slate-300 space-y-2">
            <div className="font-bold text-white flex items-center gap-1.5">
              <Globe className="w-4 h-4 text-indigo-400" />
              <span>Étape suivante : Passerelle Site Web / Commandes en ligne</span>
            </div>
            <p className="text-slate-400 text-[11px] leading-relaxed">
              Une fois vos premiers clients validés via DM sur X, vous pourrez créer une landing page dédiée avec paiement Stripe (abonnements mensuels ou commandes uniques) pour automatiser les comptes de vos clients à grande échelle !
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-[#16161a] flex items-center justify-between">
          <a
            href="https://x.com/settings/profile"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 text-xs text-indigo-400 hover:text-indigo-300 font-semibold"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>Ouvrir Modifier mon profil sur X</span>
          </a>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold transition"
          >
            Fermer
          </button>
        </div>
      </div>
    </div>
  );
};
