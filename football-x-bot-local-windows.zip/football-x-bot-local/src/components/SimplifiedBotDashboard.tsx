import React, { useState, useEffect, useCallback } from "react";
import {
  Zap,
  Clock,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  ExternalLink,
  Play,
  Pause,
  Key,
  Flame,
  Trophy,
  Radio,
  Send,
  Calendar,
  Layers,
  ChevronRight,
  ShieldCheck,
  Check,
  Terminal,
  Copy,
  Code2,
  Sparkles,
  X,
  Download,
} from "lucide-react";

export interface TrackedMatchItem {
  id: string;
  homeTeam: string;
  awayTeam: string;
  competition: string;
  date: string;
  kickoffTime: string;
  prediction: string;
  odd: string;
  status: "SCHEDULED" | "PUBLISHED" | "LIVE" | "DEBRIEF_SENT" | "SKIPPED_SLOT_DUPLICATE" | "FAILED_PUBLISH";
  publishError?: string;
  isQueued?: boolean;
  publishedAt?: number;
  publishedTweetText?: string;
  publishedTweetId?: string;
  isAutoSelectedSlot?: boolean;
  slotKey?: string;
  slotSelectionReason?: string;
  currentLiveScore?: {
    scoreHome: number;
    scoreAway: number;
    isLive: boolean;
    isFinished: boolean;
    liveMinute?: string;
  } | null;
  goalAlertsSent?: Array<{
    homeScore: number;
    awayScore: number;
    scorer?: string;
    minute?: string;
    tweetId?: string;
    tweetText?: string;
    publishedAt: number;
  }>;
  debriefTweetSent?: boolean;
  debriefTweetText?: string;
  debriefTweetId?: string;
  debriefPublishedAt?: number;
  finalScore?: string;
  isWon?: boolean;
}

export interface PublishedTweetItem {
  id: string;
  tweetText: string;
  type: "PRONO_H1" | "GOAL_LIVE" | "RECAP_FT" | "DAILY_RECAP" | "MANUAL";
  matchTitle?: string;
  publishedAt?: number;
  tweetId?: string;
  status?: string;
}

export interface CookieHealthInfo {
  status: "UNKNOWN" | "VALID" | "MISSING" | "EXPIRED" | "IP_BLOCKED" | "NETWORK_ERROR";
  username?: string;
  displayName?: string;
  checkedAt?: number;
  message: string;
}

export const SimplifiedBotDashboard: React.FC = () => {
  // Navigation: Only 2 essential tabs
  const [activeTab, setActiveTab] = useState<"pipeline" | "tweets">("pipeline");

  // Bot State
  const [isBotActive, setIsBotActive] = useState<boolean>(true);
  const [trackedMatches, setTrackedMatches] = useState<TrackedMatchItem[]>([]);
  const [publishedTweets, setPublishedTweets] = useState<PublishedTweetItem[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [lastSyncTime, setLastSyncTime] = useState<Date>(new Date());
  const [lastSyncSource, setLastSyncSource] = useState<string>("EMPTY");
  const [lastSyncMessage, setLastSyncMessage] = useState<string>("");
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Publishing Mode: Honest 2-mode cookie-only system (LIVE_COOKIES vs SIMULATION)
  const [publishingMode, setPublishingMode] = useState<"LIVE_COOKIES" | "SIMULATION">("LIVE_COOKIES");
  // Collision Mode: ANTI_COLLISION (1 match phare par fenêtre 75min) or PUBLISH_ALL
  const [collisionMode, setCollisionMode] = useState<"ANTI_COLLISION" | "PUBLISH_ALL">("ANTI_COLLISION");

  // Credentials Modal State (100% Cookie-only)
  const [isCredsModalOpen, setIsCredsModalOpen] = useState<boolean>(false);
  const [authToken, setAuthToken] = useState<string>(() => localStorage.getItem("x_auth_token") || "");
  const [ct0, setCt0] = useState<string>(() => localStorage.getItem("x_ct0") || "");
  const [booster1AuthToken, setBooster1AuthToken] = useState<string>("");
  const [booster1Ct0, setBooster1Ct0] = useState<string>("");
  const [showBoosters, setShowBoosters] = useState<boolean>(false);
  const [cookieHealth, setCookieHealth] = useState<CookieHealthInfo>({
    status: "MISSING",
    message: "Aucun cookie X configuré.",
  });
  const [testDiagnostic, setTestDiagnostic] = useState<{
    success?: boolean;
    message?: string;
    explanation?: string;
    solution?: string;
  } | null>(null);
  const [isTestingCreds, setIsTestingCreds] = useState<boolean>(false);
  const [isCliModalOpen, setIsCliModalOpen] = useState<boolean>(false);
  const [copiedCommand, setCopiedCommand] = useState<string | null>(null);

  const handleCopyCommand = (cmd: string) => {
    navigator.clipboard.writeText(cmd);
    setCopiedCommand(cmd);
    setTimeout(() => setCopiedCommand(null), 2500);
  };

  // Filter for tweets tab
  const [tweetFilter, setTweetFilter] = useState<"ALL" | "PRONO_H1" | "GOAL_LIVE" | "RECAP_FT">("ALL");
  // Filter for matches tab by dynamic date
  const [matchDateFilter, setMatchDateFilter] = useState<string>("ALL");
  // Filter for slot arbitration (retained #1 vs duplicate skipped)
  const [matchSlotFilter, setMatchSlotFilter] = useState<"ALL" | "SCHEDULED_ONLY" | "SKIPPED_ONLY">("ALL");

  // Show temporary toast notification
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4500);
  };

  // Re-run smart slot arbitration with 75-min anti-collision & Premier League priority
  const handleReapplySlotPriority = async () => {
    try {
      setIsRefreshing(true);
      showToast("🎯 Arbitrage anti-collision 75 min (Priorité Premier League)...");
      const res = await fetch("/api/pipeline/reapply-slot-priority", {
        method: "POST",
      });
      const data = await res.json();
      if (data.success) {
        showToast(
          `✅ Arbitrage appliqué : ${data.arbitration.retainedMatchesCount} créneaux retenus, ${data.arbitration.skippedDuplicatesCount} doublons écartés !`
        );
        await fetchData();
      } else {
        showToast(`❌ Échec arbitrage : ${data.message || "Erreur"}`);
      }
    } catch (e) {
      showToast("Erreur lors de l'arbitrage des créneaux.");
    } finally {
      setIsRefreshing(false);
    }
  };

  // Trigger fresh live scrape (SportyTrader + ESPN Live AI fallback) & purge old matches
  const handleAutoPurgeSync = async () => {
    try {
      setIsRefreshing(true);
      showToast("🔄 Purge des anciens matchs et synchronisation live (SportyTrader / ESPN + IA)...");
      const res = await fetch("/api/pipeline/auto-purge-sync", {
        method: "POST",
      });
      const data = await res.json();
      if (data.success) {
        showToast(
          `✅ ${data.count} match(s) actif(s) synchronisé(s) (${data.source === "SPORTYTRADER_LIVE" ? "SportyTrader Live" : data.source === "ESPN_LIVE_AI" ? "ESPN Live + IA" : "Vide"}) !`
        );
        await fetchData();
      } else {
        showToast(`❌ Échec : ${data.message || "Erreur de synchronisation"}`);
      }
    } catch (e) {
      showToast("Erreur lors de la synchronisation automatique.");
    } finally {
      setIsRefreshing(false);
    }
  };

  // Fetch bot status, cookie health, matches and queue
  const fetchData = useCallback(async () => {
    try {
      // 1. Fetch Bot status & honest cookie health
      const statusRes = await fetch("/api/bot/status");
      if (statusRes.ok) {
        const sData = await statusRes.json();
        if (sData.success) {
          const isEnabled = sData.isAutoPilotEnabled ?? sData.botState?.isAutoPilotEnabled ?? true;
          setIsBotActive(isEnabled);
          if (sData.botState?.slotCollisionMode) {
            setCollisionMode(sData.botState.slotCollisionMode);
          }
          if (sData.publishingMode === "SIMULATION" || sData.publishingMode === "LIVE_COOKIES") {
            setPublishingMode(sData.publishingMode);
          }
          if (sData.cookieHealth) {
            setCookieHealth(sData.cookieHealth);
          }
          if (sData.lastSyncSource) {
            setLastSyncSource(sData.lastSyncSource);
          }
          if (typeof sData.lastSyncMessage === "string") {
            setLastSyncMessage(sData.lastSyncMessage);
          }
        }
      }

      // 2. Fetch Tracked Matches
      const trackedRes = await fetch("/api/pipeline/tracked-predictions");
      if (trackedRes.ok) {
        const tData = await trackedRes.json();
        if (tData.success && Array.isArray(tData.tracked)) {
          setTrackedMatches(tData.tracked);
        }
      }

      // 3. Fetch Published Tweets from Queue Status
      const queueRes = await fetch("/api/pipeline/queue-status");
      if (queueRes.ok) {
        const qData = await queueRes.json();
        if (qData.success && Array.isArray(qData.recentPublished)) {
          setPublishedTweets(qData.recentPublished);
        }
      }

      setLastSyncTime(new Date());
    } catch (err) {
      console.warn("Failed to fetch dashboard data:", err);
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  }, []);

  // Initial load + periodic refresh every 15 seconds
  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 15000);
    return () => clearInterval(interval);
  }, [fetchData]);

  // Continuous Keep-Alive Automation Tick every 60 seconds while this page is open
  useEffect(() => {
    const pingCronTick = () => {
      fetch("/api/cron/tick", {
        method: "POST",
        headers: { "x-internal-ui": "1" },
      })
        .then((r) => (r.ok ? r.json() : null))
        .then((tickData) => {
          if (tickData?.synced || tickData?.cycle?.h1PublishedCount || tickData?.cycle?.goalsDetected || tickData?.cycle?.finishedCount) {
            fetchData();
          }
        })
        .catch(() => {});
    };

    pingCronTick();
    const tickInterval = setInterval(pingCronTick, 60_000);
    return () => clearInterval(tickInterval);
  }, [fetchData]);

  // Check X credentials status and mode on initial mount
  useEffect(() => {
    fetch("/api/x/credentials-status")
      .then((r) => r.json())
      .then((data) => {
        if (data.publishingMode === "SIMULATION" || data.publishingMode === "LIVE_COOKIES") {
          setPublishingMode(data.publishingMode);
        }
        if (data.cookieHealth) {
          setCookieHealth(data.cookieHealth);
        }
      })
      .catch(() => {});
  }, []);

  // Update publishing mode (LIVE_COOKIES or SIMULATION)
  const handleChangePublishingMode = async (newMode: "LIVE_COOKIES" | "SIMULATION") => {
    try {
      setPublishingMode(newMode);
      const res = await fetch("/api/x/set-publishing-mode", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mode: newMode }),
      });
      const data = await res.json();
      if (data.success) {
        showToast(
          newMode === "LIVE_COOKIES"
            ? "🍪 Mode Cookies X (Auto Réel) activé — 0€ d'API !"
            : "🧪 Mode Simulation Test activé (aucun tweet envoyé sur X)."
        );
      }
    } catch (e) {
      showToast("Erreur lors de la mise à jour du mode.");
    }
  };

  // Reset tonight's matches for retry
  const handleResetTonightMatches = async () => {
    try {
      setIsRefreshing(true);
      showToast("🔄 Déblocage des créneaux de ce soir et relance de l'auto-pilote...");
      const res = await fetch("/api/pipeline/reset-tonight-matches", {
        method: "POST",
      });
      const data = await res.json();
      if (data.success) {
        showToast(`✅ ${data.result.resetCount} créneaux réouverts ! Cycle d'envoi relancé.`);
        await fetchData();
      } else {
        showToast(`❌ Échec : ${data.message || "Erreur"}`);
      }
    } catch (e) {
      showToast("Erreur lors du déblocage.");
    } finally {
      setIsRefreshing(false);
    }
  };

  // Toggle collision mode: Anti-Collision (1 per slot) vs Publish All (every match)
  const handleToggleCollisionMode = async (newMode: "ANTI_COLLISION" | "PUBLISH_ALL") => {
    try {
      setIsRefreshing(true);
      showToast(newMode === "PUBLISH_ALL" ? "⚡ Activation du mode Tout Publier..." : "👑 Activation de l'Anti-Collision (1 match phare par créneau)...");
      const res = await fetch("/api/bot/set-collision-mode", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mode: newMode }),
      });
      const data = await res.json();
      if (data.success) {
        setCollisionMode(newMode);
        showToast(
          newMode === "PUBLISH_ALL"
            ? "✅ Mode Tout Publier actif : tous les matchs sont autorisés !"
            : "✅ Mode Anti-Collision actif (priorité Premier League)"
        );
        await fetchData();
      }
    } catch (e) {
      showToast("Erreur de modification du mode.");
    } finally {
      setIsRefreshing(false);
    }
  };

  // Force enqueue all tonight matches into publishing queue
  const handleForceEnqueueTonight = async () => {
    try {
      setIsRefreshing(true);
      showToast("⚡ Envoi de tous les matchs de ce soir vers la file de publication...");
      const res = await fetch("/api/pipeline/force-enqueue-tonight", { method: "POST" });
      const data = await res.json();
      if (data.success) {
        showToast(`✅ ${data.result.enqueuedCount} matchs enfilés pour publication immédiate !`);
        await fetchData();
      }
    } catch (e) {
      showToast("Erreur lors de l'enfilage.");
    } finally {
      setIsRefreshing(false);
    }
  };

  // Toggle Bot ON/OFF
  const handleToggleBot = async () => {
    try {
      const nextState = !isBotActive;
      setIsBotActive(nextState);
      const res = await fetch("/api/bot/toggle", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ enabled: nextState }),
      });
      if (res.ok) {
        showToast(nextState ? "🟢 Robot Automatique Activé !" : "⏸️ Robot Automatique en Pause.");
      }
    } catch (e) {
      showToast("Erreur de communication avec le serveur.");
    }
  };

  // Trigger immediate cycle check
  const handleForceRun = async () => {
    setIsRefreshing(true);
    try {
      const res = await fetch("/api/bot/force-run", { method: "POST" });
      if (res.ok) {
        const data = await res.json();
        const publishedCount = data.result?.h1PublishedCount || 0;
        const goalsCount = data.result?.goalsDetected || 0;
        const debriefCount = data.result?.finishedCount || 0;

        if (publishedCount > 0 || goalsCount > 0 || debriefCount > 0) {
          showToast(`⚡ Cycle exécuté : ${publishedCount} prono(s), ${goalsCount} but(s), ${debriefCount} débrief(s) !`);
        } else {
          showToast("⚡ Cycle vérifié : tout est synchronisé à la seconde près.");
        }
      }
      await fetchData();
    } catch (e) {
      showToast("Erreur lors du forçage.");
    } finally {
      setIsRefreshing(false);
    }
  };

  // Test X cookies live against x.com
  const handleTestCreds = async () => {
    if (!authToken || !ct0) {
      showToast("Veuillez renseigner les deux cookies auth_token et ct0.");
      return;
    }
    setIsTestingCreds(true);
    setTestDiagnostic(null);
    try {
      const res = await fetch("/api/x/test-connection", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ authToken, ct0 }),
      });
      const data = await res.json();
      setTestDiagnostic({
        success: data.success,
        message: data.message,
        explanation: data.explanation,
        solution: data.solution,
      });
      if (data.success) {
        setCookieHealth({
          status: "VALID",
          username: data.username,
          displayName: data.displayName,
          checkedAt: Date.now(),
          message: data.message,
        });
        localStorage.setItem("x_auth_token", authToken);
        localStorage.setItem("x_ct0", ct0);
        showToast(
          data.username
            ? `✅ Connecté au compte X @${data.username} !`
            : "✅ Connexion cookies X validée !"
        );
      } else {
        setCookieHealth({
          status: data.status === "EXPIRED" ? "EXPIRED" : data.status === "IP_BLOCKED" ? "IP_BLOCKED" : "NETWORK_ERROR",
          checkedAt: Date.now(),
          message: data.message || "Cookies non valides",
        });
        showToast(`❌ ${data.message || "Cookies X refusés"}`);
      }
    } catch (e) {
      showToast("Erreur lors du test des cookies X.");
    } finally {
      setIsTestingCreds(false);
    }
  };

  // Save cookies to server + verify immediately + unlock any failed matches
  const handleSaveCreds = async () => {
    setIsTestingCreds(true);
    setTestDiagnostic(null);
    localStorage.setItem("x_auth_token", authToken);
    localStorage.setItem("x_ct0", ct0);
    try {
      const res = await fetch("/api/x/save-credentials", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          publishingMode,
          authToken,
          ct0,
          booster1AuthToken: booster1AuthToken || undefined,
          booster1Ct0: booster1Ct0 || undefined,
        }),
      });
      const data = await res.json();
      if (data.cookieHealth) {
        setCookieHealth(data.cookieHealth);
      }
      if (data.diagnostic) {
        setTestDiagnostic({
          success: data.diagnostic.success,
          message: data.diagnostic.message,
          explanation: data.diagnostic.explanation,
          solution: data.diagnostic.solution,
        });
      }
      if (data.verified || publishingMode === "SIMULATION") {
        setIsCredsModalOpen(false);
        showToast(data.message || "💾 Cookies X enregistrés et vérifiés !");
        await fetchData();
      } else {
        showToast(data.message || "⚠️ Cookies enregistrés, vérifiez le diagnostic ci-dessous.");
      }
    } catch (e) {
      showToast("Erreur lors de l'enregistrement des cookies.");
    } finally {
      setIsTestingCreds(false);
    }
  };

  // Publish H-1 tweet immediately for a match via cookies (NO window.open popup!)
  const handlePublishH1Now = async (match: TrackedMatchItem) => {
    try {
      showToast(`🚀 Publication du Prono H-1 pour ${match.homeTeam} vs ${match.awayTeam}...`);
      const defaultText = `🔥 PRONO H-1 | ${match.homeTeam} vs ${match.awayTeam}\n🏆 ${match.competition} · Coup d'envoi ${match.kickoffTime}\n\n🎯 Prono : ${match.prediction}\n📈 Cote : @${match.odd}\n\n#Pronostics #Football`;
      const tweetText = match.publishedTweetText || defaultText;

      const res = await fetch("/api/x/publish-tweet", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          tweetText,
          authToken: authToken || localStorage.getItem("x_auth_token") || undefined,
          ct0: ct0 || localStorage.getItem("x_ct0") || undefined,
          matchId: match.id,
          pronoId: match.id,
          homeTeam: match.homeTeam,
          awayTeam: match.awayTeam,
          prediction: match.prediction,
          odd: match.odd,
          competition: match.competition,
          date: match.date,
          kickoffTime: match.kickoffTime,
        }),
      });
      const data = await res.json();
      if (data.success && data.isDirectPublished) {
        showToast("✅ Pronostic H-1 publié directement sur votre compte X !");
      } else if (data.success && data.mode === "simulation") {
        showToast("🧪 Tweet simulé (Mode Test actif). Passez en mode Cookies X pour publier en vrai.");
      } else {
        showToast(`❌ ${data.message || "Échec d'envoi sur X. Vérifiez vos cookies dans Compte X."}`);
      }
      await fetchData();
    } catch (e) {
      showToast("Erreur réseau lors de la publication.");
    }
  };

  // Simulate a live goal for test purposes
  const handleSimulateGoal = async (match: TrackedMatchItem, scoringTeam: "home" | "away") => {
    try {
      showToast(`⚽ But simulé pour ${scoringTeam === "home" ? match.homeTeam : match.awayTeam}...`);
      const res = await fetch("/api/pipeline/simulate-goal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          matchId: match.id,
          scoringTeam,
          liveMinute: `${Math.floor(Math.random() * 40) + 50}'`,
          scorerName: scoringTeam === "home" ? "Attaquant" : "Buteur",
        }),
      });
      const data = await res.json();
      if (data.success) {
        showToast("⚡ But détecté et tweeté en direct !");
        await fetchData();
      }
    } catch (e) {
      showToast("Erreur simulation but.");
    }
  };

  // Simulate full-time debrief for test purposes
  const handleSimulateFT = async (match: TrackedMatchItem) => {
    try {
      showToast(`🏁 Débrief fin de match en cours pour ${match.homeTeam} vs ${match.awayTeam}...`);
      const res = await fetch("/api/pipeline/simulate-ft", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          matchId: match.id,
        }),
      });
      const data = await res.json();
      if (data.success) {
        showToast("🏁 Débrief fin de match publié sur X !");
        await fetchData();
      }
    } catch (e) {
      showToast("Erreur simulation fin de match.");
    }
  };

  // Dispatch all pending debriefs for finished matches
  const handleDispatchAllDebriefs = async () => {
    try {
      setIsRefreshing(true);
      showToast("🏁 Analyse des scores et envoi des débriefs terminés...");
      const res = await fetch("/api/pipeline/dispatch-all-debriefs", { method: "POST" });
      const data = await res.json();
      if (data.success) {
        showToast(`🏁 ${data.dispatchedCount || 0} débrief(s) finaux envoyés vers X !`);
        await fetchData();
      } else {
        showToast("Erreur lors de l'envoi des débriefs.");
      }
    } catch (e) {
      showToast("Erreur communication serveur.");
    } finally {
      setIsRefreshing(false);
    }
  };

  // Publish debrief for a single match (no window.open)
  const handlePublishDebriefNow = async (match: TrackedMatchItem) => {
    try {
      showToast(`🏁 Génération et mise en file du débrief pour ${match.homeTeam} vs ${match.awayTeam}...`);
      const res = await fetch("/api/pipeline/publish-debrief-now", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ matchId: match.id }),
      });
      const data = await res.json();
      if (data.success) {
        showToast(data.message || "🏁 Débrief ajouté à la file de publication X !");
        await fetchData();
      } else {
        showToast(data.message || "Erreur lors du débrief.");
      }
    } catch (e) {
      showToast("Erreur lors de l'envoi du débrief.");
    }
  };

  // Dynamic unique dates computed directly from real live matches
  const uniqueDates = Array.from(
    new Set(trackedMatches.map((m) => m.date).filter(Boolean))
  );

  const todayDisplayLabel = new Date().toLocaleDateString("fr-FR", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  const isCookieHealthy = cookieHealth.status === "VALID";

  // Computed metrics for the 3 pillars
  const scheduledPronosCount = trackedMatches.filter((m) => m.status === "SCHEDULED").length;
  const publishedPronosCount = trackedMatches.filter(
    (m) => m.status === "PUBLISHED" || m.status === "LIVE" || m.status === "DEBRIEF_SENT"
  ).length;
  const totalGoalAlerts = trackedMatches.reduce(
    (acc, m) => acc + (m.goalAlertsSent ? m.goalAlertsSent.length : 0),
    0
  );
  const finishedDebriefsCount = trackedMatches.filter((m) => Boolean(m.debriefTweetSent)).length;

  // Filtered published tweets
  const filteredTweets = publishedTweets.filter((t) => {
    if (tweetFilter === "ALL") return true;
    return t.type === tweetFilter;
  });

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-emerald-500 selection:text-black">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 bg-emerald-600 text-white font-semibold text-sm px-4 py-3 rounded-xl shadow-2xl shadow-emerald-950 border border-emerald-400/40 flex items-center gap-2 animate-bounce">
          <CheckCircle2 className="w-4 h-4" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Header */}
      <header className="border-b border-slate-800/80 bg-slate-900/90 backdrop-blur sticky top-0 z-30">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          {/* Logo & Main Title */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center shadow-lg shadow-emerald-950">
              <span className="text-lg">⚽</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-black tracking-tight text-white">
                  Bot Football X
                </h1>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  100% Automatisé
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                Pronos H-1 ➔ Buts en direct ➔ Débriefs fin de match
              </p>
            </div>
          </div>

          {/* Quick Actions & Bot Switch */}
          <div className="flex items-center gap-2.5">
            {/* Bot Active Switch Button */}
            <button
              onClick={handleToggleBot}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer border ${
                isBotActive
                  ? "bg-emerald-500/15 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/25"
                  : "bg-rose-500/15 text-rose-300 border-rose-500/40 hover:bg-rose-500/25"
              }`}
            >
              {isBotActive ? (
                <>
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span>Robot Actif</span>
                </>
              ) : (
                <>
                  <Pause className="w-3.5 h-3.5 text-rose-400" />
                  <span>Robot en Pause</span>
                </>
              )}
            </button>

            {/* Force Run Button */}
            <button
              onClick={handleForceRun}
              disabled={isRefreshing}
              title="Exécuter une vérification maintenant"
              className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 border border-slate-700/60 transition cursor-pointer"
            >
              <RefreshCw className={`w-4 h-4 ${isRefreshing ? "animate-spin text-emerald-400" : ""}`} />
            </button>

            {/* Terminal / GitHub CLI Button */}
            <button
              onClick={() => setIsCliModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-950/80 to-slate-800 text-emerald-300 hover:text-white hover:bg-slate-700 text-xs font-bold border border-emerald-500/30 transition cursor-pointer shadow-sm"
              title="Ouvrir dans un Terminal ou déployer sur GitHub"
            >
              <Terminal className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden sm:inline">Terminal & GitHub</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 font-mono">CLI</span>
            </button>

            {/* Download Project ZIP for GitHub */}
            <a
              href="/api/export-project-zip"
              download="football-x-bot.zip"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 text-slate-200 hover:text-white hover:bg-slate-700 text-xs font-semibold border border-slate-700/60 transition cursor-pointer"
              title="Télécharger tout le projet en archive .ZIP prêt pour GitHub"
            >
              <Download className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden md:inline">Télécharger (.ZIP)</span>
            </a>

            {/* X Account Settings Button */}
            <button
              onClick={() => setIsCredsModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 text-slate-200 hover:bg-slate-700 text-xs font-semibold border border-slate-700/60 transition cursor-pointer"
            >
              <Key className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">
                {cookieHealth.username ? `@${cookieHealth.username}` : "Cookies X"}
              </span>
              {isCookieHealthy ? (
                <span className="w-2 h-2 rounded-full bg-emerald-400" title="Cookies X vérifiés" />
              ) : cookieHealth.status === "EXPIRED" || cookieHealth.status === "IP_BLOCKED" ? (
                <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" title={cookieHealth.message} />
              ) : (
                <span className="w-2 h-2 rounded-full bg-amber-400" title="Cookies à configurer" />
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-6xl mx-auto px-4 sm:px-6 py-6 space-y-6">
        {/* Hands-Free Zero-Click Automation Banner */}
        <div className="bg-gradient-to-r from-emerald-950/80 via-slate-900 to-teal-950/80 border border-emerald-500/40 rounded-2xl p-4 sm:p-5 shadow-xl shadow-emerald-950/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-400 text-xl font-bold shrink-0 mt-0.5">
              ⚡
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-sm sm:text-base font-extrabold text-white flex items-center gap-2">
                  Mode 100% Automatique & Mains-Libres
                </h2>
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/40">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                  Surveillance Continue Active
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                Vous avez juste à laisser cette page ouverte : le bot <strong>scrute SportyTrader en continu</strong>, publie le prono <strong>1 heure avant le match</strong> avec arbitrage strict (<strong>zéro superposition de tweet</strong> : 1 match par créneau), alerte <strong>chaque but en direct</strong> et envoie le <strong>débrief</strong> au coup de sifflet final !
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
            <span className="text-[11px] font-semibold px-3 py-1.5 rounded-xl bg-slate-800/90 text-emerald-300 border border-emerald-500/30 flex items-center gap-1.5 font-mono shadow-sm">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              Anti-Superposition Garanti
            </span>
          </div>
        </div>

        {/* Les 3 Piliers (Ce que fait le bot) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Pilier 1 : Prono H-1 */}
          <div className="bg-slate-900/80 rounded-2xl p-4 border border-slate-800 hover:border-emerald-500/40 transition">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-sm">
                  1
                </div>
                <h3 className="font-bold text-sm text-white">Pronos H-1</h3>
              </div>
              <span className="text-xs font-mono px-2 py-0.5 rounded-md bg-emerald-950/60 text-emerald-400 border border-emerald-800/40">
                {publishedPronosCount} publiés
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Publié automatiquement <span className="text-emerald-300 font-semibold">1h avant</span> chaque match du jour avec cote & analyse.
            </p>
            <div className="mt-3 text-[11px] text-slate-400 flex items-center justify-between pt-2 border-t border-slate-800/60 font-mono">
              <span>Programmé aujourd'hui :</span>
              <span className="text-slate-200 font-bold">{scheduledPronosCount} matchs</span>
            </div>
          </div>

          {/* Pilier 2 : Buts en Direct */}
          <div className="bg-slate-900/80 rounded-2xl p-4 border border-slate-800 hover:border-amber-500/40 transition">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-sm">
                  2
                </div>
                <h3 className="font-bold text-sm text-white">Buts en Direct</h3>
              </div>
              <span className="text-xs font-mono px-2 py-0.5 rounded-md bg-amber-950/60 text-amber-400 border border-amber-800/40">
                {totalGoalAlerts} tweetés
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Détecte les scores en direct et tweete <span className="text-amber-300 font-semibold">immédiatement</span> chaque but avec minute & buteur.
            </p>
            <div className="mt-3 text-[11px] text-slate-400 flex items-center justify-between pt-2 border-t border-slate-800/60 font-mono">
              <span>Scan des scores :</span>
              <span className="text-emerald-400 font-bold">Actif en continu</span>
            </div>
          </div>

          {/* Pilier 3 : Débrief Fin de Match */}
          <div className="bg-slate-900/80 rounded-2xl p-4 border border-slate-800 hover:border-sky-500/40 transition">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-sky-500/20 text-sky-400 flex items-center justify-center font-bold text-sm">
                  3
                </div>
                <h3 className="font-bold text-sm text-white">Débrief Fin de Match</h3>
              </div>
              <span className="text-xs font-mono px-2 py-0.5 rounded-md bg-sky-950/60 text-sky-400 border border-sky-800/40">
                {finishedDebriefsCount} envoyés
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Dès le coup de sifflet final : score final et validation du prono (<span className="text-sky-300 font-semibold">Gagné ✅ ou Perdu ❌</span>).
            </p>
            <div className="mt-3 text-[11px] text-slate-400 flex items-center justify-between pt-2 border-t border-slate-800/60 font-mono">
              <span>Débrief automatique :</span>
              <span className="text-sky-300 font-bold">Dès coup de sifflet final</span>
            </div>
          </div>
        </div>

        {/* Simplified Tabs Switcher */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab("pipeline")}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition cursor-pointer ${
                activeTab === "pipeline"
                  ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 shadow-lg shadow-emerald-950/40"
                  : "text-slate-400 hover:text-white hover:bg-slate-900"
              }`}
            >
              <Calendar className="w-4 h-4" />
              <span>Matchs du Jour ({trackedMatches.length})</span>
            </button>

            <button
              onClick={() => setActiveTab("tweets")}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition cursor-pointer ${
                activeTab === "tweets"
                  ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 shadow-lg shadow-emerald-950/40"
                  : "text-slate-400 hover:text-white hover:bg-slate-900"
              }`}
            >
              <Send className="w-4 h-4" />
              <span>Tweets Publiés sur X ({publishedTweets.length})</span>
            </button>
          </div>

          <span className="text-xs text-slate-400 hidden sm:block font-mono">
            Dernière sync : {lastSyncTime.toLocaleTimeString("fr-FR")}
          </span>
        </div>

        {/* TAB 1: PIPELINE DES MATCHS DU JOUR */}
        {activeTab === "pipeline" && (
          <div className="space-y-4">
            {/* Diffusion Mode (100% Cookie-only) & Quick Reset Card */}
            <div className="bg-slate-900/90 p-4 rounded-2xl border border-slate-800 flex flex-col lg:flex-row lg:items-center justify-between gap-4 shadow-xl">
              <div className="space-y-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Mode de diffusion :</span>
                  <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
                    <button
                      onClick={() => handleChangePublishingMode("LIVE_COOKIES")}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                        publishingMode === "LIVE_COOKIES"
                          ? "bg-emerald-500 text-slate-950 shadow-sm"
                          : "text-slate-400 hover:text-white"
                      }`}
                    >
                      🍪 Cookies X (Auto Réel · 0€)
                    </button>
                    <button
                      onClick={() => handleChangePublishingMode("SIMULATION")}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                        publishingMode === "SIMULATION"
                          ? "bg-sky-500 text-slate-950 shadow-sm"
                          : "text-slate-400 hover:text-white"
                      }`}
                    >
                      🧪 Mode Test (Simulation)
                    </button>
                  </div>
                </div>
                <p className="text-[11px] text-slate-400">
                  {publishingMode === "LIVE_COOKIES" ? (
                    <span className="text-emerald-300">
                      Publication réelle 100% gratuite via vos cookies X (<code className="font-mono">auth_token</code> + <code className="font-mono">ct0</code>), sans API payante, avec rotation automatique du <code className="font-mono">ct0</code> et réessais auto.
                    </span>
                  ) : (
                    <span className="text-sky-300">
                      Mode Simulation : exécute tout le pipeline (H-1, buts, débriefs) localement sans rien publier sur votre compte X.
                    </span>
                  )}
                </p>
              </div>

              {/* Actions: Relancer & Enfiler Tout Ce Soir */}
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={handleResetTonightMatches}
                  disabled={isRefreshing}
                  className="flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-extrabold transition shrink-0 cursor-pointer shadow-lg shadow-emerald-950/60"
                  title="Débloque les matchs du jour et relance l'auto-pilote"
                >
                  <RefreshCw className={`w-4 h-4 ${isRefreshing ? "animate-spin" : ""}`} />
                  <span>🔄 Relancer Aujourd'hui</span>
                </button>
                <button
                  onClick={handleForceEnqueueTonight}
                  disabled={isRefreshing}
                  className="flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white text-xs font-extrabold transition shrink-0 cursor-pointer shadow-lg shadow-amber-950/60"
                  title="Envoie les matchs retenus d'aujourd'hui vers la file anti-spam"
                >
                  <Zap className="w-4 h-4" />
                  <span>⚡ Enfiler Matchs du Jour</span>
                </button>
              </div>
            </div>

            {/* Honest Cookie Health Status Banner */}
            {cookieHealth.status === "VALID" ? (
              <div className="bg-emerald-950/40 border border-emerald-500/40 rounded-2xl p-3.5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-emerald-200">
                      Session Cookies X Vérifiée {cookieHealth.username ? `(@${cookieHealth.username})` : ""}
                    </h4>
                    <p className="text-xs text-emerald-300/80">
                      {cookieHealth.message} · Zéro API payante, publication automatique active.
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setIsCredsModalOpen(true)}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-300 text-xs font-bold border border-emerald-500/30 transition cursor-pointer shrink-0"
                >
                  Gérer Cookies
                </button>
              </div>
            ) : cookieHealth.status === "EXPIRED" || cookieHealth.status === "IP_BLOCKED" ? (
              <div className="bg-rose-950/50 border border-rose-500/50 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-lg">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center shrink-0">
                    <AlertCircle className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-rose-200">
                      {cookieHealth.status === "EXPIRED"
                        ? "Cookies X expirés — Action requise"
                        : "IP serveur cloud filtrée par X (Erreur 226/403)"}
                    </h4>
                    <p className="text-xs text-rose-200/80 leading-relaxed">
                      {cookieHealth.message}{" "}
                      {cookieHealth.status === "IP_BLOCKED"
                        ? "Sur un PC perso (IP résidentielle) avec 'npm run bot', les cookies passent sans blocage."
                        : "Reconnectez-vous sur x.com et collez vos nouveaux auth_token + ct0."}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  {cookieHealth.status === "IP_BLOCKED" && (
                    <button
                      onClick={() => setIsCliModalOpen(true)}
                      className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition cursor-pointer border border-slate-700"
                    >
                      Lancer sur mon PC
                    </button>
                  )}
                  <button
                    onClick={() => setIsCredsModalOpen(true)}
                    className="px-3.5 py-2 rounded-xl bg-rose-500 hover:bg-rose-400 text-white font-bold text-xs transition cursor-pointer flex items-center gap-1.5"
                  >
                    <Key className="w-4 h-4" />
                    <span>Mettre à jour Cookies</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="bg-amber-950/40 border border-amber-500/40 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-lg">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                    <Key className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-amber-200">
                      Cookies X (auth_token & ct0) non configurés
                    </h4>
                    <p className="text-xs text-amber-300/80 leading-relaxed">
                      Pour que le bot publie tout seul gratuitement (sans API X payante), cliquez sur <strong>« Relier Compte X »</strong> et collez vos cookies <code className="font-mono">auth_token</code> et <code className="font-mono">ct0</code> depuis F12 sur x.com.
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setIsCredsModalOpen(true)}
                  className="px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition shrink-0 cursor-pointer flex items-center gap-1.5 shadow-md"
                >
                  <Key className="w-4 h-4" />
                  <span>Relier Compte X</span>
                </button>
              </div>
            )}

            {/* Dynamic Live Dates & Data Source Banner */}
            <div className="bg-gradient-to-r from-emerald-950/40 via-slate-900 to-slate-900 p-4 rounded-2xl border border-emerald-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-lg">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                  <Radio className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <h4 className="text-sm font-bold text-white capitalize">
                      Matchs Live · {todayDisplayLabel}
                    </h4>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                      {lastSyncSource === "SPORTYTRADER_LIVE"
                        ? "🟢 SportyTrader Live"
                        : lastSyncSource === "ESPN_LIVE_AI"
                        ? "📡 ESPN Live + IA"
                        : "🔄 Sync Auto 30 min"}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">
                    {lastSyncMessage ||
                      "Synchronisation live automatique toutes les 30 min (SportyTrader + secours ESPN Live & IA). Aucune donnée fictive."}
                  </p>
                </div>
              </div>
              <button
                onClick={handleAutoPurgeSync}
                disabled={isRefreshing}
                className="flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition shrink-0 cursor-pointer shadow-md shadow-emerald-950"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? "animate-spin" : ""}`} />
                <span>Actualiser les matchs live</span>
              </button>
            </div>

            {/* Anti-Collision & Premier League Priority Banner with Toggle */}
            <div className="bg-gradient-to-r from-sky-950/40 via-indigo-950/30 to-slate-900/90 p-4 rounded-2xl border border-sky-500/30 flex flex-col lg:flex-row lg:items-center justify-between gap-4 shadow-lg">
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center shrink-0 mt-0.5">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <h4 className="text-sm font-bold text-white">Règle de Sélection des Créneaux :</h4>
                    <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
                      <button
                        onClick={() => handleToggleCollisionMode("ANTI_COLLISION")}
                        className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                          collisionMode === "ANTI_COLLISION"
                            ? "bg-sky-500 text-slate-950 shadow-sm"
                            : "text-slate-400 hover:text-white"
                        }`}
                      >
                        👑 Anti-Collision (1 match phare)
                      </button>
                      <button
                        onClick={() => handleToggleCollisionMode("PUBLISH_ALL")}
                        className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                          collisionMode === "PUBLISH_ALL"
                            ? "bg-amber-500 text-slate-950 shadow-sm"
                            : "text-slate-400 hover:text-white"
                        }`}
                      >
                        ⚡ Tout Publier (Tous les matchs)
                      </button>
                    </div>
                  </div>
                  <p className="text-xs text-slate-300 mt-1.5 leading-relaxed">
                    {collisionMode === "ANTI_COLLISION" ? (
                      <span>
                        Retient 1 seul match par heure avec <strong>priorité absolue à la Premier League</strong> pour éviter tout flood simultané.
                      </span>
                    ) : (
                      <span className="text-amber-300">
                        Mode Tout Publier actif : tous les matchs de chaque tranche horaire sont planifiés et publiés sans restriction.
                      </span>
                    )}
                  </p>
                </div>
              </div>
              <button
                onClick={handleReapplySlotPriority}
                disabled={isRefreshing}
                className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold transition shrink-0 cursor-pointer shadow-md shadow-sky-950"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? "animate-spin" : ""}`} />
                <span>Réarbitrer créneaux</span>
              </button>
            </div>

            {/* Quick Actions Bar: Debrief all, Enqueue tonight, Reset H-1 */}
            <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/90 p-3.5 rounded-2xl border border-slate-800 shadow-md">
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={handleDispatchAllDebriefs}
                  disabled={isRefreshing}
                  className="px-3.5 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-md shadow-sky-950 cursor-pointer"
                  title="Analyse tous les matchs terminés et diffuse automatiquement leurs débriefs officiels"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>🏁 Envoyer tous les Débriefs Terminés</span>
                </button>

                <button
                  onClick={handleForceEnqueueTonight}
                  disabled={isRefreshing}
                  className="px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-md shadow-amber-950 cursor-pointer"
                  title="Enfile immédiatement les matchs pour publication"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>⚡ Enfiler Pronos du Soir</span>
                </button>

                <button
                  onClick={handleResetTonightMatches}
                  disabled={isRefreshing}
                  className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition flex items-center gap-1.5 border border-slate-700 cursor-pointer"
                  title="Débloque les matchs et relance le cycle automatique H-1"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? "animate-spin" : ""}`} />
                  <span>🔄 Réinitialiser cycle H-1</span>
                </button>
              </div>

              <div className="text-xs text-slate-400 font-medium">
                <span className="text-emerald-400 font-semibold">{finishedDebriefsCount} débrief(s) envoyés</span>
                <span className="mx-2">•</span>
                <span className="text-amber-300">{scheduledPronosCount} en attente H-1</span>
              </div>
            </div>

            {/* Quick Filters: Date & Slot Selection */}
            <div className="space-y-2 pt-1">
              {/* Dynamic Date Filters computed from real matches */}
              <div className="flex flex-wrap items-center gap-1.5">
                <span className="text-xs text-slate-400 font-semibold mr-1">Date :</span>
                <button
                  onClick={() => setMatchDateFilter("ALL")}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition cursor-pointer border ${
                    matchDateFilter === "ALL"
                      ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40"
                      : "bg-slate-900/60 text-slate-400 hover:text-slate-200 border-slate-800"
                  }`}
                >
                  Tous les matchs ({trackedMatches.length})
                </button>
                {uniqueDates.map((d) => (
                  <button
                    key={d}
                    onClick={() => setMatchDateFilter(d)}
                    className={`px-3 py-1 rounded-lg text-xs font-semibold transition cursor-pointer border ${
                      matchDateFilter === d
                        ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40"
                        : "bg-slate-900/60 text-slate-400 hover:text-slate-200 border-slate-800"
                    }`}
                  >
                    {d} ({trackedMatches.filter((m) => m.date === d).length})
                  </button>
                ))}
              </div>

              {/* Slot Priority Filter (Retained vs Skipped duplicates) */}
              <div className="flex flex-wrap items-center gap-1.5">
                <span className="text-xs text-slate-400 font-semibold mr-1">Sélection :</span>
                <button
                  onClick={() => setMatchSlotFilter("ALL")}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition cursor-pointer border ${
                    matchSlotFilter === "ALL"
                      ? "bg-slate-700 text-white border-slate-600"
                      : "bg-slate-900/60 text-slate-400 hover:text-slate-200 border-slate-800"
                  }`}
                >
                  Tous ({trackedMatches.length})
                </button>
                <button
                  onClick={() => setMatchSlotFilter("SCHEDULED_ONLY")}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition cursor-pointer border ${
                    matchSlotFilter === "SCHEDULED_ONLY"
                      ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40"
                      : "bg-slate-900/60 text-slate-400 hover:text-slate-200 border-slate-800"
                  }`}
                >
                  👑 Retenus #1 créneau ({trackedMatches.filter((m) => m.status !== "SKIPPED_SLOT_DUPLICATE").length})
                </button>
                <button
                  onClick={() => setMatchSlotFilter("SKIPPED_ONLY")}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition cursor-pointer border ${
                    matchSlotFilter === "SKIPPED_ONLY"
                      ? "bg-rose-500/20 text-rose-300 border-rose-500/40"
                      : "bg-slate-900/60 text-slate-400 hover:text-slate-200 border-slate-800"
                  }`}
                >
                  ⛔ Doublons écartés ({trackedMatches.filter((m) => m.status === "SKIPPED_SLOT_DUPLICATE").length})
                </button>
              </div>
            </div>

            {isLoading ? (
              <div className="text-center py-16 text-slate-400">
                <RefreshCw className="w-8 h-8 animate-spin mx-auto mb-3 text-emerald-400" />
                <p>Chargement des matchs en cours...</p>
              </div>
            ) : trackedMatches.length === 0 ? (
              <div className="text-center py-16 bg-slate-900/40 rounded-2xl border border-slate-800 text-slate-400">
                <p className="text-base font-semibold text-slate-300 mb-1">
                  Aucun match dans le pipeline pour le moment
                </p>
                <p className="text-xs">
                  Le bot synchronise les matchs automatiquement toutes les 60 minutes.
                </p>
                <button
                  onClick={handleForceRun}
                  className="mt-4 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition cursor-pointer"
                >
                  Synchroniser maintenant
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                {trackedMatches
                  .filter((match) => {
                    // Slot filter
                    if (matchSlotFilter === "SCHEDULED_ONLY" && match.status === "SKIPPED_SLOT_DUPLICATE") return false;
                    if (matchSlotFilter === "SKIPPED_ONLY" && match.status !== "SKIPPED_SLOT_DUPLICATE") return false;

                    // Dynamic date filter
                    if (matchDateFilter === "ALL") return true;
                    return match.date === matchDateFilter;
                  })
                  .map((match) => {
                  const isScheduled = match.status === "SCHEDULED";
                  const isPronoSent = match.status === "PUBLISHED" || Boolean(match.publishedTweetText);
                  const isFinished = match.status === "DEBRIEF_SENT" || Boolean(match.currentLiveScore?.isFinished) || Boolean(match.finalScore);
                  const isDebriefSent = Boolean(match.debriefTweetSent);
                  const isSkippedDuplicate = match.status === "SKIPPED_SLOT_DUPLICATE";
                  const hasLiveScore = match.currentLiveScore !== null && match.currentLiveScore !== undefined;
                  const isPremierLeague = (match.competition || "").toLowerCase().includes("premier league");

                  return (
                    <div
                      key={match.id}
                      className={`rounded-2xl border p-4 transition ${
                        isSkippedDuplicate
                          ? "bg-slate-950/40 border-slate-800/60 opacity-65"
                          : "bg-slate-900/90 border-slate-800 hover:border-slate-700"
                      }`}
                    >
                      {/* Top Bar: Match Header */}
                      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-800/80">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                            {match.competition}
                          </span>
                          {isPremierLeague && (
                            <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-sky-500/20 text-sky-300 border border-sky-500/40">
                              🇬🇧 Premier League
                            </span>
                          )}
                          <span className="text-slate-600">•</span>
                          <span className="text-xs font-mono text-emerald-400 font-bold">
                            {match.date} à {match.kickoffTime}
                          </span>
                        </div>

                        {/* Match Status Badge */}
                        <div className="flex items-center gap-2">
                          {isFinished ? (
                            isDebriefSent ? (
                              <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                                🏁 Terminé & Débriefé
                              </span>
                            ) : (
                              <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-pulse">
                                🏁 Terminé (Débrief en attente)
                              </span>
                            )
                          ) : match.status === "LIVE" ? (
                            <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 animate-pulse">
                              🔴 En Direct {match.currentLiveScore?.liveMinute || ""}
                            </span>
                          ) : isPronoSent ? (
                            <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                              ✅ Prono H-1 Publié
                            </span>
                          ) : isSkippedDuplicate ? (
                            <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-slate-800/90 text-slate-400 border border-slate-700/80">
                              ⛔ Écarté (Anti-Collision {match.kickoffTime})
                            </span>
                          ) : (
                            <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40">
                              👑 Retenu #1 ({match.kickoffTime})
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Main Match Row */}
                      <div className="py-3 flex flex-col md:flex-row md:items-center justify-between gap-4">
                        {/* Teams & Score */}
                        <div className="flex-1">
                          <div className="flex items-center gap-3">
                            <span className="text-base font-black text-white">
                              {match.homeTeam}
                            </span>
                            {hasLiveScore ? (
                              <span className="px-2.5 py-1 bg-slate-800 text-white font-mono font-bold text-sm rounded-lg border border-slate-700">
                                {match.currentLiveScore?.scoreHome} - {match.currentLiveScore?.scoreAway}
                              </span>
                            ) : (
                              <span className="text-xs font-semibold text-slate-400">vs</span>
                            )}
                            <span className="text-base font-black text-white">
                              {match.awayTeam}
                            </span>
                          </div>

                          {/* Prediction & Odd & Slot reason */}
                          <div className="mt-2 flex flex-wrap items-center gap-2">
                            <span className="text-xs text-slate-400">Prono :</span>
                            <span className="text-xs font-bold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/40">
                              🎯 {match.prediction}
                            </span>
                            <span className="text-xs font-bold text-amber-400 bg-amber-950/60 px-2 py-0.5 rounded border border-amber-800/40">
                              @{match.odd}
                            </span>
                          </div>

                          {/* Slot Arbitration Details */}
                          {match.slotSelectionReason && (
                            <div className="mt-2 flex items-center gap-1.5 text-xs">
                              <span className="text-slate-500 font-semibold">Créneau :</span>
                              <span className={isSkippedDuplicate ? "text-rose-300/80 italic text-[11px]" : "text-emerald-400/90 text-[11px] font-medium"}>
                                {match.slotSelectionReason}
                              </span>
                            </div>
                          )}
                        </div>

                        {/* Visual 3-Steps Tracker for this match */}
                        <div className="flex items-center gap-2 bg-slate-950/60 px-3 py-2 rounded-xl border border-slate-800/80">
                          {/* Step 1 */}
                          <div
                            className={`flex items-center gap-1.5 text-xs ${
                              isPronoSent ? "text-emerald-400 font-bold" : "text-slate-400"
                            }`}
                          >
                            <span className="w-5 h-5 rounded-full bg-slate-800 flex items-center justify-center text-[10px]">
                              {isPronoSent ? "✓" : "1"}
                            </span>
                            <span>Prono H-1</span>
                          </div>

                          <ChevronRight className="w-3.5 h-3.5 text-slate-700" />

                          {/* Step 2 */}
                          <div
                            className={`flex items-center gap-1.5 text-xs ${
                              match.goalAlertsSent && match.goalAlertsSent.length > 0
                                ? "text-amber-400 font-bold"
                                : "text-slate-400"
                            }`}
                          >
                            <span className="w-5 h-5 rounded-full bg-slate-800 flex items-center justify-center text-[10px]">
                              {match.goalAlertsSent && match.goalAlertsSent.length > 0 ? "⚡" : "2"}
                            </span>
                            <span>Buts ({match.goalAlertsSent?.length || 0})</span>
                          </div>

                          <ChevronRight className="w-3.5 h-3.5 text-slate-700" />

                          {/* Step 3 */}
                          <div
                            className={`flex items-center gap-1.5 text-xs ${
                              isDebriefSent
                                ? "text-emerald-400 font-bold"
                                : isFinished
                                ? "text-amber-400 font-bold animate-pulse"
                                : "text-slate-400"
                            }`}
                          >
                            <span className="w-5 h-5 rounded-full bg-slate-800 flex items-center justify-center text-[10px]">
                              {isDebriefSent ? "✓" : "3"}
                            </span>
                            <span>Débrief {isDebriefSent ? "Envoyé" : isFinished ? "Prêt" : ""}</span>
                          </div>
                        </div>
                      </div>

                      {/* Bottom Actions Row */}
                      <div className="pt-3 border-t border-slate-800/60 flex flex-wrap items-center justify-between gap-2">
                        {/* Status text */}
                        <div className="text-xs text-slate-400">
                          {match.status === "FAILED_PUBLISH" ? (
                            <span className="text-rose-400 font-semibold flex items-center gap-1">
                              <span>
                                ⚠️ Échec X : {match.publishError || "Vérifiez vos cookies X puis cliquez sur Réessayer."}
                              </span>
                            </span>
                          ) : match.isQueued ? (
                            <span className="text-amber-300 font-semibold flex items-center gap-1.5">
                              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                              <span>En cours d'envoi sur X (file d'attente anti-spam)...</span>
                            </span>
                          ) : isFinished ? (
                            isDebriefSent ? (
                              <span className="text-emerald-300 font-medium">
                                🏁 Débrief officiel publié sur X avec succès !
                              </span>
                            ) : (
                              <span className="text-amber-300 font-semibold">
                                🏁 Match terminé ! Débrief prêt à être diffusé.
                              </span>
                            )
                          ) : isPronoSent ? (
                            <span className="text-emerald-300">
                              ✅ Prono publié sur X. Le robot surveille les buts en direct.
                            </span>
                          ) : isSkippedDuplicate ? (
                            <span className="text-slate-500 italic">
                              ⛔ Non publié : écarté par l'arbitrage anti-collision au profit du match prioritaire de {match.kickoffTime}.
                            </span>
                          ) : (
                            <span className="text-amber-300/90 font-medium">
                              👑 Retenu #1 : publication automatique 1h avant ({match.kickoffTime}).
                            </span>
                          )}
                        </div>

                        {/* Quick Manual Controls */}
                        <div className="flex flex-wrap items-center gap-2">
                          {/* If Match is Finished: Show Debrief actions */}
                          {isFinished ? (
                            <>
                              <button
                                onClick={() => handlePublishDebriefNow(match)}
                                className="px-2.5 py-1 rounded-lg bg-emerald-600/20 text-emerald-300 hover:bg-emerald-600/30 border border-emerald-500/30 text-xs font-semibold transition cursor-pointer flex items-center gap-1"
                                title="Envoie le débrief officiel sur X"
                              >
                                <Send className="w-3 h-3" />
                                <span>{isDebriefSent ? "Renvoyer Débrief" : "Envoyer Débrief sur X"}</span>
                              </button>

                              {(() => {
                                const homeScore = match.currentLiveScore?.scoreHome ?? 0;
                                const awayScore = match.currentLiveScore?.scoreAway ?? 0;
                                const defaultDebrief = `🏁 FIN DU MATCH !\n\n⚽ ${match.homeTeam} ${homeScore} - ${awayScore} ${match.awayTeam}\n🎯 Pronostic : ${match.prediction}\n📊 Cote : @${match.odd}\n\n#Football #${match.homeTeam.replace(/\s+/g, "")} #${match.awayTeam.replace(/\s+/g, "")}`;
                                const debriefContent = match.debriefTweetText || defaultDebrief;
                                return (
                                  <a
                                    href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(debriefContent)}`}
                                    target="_blank"
                                    rel="noreferrer"
                                    className="px-2.5 py-1 rounded-lg bg-sky-600/20 hover:bg-sky-600/30 text-sky-300 border border-sky-500/30 text-xs font-semibold transition flex items-center gap-1"
                                    title="Ouvrir le débrief pré-rempli directement sur Twitter/X"
                                  >
                                    <ExternalLink className="w-3 h-3" />
                                    <span>⚡ Débrief (1 Clic)</span>
                                  </a>
                                );
                              })()}
                            </>
                          ) : (
                            <>
                              {/* Force Publish H-1 Now or Retry */}
                              {!isPronoSent && (
                                <button
                                  onClick={() => handlePublishH1Now(match)}
                                  className="px-2.5 py-1 rounded-lg bg-emerald-600/20 text-emerald-300 hover:bg-emerald-600/30 border border-emerald-500/30 text-xs font-semibold transition cursor-pointer flex items-center gap-1"
                                  title="Publie le prono H-1 immédiatement"
                                >
                                  <Send className="w-3 h-3" />
                                  <span>{match.status === "FAILED_PUBLISH" ? "Réessayer envoi" : "Publier H-1"}</span>
                                </button>
                              )}

                              {/* 1-Click Prono Intent */}
                              {(() => {
                                const defaultText = `🔥 PRONOSTIC DU JOUR\n🏆 ${match.competition}\n⚽ ${match.homeTeam} vs ${match.awayTeam} (${match.kickoffTime})\n\n🎯 Prono : ${match.prediction}\n📈 Cote : @${match.odd}\n\n#Football #${match.homeTeam.replace(/\s+/g, "")} #${match.awayTeam.replace(/\s+/g, "")} #PariSportif`;
                                const tweetContent = match.publishedTweetText || defaultText;
                                return (
                                  <a
                                    href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(tweetContent)}`}
                                    target="_blank"
                                    rel="noreferrer"
                                    className="px-2.5 py-1 rounded-lg bg-sky-600/20 hover:bg-sky-600/30 text-sky-300 border border-sky-500/30 text-xs font-semibold transition flex items-center gap-1"
                                    title="Ouvrir le prono pré-rempli directement sur Twitter/X"
                                  >
                                    <ExternalLink className="w-3 h-3" />
                                    <span>⚡ Prono (1 Clic)</span>
                                  </a>
                                );
                              })()}

                              {/* Test Simulate Goal */}
                              <button
                                onClick={() => handleSimulateGoal(match, "home")}
                                className="px-2.5 py-1 rounded-lg bg-amber-600/20 text-amber-300 hover:bg-amber-600/30 border border-amber-500/30 text-xs font-semibold transition cursor-pointer"
                                title="Simule un but en direct pour tester le tweet instantané"
                              >
                                ⚡ Tester But
                              </button>

                              {/* Test Simulate FT */}
                              <button
                                onClick={() => handleSimulateFT(match)}
                                className="px-2.5 py-1 rounded-lg bg-sky-600/20 text-sky-300 hover:bg-sky-600/30 border border-sky-500/30 text-xs font-semibold transition cursor-pointer"
                                title="Simule le coup de sifflet final et le débrief"
                              >
                                🏁 Tester Fin
                              </button>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* TAB 2: TWEETS PUBLIÉS SUR X */}
        {activeTab === "tweets" && (
          <div className="space-y-4">
            {/* Filter Pills */}
            <div className="flex items-center gap-2 pb-2">
              <button
                onClick={() => setTweetFilter("ALL")}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                  tweetFilter === "ALL"
                    ? "bg-slate-200 text-slate-900"
                    : "bg-slate-900 text-slate-400 hover:text-white"
                }`}
              >
                Tous ({publishedTweets.length})
              </button>
              <button
                onClick={() => setTweetFilter("PRONO_H1")}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                  tweetFilter === "PRONO_H1"
                    ? "bg-emerald-500 text-slate-950 font-black"
                    : "bg-slate-900 text-slate-400 hover:text-white"
                }`}
              >
                🎯 Pronos H-1
              </button>
              <button
                onClick={() => setTweetFilter("GOAL_LIVE")}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                  tweetFilter === "GOAL_LIVE"
                    ? "bg-amber-500 text-slate-950 font-black"
                    : "bg-slate-900 text-slate-400 hover:text-white"
                }`}
              >
                ⚡ Buts en Direct
              </button>
              <button
                onClick={() => setTweetFilter("RECAP_FT")}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                  tweetFilter === "RECAP_FT"
                    ? "bg-sky-500 text-slate-950 font-black"
                    : "bg-slate-900 text-slate-400 hover:text-white"
                }`}
              >
                🏁 Débriefs Fin de Match
              </button>
            </div>

            {/* Tweets Feed */}
            {filteredTweets.length === 0 ? (
              <div className="text-center py-16 bg-slate-900/40 rounded-2xl border border-slate-800 text-slate-400">
                <p className="text-sm font-semibold text-slate-300 mb-1">
                  Aucun tweet dans cette catégorie pour l'instant
                </p>
                <p className="text-xs">
                  Les tweets s'affichent ici dès qu'ils sont publiés sur votre compte X.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredTweets.map((tweet) => {
                  const isProno = tweet.type === "PRONO_H1";
                  const isGoal = tweet.type === "GOAL_LIVE";
                  const isDebrief = tweet.type === "RECAP_FT";

                  return (
                    <div
                      key={tweet.id}
                      className="bg-slate-900/90 rounded-2xl border border-slate-800 p-4 hover:border-slate-700 transition space-y-3"
                    >
                      {/* Tweet Top Bar */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {isProno && (
                            <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                              🎯 Pronostic H-1
                            </span>
                          )}
                          {isGoal && (
                            <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40">
                              ⚡ But en Direct
                            </span>
                          )}
                          {isDebrief && (
                            <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-sky-500/20 text-sky-300 border border-sky-500/40">
                              🏁 Débrief Fin de Match
                            </span>
                          )}
                          {tweet.matchTitle && (
                            <span className="text-xs text-slate-400 font-semibold">
                              {tweet.matchTitle}
                            </span>
                          )}
                        </div>

                        {/* Time & Link */}
                        <div className="flex items-center gap-2">
                          {tweet.publishedAt && (
                            <span className="text-xs text-slate-400 font-mono">
                              {new Date(tweet.publishedAt).toLocaleTimeString("fr-FR", {
                                hour: "2-digit",
                                minute: "2-digit",
                              })}
                            </span>
                          )}

                          {tweet.tweetId && !tweet.tweetId.startsWith("sim-") && !tweet.tweetId.startsWith("auto-") ? (
                            <a
                              href={`https://x.com/i/web/status/${tweet.tweetId}`}
                              target="_blank"
                              rel="noreferrer"
                              className="flex items-center gap-1 text-xs text-emerald-400 hover:text-emerald-300 font-semibold transition"
                            >
                              <span>Voir sur X</span>
                              <ExternalLink className="w-3.5 h-3.5" />
                            </a>
                          ) : (
                            <a
                              href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(tweet.tweetText)}`}
                              target="_blank"
                              rel="noreferrer"
                              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-sky-500/20 text-sky-300 hover:bg-sky-500/30 font-semibold text-xs border border-sky-500/30 transition shadow-sm"
                              title="Publier ce tweet instantanément sur votre compte X"
                            >
                              <span>⚡ Publier sur X en 1 Clic</span>
                              <ExternalLink className="w-3 h-3" />
                            </a>
                          )}
                        </div>
                      </div>

                      {/* Tweet Text Box */}
                      <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800/80 font-mono text-xs text-slate-200 whitespace-pre-wrap leading-relaxed">
                        {tweet.tweetText}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </main>

      {/* MODAL IDENTIFIANTS X (100% COOKIES GRATUIT - ZÉRO API PAYANTE) */}
      {isCredsModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Key className="w-5 h-5 text-emerald-400" />
                <h3 className="font-bold text-base text-white">Cookies Compte X (0€ · Sans API)</h3>
              </div>
              <button
                onClick={() => setIsCredsModalOpen(false)}
                className="text-slate-400 hover:text-white text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="bg-slate-950/90 p-3 rounded-xl border border-slate-800 text-[11px] text-slate-300 space-y-1">
              <p className="font-bold text-emerald-300">Comment récupérer vos cookies en 10 secondes :</p>
              <ol className="list-decimal list-inside space-y-0.5 text-slate-400">
                <li>Ouvrez <strong className="text-white">x.com</strong> connecté dans Chrome / Edge / Brave.</li>
                <li>Appuyez sur <strong className="text-white">F12</strong> ➔ onglet <strong className="text-white">Application</strong> ➔ <strong className="text-white">Cookies</strong> ➔ <code className="text-emerald-300">https://x.com</code>.</li>
                <li>Copiez les valeurs de <code className="text-emerald-300 font-mono">auth_token</code> et <code className="text-emerald-300 font-mono">ct0</code> ci-dessous.</li>
              </ol>
            </div>

            {/* Honest 2-Mode selection */}
            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-2">
              <label className="block text-xs font-bold text-slate-300">
                Mode de publication :
              </label>
              <div className="grid grid-cols-2 gap-2 text-center">
                <button
                  type="button"
                  onClick={() => setPublishingMode("LIVE_COOKIES")}
                  className={`py-2 px-2 rounded-lg text-xs font-bold cursor-pointer transition border ${
                    publishingMode === "LIVE_COOKIES"
                      ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40"
                      : "bg-slate-900 text-slate-400 border-slate-800"
                  }`}
                >
                  🍪 Cookies X (Réel)
                </button>
                <button
                  type="button"
                  onClick={() => setPublishingMode("SIMULATION")}
                  className={`py-2 px-2 rounded-lg text-xs font-bold cursor-pointer transition border ${
                    publishingMode === "SIMULATION"
                      ? "bg-sky-500/20 text-sky-300 border-sky-500/40"
                      : "bg-slate-900 text-slate-400 border-slate-800"
                  }`}
                >
                  🧪 Simulation Test
                </button>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Cookie auth_token :
                </label>
                <input
                  type="password"
                  value={authToken}
                  onChange={(e) => setAuthToken(e.target.value.trim())}
                  placeholder="Collez la valeur de auth_token..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Cookie ct0 :
                </label>
                <input
                  type="text"
                  value={ct0}
                  onChange={(e) => setCt0(e.target.value.trim())}
                  placeholder="Collez la valeur de ct0..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              {/* Optional Booster 1 */}
              <button
                type="button"
                onClick={() => setShowBoosters(!showBoosters)}
                className="text-[11px] text-emerald-400 hover:text-emerald-300 font-semibold cursor-pointer"
              >
                {showBoosters ? "▾ Masquer compte Booster (auto-like)" : "▸ Ajouter un compte Booster optionnel (auto-like)"}
              </button>

              {showBoosters && (
                <div className="space-y-2 p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <input
                    type="password"
                    value={booster1AuthToken}
                    onChange={(e) => setBooster1AuthToken(e.target.value.trim())}
                    placeholder="Booster 1 auth_token (optionnel)"
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs font-mono text-white"
                  />
                  <input
                    type="text"
                    value={booster1Ct0}
                    onChange={(e) => setBooster1Ct0(e.target.value.trim())}
                    placeholder="Booster 1 ct0 (optionnel)"
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs font-mono text-white"
                  />
                </div>
              )}
            </div>

            {/* Honest Live Diagnostic Result */}
            {testDiagnostic && (
              <div
                className={`p-3 rounded-xl border text-xs space-y-1 ${
                  testDiagnostic.success
                    ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-300"
                    : "bg-rose-500/10 border-rose-500/30 text-rose-200"
                }`}
              >
                <p className="font-bold">{testDiagnostic.message}</p>
                {testDiagnostic.explanation && (
                  <p className="text-[11px] opacity-85">{testDiagnostic.explanation}</p>
                )}
                {testDiagnostic.solution && (
                  <p className="text-[11px] text-amber-200 font-medium">➔ {testDiagnostic.solution}</p>
                )}
              </div>
            )}

            {/* Action Buttons */}
            <div className="pt-2 flex items-center justify-between gap-3">
              <button
                onClick={handleTestCreds}
                disabled={isTestingCreds}
                className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold transition cursor-pointer flex items-center gap-1.5"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isTestingCreds ? "animate-spin text-emerald-400" : ""}`} />
                <span>Tester sur X</span>
              </button>

              <button
                onClick={handleSaveCreds}
                disabled={isTestingCreds}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition cursor-pointer shadow-lg shadow-emerald-950"
              >
                {isTestingCreds ? "Vérification..." : "Enregistrer & Vérifier"}
              </button>
            </div>

            {isCookieHealthy && !testDiagnostic && (
              <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 shrink-0" />
                <span>
                  Connecté {cookieHealth.username ? `(@${cookieHealth.username})` : ""} · Les cookies sont stockés uniquement dans <code className="font-mono">data/</code> (exclus de Git & du ZIP).
                </span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* MODAL 2: TERMINAL CLI & GITHUB GUIDE MODAL */}
      {isCliModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="bg-slate-900 border border-emerald-500/40 rounded-3xl max-w-2xl w-full p-6 space-y-5 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            {/* Close Button */}
            <button
              onClick={() => setIsCliModalOpen(false)}
              className="absolute top-5 right-5 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Header */}
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shadow-lg shrink-0">
                <Terminal className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base sm:text-lg font-extrabold text-white">
                    Exporter sur GitHub & Lancer dans un Terminal
                  </h3>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    100% Gratuit
                  </span>
                </div>
                <p className="text-xs text-slate-400">
                  Installez les outils requis sur votre machine pour publier le code sur votre GitHub et faire tourner le bot sans API payante.
                </p>
              </div>
            </div>

            {/* Direct ZIP Download Banner */}
            <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-indigo-950 p-4 rounded-2xl border border-emerald-500/40 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xl">
              <div>
                <h4 className="text-sm font-extrabold text-white flex items-center gap-2">
                  <Download className="w-4 h-4 text-emerald-400" />
                  <span>1. Télécharger le code source du projet</span>
                </h4>
                <p className="text-xs text-slate-300 mt-0.5">
                  Archive complète prête à l'emploi (sans node_modules ni cache).
                </p>
              </div>
              <a
                href="/api/export-project-zip"
                download="football-x-bot.zip"
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 shadow-lg shadow-emerald-950/50 cursor-pointer shrink-0"
              >
                <Download className="w-4 h-4" />
                <span>Télécharger football-x-bot.zip</span>
              </a>
            </div>

            {/* Section: Software to Install */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <span>2. Ce qu'il faut installer sur votre PC :</span>
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* Tool 1: GitHub Desktop */}
                <div className="bg-slate-950 p-3.5 rounded-2xl border border-emerald-500/30 flex flex-col justify-between space-y-2">
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white text-xs">GitHub Desktop</span>
                      <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.5 rounded font-semibold">
                        Recommandé
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                      L'outil officiel pour publier sur GitHub en 3 clics sans taper de commande.
                    </p>
                  </div>
                  <a
                    href="https://desktop.github.com"
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-300 hover:text-white text-xs font-bold transition border border-slate-700"
                  >
                    <span>Télécharger Desktop</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>

                {/* Tool 2: Git CLI */}
                <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 flex flex-col justify-between space-y-2">
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white text-xs">Git CLI (Git Bash)</span>
                      <span className="text-[10px] bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded font-mono">
                        Terminal
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                      Le moteur Git standard pour Windows, Mac et Linux (nécessaire pour le terminal).
                    </p>
                  </div>
                  <a
                    href="https://git-scm.com/downloads"
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold transition border border-slate-700"
                  >
                    <span>Télécharger Git</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>

                {/* Tool 3: Node.js */}
                <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 flex flex-col justify-between space-y-2">
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white text-xs">Node.js (LTS v20+)</span>
                      <span className="text-[10px] bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded font-mono">
                        Runtime
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                      Nécessaire pour faire tourner le bot chez vous avec npm install et npm run bot.
                    </p>
                  </div>
                  <a
                    href="https://nodejs.org"
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold transition border border-slate-700"
                  >
                    <span>Télécharger Node.js</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            </div>

            {/* Section: Steps to publish on GitHub */}
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Code2 className="w-4 h-4 text-emerald-400" />
                <span>3. Comment publier sur GitHub en 1 minute :</span>
              </h4>

              <div className="space-y-2 text-xs text-slate-300">
                <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-1">
                  <span className="font-bold text-emerald-300">Méthode la plus simple (GitHub Desktop) :</span>
                  <ol className="list-decimal list-inside space-y-1 text-slate-400">
                    <li>Dézippez le fichier <code className="text-white">football-x-bot.zip</code> dans un dossier sur votre PC.</li>
                    <li>Ouvrez <strong>GitHub Desktop</strong> et connectez votre compte GitHub.</li>
                    <li>Faites <strong>File &gt; Add local repository...</strong> et choisissez le dossier décompressé.</li>
                    <li>Cliquez sur <strong>"Create a repository"</strong> puis <strong>"Publish repository"</strong>. C'est en ligne !</li>
                  </ol>
                </div>

                <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-2 font-mono">
                  <div className="flex items-center justify-between text-slate-400 text-[11px] font-sans">
                    <span className="font-bold text-emerald-300">Méthode Terminal classique :</span>
                    <button
                      onClick={() =>
                        handleCopyCommand(
                          'git init\ngit add .\ngit commit -m "feat: Football X Bot 100% Gratuit"\ngit branch -M main\n# git remote add origin https://github.com/VOTRE_PSEUDO/football-x-bot.git\n# git push -u origin main'
                        )
                      }
                      className="flex items-center gap-1 text-emerald-400 hover:text-emerald-300 transition cursor-pointer font-sans"
                    >
                      {copiedCommand?.includes("git init") ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedCommand?.includes("git init") ? "Copié !" : "Copier commandes Git"}</span>
                    </button>
                  </div>
                  <pre className="text-slate-300 text-[11px] leading-relaxed overflow-x-auto whitespace-pre-wrap select-all">
{`git init
git add .
git commit -m "feat: Football X Bot 100% Gratuit"
git branch -M main
git remote add origin https://github.com/VOTRE_PSEUDO/football-x-bot.git
git push -u origin main`}
                  </pre>
                </div>
              </div>
            </div>

            {/* Section: Running the bot */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                <Terminal className="w-4 h-4 text-emerald-400" />
                <span>4. Commandes pour faire tourner le bot chez vous :</span>
              </h4>

              {/* Step 1: Install */}
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1.5 font-mono text-xs">
                <div className="flex items-center justify-between text-slate-400 text-[11px] font-sans">
                  <span className="font-semibold text-slate-300">A. Installer les dépendances</span>
                  <button
                    onClick={() => handleCopyCommand("npm install")}
                    className="flex items-center gap-1 text-emerald-400 hover:text-emerald-300 transition cursor-pointer"
                  >
                    {copiedCommand === "npm install" ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedCommand === "npm install" ? "Copié !" : "Copier"}</span>
                  </button>
                </div>
                <div className="text-emerald-300 select-all">$ npm install</div>
              </div>

              {/* Step 2: Interactive CLI */}
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1.5 font-mono text-xs">
                <div className="flex items-center justify-between text-slate-400 text-[11px] font-sans">
                  <span className="font-semibold text-slate-300">B. Lancer le Menu Interactif (Configuration X, Test Tweet, Sync)</span>
                  <button
                    onClick={() => handleCopyCommand("npm run cli")}
                    className="flex items-center gap-1 text-emerald-400 hover:text-emerald-300 transition cursor-pointer"
                  >
                    {copiedCommand === "npm run cli" ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedCommand === "npm run cli" ? "Copié !" : "Copier"}</span>
                  </button>
                </div>
                <div className="text-emerald-300 select-all">$ npm run cli</div>
              </div>

              {/* Step 3: Run as Daemon 24/7 */}
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1.5 font-mono text-xs">
                <div className="flex items-center justify-between text-slate-400 text-[11px] font-sans">
                  <span className="font-semibold text-slate-300">C. Démarrer le Bot Autonome en continu (24h/24)</span>
                  <button
                    onClick={() => handleCopyCommand("npm run bot")}
                    className="flex items-center gap-1 text-emerald-400 hover:text-emerald-300 transition cursor-pointer"
                  >
                    {copiedCommand === "npm run bot" ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedCommand === "npm run bot" ? "Copié !" : "Copier"}</span>
                  </button>
                </div>
                <div className="text-emerald-300 select-all">$ npm run bot</div>
              </div>
            </div>

            {/* 24/7 Free Automation via GitHub Actions Cron */}
            <div className="bg-gradient-to-r from-sky-950/60 via-slate-950 to-slate-950 p-4 rounded-2xl border border-sky-500/30 space-y-2">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 text-sky-300 font-bold text-xs uppercase tracking-wider">
                  <Radio className="w-4 h-4" />
                  <span>5. Automatisation 24h/24 gratuite (même onglet fermé)</span>
                </div>
                <button
                  onClick={() => handleCopyCommand(`${window.location.origin}/api/cron/tick`)}
                  className="flex items-center gap-1 text-sky-400 hover:text-sky-300 text-[11px] font-semibold cursor-pointer"
                >
                  {copiedCommand?.includes("/api/cron/tick") ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCommand?.includes("/api/cron/tick") ? "Copié !" : "Copier URL Cron"}</span>
                </button>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Le workflow <code className="text-sky-300 font-mono">.github/workflows/autopilot-cron.yml</code> est déjà inclus dans le ZIP ! Ajoutez simplement le secret GitHub <code className="text-emerald-300 font-mono">BOT_APP_URL</code> (URL de votre serveur hébergé) : GitHub Actions appellera automatiquement <code className="text-sky-300 font-mono">/api/cron/tick</code> toutes les 5 minutes gratuitement.
              </p>
            </div>

            {/* Zero Paid API & Cookie Security Highlight */}
            <div className="bg-gradient-to-r from-emerald-950/60 via-slate-950 to-slate-950 p-4 rounded-2xl border border-emerald-500/30 space-y-2">
              <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs uppercase tracking-wider">
                <Sparkles className="w-4 h-4" />
                <span>0 € / Mois · 100% Cookies · Confidentialité garantie</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Le bot publie directement avec vos cookies <code className="text-emerald-300 font-mono">auth_token</code> et <code className="text-emerald-300 font-mono">ct0</code> (sans API Twitter payante). Vos cookies sont isolés dans <code className="text-emerald-300 font-mono">data/</code> et <strong>automatiquement exclus</strong> de <code className="font-mono">.gitignore</code> et du fichier <code className="font-mono">.zip</code>.
              </p>
            </div>

            {/* Footer Buttons */}
            <div className="flex items-center justify-between pt-2 border-t border-slate-800">
              <a
                href="/api/export-project-zip"
                download="football-x-bot.zip"
                className="flex items-center gap-2 text-emerald-400 hover:text-emerald-300 text-xs font-bold"
              >
                <Download className="w-4 h-4" />
                <span>Télécharger football-x-bot.zip</span>
              </a>

              <button
                onClick={() => setIsCliModalOpen(false)}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition cursor-pointer shadow-lg shadow-emerald-950"
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
