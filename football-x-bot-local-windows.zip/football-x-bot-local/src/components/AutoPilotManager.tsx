import React, { useState, useEffect } from "react";
import {
  Zap,
  Play,
  Pause,
  Clock,
  CheckCircle,
  AlertCircle,
  ExternalLink,
  Bot,
  Flame,
  ShieldCheck,
  RotateCw,
  Sparkles,
  ArrowRight,
  ListFilter,
  CheckCheck,
} from "lucide-react";
import { FootballMatch, PublishedTweetLog, AutoPilotConfig } from "../types";

interface AutoPilotManagerProps {
  autoPilotConfig: AutoPilotConfig;
  onUpdateConfig: (config: AutoPilotConfig) => void;
  matches: FootballMatch[];
  publishedLogs: PublishedTweetLog[];
  authToken: string;
  ct0: string;
  onForceRunAutoPilot: () => void;
  isAutoPilotRunning: boolean;
  nextTriggerCountdown: number; // in seconds
}

export const AutoPilotManager: React.FC<AutoPilotManagerProps> = ({
  autoPilotConfig,
  onUpdateConfig,
  matches,
  publishedLogs,
  authToken,
  ct0,
  onForceRunAutoPilot,
  isAutoPilotRunning,
  nextTriggerCountdown,
}) => {
  const isCookiesConfigured = Boolean(authToken && ct0 && authToken.length > 10);

  // Find upcoming matches that will be handled by Auto-Pilot
  const upcomingAutoMatches = matches.filter(
    (m) => m.status === "UPCOMING" || m.status === "READY_FOR_PRONO" || m.status === "LIVE"
  );

  const formatCountdown = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  return (
    <div className="space-y-6">
      {/* Hero Auto-Pilot Status Card */}
      <div className="bg-[#16161a] border border-slate-800 rounded-2xl p-6 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex items-center gap-2.5 flex-wrap">
              <div
                className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold border ${
                  autoPilotConfig.isEnabled
                    ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                    : "bg-amber-500/10 text-amber-400 border-amber-500/20"
                }`}
              >
                <div
                  className={`w-2 h-2 rounded-full ${
                    autoPilotConfig.isEnabled ? "bg-emerald-400 animate-ping" : "bg-amber-400"
                  }`}
                />
                <span>
                  {autoPilotConfig.isEnabled
                    ? "AUTO-PILOTE X : ACTIF & EN VEILLE CONTINUE"
                    : "AUTO-PILOTE X : EN PAUSE"}
                </span>
              </div>

              {isCookiesConfigured ? (
                <span className="flex items-center gap-1 text-[11px] font-semibold text-indigo-300 bg-indigo-950/40 px-2.5 py-1 rounded-full border border-indigo-800/60">
                  <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
                  Mode Direct Réel (Cookies X Validés)
                </span>
              ) : (
                <span className="flex items-center gap-1 text-[11px] font-semibold text-amber-300 bg-amber-950/40 px-2.5 py-1 rounded-full border border-amber-800/60">
                  <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
                  Mode Simulation / Web Intent
                </span>
              )}
            </div>

            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Publication Automatique 100% Autonome sur X
            </h2>
            <p className="text-xs text-slate-400 leading-relaxed">
              Le robot surveille l'horloge des matchs en continu. À <strong>H-1h (60 minutes avant le coup d'envoi)</strong>, il génère le pronostic avec <strong>Mistral AI</strong> et le publie automatiquement sur X. Dès le <strong>coup de sifflet final (FT)</strong>, il publie le récapitulatif avec score et bilan.
            </p>
          </div>

          {/* Action buttons & Next trigger box */}
          <div className="flex flex-col sm:flex-row items-stretch lg:items-center gap-3 shrink-0">
            {autoPilotConfig.isEnabled && (
              <div className="bg-[#1c1c22] border border-slate-700/80 rounded-xl p-3 text-center sm:text-right">
                <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">
                  Prochaine vérification
                </span>
                <span className="text-lg font-mono font-bold text-emerald-400">
                  {formatCountdown(nextTriggerCountdown)}
                </span>
              </div>
            )}

            <button
              onClick={() =>
                onUpdateConfig({
                  ...autoPilotConfig,
                  isEnabled: !autoPilotConfig.isEnabled,
                })
              }
              className={`flex items-center justify-center gap-2 px-5 py-3 rounded-xl font-bold text-xs transition shadow-lg ${
                autoPilotConfig.isEnabled
                  ? "bg-amber-600 hover:bg-amber-500 active:bg-amber-700 text-white shadow-amber-950/40"
                  : "bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white shadow-emerald-950/40"
              }`}
            >
              {autoPilotConfig.isEnabled ? (
                <>
                  <Pause className="w-4 h-4" />
                  <span>Mettre en Pause</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-current" />
                  <span>Activer la Publication Auto</span>
                </>
              )}
            </button>

            <button
              onClick={onForceRunAutoPilot}
              disabled={isAutoPilotRunning}
              className="flex items-center justify-center gap-2 px-4 py-3 bg-[#1c1c22] hover:bg-slate-800 active:bg-slate-700 disabled:opacity-50 text-slate-200 border border-slate-700/80 rounded-xl text-xs font-bold transition"
            >
              <RotateCw className={`w-4 h-4 ${isAutoPilotRunning ? "animate-spin text-indigo-400" : ""}`} />
              <span>{isAutoPilotRunning ? "Publication en cours..." : "Forcer la Publication Immédiate"}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Auto-Pilot Rules & Controls Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Rule 1: H-1h Pronos */}
        <div className="bg-[#16161a] border border-slate-800 rounded-2xl p-5 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-indigo-500/10 text-indigo-400 rounded-lg">
                <Clock className="w-4 h-4" />
              </div>
              <h3 className="text-sm font-bold text-white">Déclencheur H-1h</h3>
            </div>
            <input
              type="checkbox"
              checked={autoPilotConfig.autoPostPronoH1}
              onChange={(e) =>
                onUpdateConfig({
                  ...autoPilotConfig,
                  autoPostPronoH1: e.target.checked,
                })
              }
              className="w-4 h-4 rounded text-indigo-600 accent-indigo-600 bg-[#0d0d0f] border-slate-700"
            />
          </div>
          <p className="text-xs text-slate-400">
            Publie automatiquement le tweet d'analyse et de pronostic 60 minutes avant le début de chaque match.
          </p>
          <div className="text-[11px] font-mono text-emerald-400 bg-[#0d0d0f] p-2 rounded-lg border border-slate-800 flex items-center gap-1.5">
            <CheckCircle className="w-3.5 h-3.5" />
            <span>Format strict X &lt; 270 caractères</span>
          </div>
        </div>

        {/* Rule 2: Post-match Recap */}
        <div className="bg-[#16161a] border border-slate-800 rounded-2xl p-5 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-lg">
                <CheckCheck className="w-4 h-4" />
              </div>
              <h3 className="text-sm font-bold text-white">Bilan Fin de Match</h3>
            </div>
            <input
              type="checkbox"
              checked={autoPilotConfig.autoPostRecapFT}
              onChange={(e) =>
                onUpdateConfig({
                  ...autoPilotConfig,
                  autoPostRecapFT: e.target.checked,
                })
              }
              className="w-4 h-4 rounded text-indigo-600 accent-indigo-600 bg-[#0d0d0f] border-slate-700"
            />
          </div>
          <p className="text-xs text-slate-400">
            Publie le récapitulatif officiel dès que le match passe à l'état Terminé (FT) avec score et validation du prono.
          </p>
          <div className="text-[11px] font-mono text-indigo-400 bg-[#0d0d0f] p-2 rounded-lg border border-slate-800 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Calcul ROI & Emojis ✅ / ❌</span>
          </div>
        </div>

        {/* Rule 3: Tone & Cadence */}
        <div className="bg-[#16161a] border border-slate-800 rounded-2xl p-5 space-y-3">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-amber-500/10 text-amber-400 rounded-lg">
              <Flame className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-white">Tonalité & Intervalle</h3>
          </div>
          <div className="space-y-2">
            <select
              value={autoPilotConfig.tone}
              onChange={(e) =>
                onUpdateConfig({
                  ...autoPilotConfig,
                  tone: e.target.value as any,
                })
              }
              className="w-full bg-[#0d0d0f] border border-slate-800 rounded-xl p-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
            >
              <option value="tipster">Tipster Pro & Value Bet</option>
              <option value="viral">Viral & Énergique (High Engagement)</option>
              <option value="expert">Analyste Tactique & Statistiques</option>
              <option value="minimal">Minimaliste & Sobre</option>
            </select>
          </div>
          <p className="text-[11px] text-slate-500">
            Adapte le vocabulaire et les emojis générés par l'IA Gemini.
          </p>
        </div>
      </div>

      {/* Two columns: Upcoming Auto Queue vs. Published History */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Queue */}
        <div className="lg:col-span-6 bg-[#16161a] border border-slate-800 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <ListFilter className="w-4 h-4 text-indigo-400" />
              <h3 className="text-sm font-bold text-white">
                File d'Attente des Matchs Pris en Charge ({upcomingAutoMatches.length})
              </h3>
            </div>
            <span className="text-[11px] font-mono text-slate-400 bg-[#1c1c22] px-2 py-0.5 rounded border border-slate-700/60">
              Surveillance Active
            </span>
          </div>

          <div className="space-y-2.5 max-h-[380px] overflow-y-auto">
            {upcomingAutoMatches.length === 0 ? (
              <div className="text-center py-8 text-slate-500 text-xs">
                Aucun match en attente. Synchronisez les matchs récents via l'onglet Matchs.
              </div>
            ) : (
              upcomingAutoMatches.map((m) => {
                const isPronoPosted = m.status === "PRONO_PUBLISHED" || m.status === "RECAP_PUBLISHED";
                const isRecapPosted = m.status === "RECAP_PUBLISHED";

                return (
                  <div
                    key={m.id}
                    className="p-3 bg-[#0d0d0f] border border-slate-800 rounded-xl flex items-center justify-between gap-3 text-xs"
                  >
                    <div className="space-y-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white truncate">
                          {m.homeTeam} 🆚 {m.awayTeam}
                        </span>
                        <span className="text-[10px] text-indigo-400 font-mono bg-indigo-950/40 px-1.5 py-0.5 rounded border border-indigo-800/40">
                          {m.kickoffTime}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 truncate">
                        {m.league} · {m.stadium || "Stade Principal"}
                      </p>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <span
                        className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${
                          isPronoPosted
                            ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                            : "bg-indigo-500/10 text-indigo-300 border-indigo-500/20"
                        }`}
                      >
                        {isPronoPosted ? "Prono Publié" : "Prêt H-1h"}
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right: Published Logs */}
        <div className="lg:col-span-6 bg-[#16161a] border border-slate-800 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Bot className="w-4 h-4 text-emerald-400" />
              <h3 className="text-sm font-bold text-white">
                Historique des Publications Récentes ({publishedLogs.length})
              </h3>
            </div>
            <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-800/60">
              Direct X
            </span>
          </div>

          <div className="space-y-2.5 max-h-[380px] overflow-y-auto font-mono text-xs">
            {publishedLogs.length === 0 ? (
              <div className="text-center py-8 text-slate-500 text-xs font-sans">
                Aucun tweet publié pour le moment. Cliquez sur "Forcer la Publication" ou lancez le simulateur pour voir le premier tweet !
              </div>
            ) : (
              publishedLogs.map((log) => (
                <div
                  key={log.id}
                  className="p-3 bg-[#0d0d0f] border border-slate-800 rounded-xl space-y-2"
                >
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-bold text-white font-sans flex items-center gap-1.5">
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      {log.matchTitle}
                    </span>
                    <span className="text-[10px] text-slate-400">{log.publishedAt}</span>
                  </div>

                  <p className="text-[11px] font-sans text-slate-300 bg-[#16161a] p-2.5 rounded-lg border border-slate-800/80 whitespace-pre-line leading-relaxed">
                    {log.tweetText}
                  </p>

                  <div className="flex items-center justify-between text-[10px] pt-1">
                    <span className="text-emerald-400 font-semibold">
                      {log.mode === "real_x_api" ? "✅ En direct sur X" : "⚡ Exécuté via Playwright"}
                    </span>
                    {log.tweetUrl && (
                      <a
                        href={log.tweetUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="text-indigo-400 hover:text-indigo-300 flex items-center gap-1 font-semibold"
                      >
                        <span>Voir sur X</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
