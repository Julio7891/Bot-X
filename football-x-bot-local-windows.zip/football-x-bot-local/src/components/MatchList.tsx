import React, { useState } from "react";
import { Clock, Trophy, Sparkles, Send, CheckCircle2, AlertCircle, Plus, RefreshCw, Filter, Flame, ChevronRight, Eye, Calendar, Radio, Activity } from "lucide-react";
import { FootballMatch, PronoResult, RecapResult } from "../types";

interface MatchListProps {
  matches: FootballMatch[];
  onOpenPronoModal: (match: FootballMatch) => void;
  onOpenRecapModal: (match: FootballMatch) => void;
  onSendToSimulator: (tweetText: string) => void;
  onAddNewMatch: () => void;
  onRefreshFixtures: () => void;
  onOpenApiSettings?: () => void;
  isRefreshingFixtures?: boolean;
}

export const MatchList: React.FC<MatchListProps> = ({
  matches,
  onOpenPronoModal,
  onOpenRecapModal,
  onSendToSimulator,
  onAddNewMatch,
  onRefreshFixtures,
  onOpenApiSettings,
  isRefreshingFixtures = false,
}) => {
  const [selectedLeague, setSelectedLeague] = useState<string>("ALL");
  const [selectedStatus, setSelectedStatus] = useState<string>("ALL");

  const leagues = Array.from(new Set(matches.map((m) => m.league)));

  const filteredMatches = matches.filter((match) => {
    if (selectedLeague !== "ALL" && match.league !== selectedLeague) return false;
    if (selectedStatus === "READY_FOR_PRONO" && match.status !== "READY_FOR_PRONO") return false;
    if (selectedStatus === "LIVE" && match.status !== "LIVE") return false;
    if (selectedStatus === "PUBLISHED" && match.status !== "PRONO_PUBLISHED" && match.status !== "RECAP_PUBLISHED") return false;
    if (selectedStatus === "FINISHED" && match.status !== "FINISHED" && match.status !== "RECAP_PUBLISHED") return false;
    return true;
  });

  return (
    <div className="space-y-5">
      {/* Filters & Actions Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#16161a] p-4 rounded-2xl border border-slate-800 backdrop-blur-sm shadow-xl">
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-400 mr-2">
            <Filter className="w-3.5 h-3.5 text-indigo-400" />
            <span>Filtrer :</span>
          </div>

          <button
            onClick={() => setSelectedLeague("ALL")}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition ${
              selectedLeague === "ALL"
                ? "bg-indigo-600 text-white shadow-md shadow-indigo-950/40"
                : "bg-[#1c1c22] text-slate-400 hover:text-slate-200 border border-slate-800"
            }`}
          >
            Tous les championnats ({matches.length})
          </button>

          {leagues.map((league) => (
            <button
              key={league}
              onClick={() => setSelectedLeague(league)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition ${
                selectedLeague === league
                  ? "bg-indigo-600 text-white shadow-md shadow-indigo-950/40"
                  : "bg-[#1c1c22] text-slate-400 hover:text-slate-200 border border-slate-800"
              }`}
            >
              {league}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onRefreshFixtures}
            disabled={isRefreshingFixtures}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-300 bg-[#1c1c22] hover:bg-slate-800 active:bg-slate-700 disabled:opacity-50 rounded-xl border border-slate-700/80 transition"
            title="Synchroniser avec les vraies données ESPN / Football-Data"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-indigo-400 ${isRefreshingFixtures ? "animate-spin" : ""}`} />
            <span>{isRefreshingFixtures ? "Chargement API..." : "📡 Sync Vrais Matchs (API Foot)"}</span>
          </button>

          {onOpenApiSettings && (
            <button
              onClick={onOpenApiSettings}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-indigo-300 bg-indigo-950/40 hover:bg-indigo-900/50 rounded-xl border border-indigo-800/70 transition"
            >
              <Radio className="w-3.5 h-3.5" />
              <span>Connecteurs API</span>
            </button>
          )}

          <button
            onClick={onAddNewMatch}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 rounded-xl shadow-lg shadow-indigo-950/40 transition"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Ajouter</span>
          </button>
        </div>
      </div>

      {/* Match Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredMatches.map((match) => {
          const isHMinusOne = match.status === "READY_FOR_PRONO";
          const isLive = match.status === "LIVE";
          const isFinished = match.status === "FINISHED" || match.status === "RECAP_PUBLISHED";
          const hasProno = !!match.pronoData;
          const hasRecap = !!match.recapData;

          return (
            <div
              key={match.id}
              className={`bg-[#16161a] rounded-2xl border transition-all duration-300 flex flex-col justify-between overflow-hidden shadow-xl hover:border-slate-700 ${
                isLive
                  ? "border-emerald-500/60 shadow-emerald-950/20 ring-1 ring-emerald-500/30"
                  : isHMinusOne
                  ? "border-amber-500/50 shadow-amber-950/20 ring-1 ring-amber-500/20"
                  : "border-slate-800"
              }`}
            >
              {/* Card Top: League & Status Badge */}
              <div className="p-4 border-b border-slate-800/80 bg-[#16161a] flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-xs font-bold text-slate-300 truncate max-w-[190px]">
                  <span>{match.leagueFlag || "⚽"}</span>
                  <span className="truncate">{match.league}</span>
                  {match.sourceApi && (
                    <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                      {match.sourceApi}
                    </span>
                  )}
                </div>

                <div>
                  {isLive ? (
                    <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 flex items-center gap-1.5 animate-pulse">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                      <span>DIRECT {match.liveMinute || "En cours"}</span>
                    </span>
                  ) : isHMinusOne ? (
                    <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/30 flex items-center gap-1 animate-pulse">
                      <Clock className="w-3 h-3" />
                      <span>H-1h (À Poster !)</span>
                    </span>
                  ) : match.status === "PRONO_PUBLISHED" ? (
                    <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>Prono Publié</span>
                    </span>
                  ) : match.status === "FINISHED" ? (
                    <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
                      <Trophy className="w-3 h-3" />
                      <span>Terminé (FT)</span>
                    </span>
                  ) : match.status === "RECAP_PUBLISHED" ? (
                    <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>Récap Publié</span>
                    </span>
                  ) : (
                    <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-[#1c1c22] text-slate-400 border border-slate-700">
                      {match.kickoffDate} · {match.kickoffTime}
                    </span>
                  )}
                </div>
              </div>

              {/* Match Versus Info with Real Crests */}
              <div className="p-5 space-y-4">
                <div className="flex items-center justify-between">
                  {/* Home Team */}
                  <div className="text-center flex-1 flex flex-col items-center">
                    <div className="w-12 h-12 rounded-xl bg-[#1c1c22] border border-slate-800 p-1.5 flex items-center justify-center mb-2 overflow-hidden shadow-md">
                      {match.homeLogoUrl ? (
                        <img
                          src={match.homeLogoUrl}
                          alt={match.homeTeam}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-contain"
                          onError={(e) => {
                            (e.target as HTMLElement).style.display = "none";
                          }}
                        />
                      ) : (
                        <span className="text-xl font-bold">{match.homeLogo}</span>
                      )}
                    </div>
                    <div className="text-sm font-bold text-white truncate max-w-[110px]" title={match.homeTeam}>
                      {match.homeTeam}
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono mt-0.5">Forme: {match.formHome}</div>
                  </div>

                  {/* Center Score or Time */}
                  <div className="px-2 text-center">
                    {match.actualScore !== undefined || isLive || isFinished ? (
                      <div className="flex flex-col items-center">
                        <div className={`px-3 py-1 rounded-xl border text-xl font-mono font-bold ${
                          isLive 
                            ? "bg-emerald-950/40 border-emerald-500/40 text-emerald-400 animate-pulse" 
                            : "bg-[#0d0d0f] border-slate-800 text-white"
                        }`}>
                          {match.actualScore?.home ?? 0} - {match.actualScore?.away ?? 0}
                        </div>
                        <span className="text-[10px] font-mono text-slate-400 mt-1">
                          {isLive ? (match.liveMinute || "En cours") : "Score Final"}
                        </span>
                      </div>
                    ) : (
                      <div className="text-xs font-bold text-slate-400 uppercase tracking-widest bg-[#1c1c22] px-2.5 py-1 rounded-lg border border-slate-800">
                        {match.kickoffTime}
                      </div>
                    )}
                    {match.stadium && (
                      <div className="text-[10px] text-slate-500 truncate max-w-[100px] mt-1">
                        {match.stadium.split("(")[0]}
                      </div>
                    )}
                  </div>

                  {/* Away Team */}
                  <div className="text-center flex-1 flex flex-col items-center">
                    <div className="w-12 h-12 rounded-xl bg-[#1c1c22] border border-slate-800 p-1.5 flex items-center justify-center mb-2 overflow-hidden shadow-md">
                      {match.awayLogoUrl ? (
                        <img
                          src={match.awayLogoUrl}
                          alt={match.awayTeam}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-contain"
                          onError={(e) => {
                            (e.target as HTMLElement).style.display = "none";
                          }}
                        />
                      ) : (
                        <span className="text-xl font-bold">{match.awayLogo}</span>
                      )}
                    </div>
                    <div className="text-sm font-bold text-white truncate max-w-[110px]" title={match.awayTeam}>
                      {match.awayTeam}
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono mt-0.5">Forme: {match.formAway}</div>
                  </div>
                </div>

                {/* Scorers if present */}
                {match.goalScorers && match.goalScorers.length > 0 && (
                  <div className="p-2 bg-[#0d0d0f] rounded-xl border border-slate-800 text-[11px] text-slate-400 font-mono">
                    <div className="text-[10px] text-slate-500 font-sans font-bold">⚽ Buteurs :</div>
                    <div className="truncate">{match.goalScorers.join(", ")}</div>
                  </div>
                )}

                {/* Odds Bar */}
                <div className="grid grid-cols-3 gap-1.5 p-2 bg-[#1c1c22] rounded-xl border border-slate-800 text-xs font-mono text-center">
                  <div className="text-slate-400">
                    <span className="text-[10px] block text-slate-500">1</span>
                    <b className="text-slate-200">{match.odds.home}</b>
                  </div>
                  <div className="text-slate-400 border-x border-slate-800">
                    <span className="text-[10px] block text-slate-500">X</span>
                    <b className="text-slate-200">{match.odds.draw}</b>
                  </div>
                  <div className="text-slate-400">
                    <span className="text-[10px] block text-slate-500">2</span>
                    <b className="text-slate-200">{match.odds.away}</b>
                  </div>
                </div>

                {/* Prono Preview Snippet if available */}
                {match.pronoData && (
                  <div className="p-3 bg-indigo-950/20 border border-indigo-900/40 rounded-xl text-xs space-y-1.5">
                    <div className="flex items-center justify-between text-[11px] font-bold text-indigo-400">
                      <span className="flex items-center gap-1">
                        <Sparkles className="w-3 h-3" />
                        Prono : {match.pronoData.predictionType}
                      </span>
                      <span>Score: {match.pronoData.predictedScore}</span>
                    </div>
                    <p className="text-[11px] text-slate-300 line-clamp-2 italic">
                      "{match.pronoData.tweetText.split("\n\n")[1] || match.pronoData.keyReasoning}"
                    </p>
                  </div>
                )}

                {/* Recap Preview Snippet if available */}
                {match.recapData && (
                  <div className="p-3 bg-emerald-950/20 border border-emerald-900/40 rounded-xl text-xs space-y-1">
                    <div className="flex items-center justify-between text-[11px] font-bold text-emerald-400">
                      <span>{match.recapData.statusEmoji} Score Final : {match.recapData.finalScore}</span>
                      <span>{match.recapData.roiImpact}</span>
                    </div>
                    <p className="text-[11px] text-slate-300 line-clamp-2">
                      {match.recapData.summary}
                    </p>
                  </div>
                )}
              </div>

              {/* Card Footer: Action Buttons */}
              <div className="p-4 border-t border-slate-800/80 bg-[#16161a] flex items-center justify-between gap-2">
                {!isFinished ? (
                  <>
                    <button
                      onClick={() => onOpenPronoModal(match)}
                      className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-bold text-indigo-300 bg-indigo-950/40 hover:bg-indigo-900/50 border border-indigo-800/70 rounded-xl transition"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>{hasProno ? "Modifier Prono IA" : "Générer Prono IA"}</span>
                    </button>

                    {hasProno && (
                      <button
                        onClick={() => onSendToSimulator(match.pronoData!.tweetText)}
                        className="px-3 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-xl shadow transition flex items-center gap-1"
                        title="Tester la publication sur X"
                      >
                        <Send className="w-3.5 h-3.5" />
                        <span>Poster</span>
                      </button>
                    )}
                  </>
                ) : (
                  <>
                    <button
                      onClick={() => onOpenRecapModal(match)}
                      className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-bold text-emerald-300 bg-emerald-950/40 hover:bg-emerald-900/50 border border-emerald-800/70 rounded-xl transition"
                    >
                      <Trophy className="w-3.5 h-3.5" />
                      <span>{hasRecap ? "Modifier Récap" : "Générer Récap Fin de Match"}</span>
                    </button>

                    {hasRecap && (
                      <button
                        onClick={() => onSendToSimulator(match.recapData!.tweetText)}
                        className="px-3 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-xl shadow transition flex items-center gap-1"
                        title="Publier le récap sur X"
                      >
                        <Send className="w-3.5 h-3.5" />
                        <span>Poster</span>
                      </button>
                    )}
                  </>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

