import React, { useState } from "react";
import { Code, Download, Copy, Check, Terminal, FileCode, CheckCircle2, Shield, AlertTriangle, Key, Cpu, HelpCircle, ExternalLink } from "lucide-react";
import { generatePythonPlaywrightScript, generateNodePlaywrightScript } from "../utils/playwrightScriptGenerator";

interface PlaywrightCodeExporterProps {
  authToken: string;
  ct0: string;
}

export const PlaywrightCodeExporter: React.FC<PlaywrightCodeExporterProps> = ({
  authToken,
  ct0,
}) => {
  const [lang, setLang] = useState<"python" | "nodejs">("python");
  const [copied, setCopied] = useState(false);
  const [headlessMode, setHeadlessMode] = useState(false);

  const pythonCode = generatePythonPlaywrightScript({
    authToken: authToken || "YOUR_AUTH_TOKEN_HERE",
    ct0: ct0 || "YOUR_CT0_COOKIE_HERE",
    headless: headlessMode,
    useShortcut: true,
  });

  const nodeCode = generateNodePlaywrightScript({
    authToken: authToken || "YOUR_AUTH_TOKEN_HERE",
    ct0: ct0 || "YOUR_CT0_COOKIE_HERE",
    headless: headlessMode,
  });

  const currentCode = lang === "python" ? pythonCode : nodeCode;
  const currentFileName = lang === "python" ? "bot_x_pronos.py" : "bot_x_pronos.mjs";

  const handleCopy = () => {
    navigator.clipboard.writeText(currentCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([currentCode], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = currentFileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="bg-[#16161a] border border-slate-800 rounded-2xl shadow-xl overflow-hidden space-y-6">
      {/* Header */}
      <div className="p-6 border-b border-slate-800 bg-[#16161a]">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-500/10 text-indigo-400 rounded-xl border border-indigo-500/20">
              <FileCode className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Scripts Playwright Autonomes Prêts à l'Emploi
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-semibold">
                  100% Gratuit / Sans API Payante
                </span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Code corrigé et optimisé avec authentification par cookies, raccourci clavier Ctrl+Enter et boucle H-1h.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Lang switcher */}
            <div className="flex items-center bg-[#0d0d0f] p-1 rounded-xl border border-slate-800">
              <button
                onClick={() => setLang("python")}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                  lang === "python"
                    ? "bg-indigo-600 text-white shadow-md shadow-indigo-950/40"
                    : "text-slate-400 hover:text-slate-200"
                }`}
              >
                <span>🐍 Python</span>
              </button>
              <button
                onClick={() => setLang("nodejs")}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                  lang === "nodejs"
                    ? "bg-indigo-600 text-white shadow-md shadow-indigo-950/40"
                    : "text-slate-400 hover:text-slate-200"
                }`}
              >
                <span>⚡ Node.js</span>
              </button>
            </div>

            {/* Action buttons */}
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold bg-[#1c1c22] hover:bg-slate-800 active:bg-slate-700 text-slate-200 rounded-xl border border-slate-700/80 transition"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Code Copié !</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copier le Script</span>
                </>
              )}
            </button>

            <button
              onClick={handleDownload}
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white rounded-xl shadow-lg shadow-indigo-950/40 transition"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Télécharger ({currentFileName})</span>
            </button>
          </div>
        </div>
      </div>

      {/* Code Explanatory Cards */}
      <div className="px-6 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 bg-[#1c1c22] rounded-xl border border-slate-800 space-y-1.5">
          <div className="flex items-center gap-2 text-xs font-bold text-emerald-400">
            <CheckCircle2 className="w-4 h-4" />
            <span>1. Authentification par Cookies</span>
          </div>
          <p className="text-[11px] text-slate-400 leading-relaxed">
            Plus besoin de saisir manuellement vos identifiants ou de valider le 2FA à chaque fois. Les cookies <code>auth_token</code> et <code>ct0</code> injectent directement votre session validée.
          </p>
        </div>

        <div className="p-4 bg-[#1c1c22] rounded-xl border border-slate-800 space-y-1.5">
          <div className="flex items-center gap-2 text-xs font-bold text-indigo-400">
            <Cpu className="w-4 h-4" />
            <span>2. Raccourci Ctrl+Enter</span>
          </div>
          <p className="text-[11px] text-slate-400 leading-relaxed">
            Sur X, les boutons "Publier" changent constamment de balises HTML. Le script déclenche <code className="text-amber-300">Control+Enter</code> pour publier instantanément sans risque d'erreur de sélecteur.
          </p>
        </div>

        <div className="p-4 bg-[#1c1c22] rounded-xl border border-slate-800 space-y-1.5">
          <div className="flex items-center gap-2 text-xs font-bold text-amber-400">
            <Shield className="w-4 h-4" />
            <span>3. Anti-Détection Stealth</span>
          </div>
          <p className="text-[11px] text-slate-400 leading-relaxed">
            Désactivation du flag <code>navigator.webdriver</code>, simulation de la vitesse de frappe humaine et délais aléatoires pour protéger votre compte X contre les shadowbans.
          </p>
        </div>
      </div>

      {/* Code Editor Preview */}
      <div className="px-6">
        <div className="rounded-xl border border-slate-800 bg-[#0d0d0f] overflow-hidden">
          {/* File bar */}
          <div className="px-4 py-2.5 bg-[#16161a] border-b border-slate-800 flex items-center justify-between text-xs font-mono">
            <div className="flex items-center gap-2 text-slate-300">
              <Code className="w-4 h-4 text-indigo-400" />
              <span>{currentFileName}</span>
            </div>
            <div className="flex items-center gap-3">
              <label className="flex items-center gap-1.5 text-[11px] text-slate-400 cursor-pointer">
                <input
                  type="checkbox"
                  checked={headlessMode}
                  onChange={(e) => setHeadlessMode(e.target.checked)}
                  className="rounded bg-[#0d0d0f] border-slate-700 text-indigo-500 focus:ring-0"
                />
                <span>Mode Headless (Serveur / VPS)</span>
              </label>
            </div>
          </div>

          {/* Code display */}
          <pre className="p-4 text-xs font-mono text-slate-200 overflow-x-auto max-h-[420px] overflow-y-auto leading-relaxed bg-black selection:bg-indigo-600 selection:text-white">
            <code>{currentCode}</code>
          </pre>
        </div>
      </div>

      {/* Quick Setup Instructions */}
      <div className="px-6 pb-6">
        <div className="p-4 bg-[#1c1c22] rounded-xl border border-slate-800 space-y-3">
          <h3 className="text-xs font-bold text-white flex items-center gap-2">
            <Terminal className="w-4 h-4 text-indigo-400" />
            Guide d'installation en 2 étapes sur votre machine / VPS
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs font-mono">
            <div className="bg-[#0d0d0f] p-3 rounded-lg border border-slate-800">
              <div className="text-slate-400 text-[11px] mb-1 font-sans font-semibold">1. Installer les dépendances :</div>
              <code className="text-emerald-400 select-all">
                {lang === "python"
                  ? "pip install playwright requests && playwright install chromium"
                  : "npm install playwright axios dotenv && npx playwright install chromium"}
              </code>
            </div>

            <div className="bg-[#0d0d0f] p-3 rounded-lg border border-slate-800">
              <div className="text-slate-400 text-[11px] mb-1 font-sans font-semibold">2. Exécuter le script :</div>
              <code className="text-indigo-400 select-all">
                {lang === "python" ? "python3 bot_x_pronos.py" : "node bot_x_pronos.mjs"}
              </code>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
