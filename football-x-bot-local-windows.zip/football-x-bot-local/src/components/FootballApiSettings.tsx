import React, { useState } from "react";
import { Radio, Activity, CheckCircle2, AlertCircle, RefreshCw, Key, Globe, ShieldCheck, Zap, Database, ExternalLink } from "lucide-react";
import { FootballApiConfig, FootballMatch } from "../types";

interface FootballApiSettingsProps {
  apiConfig: FootballApiConfig;
  onUpdateConfig: (newConfig: FootballApiConfig) => void;
  onSyncRealFixtures: (customKey?: string) => Promise<void>;
  isSyncing: boolean;
  matchesCount: number;
  lastSyncTime: string | null;
}

export const FootballApiSettings: React.FC<FootballApiSettingsProps> = ({
  apiConfig,
  onUpdateConfig,
  onSyncRealFixtures,
  isSyncing,
  matchesCount,
  lastSyncTime,
}) => {
  const [apiKeyInput, setApiKeyInput] = useState(apiConfig.apiKey || "");
  const [testResult, setTestResult] = useState<{ status: "idle" | "success" | "error"; message: string } | null>(null);
  const [isTesting, setIsTesting] = useState(false);

  const handleSaveApiKey = () => {
    onUpdateConfig({
      ...apiConfig,
      apiKey: apiKeyInput,
    });
    setTestResult({
      status: "success",
      message: "Clé d'API enregistrée dans la configuration locale !",
    });
  };

  const handleTestApi = async (provider: string) => {
    setIsTesting(true);
    setTestResult(null);
    try {
      const headers: Record<string, string> = {};
      if (apiKeyInput) {
        headers["x-apisports-key"] = apiKeyInput;
        headers["x-football-data-key"] = apiKeyInput;
        headers["x-rapidapi-key"] = apiKeyInput;
      }
      const res = await fetch("/api/football/real-fixtures", { headers });
      const data = await res.json();
      if (data.success && data.fixtures && data.fixtures.length > 0) {
        setTestResult({
          status: "success",
          message: `Connexion réussie ! ${data.fixtures.length} vrais matchs récupérés en direct (${data.source}) incluant la Ligue des Champions (LDC), Ligue 1, Premier League, etc.`,
        });
      } else {
        setTestResult({
          status: "error",
          message: data.error || "Aucun match en direct trouvé pour aujourd'hui sur ce flux.",
        });
      }
    } catch (e: any) {
      setTestResult({
        status: "error",
        message: `Erreur de connexion : ${e.message}`,
      });
    } finally {
      setIsTesting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-[#16161a] border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-indigo-500/10 text-indigo-400 rounded-xl border border-indigo-500/20">
                <Radio className="w-5 h-5 animate-pulse" />
              </div>
              <h2 className="text-lg font-bold text-white">
                Connecteurs d'API Football en Direct & Données Réelles
              </h2>
            </div>
            <p className="text-xs text-slate-400 max-w-2xl">
              Connectez le bot aux vrais flux de scores et calendriers de football pour générer automatiquement les pronostics à H-1h du coup d'envoi et les bilans au coup de sifflet final.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => onSyncRealFixtures(apiKeyInput)}
              disabled={isSyncing}
              className="flex items-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-lg shadow-indigo-950/40 transition"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? "animate-spin" : ""}`} />
              <span>{isSyncing ? "Synchronisation..." : "Synchroniser Matchs Réels"}</span>
            </button>
          </div>
        </div>

        {/* Live sync telemetry */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-6 pt-5 border-t border-slate-800/80 text-xs">
          <div className="p-3 bg-[#1c1c22] rounded-xl border border-slate-800 flex items-center justify-between">
            <span className="text-slate-400">Matchs synchronisés</span>
            <span className="font-mono font-bold text-white">{matchesCount}</span>
          </div>
          <div className="p-3 bg-[#1c1c22] rounded-xl border border-slate-800 flex items-center justify-between">
            <span className="text-slate-400">Dernière synchro</span>
            <span className="font-mono text-indigo-400">{lastSyncTime || "À l'instant"}</span>
          </div>
          <div className="p-3 bg-[#1c1c22] rounded-xl border border-slate-800 flex items-center justify-between">
            <span className="text-slate-400">Flux Par Défaut</span>
            <span className="font-semibold text-emerald-400 flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              ESPN Live (Actif)
            </span>
          </div>
        </div>
      </div>

      {/* Providers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Provider 1: ESPN Real-Time Scoreboards (Free & Active) */}
        <div className="bg-[#16161a] border border-indigo-500/30 rounded-2xl p-5 shadow-xl flex flex-col justify-between space-y-4 ring-1 ring-indigo-500/20">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-lg">📡</span>
                <h3 className="font-bold text-white text-sm">ESPN Live Soccer API</h3>
              </div>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" />
                100% Gratuit & Actif
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Récupère les scores en direct, logos officiels haute résolution, cotes bookmakers, statuts de match, et buteurs sans aucune clé requise.
            </p>
            <div className="text-[11px] text-slate-400 space-y-1 bg-[#1c1c22] p-3 rounded-xl border border-slate-800 font-mono">
              <div className="text-indigo-300 font-bold mb-1 font-sans">Compétitions incluses :</div>
              <div>• Ligue 1 McDonald's (fra.1)</div>
              <div>• UEFA Champions League (uefa.champions)</div>
              <div>• Premier League (eng.1)</div>
              <div>• La Liga & Serie A & Bundesliga</div>
            </div>
          </div>

          <button
            onClick={() => handleTestApi("espn")}
            disabled={isTesting}
            className="w-full py-2 px-3 text-xs font-semibold text-indigo-300 bg-indigo-950/40 hover:bg-indigo-900/50 border border-indigo-800/70 rounded-xl transition flex items-center justify-center gap-1.5"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Tester Flux ESPN en Direct</span>
          </button>
        </div>

        {/* Provider 2: Football-Data.org */}
        <div className="bg-[#16161a] border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between space-y-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-lg">⚽</span>
                <h3 className="font-bold text-white text-sm">Football-Data.org</h3>
              </div>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-800 text-slate-400 border border-slate-700">
                Optionnel (Tier Gratuit)
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              API européenne très réputée avec 12 ligues majeures. Vous pouvez utiliser votre propre clé pour des quotas dédiés.
            </p>

            <div className="space-y-1.5">
              <label className="text-[11px] font-semibold text-slate-300 flex items-center gap-1">
                <Key className="w-3 h-3 text-amber-400" />
                <span>Clé d'API (X-Auth-Token) :</span>
              </label>
              <div className="flex gap-2">
                <input
                  type="password"
                  value={apiKeyInput}
                  onChange={(e) => setApiKeyInput(e.target.value)}
                  placeholder="Ex: a1b2c3d4e5f6..."
                  className="flex-1 bg-[#0d0d0f] border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 font-mono"
                />
                <button
                  onClick={handleSaveApiKey}
                  className="px-3 py-1.5 text-xs font-bold text-white bg-[#1c1c22] hover:bg-slate-800 border border-slate-700 rounded-xl transition"
                >
                  OK
                </button>
              </div>
            </div>
          </div>

          <button
            onClick={() => handleTestApi("football-data")}
            disabled={isTesting}
            className="w-full py-2 px-3 text-xs font-semibold text-slate-300 bg-[#1c1c22] hover:bg-slate-800 border border-slate-700 rounded-xl transition flex items-center justify-center gap-1.5"
          >
            <Activity className="w-3.5 h-3.5 text-amber-400" />
            <span>Tester Football-Data.org</span>
          </button>
        </div>

        {/* Provider 3: API-Sports / RapidAPI */}
        <div className="bg-[#16161a] border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between space-y-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-lg">🏆</span>
                <h3 className="font-bold text-white text-sm">API-Football / API-Sports</h3>
              </div>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-800 text-slate-400 border border-slate-700">
                Optionnel (RapidAPI)
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Fournisseur mondial avec statistiques poussées, compos officielles 1h avant match et cotes de 30+ bookmakers.
            </p>
            <div className="text-[11px] text-slate-400 bg-[#1c1c22] p-3 rounded-xl border border-slate-800 space-y-1">
              <div>• Compositions officielles à H-45min</div>
              <div>• Cotes Unibet, Betclic, Winamax</div>
              <div>• Couverture mondiale (1000+ ligues)</div>
            </div>
          </div>

          <div className="pt-2">
            <button
              onClick={() => handleTestApi("api-football")}
              disabled={isTesting}
              className="w-full py-2 px-3 text-xs font-semibold text-slate-300 bg-[#1c1c22] hover:bg-slate-800 border border-slate-700 rounded-xl transition flex items-center justify-center gap-1.5"
            >
              <Globe className="w-3.5 h-3.5 text-emerald-400" />
              <span>Tester API-Football</span>
            </button>
          </div>
        </div>
      </div>

      {/* Test feedback alert */}
      {testResult && (
        <div
          className={`p-4 rounded-2xl border flex items-center gap-3 text-xs animate-in fade-in ${
            testResult.status === "success"
              ? "bg-emerald-950/40 border-emerald-800/80 text-emerald-300"
              : "bg-rose-950/40 border-rose-800/80 text-rose-300"
          }`}
        >
          {testResult.status === "success" ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          ) : (
            <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
          )}
          <span className="font-medium">{testResult.message}</span>
        </div>
      )}

      {/* Auto Refresh & Worker Scheduler Config */}
      <div className="bg-[#16161a] border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <div className="flex items-center gap-2">
          <Zap className="w-5 h-5 text-amber-400" />
          <h3 className="font-bold text-white text-sm">
            Mode Auto-Rafraîchissement & Détecteur Automatique de Déclenchement
          </h3>
        </div>
        <p className="text-xs text-slate-400 leading-relaxed">
          Le bot surveille automatiquement l'heure des matchs en temps réel. Dès qu'un match passe à <strong>H-1h (60 minutes avant le coup d'envoi)</strong>, le statut bascule automatiquement sur <span className="text-amber-400 font-bold">READY_FOR_PRONO</span>. Dès que le coup de sifflet final retentit (<span className="text-emerald-400 font-bold">STATUS_FULL_TIME / FT</span>), le score final et les buteurs sont capturés pour générer le tweet récap.
        </p>

        <div className="flex flex-wrap items-center gap-3 pt-2">
          <button
            onClick={() => onUpdateConfig({ ...apiConfig, autoRefreshInterval: 30 })}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold border transition ${
              apiConfig.autoRefreshInterval === 30
                ? "bg-indigo-600 border-indigo-500 text-white shadow-md shadow-indigo-950/40"
                : "bg-[#1c1c22] border-slate-800 text-slate-400 hover:text-slate-200"
            }`}
          >
            ⚡ Auto-scan toutes les 30s
          </button>
          <button
            onClick={() => onUpdateConfig({ ...apiConfig, autoRefreshInterval: 60 })}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold border transition ${
              apiConfig.autoRefreshInterval === 60
                ? "bg-indigo-600 border-indigo-500 text-white shadow-md shadow-indigo-950/40"
                : "bg-[#1c1c22] border-slate-800 text-slate-400 hover:text-slate-200"
            }`}
          >
            ⏱️ Auto-scan chaque minute
          </button>
          <button
            onClick={() => onUpdateConfig({ ...apiConfig, autoRefreshInterval: 0 })}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold border transition ${
              apiConfig.autoRefreshInterval === 0
                ? "bg-[#1c1c22] border-slate-700 text-slate-200"
                : "bg-[#1c1c22] border-slate-800 text-slate-400 hover:text-slate-200"
            }`}
          >
            🛑 Manuel uniquement
          </button>
        </div>
      </div>
    </div>
  );
};
