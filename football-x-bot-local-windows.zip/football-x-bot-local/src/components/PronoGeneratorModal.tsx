import React, { useState } from "react";
import { X, Sparkles, Wand2, Sliders, CheckCircle2, AlertCircle, Copy, Check, Send, Clock, Flame, ShieldAlert, TrendingUp } from "lucide-react";
import { FootballMatch, PronoResult } from "../types";
import { TweetPreviewCard } from "./TweetPreviewCard";

interface PronoGeneratorModalProps {
  match: FootballMatch;
  isOpen: boolean;
  onClose: () => void;
  onSaveProno: (matchId: string, prono: PronoResult) => void;
  onSendToSimulator: (tweetText: string) => void;
}

export const PronoGeneratorModal: React.FC<PronoGeneratorModalProps> = ({
  match,
  isOpen,
  onClose,
  onSaveProno,
  onSendToSimulator,
}) => {
  const [tone, setTone] = useState<"expert" | "viral" | "tipster" | "minimal">("tipster");
  const [customNote, setCustomNote] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedProno, setGeneratedProno] = useState<PronoResult | null>(
    match.pronoData || null
  );
  const [editedTweetText, setEditedTweetText] = useState(
    match.pronoData?.tweetText || ""
  );
  const [fallbackNote, setFallbackNote] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleGenerate = async () => {
    setIsGenerating(true);
    setErrorMsg(null);
    setFallbackNote(null);
    try {
      const res = await fetch("/api/gemini/generate-prono", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          homeTeam: match.homeTeam,
          awayTeam: match.awayTeam,
          league: match.league,
          matchTime: match.kickoffTime,
          odds: match.odds,
          formHome: match.formHome,
          formAway: match.formAway,
          keyStat: match.keyStat,
          tone,
          targetMarket: "auto",
          customNote,
        }),
      });

      const json = await res.json();
      if (json.data) {
        const prono: PronoResult = {
          id: "prono-" + Date.now(),
          matchId: match.id,
          tweetText: json.data.tweetText,
          predictionType: json.data.predictionType || "Prono IA",
          predictedScore: json.data.predictedScore || "2-1",
          estimatedOdd: json.data.estimatedOdd || "1.80",
          confidencePercent: json.data.confidencePercent || 80,
          keyReasoning: json.data.keyReasoning || "",
          recommendedBet: json.data.recommendedBet || "",
          safeAlternative: json.data.safeAlternative || "",
          generatedAt: new Date().toISOString(),
          status: "SCHEDULED",
        };
        setGeneratedProno(prono);
        setEditedTweetText(prono.tweetText);
        if (json.isFallback) {
          setFallbackNote(json.fallbackReason || "Généré via le moteur statistique expert");
        }
      } else if (json.fallbackTweet) {
        const prono: PronoResult = {
          id: "prono-" + Date.now(),
          matchId: match.id,
          tweetText: json.fallbackTweet,
          predictionType: "Prono Expert",
          predictedScore: "2-1",
          estimatedOdd: "1.85",
          confidencePercent: 80,
          keyReasoning: "Analyse sur forme récente et historique",
          recommendedBet: `Victoire ${match.homeTeam}`,
          safeAlternative: "1X & +1.5 buts",
          generatedAt: new Date().toISOString(),
          status: "SCHEDULED",
        };
        setGeneratedProno(prono);
        setEditedTweetText(prono.tweetText);
      } else {
        throw new Error(json.error || "Erreur de génération");
      }
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || "Erreur temporaire de connexion");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSave = () => {
    if (!generatedProno) return;
    const finalProno: PronoResult = {
      ...generatedProno,
      tweetText: editedTweetText,
    };
    onSaveProno(match.id, finalProno);
    onClose();
  };

  const handleTestNow = () => {
    const text = editedTweetText || generatedProno?.tweetText || "";
    if (text) {
      onSendToSimulator(text);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#16161a] border border-slate-800 rounded-2xl w-full max-w-4xl shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 bg-[#16161a] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-500/10 text-indigo-400 rounded-lg border border-indigo-500/20">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                Générateur IA de Pronostics X (H-1h Avant Match)
              </h2>
              <p className="text-xs text-slate-400">
                {match.league} · {match.homeTeam} vs {match.awayTeam} ({match.kickoffTime})
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 max-h-[78vh] overflow-y-auto">
          {/* Left: Configuration & Generation Controls */}
          <div className="lg:col-span-5 space-y-4">
            {/* Match summary card */}
            <div className="p-4 bg-[#1c1c22] rounded-xl border border-slate-800 space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-400 border-b border-slate-800 pb-2">
                <span className="font-semibold text-slate-300">Détails du match</span>
                <span className="bg-[#0d0d0f] px-2 py-0.5 rounded text-indigo-400 font-mono border border-slate-800">
                  ⏰ Coup d'envoi: {match.kickoffTime}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <div className="text-center flex-1">
                  <div className="text-xl mb-1">{match.homeLogo}</div>
                  <div className="text-xs font-bold text-white truncate">{match.homeTeam}</div>
                  <div className="text-[10px] text-slate-400 font-mono mt-0.5">Forme: {match.formHome}</div>
                </div>
                <div className="px-2 text-xs font-bold text-slate-500">VS</div>
                <div className="text-center flex-1">
                  <div className="text-xl mb-1">{match.awayLogo}</div>
                  <div className="text-xs font-bold text-white truncate">{match.awayTeam}</div>
                  <div className="text-[10px] text-slate-400 font-mono mt-0.5">Forme: {match.formAway}</div>
                </div>
              </div>
              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-around text-xs font-mono">
                <span className="text-slate-400">1: <b className="text-slate-200">{match.odds.home}</b></span>
                <span className="text-slate-400">X: <b className="text-slate-200">{match.odds.draw}</b></span>
                <span className="text-slate-400">2: <b className="text-slate-200">{match.odds.away}</b></span>
              </div>
            </div>

            {/* Tone Selector */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-indigo-400" />
                Style & Ton du Tweet
              </label>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: "tipster", label: "Tipster Pro", desc: "Confiance & Cotes" },
                  { id: "viral", label: "Viral & Punchy", desc: "Emojis & Hype" },
                  { id: "expert", label: "Analyste xG", desc: "Stats & Tactique" },
                  { id: "minimal", label: "Minimaliste", desc: "Court & Direct" },
                ].map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => setTone(t.id as any)}
                    className={`p-2.5 rounded-xl border text-left transition ${
                      tone === t.id
                        ? "bg-indigo-950/40 border-indigo-500 text-indigo-200 ring-1 ring-indigo-500/50"
                        : "bg-[#1c1c22] border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200"
                    }`}
                  >
                    <div className="text-xs font-bold">{t.label}</div>
                    <div className="text-[10px] text-slate-500">{t.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Custom Notes */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">
                Instruction personnalisée (Optionnel)
              </label>
              <input
                type="text"
                value={customNote}
                onChange={(e) => setCustomNote(e.target.value)}
                placeholder="Ex: Insister sur la solidité défensive à domicile, le pressing haut..."
                className="w-full bg-[#0d0d0f] border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500"
              />
            </div>

            {/* Generate Button */}
            <button
              onClick={handleGenerate}
              disabled={isGenerating}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl shadow-lg shadow-indigo-950/40 transition"
            >
              {isGenerating ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Analyse Gemini en cours...</span>
                </>
              ) : (
                <>
                  <Wand2 className="w-4 h-4" />
                  <span>Générer le Prono IA avec Gemini</span>
                </>
              )}
            </button>

            {errorMsg && (
              <div className="p-3 bg-rose-950/30 border border-rose-900/50 rounded-xl text-rose-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {fallbackNote && (
              <div className="p-3 bg-indigo-950/30 border border-indigo-800/40 rounded-xl text-indigo-300 text-xs flex items-center gap-2">
                <Sparkles className="w-4 h-4 shrink-0 text-indigo-400" />
                <span>{fallbackNote}</span>
              </div>
            )}
          </div>

          {/* Right: Live Preview & Editor */}
          <div className="lg:col-span-7 space-y-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <Flame className="w-3.5 h-3.5 text-amber-400" />
                  Texte du Tweet Formaté pour X
                </label>
                {generatedProno && (
                  <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800">
                    Confiance: {generatedProno.confidencePercent}%
                  </span>
                )}
              </div>

              {/* Editable Textarea */}
              <textarea
                value={editedTweetText}
                onChange={(e) => setEditedTweetText(e.target.value)}
                placeholder="Cliquez sur 'Générer le Prono IA' pour créer automatiquement le tweet parfait..."
                rows={5}
                className="w-full bg-[#0d0d0f] border border-slate-800 rounded-xl p-3 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-indigo-500 font-sans leading-relaxed resize-none shadow-inner"
              />
            </div>

            {/* Tweet Real Preview Card */}
            {editedTweetText ? (
              <TweetPreviewCard
                tweetText={editedTweetText}
                title="Aperçu Réel sur X (Twitter)"
                badgeText="Prono H-1h"
                badgeColor="bg-indigo-500/10 text-indigo-400 border-indigo-500/20"
              />
            ) : (
              <div className="p-8 border border-dashed border-slate-800 rounded-2xl text-center text-slate-500 text-xs bg-[#1c1c22]">
                <Sparkles className="w-8 h-8 mx-auto mb-2 text-slate-600" />
                <span>L'aperçu en direct du tweet apparaîtra ici après la génération IA.</span>
              </div>
            )}

            {/* Key stats badges */}
            {generatedProno && (
              <div className="grid grid-cols-3 gap-2 text-xs">
                <div className="p-2.5 bg-[#1c1c22] rounded-xl border border-slate-800 text-center">
                  <div className="text-[10px] text-slate-400 uppercase">Pari Recommandé</div>
                  <div className="font-bold text-indigo-400 truncate mt-0.5">{generatedProno.predictionType}</div>
                </div>
                <div className="p-2.5 bg-[#1c1c22] rounded-xl border border-slate-800 text-center">
                  <div className="text-[10px] text-slate-400 uppercase">Score Estimé</div>
                  <div className="font-bold text-amber-400 truncate mt-0.5">{generatedProno.predictedScore}</div>
                </div>
                <div className="p-2.5 bg-[#1c1c22] rounded-xl border border-slate-800 text-center">
                  <div className="text-[10px] text-slate-400 uppercase">Cote Estimée</div>
                  <div className="font-bold text-emerald-400 truncate mt-0.5">@{generatedProno.estimatedOdd}</div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 border-t border-slate-800 bg-[#16161a] flex flex-wrap items-center justify-between gap-3">
          <div className="text-xs text-slate-400 flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-indigo-400" />
            <span>Publication automatique programmée à 1 heure du coup d'envoi.</span>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={handleTestNow}
              disabled={!editedTweetText}
              className="px-3 py-2 text-xs font-medium text-emerald-300 bg-emerald-950/40 hover:bg-emerald-900/50 border border-emerald-800/80 disabled:opacity-40 disabled:cursor-not-allowed rounded-xl transition flex items-center gap-1.5"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Tester dans le Simulateur</span>
            </button>

            <button
              onClick={handleSave}
              disabled={!editedTweetText}
              className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 disabled:opacity-40 disabled:cursor-not-allowed rounded-xl shadow-lg shadow-indigo-950/40 transition flex items-center gap-1.5"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Enregistrer & Planifier le Prono</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
