import React, { useState } from "react";
import { X, Plus, Calendar, Clock, Trophy } from "lucide-react";
import { FootballMatch } from "../types";

interface AddMatchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddMatch: (match: FootballMatch) => void;
}

export const AddMatchModal: React.FC<AddMatchModalProps> = ({
  isOpen,
  onClose,
  onAddMatch,
}) => {
  const [league, setLeague] = useState("Ligue 1");
  const [homeTeam, setHomeTeam] = useState("");
  const [awayTeam, setAwayTeam] = useState("");
  const [kickoffTime, setKickoffTime] = useState("21:00");
  const [kickoffDate, setKickoffDate] = useState("Aujourd'hui");
  const [oddHome, setOddHome] = useState("2.10");
  const [oddDraw, setOddDraw] = useState("3.40");
  const [oddAway, setOddAway] = useState("3.20");
  const [formHome, setFormHome] = useState("V-V-N-V-D");
  const [formAway, setFormAway] = useState("V-N-V-D-V");

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!homeTeam || !awayTeam) return;

    const newMatch: FootballMatch = {
      id: "match-custom-" + Date.now(),
      league,
      homeTeam,
      awayTeam,
      homeLogo: "⚽",
      awayLogo: "⚽",
      kickoffTime,
      kickoffDate,
      kickoffTimestamp: Date.now() + 60 * 60 * 1000,
      odds: {
        home: oddHome,
        draw: oddDraw,
        away: oddAway,
      },
      formHome,
      formAway,
      status: "UPCOMING",
    };

    onAddMatch(newMatch);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#16161a] border border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-800 bg-[#16161a] flex items-center justify-between">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Plus className="w-5 h-5 text-indigo-400" />
            Ajouter un Match de Football
          </h2>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          <div className="space-y-1">
            <label className="font-semibold text-slate-300">Compétition</label>
            <select
              value={league}
              onChange={(e) => setLeague(e.target.value)}
              className="w-full bg-[#0d0d0f] border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
            >
              <option value="UEFA Champions League">🏆 UEFA Champions League</option>
              <option value="Ligue 1 McDonald's">🇫🇷 Ligue 1 McDonald's</option>
              <option value="Premier League">🏴󠁧󠁢󠁥󠁮󠁧󠁿 Premier League</option>
              <option value="La Liga EA Sports">🇪🇸 La Liga EA Sports</option>
              <option value="Serie A Enilive">🇮🇹 Serie A Enilive</option>
              <option value="Bundesliga">🇩🇪 Bundesliga</option>
              <option value="Autre Compétition">⚽ Autre</option>
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="font-semibold text-slate-300">Équipe Domicile</label>
              <input
                type="text"
                required
                value={homeTeam}
                onChange={(e) => setHomeTeam(e.target.value)}
                placeholder="Ex: PSG, Real Madrid..."
                className="w-full bg-[#0d0d0f] border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div className="space-y-1">
              <label className="font-semibold text-slate-300">Équipe Extérieur</label>
              <input
                type="text"
                required
                value={awayTeam}
                onChange={(e) => setAwayTeam(e.target.value)}
                placeholder="Ex: Chelsea, Barça..."
                className="w-full bg-[#0d0d0f] border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="font-semibold text-slate-300">Heure Coup d'envoi</label>
              <input
                type="text"
                value={kickoffTime}
                onChange={(e) => setKickoffTime(e.target.value)}
                placeholder="21:00"
                className="w-full bg-[#0d0d0f] border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div className="space-y-1">
              <label className="font-semibold text-slate-300">Date</label>
              <input
                type="text"
                value={kickoffDate}
                onChange={(e) => setKickoffDate(e.target.value)}
                placeholder="Aujourd'hui"
                className="w-full bg-[#0d0d0f] border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          <div className="space-y-1 pt-1">
            <label className="font-semibold text-slate-300">Cotes 1 - N - 2</label>
            <div className="grid grid-cols-3 gap-2">
              <input
                type="text"
                value={oddHome}
                onChange={(e) => setOddHome(e.target.value)}
                placeholder="1 (2.10)"
                className="bg-[#0d0d0f] border border-slate-800 rounded-xl px-3 py-2 text-slate-200 font-mono text-center focus:outline-none focus:border-indigo-500"
              />
              <input
                type="text"
                value={oddDraw}
                onChange={(e) => setOddDraw(e.target.value)}
                placeholder="N (3.40)"
                className="bg-[#0d0d0f] border border-slate-800 rounded-xl px-3 py-2 text-slate-200 font-mono text-center focus:outline-none focus:border-indigo-500"
              />
              <input
                type="text"
                value={oddAway}
                onChange={(e) => setOddAway(e.target.value)}
                placeholder="2 (3.20)"
                className="bg-[#0d0d0f] border border-slate-800 rounded-xl px-3 py-2 text-slate-200 font-mono text-center focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-slate-400 hover:text-slate-200 font-semibold"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl shadow-lg shadow-indigo-950/40 transition"
            >
              Ajouter le Match
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
