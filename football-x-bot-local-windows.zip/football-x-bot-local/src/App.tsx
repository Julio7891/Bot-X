import React from "react";
import { SimplifiedBotDashboard } from "./components/SimplifiedBotDashboard";

export function App() {
  return <SimplifiedBotDashboard />;
}

export default App;
