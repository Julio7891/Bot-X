# ⚽ Football X-Bot Pro — Bot Autonome Twitter / X (100% Gratuit)

> **Bot autonome de pronostics de football et d'alertes de buts en direct sur X (Twitter), conçu pour fonctionner en continu sans payer l'abonnement Twitter API v2 ($100+/mois).**

[![Node.js Version](https://img.shields.io/badge/Node.js-18%2B%20%7C%2020%2B%20%7C%2022%2B-brightgreen)](https://nodejs.org/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.8-blue)](https://www.typescriptlang.org/)
[![License](https://img.shields.io/badge/License-MIT-purple.svg)](LICENSE)
[![Zero Twitter API Paywall](https://img.shields.io/badge/Twitter%20API-100%25%20GRATUIT%20(Cookies%20Web)-success)](https://x.com)
[![Anti-Collision](https://img.shields.io/badge/Anti--Collision-Priorit%C3%A9%20Premier%20League-orange)](README.md)

---

## ⚡ Pourquoi ce projet ?

Depuis le rachat de Twitter/X, l'accès à l'API v2 en écriture (`POST /2/tweets`) est bloqué derrière l'offre payante **Basic à $100 - $200 par mois**, rendant les bots inaccessibles aux passionnés.

Ce projet résout définitivement ce problème en utilisant **l'authentification par session Web (`auth_token` + `ct0`)** et les endpoints internes GraphQL de Twitter. 
- 💸 **0 € / mois de frais d'API**
- 🛡️ **Zéro ban / Zéro shadowban** grâce à la simulation des en-têtes réels de navigateur
- 👑 **Arbitrage Anti-Collision Intelligent** : 1 seul tweet de pronostic par créneau horaire (H-1h avant le coup d'envoi), avec priorité absolue aux chocs de Premier League et des Top 4 Ligues européennes
- ⚽ **Alertes Buts en Direct** : Détection des scores en temps réel et tweet instantané dès qu'un but est marqué
- 🏁 **Débriefs Fin de Match (FT)** : Résumé automatique dès le coup de sifflet final (prono validé ou manqué)
- 🚀 **Multi-Like Satellites** : Possibilité de configurer des comptes secondaires pour liker automatiquement chaque tweet et propulser le compte dans l'algorithme *Pour Vous*

---

## 🚀 Démarrage Rapide dans un Terminal

### 1. Prérequis
- [Node.js](https://nodejs.org/) version 18, 20 ou 22 LTS
- Git

### 2. Cloner et installer le projet

```bash
# Cloner le dépôt
git clone https://github.com/votre-compte/football-x-bot.git
cd football-x-bot

# Installer les dépendances
npm install
```

### 3. Lancer l'outil CLI interactif

```bash
npm run cli
```

Le menu interactif s'affiche dans votre terminal :
```text
╔═══════════════════════════════════════════════════════════════════════╗
║   ⚽  FOOTBALL X-BOT PRO — TERMINAL CLI RUNNER                       ║
║   100% GRATUIT | ZÉRO API TWITTER PAYANTE | SESSION COOKIES WEB       ║
╚═══════════════════════════════════════════════════════════════════════╝

MENU PRINCIPAL :
  1. 🔑 Configurer le compte X principal (Cookies auth_token + ct0 gratuits)
  2. 🚀 Configurer les comptes Boosters (Multi-Like anti-shadowban)
  3. 🧪 Tester la publication d'un Tweet instantané sur X
  4. ⚽ Synchroniser SportyTrader & Planifier H-1 (Anti-collision)
  5. 🤖 Démarrer le Bot Autonome en direct (Veille continue H-1, Buts, FT)
  6. 📊 Voir la liste des matchs suivis et la file d'attente
  7. ⚙️ Changer le mode de publication
  8. 🚪 Quitter
```

---

## 🔑 Comment récupérer vos cookies X gratuits (en 30 secondes)

Pas besoin de compte développeur Twitter ni de carte bancaire. Vous utilisez simplement les cookies de votre compte déjà connecté sur votre navigateur :

1. Ouvrez [https://x.com](https://x.com) dans **Google Chrome**, **Edge**, **Brave** ou **Firefox** avec votre compte connecté.
2. Ouvrez les outils développeurs en appuyant sur **`F12`** (ou Clic droit > *Inspecter*).
3. Cliquez sur l'onglet **`Application`** (ou **`Stockage`** sous Firefox).
4. Dans le panneau de gauche, déroulez **`Cookies`** puis cliquez sur `https://x.com`.
5. Repérez et copiez la valeur de ces deux cookies :
   - `auth_token` *(chaîne hexadécimale de ~40 caractères)*
   - `ct0` *(chaîne de ~32 à 160 caractères)*
6. Collez-les dans le CLI (Option 1) ou dans le fichier `.env` :

```env
X_AUTH_TOKEN=votre_auth_token_ici
X_CT0=votre_ct0_ici
```

---

## 🤖 Lancer le Bot Autonome (Mode Démon)

Pour laisser le bot tourner 24h/24 en arrière-plan sur votre machine ou un VPS Linux :

```bash
# Démarrer directement la boucle autonome en ligne de commande
npm run bot
```

### Tournée du bot toutes les 60 secondes :
1. **Veille H-1h** : Vérifie l'heure des matchs du jour. Exactement 1h avant le coup d'envoi (entre H-75min et H-40min), il publie le pronostic sélectionné.
2. **Anti-superposition** : Si plusieurs matchs démarrent à 21h00 (ex: Arsenal vs Chelsea et Brest vs Metz), seul le match de Premier League est publié. Aucun spam, aucun doublon.
3. **Live Goals** : Surveille les scores en direct (ESPN Scoreboard & API). Dès qu'un but est marqué, un tweet dynamique d'alerte but est posté.
4. **Débrief FT** : Au coup de sifflet final, analyse le résultat vs le prono initial et publie le bilan.
5. **Multi-Like** : Dès qu'un tweet est publié, vos comptes satellites le likent immédiatement pour donner un coup de pouce algorithmique.

---

## 🌐 Interface Web Dashboard (Optionnel)

Si vous préférez une interface graphique avec aperçu visuel en direct, démarrez le serveur Web :

```bash
npm run dev
```
Puis ouvrez **`http://localhost:3000`** dans votre navigateur.

---

## 🖥️ Déploiement sur un VPS Linux (Production 24/7)

### Option A : Avec PM2 (Recommandé)

```bash
# Installer PM2 globalement
npm install -g pm2

# Démarrer le bot autonome
pm2 start "npm run bot" --name "football-x-bot"

# Configurer le redémarrage automatique en cas de reboot serveur
pm2 startup
pm2 save

# Voir les logs en direct
pm2 logs football-x-bot
```

### Option B : Avec Docker & Docker Compose

```bash
# Lancer avec docker-compose
docker compose up -d

# Voir les logs
docker compose logs -f
```

### Option C : Avec un service Systemd

Créez le fichier `/etc/systemd/system/football-x-bot.service` :
```ini
[Unit]
Description=Football X-Bot Pro
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/root/football-x-bot
ExecStart=/usr/bin/npm run bot
Restart=always
RestartSec=10
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
```

Puis activez-le :
```bash
sudo systemctl daemon-reload
sudo systemctl enable football-x-bot
sudo systemctl start football-x-bot
sudo journalctl -u football-x-bot -f
```

---

## 📁 Structure du Projet

```text
├── scripts/
│   └── cli.ts                     # Runner interactif Terminal & Démon
├── server/
│   ├── xPublisher.ts              # Moteur de publication X sans API payante (GraphQL + Cookies)
│   ├── autoTweetPipeline.ts       # Pipeline H-1, alertes buts et débriefs FT
│   ├── dateScheduler.ts           # Logique temporelle stricte et anti-passé
│   ├── liveScoreChecker.ts        # Vérification en direct des scores (ESPN Scoreboards)
│   ├── sportytraderScraper.ts     # Scraper SportyTrader (Top 4 Ligues)
│   └── tweetQueue.ts              # File d'attente anti-spam (espacement garanti)
├── src/
│   └── components/
│       └── SimplifiedBotDashboard.tsx  # Dashboard Web React / Tailwind
├── server.ts                      # Serveur Node.js / Express
├── Dockerfile                     # Image Docker de production
├── docker-compose.yml             # Déploiement multi-conteneur
└── package.json                   # Scripts et dépendances
```

---

## ⚙️ Variables d'Environnement (`.env`)

Copiez le fichier `.env.example` vers `.env` :

```bash
cp .env.example .env
```

| Variable | Description | Obligatoire |
| :--- | :--- | :--- |
| `X_AUTH_TOKEN` | Cookie d'authentification Twitter principal | **Oui** |
| `X_CT0` | Token CSRF Twitter principal | **Oui** |
| `X_BOOSTER1_AUTH_TOKEN` | Cookie du compte satellite booster #1 (multi-like) | Non |
| `X_BOOSTER1_CT0` | CSRF token du booster #1 | Non |
| `API_FOOTBALL_KEY` | Clé API-Football / RapidAPI (optionnel, ESPN par défaut) | Non |
| `MISTRAL_API_KEY` | Clé Mistral AI (optionnel, moteur heuristique local par défaut) | Non |
| `GEMINI_API_KEY` | Clé Gemini (optionnel, moteur heuristique local par défaut) | Non |

---

## 🛡️ Respect des Règles et Sécurité

1. **Anti-Spam & Espacement** : Le bot impose un intervalle minimum entre chaque publication pour éviter toute détection par les filtres de Twitter.
2. **Rotation des en-têtes** : Les requêtes GraphQL imitent fidèlement les headers officiels du client Web Twitter.
3. **Persistance Locale** : Vos identifiants et l'historique sont enregistrés localement sur votre machine dans `.x_credentials.json` et ne sont jamais transmis à un tiers.

---

## 📄 Licence

Ce projet est sous licence MIT. Vous êtes libre de l'utiliser, le modifier et le déployer sur vos propres serveurs.
