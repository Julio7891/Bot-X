@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Football X-Bot - Dashboard local
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js est introuvable. Installe Node.js LTS depuis https://nodejs.org puis relance ce fichier.
  pause
  exit /b 1
)
if not exist node_modules (
  echo Installation des dependances (premier lancement)...
  call npm install
  if errorlevel 1 (
    echo Echec de npm install. Verifie ta connexion Internet et relance.
    pause
    exit /b 1
  )
)
echo.
echo Demarrage du dashboard local sur http://localhost:3000
echo Le serveur gere aussi les cycles automatiques en arriere-plan.
echo N'utilise pas en meme temps le mode Bot Terminal pour eviter deux processus concurrents.
echo Pour arreter : ferme cette fenetre avec Ctrl+C.
start "" /min cmd /c "timeout /t 5 /nobreak >nul & start http://localhost:3000"
call npm run dev
pause
