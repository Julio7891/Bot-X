@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Football X-Bot - Bot autonome
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js est introuvable. Installe Node.js LTS depuis https://nodejs.org puis relance ce fichier.
  pause
  exit /b 1
)
if not exist node_modules (
  echo Installation des dependances (premier lancement)...
  call npm install
  if errorlevel 1 (
    echo Echec de npm install. Verifie ta connexion Internet et relance.
    pause
    exit /b 1
  )
)
echo.
echo Demarrage du bot autonome dans ce terminal.
echo Ne lance pas aussi le Dashboard : les deux modes peuvent executer les memes automatisations.
echo Pour arreter : Ctrl+C.
call npm run bot
pause
