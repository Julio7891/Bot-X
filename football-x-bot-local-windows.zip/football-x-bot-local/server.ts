import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import {
  fetchEspnFixtures,
  fetchFootballDataOrg,
  fetchApiFootballFixtures,
  RealFootballMatch,
} from "./server/footballService";
import {
  executeGeminiWithFallback,
  generateLocalHeuristicProno,
  generateLocalHeuristicRecap,
  generateAiLiveMatchEventTweet,
} from "./server/geminiService";
import { executeMistralWithFallback, cleanAndParseJson } from "./server/mistralService";
import {
  publishTweetToX,
  likeTweetViaCookies,
  likeTweetWithAllAccounts,
  testXCookies,
  updateServerXCredentials,
  getServerXCredentials,
  getPublishingMode,
  setPublishingMode,
  getCookieHealth,
} from "./server/xPublisher";
import {
  scrapeSportyTrader,
  parseSportyTraderInput,
  SportyTraderProno,
} from "./server/sportytraderScraper";
import {
  syncSportyTraderAndGenerateTweets,
  checkAndProcessLiveGoalsAndFT,
  generateMorningAnnouncementTweet,
  generateDailyRecapTweet,
  getTodayFinishedMatchesSummary,
  setAutoGoalAlertsEnabled,
  isAutoGoalAlertsEnabled,
  getAllManagedTweets,
  getManagedPronosList,
  markTweetPublished,
  registerTrackedPrediction,
  getTrackedPredictions,
  removeTrackedPrediction,
  trackAllPronos,
  updateMatchLiveScoreManual,
  simulateGoalForMatch,
  simulateFTForMatch,
  runAutoPilotCycle,
  getBotState,
  setAutoPilotEnabled,
  getBotLogs,
  clearBotLogs,
  selectAndScheduleSmartSlotMatches,
  autoPurgeOldMatchesAndSyncFresh,
  applySmartSlotArbitration,
  resetTonightMatchesForRetry,
  unlockFailedUpcomingMatchesForRetry,
  setSlotCollisionMode,
  getSlotCollisionMode,
  forceEnqueueAllTonightMatches,
  dispatchAllPendingDebriefs,
  publishSingleDebriefNow,
  getDebriefTweetTextForMatch,
  repairCorruptedDebriefStatuses,
} from "./server/autoTweetPipeline";
import { fetchLiveScoresForLeagues, findMatchScore } from "./server/liveScoreChecker";
import { getQueueStatus, setMinSpacingSeconds, processQueueTick } from "./server/tweetQueue";
import { getParisNow } from "./server/dateScheduler";

import AdmZip from "adm-zip";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// API: Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// API: One-click download project as ZIP (Ready for GitHub)
app.get("/api/export-project-zip", (req, res) => {
  try {
    const zip = new AdmZip();
    const rootDir = process.cwd();

    function addDirToZip(currentDir: string, zipPath: string) {
      const items = fs.readdirSync(currentDir, { withFileTypes: true });
      const EXCLUDED_NAMES = new Set([
        "node_modules",
        "dist",
        "data",
        ".git",
        ".aistudio",
        ".env",
        ".env.local",
        ".x_credentials.json",
        ".bot_state.json",
        ".bot_activity_logs.json",
        ".tracked_predictions.json",
        ".managed_pronos.json",
        ".managed_tweets.json",
        ".handled_events.json",
        ".tweet_queue.json",
        "server.js",
      ]);

      for (const item of items) {
        if (
          EXCLUDED_NAMES.has(item.name) ||
          item.name.endsWith(".zip") ||
          item.name.endsWith(".log") ||
          item.name.endsWith(".tmp")
        ) {
          continue;
        }

        const fullPath = path.join(currentDir, item.name);
        const relZipPath = zipPath ? `${zipPath}/${item.name}` : item.name;

        if (item.isDirectory()) {
          addDirToZip(fullPath, relZipPath);
        } else {
          zip.addLocalFile(fullPath, zipPath || "");
        }
      }
    }

    addDirToZip(rootDir, "");

    const buffer = zip.toBuffer();
    res.setHeader("Content-Disposition", 'attachment; filename="football-x-bot.zip"');
    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Length", buffer.length);
    res.send(buffer);
  } catch (err: any) {
    console.error("[ZIP Export] Error generating zip:", err);
    if (!res.headersSent) {
      res.status(500).json({ error: err?.message || "Internal error" });
    }
  }
});

// API: Real Football Fixtures (Live from ESPN Scoreboards, API-Football & Football-Data)
app.get("/api/football/real-fixtures", async (req, res) => {
  try {
    const apiFootballKey =
      (req.headers["x-apisports-key"] as string) ||
      (req.headers["x-rapidapi-key"] as string) ||
      (req.headers["x-football-data-key"] as string) ||
      process.env.API_FOOTBALL_KEY ||
      process.env.FOOTBALL_DATA_API_KEY;

    let matches: RealFootballMatch[] = [];

    // 1. If an API-Football / API-Sports key is provided, query it
    if (apiFootballKey) {
      if (apiFootballKey.length === 32 || apiFootballKey.includes("-") || apiFootballKey.length > 40) {
        const apiFbMatches = await fetchApiFootballFixtures(apiFootballKey);
        if (apiFbMatches.length > 0) {
          matches = [...matches, ...apiFbMatches];
        }
      }
      // Also try Football-Data.org
      const fdMatches = await fetchFootballDataOrg(apiFootballKey);
      if (fdMatches.length > 0) {
        matches = [...matches, ...fdMatches];
      }
    }

    // 2. Fetch real live fixtures from ESPN scoreboards (Ligue 1, Champions League & Qualifiers, Premier League, La Liga, Serie A, etc.)
    const espnMatches = await fetchEspnFixtures();
    if (espnMatches.length > 0) {
      matches = [...matches, ...espnMatches];
    }

    // Deduplicate by team names
    const uniqueMap = new Map<string, RealFootballMatch>();
    for (const m of matches) {
      const key = `${m.homeTeam.toLowerCase()}-${m.awayTeam.toLowerCase()}`;
      if (!uniqueMap.has(key)) {
        uniqueMap.set(key, m);
      }
    }
    const finalMatches = Array.from(uniqueMap.values());

    res.json({
      success: true,
      source: finalMatches.length > 0 ? "LIVE_SPORTS_API" : "FALLBACK",
      count: finalMatches.length,
      fixtures: finalMatches,
    });
  } catch (error: any) {
    console.error("[API Football] Error retrieving real fixtures:", error);
    res.status(500).json({
      success: false,
      error: error.message || "Failed to fetch real football fixtures",
      fixtures: [],
    });
  }
});

// API: Live score updater poll
app.get("/api/football/live-scores", async (req, res) => {
  try {
    const espnMatches = await fetchEspnFixtures();
    const liveOrFinished = espnMatches.map((m) => ({
      id: m.id,
      homeTeam: m.homeTeam,
      awayTeam: m.awayTeam,
      status: m.status,
      liveMinute: m.liveMinute,
      actualScore: m.actualScore,
      goalScorers: m.goalScorers,
    }));

    res.json({
      success: true,
      timestamp: Date.now(),
      matches: liveOrFinished,
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// API: Save X Session Cookies (100% Free - Zero Paid API) + Immediate Live Verification
app.post("/api/x/save-credentials", async (req, res) => {
  try {
    const {
      publishingMode,
      authToken,
      ct0,
      booster1AuthToken,
      booster1Ct0,
      booster2AuthToken,
      booster2Ct0,
    } = req.body;

    const cleanAuth = typeof authToken === "string" ? authToken.trim() : undefined;
    const cleanCt0 = typeof ct0 === "string" ? ct0.trim() : undefined;

    updateServerXCredentials({
      publishingMode:
        publishingMode || (cleanAuth && cleanCt0 ? "LIVE_COOKIES" : undefined),
      authToken: cleanAuth,
      ct0: cleanCt0,
      booster1AuthToken: typeof booster1AuthToken === "string" ? booster1AuthToken.trim() : undefined,
      booster1Ct0: typeof booster1Ct0 === "string" ? booster1Ct0.trim() : undefined,
      booster2AuthToken: typeof booster2AuthToken === "string" ? booster2AuthToken.trim() : undefined,
      booster2Ct0: typeof booster2Ct0 === "string" ? booster2Ct0.trim() : undefined,
    });

    const creds = getServerXCredentials();
    const hasCookies = Boolean(creds.authToken && creds.ct0);
    const hasBooster1 = Boolean(creds.booster1AuthToken && creds.booster1Ct0);
    const hasBooster2 = Boolean(creds.booster2AuthToken && creds.booster2Ct0);

    let diagnostic = null;
    let unlockedCount = 0;
    if (hasCookies) {
      diagnostic = await testXCookies(creds.authToken, creds.ct0);
      if (diagnostic.success) {
        unlockedCount = unlockFailedUpcomingMatchesForRetry();
        processQueueTick().catch(() => {});
      }
    }

    const cookieHealth = getCookieHealth();
    const mode = getPublishingMode();

    res.json({
      success: true,
      verified: Boolean(diagnostic?.success),
      diagnostic,
      unlockedCount,
      cookieHealth,
      message: diagnostic?.success
        ? `✅ Compte X connecté (${diagnostic.username ? `@${diagnostic.username}` : "Session vérifiée"}) !${unlockedCount > 0 ? ` ${unlockedCount} match(s) débloqué(s).` : ""}`
        : hasCookies
        ? `⚠️ Cookies enregistrés, mais vérification X : ${diagnostic?.message || "à vérifier"}`
        : "⚠️ Aucun cookie auth_token + ct0 fourni.",
      status: {
        hasCookies,
        hasBooster1,
        hasBooster2,
        username: cookieHealth.username || creds.username,
        displayName: cookieHealth.displayName || creds.displayName,
        cookieHealth,
        publishingMode: mode,
        autonomousReady:
          (hasCookies && cookieHealth.status !== "EXPIRED" && cookieHealth.status !== "IP_BLOCKED") ||
          mode === "SIMULATION",
      },
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err?.message || "Erreur d'enregistrement" });
  }
});

// API: Set Publishing Mode (LIVE_COOKIES or SIMULATION)
app.post("/api/x/set-publishing-mode", (req, res) => {
  const { mode } = req.body;
  if (mode === "AUTO" || mode === "LIVE_COOKIES" || mode === "SIMULATION") {
    setPublishingMode(mode);
  }
  res.json({
    success: true,
    publishingMode: getPublishingMode(),
  });
});

// API: Get current server-side credentials & real cookie health status
app.get("/api/x/credentials-status", (_req, res) => {
  const creds = getServerXCredentials();
  const cookieHealth = getCookieHealth();
  const hasCookies = Boolean(creds.authToken && creds.ct0);
  const hasBooster1 = Boolean(creds.booster1AuthToken && creds.booster1Ct0);
  const hasBooster2 = Boolean(creds.booster2AuthToken && creds.booster2Ct0);
  const mode = getPublishingMode();

  res.json({
    hasCookies,
    hasBooster1,
    hasBooster2,
    username: cookieHealth.username || creds.username,
    displayName: cookieHealth.displayName || creds.displayName,
    cookieHealth,
    publishingMode: mode,
    autonomousReady:
      (hasCookies && cookieHealth.status !== "EXPIRED" && cookieHealth.status !== "IP_BLOCKED") ||
      mode === "SIMULATION",
    mode: hasCookies ? "session_cookies" : "none",
  });
});

// API: Validate X Cookies / Session Format & Connectivity
app.post("/api/x/validate-session", (req, res) => {
  const { authToken, ct0 } = req.body;
  if (!authToken || !ct0) {
    return res.status(400).json({
      valid: false,
      message: "Les cookies auth_token et ct0 sont tous les deux requis.",
    });
  }

  const isTokenHexOrAlpha = authToken.length >= 20;
  const isCt0Valid = ct0.length >= 20;

  if (isTokenHexOrAlpha && isCt0Valid) {
    return res.json({
      valid: true,
      message: "Format de session valide ! Prêt pour l'injection Playwright.",
      details: {
        authTokenLength: authToken.length,
        ct0Length: ct0.length,
      },
    });
  }

  return res.json({
    valid: false,
    message: "Le format des cookies semble incomplet (vérifiez avoir copié la valeur exacte dans DevTools).",
  });
});

// API: Detailed Cookie Diagnostic & Live Test
app.post("/api/x/test-connection", async (req, res) => {
  const { authToken, ct0 } = req.body;
  const diagnostic = await testXCookies(authToken, ct0);
  res.json(diagnostic);
});

// API: Generate Pronostic Tweet (1 hour before match)
const generatePronoHandler: express.RequestHandler = async (req, res) => {
  const {
    homeTeam,
    awayTeam,
    league = "Ligue 1",
    matchTime = "21h00",
    odds,
    formHome,
    formAway,
    keyStat,
    tone = "tipster",
    targetMarket = "auto",
    includeHashtags = true,
    includeOdds = true,
    customNote = "",
  } = req.body;

  if (!homeTeam || !awayTeam) {
    res.status(400).json({ error: "homeTeam and awayTeam are required" });
    return;
  }

  const prompt = `You are the most reputable European football data analyst and professional sports tipster on X (Twitter), specializing in Premier League, Champions League, La Liga, Serie A, and Ligue 1. You are celebrated for sharp tactical insights, mathematical value betting, and high engagement tweets on X.

MISSION: Provide a DEEP, UNIQUE TACTICAL ANALYSIS and an EXPERT BETTING PREDICTION for this match. ALL OUTPUT TEXT AND TWEETS MUST BE IN ENGLISH.

MATCH DETAILS:
- Competition: ${league}
- Fixture: ${homeTeam} (Home) vs ${awayTeam} (Away)
- Kickoff: ${matchTime}
- 1X2 Market Odds: [1: ${odds?.home || "2.10"} | X: ${odds?.draw || "3.40"} | 2: ${odds?.away || "3.20"}]
- Side Market Odds: Over 2.5: ${odds?.over25 || "1.75"} | Under 2.5: ${odds?.under25 || "1.95"} | BTTS Yes: ${odds?.bttsYes || "1.72"} | DNB 1: ${odds?.dnbHome || "1.45"}
- Recent Form: ${homeTeam} (${formHome || "W-D-W-W-L"}) vs ${awayTeam} (${formAway || "W-W-D-L-W"})
- Key Tactical Factor: ${keyStat || "Collective tactical dynamics, xG differential, and head-to-head records"}
- Target Market: ${targetMarket === "auto" ? "Select the highest-value collective market" : targetMarket}
- Tone: ${tone} (expert, sharp, concise)

CRITICAL DIRECTIVES:
1. ⚠️ STRICT BAN: NEVER MENTION INDIVIDUAL PLAYER NAMES, GOALSCORER NAMES, OR COACH/MANAGER NAMES. Focus EXCLUSIVELY on club names, tactical setup, and collective dynamics.
2. DIVERSE COLLECTIVE MARKETS:
   - Total Goals: Over/Under 1.5, Over/Under 2.5, Over/Under 3.5, Over 2.0 Goal Line
   - Both Teams to Score: BTTS (Yes) / BTTS (No)
   - Double Chance & Goals (e.g. 1X & Over 1.5 Goals, X2 & Under 3.5 Goals)
   - Draw No Bet (DNB 1 or DNB 2)
   - Moneyline 1X2 or Asian Handicap (-1.5 / +1.5)
3. ROTATE PREDICTIONS & SCORES:
   - Avoid monotonous predictions. Vary realistic projected scores: 1-0, 3-0, 0-2, 2-0, 3-1, 1-2, 2-2, 0-1, 3-2, 4-1, 0-0.
4. ENGAGING HOOKS:
   - Use dynamic headers (e.g. "🔥 VALUE MATCH OF THE DAY", "📊 DATA & TACTICAL ANALYSIS", "⚡ BIG MATCHDAY PICK", "🛡️ TODAY'S BANKER PICK", "🎯 EXPERT BETTING SELECTION").
5. ACCURATE CONFIDENCE PERCENTAGE:
   - Low-risk banker picks: 86% - 93%
   - Balanced value picks: 72% - 83%
   - High-reward picks: 58% - 69%
6. X TWEET FORMAT:
   - STRICTLY UNDER 270 CHARACTERS.
   - Written in natural, fluent English with emojis, score projection, confidence rating, and club hashtags (#FootballTips #BettingTips).

Respond STRICTLY in valid JSON format:
{
  "tweetText": "Full ready-to-publish English tweet (< 270 chars) with hashtags",
  "predictionType": "Exact market name in English (e.g. Over 2.5 Goals, Liverpool to Win, Both Teams to Score)",
  "predictedScore": "Projected score (e.g. 3-1, 0-2, 2-0, 3-2)",
  "estimatedOdd": "Market odds (e.g. 1.68, 1.85, 2.10, 1.45)",
  "confidencePercent": 77,
  "keyReasoning": "1 concise tactical sentence explaining the collective edge in English",
  "recommendedBet": "Full bet description and odd in English",
  "safeAlternative": "Safer alternative market in English"
}`;

  // 1. Try Mistral AI first (Primary AI Engine)
  try {
    const rawText = await executeMistralWithFallback(prompt);
    const parsed = cleanAndParseJson(rawText);
    res.json({
      success: true,
      provider: "Mistral AI",
      model: "mistral-large-latest",
      data: {
        ...parsed,
        isAiGenerated: true,
        aiProvider: "Mistral AI",
      },
    });
    return;
  } catch (mistralErr: any) {
    console.warn("[Mistral AI] Error, falling back to Gemini:", mistralErr?.message || mistralErr);
    
    // 2. Try Gemini as secondary AI fallback
    try {
      const rawText = await executeGeminiWithFallback(prompt);
      const parsed = cleanAndParseJson(rawText);
      res.json({
        success: true,
        provider: "Gemini AI",
        data: {
          ...parsed,
          isAiGenerated: true,
          aiProvider: "Gemini AI",
        },
      });
      return;
    } catch (error: any) {
      console.warn("[Gemini Fallback Triggered] Using intelligent statistical heuristic engine:", error?.message || error);
      // 3. Graceful fallback to expert heuristic engine so user NEVER sees a 503 error
      const fallbackData = generateLocalHeuristicProno({
        homeTeam,
        awayTeam,
        league,
        matchTime,
        odds,
        formHome,
        formAway,
        keyStat,
        tone,
        targetMarket,
        customNote,
      });
      res.json({
        success: true,
        data: fallbackData,
        isFallback: true,
        fallbackReason: "Spike de charge IA temporaire - Analyse générée via le moteur statistique expert.",
      });
      return;
    }
  }
};

app.post("/api/gemini/generate-prono", generatePronoHandler);
app.post("/api/ai/generate-prono", generatePronoHandler);

// API: Generate Post-Match Recap Tweet (After match FT)
const generateRecapHandler: express.RequestHandler = async (req, res) => {
  const {
    homeTeam,
    awayTeam,
    league = "Football",
    finalScore = "2-1",
    initialPrediction = "Prono",
    wasPredictionWon = true,
    keyMatchFacts = "",
  } = req.body;

  const isWon = wasPredictionWon ?? true;
  const prompt = `You are a professional football tipster and data analyst on X (Twitter).
Write a high-impact POST-MATCH FULL TIME RESULT TWEET in ENGLISH to wrap up the match and evaluate the prediction.

Match Info:
- Fixture: ${homeTeam} ${finalScore} ${awayTeam}
- League: ${league}
- Initial Tip: ${initialPrediction}
- Status: ${isWon ? "WON / GREEN (✅)" : "LOST / MISSED (❌)"}
- Key Facts: ${keyMatchFacts || "Final score " + finalScore}

CRITICAL RULES:
1. STRICTLY UNDER 270 CHARACTERS.
2. ⚠️ ABSOLUTE BAN: NEVER MENTION INDIVIDUAL PLAYER NAMES, GOALSCORER NAMES, OR COACH/MANAGER NAMES. Mention only club names, collective performance, and final score.
3. ALL TEXT MUST BE IN ENGLISH.
4. Structure:
   - ${isWon ? "🏁 FULL TIME | ✅ GREEN & CASHED IN!" : "🏁 FULL TIME | ❌ TIP MISSED"}
   - Clear final score: ${homeTeam} ${finalScore} ${awayTeam}
   - Tip evaluation: "${initialPrediction}" landed comfortably or narrow miss
   - Closing sentence (transparency, next value bet)
   - Relevant hashtags (#FootballTips #BettingTips)

Respond in strict JSON format:
{
  "tweetText": "Full English tweet formatted for X (< 270 chars)",
  "summary": "1 sentence summarizing the outcome in English",
  "statusEmoji": "${isWon ? "✅" : "❌"}",
  "roiImpact": "${isWon ? "+0.85u" : "-1.00u"}"
}`;

  // 1. Try Mistral AI
  try {
    const rawText = await executeMistralWithFallback(prompt);
    const parsed = cleanAndParseJson(rawText);
    res.json({
      success: true,
      provider: "Mistral AI",
      data: {
        ...parsed,
        isAiGenerated: true,
        aiProvider: "Mistral AI",
      },
    });
    return;
  } catch (mistralErr: any) {
    console.warn("[Mistral AI Recap] Fallback to Gemini:", mistralErr?.message || mistralErr);

    // 2. Try Gemini
    try {
      const rawText = await executeGeminiWithFallback(prompt);
      const parsed = cleanAndParseJson(rawText);
      res.json({
        success: true,
        provider: "Gemini AI",
        data: {
          ...parsed,
          isAiGenerated: true,
          aiProvider: "Gemini AI",
        },
      });
      return;
    } catch (error: any) {
      console.warn("[Recap Fallback Triggered] Using heuristic engine:", error?.message || error);
      const fallbackRecap = generateLocalHeuristicRecap({
        homeTeam,
        awayTeam,
        league,
        finalScore,
        initialPrediction,
        wasPredictionWon: isWon,
      });
      res.json({
        success: true,
        data: fallbackRecap,
        isFallback: true,
      });
      return;
    }
  }
};

app.post("/api/gemini/generate-recap", generateRecapHandler);
app.post("/api/ai/generate-recap", generateRecapHandler);

export interface AiBrainThoughtRecord {
  id: string;
  timestamp: number;
  fixture: string;
  minute: string;
  score: string;
  scorers?: string;
  thought: string;
  detectedEvent: string;
  shockFactor: number;
  tweetText: string;
  status: "ANALYZED" | "PUBLISHED" | "PENDING";
  provider: string;
  publishedTweetId?: string;
}

const aiBrainThoughtLog: AiBrainThoughtRecord[] = [];

// Seed initial example thought matching user request (Racing Santander 3-0 Elche, Zabiri 15', 21', 36')
aiBrainThoughtLog.push({
  id: `thought-seed-1`,
  timestamp: Date.now() - 120000,
  fixture: "Racing Santander vs Elche",
  minute: "50:19",
  score: "3 - 0",
  scorers: "Zabiri 15', 21', 36'",
  thought: "Analyzed 36-minute first-half hat-trick from Zabiri. Unbelievable shock index (9.8/10). Racing running riot 3-0. Formulated viral English reaction tweet on X.",
  detectedEvent: "Zabiri 36-minute Hat-Trick Masterclass",
  shockFactor: 10,
  tweetText: "Who on earth could have predicted a 36-minute hat-trick from Zabiri?! 🤯🎩\n\nRacing Santander running completely riot 3-0 against Elche (50')! Absolute madness in La Liga 2 🔥\n\n#RacingSantander #Elche #LaLiga2 #FootballTips",
  status: "ANALYZED",
  provider: "Gemini 3.7 Flash AI",
});

// API: Generate AI Live Event Commentary (Hat-tricks, Goals, Comebacks, Blowouts in pure English)
app.post("/api/ai/live-event-tweet", async (req, res) => {
  try {
    const {
      homeTeam,
      awayTeam,
      competition = "Football",
      scoreHome = 0,
      scoreAway = 0,
      minute = "LIVE",
      scorers = "",
      eventType = "AUTO",
      prediction = "",
      odd = "1.85",
      extraContext = "",
    } = req.body;

    if (!homeTeam || !awayTeam) {
      return res.status(400).json({ success: false, message: "homeTeam and awayTeam are required" });
    }

    const aiResult = await generateAiLiveMatchEventTweet({
      homeTeam: String(homeTeam).trim(),
      awayTeam: String(awayTeam).trim(),
      competition: String(competition).trim(),
      scoreHome: parseInt(scoreHome, 10) || 0,
      scoreAway: parseInt(scoreAway, 10) || 0,
      minute: String(minute).trim(),
      scorers: String(scorers || "").trim(),
      eventType,
      prediction: String(prediction || "").trim(),
      odd: String(odd || "1.85"),
      extraContext: String(extraContext || "").trim(),
    });

    res.json({
      success: true,
      data: aiResult,
    });
  } catch (error: any) {
    console.error("[API Live Event Tweet Error]:", error);
    res.status(500).json({ success: false, message: error.message });
  }
});

// API: Full Autonomous AI Brain Trigger (Simulate + AI Thought + Live Score + Auto-Publish to X)
app.post("/api/ai/simulate-live-brain", async (req, res) => {
  try {
    const {
      homeTeam = "Racing Santander",
      awayTeam = "Elche",
      competition = "La Liga 2",
      scoreHome = 3,
      scoreAway = 0,
      minute = "50:19",
      scorers = "Zabiri 15', 21', 36'",
      prediction = "Racing Santander to Win",
      odd = "2.10",
      autoPublishToX = false,
    } = req.body;

    const parsedHomeScore = parseInt(scoreHome, 10) || 0;
    const parsedAwayScore = parseInt(scoreAway, 10) || 0;

    // 1. Generate Intelligent AI Thought & English Tweet
    const aiResult = await generateAiLiveMatchEventTweet({
      homeTeam,
      awayTeam,
      competition,
      scoreHome: parsedHomeScore,
      scoreAway: parsedAwayScore,
      minute,
      scorers,
      prediction,
      odd,
      extraContext: scorers ? `Scorers: ${scorers}` : `Live score ${scoreHome}-${scoreAway}`,
    });

    // 2. Register or update tracked prediction in auto-pipeline
    const registeredPred = registerTrackedPrediction({
      homeTeam,
      awayTeam,
      competition,
      prediction,
      odd,
      kickoffTime: minute,
      status: "LIVE",
      publishedTweetText: aiResult.tweetText,
    });

    // 3. Update in-memory live scores
    updateMatchLiveScoreManual({
      matchId: registeredPred.id,
      scoreHome: parsedHomeScore,
      scoreAway: parsedAwayScore,
      isLive: true,
      liveMinute: minute,
    });

    // 4. Record AI thought in real-time stream
    const thoughtRecord: AiBrainThoughtRecord = {
      id: `thought-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      timestamp: Date.now(),
      fixture: `${homeTeam} vs ${awayTeam}`,
      minute,
      score: `${parsedHomeScore} - ${parsedAwayScore}`,
      scorers,
      thought: aiResult.aiReasoning,
      detectedEvent: aiResult.detectedEvent,
      shockFactor: aiResult.shockFactor,
      tweetText: aiResult.tweetText,
      status: "ANALYZED",
      provider: aiResult.provider,
    };

    // 5. If autoPublish requested, publish to X
    let publishResult: any = null;
    if (autoPublishToX) {
      try {
        publishResult = await publishTweetToX({ tweetText: aiResult.tweetText });
        if (publishResult?.success) {
          thoughtRecord.status = "PUBLISHED";
          thoughtRecord.publishedTweetId = publishResult.tweetId || publishResult.id;
        }
      } catch (pubErr: any) {
        console.warn("[AI Live Brain Publish Error]:", pubErr?.message);
      }
    }

    aiBrainThoughtLog.unshift(thoughtRecord);
    if (aiBrainThoughtLog.length > 50) {
      aiBrainThoughtLog.pop();
    }

    res.json({
      success: true,
      thought: thoughtRecord,
      aiAnalysis: aiResult,
      published: publishResult?.success || false,
      trackedPrediction: registeredPred,
    });
  } catch (error: any) {
    console.error("[AI Simulate Live Brain Error]:", error);
    res.status(500).json({ success: false, message: error.message });
  }
});

// API: Get AI Brain Thought Stream
app.get("/api/ai/brain-thoughts", (_req, res) => {
  res.json({
    success: true,
    count: aiBrainThoughtLog.length,
    thoughts: aiBrainThoughtLog,
  });
});

// API: Get AI Brain Status
app.get("/api/ai/status", (_req, res) => {
  const tracked = getTrackedPredictions();
  res.json({
    success: true,
    isOnline: true,
    activeTrackedMatches: tracked.length,
    recentThoughtsCount: aiBrainThoughtLog.length,
    lastThought: aiBrainThoughtLog[0] || null,
    modelName: "Gemini 3.7 Flash & Mistral AI",
    language: "English (100% Native)",
  });
});

// API: Generate Football Fixtures list with AI
app.post("/api/gemini/generate-fixtures", async (req, res) => {
  const { league = "Ligue 1 & Champions League" } = req.body;

  const prompt = `Génère une liste de 5 matchs de football réalistes et passionnants pour aujourd'hui ou ce week-end (Compétitions : ${league}, Ligue des Champions, Premier League, La Liga, Ligue 1, Serie A).
Pour chaque match, inclus des cotes crédibles, la forme récente des deux équipes, et l'heure du coup d'envoi.

Réponds au format JSON strict :
{
  "fixtures": [
    {
      "id": "match-1",
      "league": "UEFA Champions League",
      "homeTeam": "Paris Saint-Germain",
      "awayTeam": "Real Madrid",
      "homeLogo": "🔴🔵",
      "awayLogo": "⚪👑",
      "kickoffTime": "21:00",
      "kickoffDate": "Aujourd'hui",
      "odds": { "home": "2.25", "draw": "3.50", "away": "2.95" },
      "formHome": "V-V-N-V-V",
      "formAway": "V-N-V-D-V",
      "stadium": "Parc des Princes",
      "keyStat": "PSG invaincu à domicile lors des 8 derniers matchs d'Europe"
    }
  ]
}`;

  try {
    let rawText = "";
    try {
      rawText = await executeMistralWithFallback(prompt);
    } catch (e) {
      rawText = await executeGeminiWithFallback(prompt);
    }
    const data = cleanAndParseJson(rawText);
    return res.json({
      success: true,
      provider: "Mistral AI",
      fixtures: data.fixtures || [],
    });
  } catch (error: any) {
    console.warn("[Gemini Fixtures Fallback Triggered]:", error?.message || error);
    return res.json({
      success: true,
      fixtures: [
        {
          id: "fix-fallback-1",
          league: "UEFA Champions League",
          homeTeam: "Paris Saint-Germain",
          awayTeam: "Real Madrid",
          homeLogo: "🔴🔵",
          awayLogo: "⚪👑",
          kickoffTime: "21:00",
          kickoffDate: "Ce soir",
          odds: { home: "2.20", draw: "3.45", away: "2.90" },
          formHome: "V-V-N-V-V",
          formAway: "V-N-V-D-V",
          stadium: "Parc des Princes",
          keyStat: "Choc au sommet européen",
        },
        {
          id: "fix-fallback-2",
          league: "Premier League",
          homeTeam: "Arsenal",
          awayTeam: "Manchester City",
          homeLogo: "🔴⚪",
          awayLogo: "🔵⚪",
          kickoffTime: "18:30",
          kickoffDate: "Aujourd'hui",
          odds: { home: "2.55", draw: "3.30", away: "2.65" },
          formHome: "V-V-V-N-V",
          formAway: "V-V-N-D-V",
          stadium: "Emirates Stadium",
          keyStat: "Duel pour la première place",
        },
        {
          id: "fix-fallback-3",
          league: "Ligue 1",
          homeTeam: "Marseille",
          awayTeam: "Lyon",
          homeLogo: "⚪🔵",
          awayLogo: "🔴🔵",
          kickoffTime: "20:45",
          kickoffDate: "Ce soir",
          odds: { home: "2.05", draw: "3.50", away: "3.35" },
          formHome: "V-D-V-V-N",
          formAway: "V-V-N-V-D",
          stadium: "Orange Vélodrome",
          keyStat: "Olympico sous haute intensité",
        },
      ],
    });
  }
});

// Helper to parse match info from tweet text if not explicitly provided
function extractMatchInfoFromTweet(text: string): {
  homeTeam: string;
  awayTeam: string;
  prediction?: string;
  odd?: string;
  kickoffTime?: string;
} | null {
  if (!text) return null;

  // Pattern 1: "Match: TeamA vs TeamB"
  const matchRegex = /(?:Match|Fixture|Match\s*:|⚽\s*Match\s*:)\s*([^\n\r–—\-]+?)\s+(?:vs|v\.|contre)\s+([^\n\r]+)/i;
  const matchMatch = text.match(matchRegex);

  let homeTeam = "";
  let awayTeam = "";

  if (matchMatch) {
    homeTeam = matchMatch[1].trim().replace(/^[:\s]+/, "");
    awayTeam = matchMatch[2].trim().replace(/[\r\n].*$/, "").trim();
  } else {
    // Pattern 2: "PREDICTION TEAMA vs TEAMB" or "TEAM A vs TEAM B"
    const simpleVsRegex = /(?:PREDICTION\s+)?([A-Za-zÀ-ÿ0-9\s.]{3,25})\s+vs\s+([A-Za-zÀ-ÿ0-9\s.]{3,25})/i;
    const simpleMatch = text.match(simpleVsRegex);
    if (simpleMatch) {
      homeTeam = simpleMatch[1].trim();
      awayTeam = simpleMatch[2].trim();
    }
  }

  if (!homeTeam || !awayTeam) return null;

  const tipMatch = text.match(/(?:Tip|Prono|🎯\s*Tip\s*:)\s*([^\n\r]+)/i);
  const oddMatch = text.match(/(?:Odds|Cote|📈\s*Odds\s*:)\s*@?([0-9]+[.,][0-9]+)/i);
  const timeMatch = text.match(/\(([0-2]?[0-9][h:][0-5][0-9])\)/i);

  return {
    homeTeam,
    awayTeam,
    prediction: tipMatch ? tipMatch[1].trim() : "Victoire",
    odd: oddMatch ? oddMatch[1].replace(",", ".").trim() : "1.85",
    kickoffTime: timeMatch ? timeMatch[1].replace("h", ":").trim() : "21:00",
  };
}

// API: Publish Tweet to X using Session Cookies & Anti-Detection
app.post("/api/x/publish-tweet", async (req, res) => {
  try {
    const {
      tweetText,
      authToken,
      ct0,
      booster1AuthToken,
      booster1Ct0,
      booster2AuthToken,
      booster2Ct0,
      homeTeam,
      awayTeam,
      matchId,
      pronoId,
      prediction,
      odd,
      competition,
      date,
      kickoffTime,
    } = req.body;
    if (!tweetText) {
      return res.status(400).json({ success: false, message: "Le texte du tweet est requis" });
    }

    if (authToken && ct0 && authToken.length >= 20 && ct0.length >= 20) {
      updateServerXCredentials({
        authToken,
        ct0,
        booster1AuthToken,
        booster1Ct0,
        booster2AuthToken,
        booster2Ct0,
      });
    }

    const result = await publishTweetToX({
      tweetText,
      authToken,
      ct0,
      booster1AuthToken,
      booster1Ct0,
      booster2AuthToken,
      booster2Ct0,
    });

    // 🎯 If published successfully, register match in real-time tracking registry for Live Goals & FT Debrief
    if (result.success) {
      let finalHome = homeTeam;
      let finalAway = awayTeam;
      let finalPred = prediction;
      let finalOdd = odd;
      let finalKickoff = kickoffTime;

      if (!finalHome || !finalAway) {
        const parsed = extractMatchInfoFromTweet(tweetText);
        if (parsed) {
          finalHome = parsed.homeTeam;
          finalAway = parsed.awayTeam;
          finalPred = finalPred || parsed.prediction;
          finalOdd = finalOdd || parsed.odd;
          finalKickoff = finalKickoff || parsed.kickoffTime;
        }
      }

      if (finalHome && finalAway) {
        registerTrackedPrediction({
          id: matchId || pronoId,
          homeTeam: finalHome,
          awayTeam: finalAway,
          competition: competition || "Football",
          prediction: finalPred || "Victoire",
          odd: finalOdd || "1.85",
          date: date || "Aujourd'hui",
          kickoffTime: finalKickoff || "21:00",
          status: "PUBLISHED",
          publishedAt: Date.now(),
          publishedTweetId: result.tweetId,
          publishedTweetText: tweetText,
        });
        console.log(`[Auto-Tracker] 🎯 Match enregistré pour suivi Live Scores & Débrief FT : ${finalHome} vs ${finalAway}`);
      }
    }

    res.json(result);
  } catch (error: any) {
    console.error("Error in /api/x/publish-tweet:", error);
    res.status(500).json({
      success: false,
      message: error?.message || "Erreur lors de la publication",
    });
  }
});

// API: Register or Track a match for live score detection & debrief
app.post("/api/pipeline/track-prediction", (req, res) => {
  try {
    const { id, homeTeam, awayTeam, competition, date, kickoffTime, prediction, odd, status } = req.body;
    if (!homeTeam || !awayTeam) {
      return res.status(400).json({ success: false, message: "homeTeam et awayTeam requis" });
    }

    const tracked = registerTrackedPrediction({
      id,
      homeTeam,
      awayTeam,
      competition,
      date,
      kickoffTime,
      prediction: prediction || "Victoire",
      odd: odd || "1.85",
      status: status || "PUBLISHED",
      publishedAt: Date.now(),
    });

    res.json({ success: true, tracked });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// API: Untrack / remove a match prediction
app.post("/api/pipeline/untrack-prediction", (req, res) => {
  try {
    const { id } = req.body;
    if (!id) {
      return res.status(400).json({ success: false, message: "id requis" });
    }
    removeTrackedPrediction(id);
    res.json({ success: true, totalTracked: getTrackedPredictions().length });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// API: Track ALL available SportyTrader pronos with 1 click
app.post("/api/pipeline/track-all-pronos", async (_req, res) => {
  try {
    const result = await trackAllPronos();
    res.json({ success: true, ...result });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// API: Manually set/update live score or status for a tracked match
app.post("/api/pipeline/update-live-score", async (req, res) => {
  try {
    const {
      matchId,
      scoreHome,
      scoreAway,
      isLive,
      isFinished,
      liveMinute,
      scorerName,
      scoringTeam,
      authToken,
      ct0,
      booster1AuthToken,
      booster1Ct0,
      booster2AuthToken,
      booster2Ct0,
    } = req.body;
    if (!matchId) {
      return res.status(400).json({ success: false, message: "matchId requis" });
    }

    const result = await updateMatchLiveScoreManual({
      matchId,
      scoreHome: parseInt(scoreHome || "0", 10),
      scoreAway: parseInt(scoreAway || "0", 10),
      isLive: isLive !== undefined ? isLive : true,
      isFinished: isFinished !== undefined ? isFinished : false,
      liveMinute,
      scorerName,
      scoringTeam,
      authToken,
      ct0,
      booster1AuthToken,
      booster1Ct0,
      booster2AuthToken,
      booster2Ct0,
    });

    res.json(result);
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// API: Simulate Goal Event with live alert creation & tweet
app.post("/api/pipeline/simulate-goal", async (req, res) => {
  try {
    const {
      matchId,
      scoringTeam = "home",
      scorerName,
      minute,
      authToken,
      ct0,
      booster1AuthToken,
      booster1Ct0,
      booster2AuthToken,
      booster2Ct0,
    } = req.body;
    if (!matchId) {
      return res.status(400).json({ success: false, message: "matchId requis" });
    }

    const result = await simulateGoalForMatch({
      matchId,
      scoringTeam,
      scorerName,
      minute,
      authToken,
      ct0,
      booster1AuthToken,
      booster1Ct0,
      booster2AuthToken,
      booster2Ct0,
    });

    res.json(result);
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// API: Simulate Full Time (FT) Event with automated debrief creation & tweet
app.post("/api/pipeline/simulate-ft", async (req, res) => {
  try {
    const { matchId, scoreHome, scoreAway } = req.body;
    if (!matchId) {
      return res.status(400).json({ success: false, message: "matchId requis" });
    }

    const result = await simulateFTForMatch({
      matchId,
      scoreHome: scoreHome !== undefined ? parseInt(scoreHome, 10) : undefined,
      scoreAway: scoreAway !== undefined ? parseInt(scoreAway, 10) : undefined,
    });

    res.json(result);
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// API: Get all actively tracked match predictions
app.get("/api/pipeline/tracked-predictions", async (_req, res) => {
  try {
    const tracked = getTrackedPredictions();
    const liveScores = await fetchLiveScoresForLeagues();

    // Attach live scores to tracked predictions
    const trackedWithScores = tracked.map((t) => {
      const matchScore = findMatchScore(t.homeTeam, t.awayTeam, liveScores);
      return {
        ...t,
        currentLiveScore: matchScore
          ? {
              scoreHome: matchScore.scoreHome,
              scoreAway: matchScore.scoreAway,
              isLive: matchScore.isLive,
              isFinished: matchScore.isFinished,
              liveMinute: matchScore.liveMinute || matchScore.statusText,
            }
          : (t.scoreHome !== undefined && t.scoreAway !== undefined)
          ? {
              scoreHome: t.scoreHome,
              scoreAway: t.scoreAway,
              isLive: t.status === "LIVE",
              isFinished: t.status === "DEBRIEF_SENT" && Boolean(t.debriefTweetSent),
              liveMinute: t.lastLiveMinute || (t.debriefTweetSent ? "FT" : "LIVE"),
            }
          : null,
      };
    });

    res.json({
      success: true,
      count: tracked.length,
      tracked: trackedWithScores,
    });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// API: Dispatch debriefs for all finished matches that have not been debriefed yet
app.post("/api/pipeline/dispatch-all-debriefs", async (_req, res) => {
  try {
    const result = await dispatchAllPendingDebriefs();
    const tracked = getTrackedPredictions();
    res.json({
      success: true,
      ...result,
      tracked,
    });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// API: Publish or generate debrief for a single match
app.post("/api/pipeline/publish-debrief-now", async (req, res) => {
  try {
    const { matchId } = req.body;
    if (!matchId) {
      return res.status(400).json({ success: false, message: "matchId requis" });
    }
    const result = await publishSingleDebriefNow(matchId);
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// API: Get debrief text and intent URL preview for a match
app.get("/api/pipeline/debrief-preview/:matchId", (req, res) => {
  try {
    const { matchId } = req.params;
    const preview = getDebriefTweetTextForMatch(matchId);
    if (!preview) {
      return res.status(404).json({ success: false, message: "Match non trouvé" });
    }
    res.json({
      success: true,
      ...preview,
      intentUrl: `https://twitter.com/intent/tweet?text=${encodeURIComponent(preview.tweetText)}`,
    });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// API: Repair corrupted statuses
app.post("/api/pipeline/repair-debrief-statuses", (_req, res) => {
  try {
    const repairedCount = repairCorruptedDebriefStatuses();
    const tracked = getTrackedPredictions();
    res.json({
      success: true,
      repairedCount,
      count: tracked.length,
      tracked,
    });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// API: Purge expired matches AND perform fresh live scrape (SportyTrader + ESPN Live AI fallback)
app.post("/api/pipeline/auto-purge-sync", async (_req, res) => {
  try {
    const stats = autoPurgeOldMatchesAndSyncFresh();
    const syncRes = await syncSportyTraderAndGenerateTweets();
    lastScrapeTimestamp = Date.now();
    nextScrapeTimestamp = Date.now() + 30 * 60 * 1000;
    lastScrapeCount = syncRes.pronos.length;
    lastScrapeStatus = syncRes.pronos.length > 0 ? "SUCCESS" : "EMPTY";
    const tracked = getTrackedPredictions();
    res.json({
      success: true,
      stats: {
        ...stats,
        newMatchesAdded: syncRes.newPronosCount,
      },
      source: syncRes.source,
      sourceMessage: syncRes.sourceMessage,
      count: tracked.length,
      tracked,
    });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// API: Re-run Smart Slot Arbitration (Strict 1 match per slot, Premier League priority #1)
app.post("/api/pipeline/reapply-slot-priority", (_req, res) => {
  try {
    const arbitration = applySmartSlotArbitration();
    const tracked = getTrackedPredictions();
    res.json({
      success: true,
      arbitration,
      count: tracked.length,
      tracked,
    });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// API: Reset Tonight's Matches for Re-publishing (Unlocks slots and re-runs cycle)
app.post("/api/pipeline/reset-tonight-matches", async (_req, res) => {
  try {
    const result = resetTonightMatchesForRetry();
    const cycle = await runAutoPilotCycle();
    const tracked = getTrackedPredictions();
    res.json({
      success: true,
      result,
      cycle,
      count: tracked.length,
      tracked,
    });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// API: Sync client flights into backend tracking registry
app.post("/api/pipeline/sync-tracked-flights", (req, res) => {
  try {
    const { flights = [] } = req.body;
    let registeredCount = 0;

    for (const f of flights) {
      const matchStr = f.baggages?.match || f.matchTitle || "";
      const parts = matchStr.split(/\s+(?:vs|v\.|contre)\s+/i);
      const homeTeam = parts[0]?.trim();
      const awayTeam = parts[1]?.trim();

      if (homeTeam && awayTeam) {
        registerTrackedPrediction({
          id: f.matchId || f.id,
          homeTeam,
          awayTeam,
          competition: f.matchTitle || "Football",
          prediction: f.baggages?.prediction || "Victoire",
          odd: f.baggages?.odd || "1.85",
          kickoffTime: f.departureTime || "21:00",
          status: f.status === "PUBLISHED" ? "PUBLISHED" : "SCHEDULED",
          publishedTweetText: f.tweetText,
        });
        registeredCount++;
      }
    }

    res.json({
      success: true,
      registeredCount,
      totalTracked: getTrackedPredictions().length,
    });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// API: Anti-Shadowban - Auto-Like a Tweet on X (Single or Multi-Account)
app.post("/api/x/like-tweet", async (req, res) => {
  try {
    const { tweetId, authToken, ct0 } = req.body;
    if (!tweetId) {
      return res.status(400).json({ success: false, message: "tweetId est requis" });
    }

    const result = await likeTweetViaCookies(tweetId, authToken, ct0);
    res.json(result);
  } catch (error: any) {
    console.error("Error in /api/x/like-tweet:", error);
    res.status(500).json({
      success: false,
      message: error?.message || "Erreur lors du like",
    });
  }
});

// API: Multi-Account Like (Main + Booster 1 + Booster 2)
app.post("/api/x/like-all-accounts", async (req, res) => {
  try {
    const { tweetId, authToken, ct0, booster1AuthToken, booster1Ct0, booster2AuthToken, booster2Ct0 } = req.body;
    if (!tweetId) {
      return res.status(400).json({ success: false, message: "tweetId ou URL de tweet requis" });
    }

    const result = await likeTweetWithAllAccounts(tweetId, {
      authToken,
      ct0,
      booster1AuthToken,
      booster1Ct0,
      booster2AuthToken,
      booster2Ct0,
    });

    res.json({
      success: result.totalLikes > 0,
      ...result,
    });
  } catch (error: any) {
    console.error("Error in /api/x/like-all-accounts:", error);
    res.status(500).json({
      success: false,
      message: error?.message || "Erreur lors du multi-like",
    });
  }
});

// API: Single Account Like Direct Test (for Main or Booster 1 or Booster 2)
app.post("/api/x/test-account-like", async (req, res) => {
  try {
    const { tweetId, authToken, ct0, accountLabel } = req.body;
    if (!tweetId) {
      return res.status(400).json({ success: false, message: "tweetId ou URL de tweet requis" });
    }
    if (!authToken || !ct0) {
      return res.status(400).json({ success: false, message: "Cookies auth_token et ct0 requis pour ce compte" });
    }

    const result = await likeTweetViaCookies(tweetId, authToken, ct0);
    res.json({
      ...result,
      accountLabel: accountLabel || "Compte",
    });
  } catch (error: any) {
    console.error("Error in /api/x/test-account-like:", error);
    res.status(500).json({
      success: false,
      message: error?.message || "Erreur lors du test de like",
    });
  }
});

// Helper: Extract structured SportyTrader cards from raw HTML snippets
function extractSportyTraderHtmlCards(html: string) {
  const cards: Array<{ match: string; tip: string; odd: string; url?: string }> = [];
  // Regex to match SportyTrader card blocks
  // Match link/title, tip paragraph, and odd span
  const cardRegex = /<a[^>]*href="([^"]*\/pronostics\/[^"]*)"[^>]*>([\s\S]*?)<\/a>[\s\S]*?<p[^>]*class="[^"]*font-semibold[^"]*"[^>]*>([\s\S]*?)<\/p>[\s\S]*?<span[^>]*class="[^"]*tabular-nums[^"]*"[^>]*>([\s\S]*?)<\/span>/gi;
  let match;
  while ((match = cardRegex.exec(html)) !== null) {
    const url = match[1]?.trim();
    const rawTitle = match[2]?.replace(/<[^>]*>/g, "").replace(/^Pronostic\s+/i, "").trim();
    const tip = match[3]?.replace(/<[^>]*>/g, "").trim();
    const odd = match[4]?.replace(/<[^>]*>/g, "").trim();
    if (rawTitle && tip) {
      cards.push({ match: rawTitle, tip, odd: odd || "1.80", url });
    }
  }
  return cards;
}

// Helper to format a ScrapedPronoItem tweet text
function generatePronoItemTweet(p: SportyTraderProno): string {
  const triHome = p.homeTeam.slice(0, 3).toUpperCase();
  const triAway = p.awayTeam.slice(0, 3).toUpperCase();
  const flag = p.competition.includes("Champions")
    ? "🏆"
    : p.competition.includes("Ligue 1")
    ? "🇫🇷"
    : p.competition.includes("Premier League")
    ? "🏴󠁧󠁢󠁥󠁮󠁧󠁿"
    : p.competition.includes("Liga")
    ? "🇪🇸"
    : p.competition.includes("Serie A")
    ? "🇮🇹"
    : "⚽";

  const cleanHome = p.homeTeam.replace(/[^a-zA-Z0-9]/g, "");
  const cleanAway = p.awayTeam.replace(/[^a-zA-Z0-9]/g, "");

  return `🔥 PREDICTION ${triHome} vs ${triAway} (${p.kickoffTime || "21:00"})
${flag} ${p.competition} · ${p.date || "Today"}

⚽ Match: ${p.homeTeam} vs ${p.awayTeam}
🎯 Tip: ${p.prediction}
📈 Odds: @${p.odds}
⚡ Confidence: ${p.confidencePercent || 85}%

#FootballTips #${triHome}${triAway} #${cleanHome} #${cleanAway} #BettingTips`;
}

// API: Parse & Scrape SportyTrader predictions into X Tweets
app.post("/api/scraper/sportytrader-parse", async (req, res) => {
  const { rawContent = "", customInstructions = "" } = req.body;

  try {
    // 1. Direct deterministic & instant parsing of SportyTrader content (HTML or Copied Text)
    if (rawContent && rawContent.trim().length > 10) {
      const parsedDirect = parseSportyTraderInput(rawContent);
      if (parsedDirect && parsedDirect.length > 0) {
        const mappedPronos = parsedDirect.map((p, idx) => ({
          id: p.id || `st-${idx + 1}`,
          homeTeam: p.homeTeam,
          awayTeam: p.awayTeam,
          league: p.competition,
          leagueFlag: p.competition.includes("Champions")
            ? "🏆"
            : p.competition.includes("Ligue 1")
            ? "🇫🇷"
            : p.competition.includes("Premier")
            ? "🏴󠁧󠁢󠁥󠁮󠁧󠁿"
            : p.competition.includes("Liga")
            ? "🇪🇸"
            : p.competition.includes("Serie A")
            ? "🇮🇹"
            : "⚽",
          kickoffTime: p.kickoffTime,
          kickoffDate: p.date,
          predictionType: p.prediction,
          estimatedOdd: p.odds,
          predictedScore: p.predictedScore || "2-1",
          confidencePercent: p.confidencePercent || 85,
          keyReasoning: p.keyReasoning || `High probability edge for ${p.homeTeam} vs ${p.awayTeam}.`,
          source: "SportyTrader",
          tweetText: generatePronoItemTweet(p),
        }));

        return res.json({
          success: true,
          provider: "SportyTrader Direct Parser",
          scrapedPronos: mappedPronos,
        });
      }
    }

    // 2. Fallback to AI Parser if unstructured
    const extractedCards = extractSportyTraderHtmlCards(rawContent);
    const cardsContext = extractedCards.length > 0
      ? `\nCARTES SPORTYTRADER DÉTECTÉES DIRECTEMENT DANS LE CODE HTML :\n` +
        extractedCards.map((c, i) => `#${i + 1} MATCH: ${c.match} | CONSEIL SPORTYTRADER: "${c.tip}" | COTE: @${c.odd} (Lien: ${c.url || ""})`).join("\n")
      : "";

    const prompt = `You are a world-class football data analyst and high-engagement X (Twitter) content creator.
Your goal is to extract match predictions from SportyTrader content and format them into viral, professional English tweets.

${cardsContext}

SOURCE CONTENT RECEIVED:
${rawContent ? rawContent.slice(0, 12000) : "Extract today's major football predictions for top European leagues (Premier League, La Liga, Serie A, Ligue 1, Champions League)."}

${customInstructions ? `ADDITIONAL INSTRUCTIONS: ${customInstructions}` : ""}

STRICT REQUIREMENTS (100% IN ENGLISH):
1. Extract ALL football predictions present.
2. For each match provide:
   - Home team (homeTeam) & Away team (awayTeam) (e.g., "Liverpool", "Newcastle")
   - League/Competition (league) & emoji flag (leagueFlag) (e.g., "Premier League", "La Liga")
   - Time and Date (kickoffTime e.g., "17:30", kickoffDate e.g., "Today")
   - Clear English prediction type (predictionType e.g., "Liverpool to Win", "Over 2.5 Goals", "Both Teams to Score (BTTS - Yes)", "Arsenal or Draw (1X)")
   - Odds (estimatedOdd e.g., "1.90", "2.10")
   - Projected exact score (predictedScore e.g., "1-2")
   - Confidence percentage (confidencePercent e.g., 85)
   - Concise tactical reasoning in English (keyReasoning)
   - Final viral X Tweet strictly under 270 characters in English (tweetText) with emojis and hashtags.

Output strict JSON only:
{
  "scrapedPronos": [
    {
      "id": "st-1",
      "homeTeam": "Newcastle",
      "awayTeam": "Liverpool",
      "league": "Premier League",
      "leagueFlag": "🏴󠁧󠁢󠁥󠁮󠁧󠁿",
      "kickoffTime": "17:30",
      "kickoffDate": "Today",
      "predictionType": "Liverpool to Win",
      "estimatedOdd": "1.90",
      "predictedScore": "1-2",
      "confidencePercent": 85,
      "keyReasoning": "Impressive collective dynamic for the Reds and clinical finishing on counter attacks.",
      "source": "SportyTrader",
      "tweetText": "🔥 PREDICTION NEW vs LIV (17:30)\\n🏆 Premier League · Today\\n\\n⚽ Match: Newcastle vs Liverpool\\n🎯 Tip: Liverpool to Win\\n📈 Odds: 1.90\\n⚡ Confidence: 85%\\n\\n#FootballTips #NEWLIV #Newcastle #Liverpool #BettingTips"
    }
  ]
}`;

    let rawText = "";
    try {
      rawText = await executeMistralWithFallback(prompt);
    } catch (e) {
      rawText = await executeGeminiWithFallback(prompt);
    }

    const data = cleanAndParseJson(rawText);
    res.json({
      success: true,
      provider: "Mistral AI",
      scrapedPronos: data.scrapedPronos || [],
    });
  } catch (error: any) {
    console.error("Error in /api/scraper/sportytrader-parse:", error);
    res.status(500).json({
      success: false,
      message: error?.message || "Erreur lors de l'extraction des pronostics SportyTrader",
    });
  }
});

// API: Direct Cheerio Scraper for SportyTrader
app.get("/api/scraper/sportytrader", async (_req, res) => {
  try {
    const managed = getManagedPronosList();
    if (managed && managed.length > 0) {
      return res.json({
        success: true,
        count: managed.length,
        pronos: managed,
      });
    }
    const pronos = await scrapeSportyTrader();
    res.json({
      success: true,
      count: pronos.length,
      pronos,
    });
  } catch (error: any) {
    console.error("[SportyTrader]", error);
    res.status(502).json({
      success: false,
      message: error.message,
    });
  }
});

// API: Sync SportyTrader & Generate Scheduled Tweets (H-1h ONLY before match)
app.post("/api/scraper/sportytrader/sync-pipeline", async (req, res) => {
  try {
    const rawContent = req.body?.rawHtml || req.body?.rawText || req.body?.content || "";
    const result = await syncSportyTraderAndGenerateTweets(rawContent);
    res.json({
      success: true,
      ...result,
    });
  } catch (error: any) {
    console.error("[SportyTrader Sync]", error);
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
});

// API: Get Daily Posting Cycle Summary (Morning Announcement text, Daily Recap data, Live Goals config)
app.get("/api/pipeline/daily-summary", async (req, res) => {
  try {
    let pronos = getManagedPronosList();
    if (pronos.length === 0) {
      pronos = await scrapeSportyTrader();
    }

    const morningTweet = generateMorningAnnouncementTweet(pronos);
    const finishedSummary = await getTodayFinishedMatchesSummary();
    const dailyRecap = generateDailyRecapTweet(finishedSummary);

    res.json({
      success: true,
      morningTweet,
      dailyRecap,
      isAutoGoalAlertsEnabled: isAutoGoalAlertsEnabled(),
      totalMatchesToday: pronos.length,
      finishedMatchesCount: finishedSummary.length,
    });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// API: Publish Morning Announcement Tweet on X
app.post("/api/pipeline/publish-morning-announcement", async (req, res) => {
  try {
    const { customText } = req.body;
    let textToSend = customText;

    if (!textToSend) {
      const pronos = getManagedPronosList();
      textToSend = generateMorningAnnouncementTweet(pronos);
    }

    const pubResult = await publishTweetToX({ tweetText: textToSend });
    res.json({
      success: pubResult.success,
      tweetId: pubResult.tweetId,
      tweetUrl: pubResult.tweetUrl,
      tweetText: textToSend,
      message: pubResult.success
        ? "☀️ Tweet d'Annonce du Matin publié avec succès sur X !"
        : "⚠️ Erreur lors de la publication de l'annonce du matin.",
    });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// API: Publish Grand Daily Recap Tweet on X
app.post("/api/pipeline/publish-daily-recap", async (req, res) => {
  try {
    const { customText } = req.body;
    let textToSend = customText;

    if (!textToSend) {
      const finishedSummary = await getTodayFinishedMatchesSummary();
      const recap = generateDailyRecapTweet(finishedSummary);
      textToSend = recap.tweetText;
    }

    const pubResult = await publishTweetToX({ tweetText: textToSend });
    res.json({
      success: pubResult.success,
      tweetId: pubResult.tweetId,
      tweetUrl: pubResult.tweetUrl,
      tweetText: textToSend,
      message: pubResult.success
        ? "🏁 Grand Tweet Bilan de la Journée publié avec succès sur X !"
        : "⚠️ Erreur lors de la publication du bilan.",
    });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// API: Toggle live goal alerts
app.post("/api/pipeline/toggle-goal-alerts", (req, res) => {
  const { enabled } = req.body;
  if (typeof enabled === "boolean") {
    setAutoGoalAlertsEnabled(enabled);
  }
  res.json({
    success: true,
    isAutoGoalAlertsEnabled: isAutoGoalAlertsEnabled(),
  });
});

// API: Complete Bot Status & Diagnostics
app.get("/api/bot/status", (_req, res) => {
  const botState = getBotState();
  const tracked = getTrackedPredictions();
  const tweets = getAllManagedTweets();
  const logs = getBotLogs(50);
  const liveMatches = tracked.filter((p) => p.status === "LIVE" || p.status === "PUBLISHED");
  const finishedMatches = tracked.filter((p) => p.status === "DEBRIEF_SENT" || p.finalScore !== undefined);
  const queueStatus = getQueueStatus();
  const cookieHealth = getCookieHealth();
  const publishingMode = getPublishingMode();

  res.json({
    success: true,
    botState,
    isAutoPilotEnabled: botState.isAutoPilotEnabled,
    isAutoGoalAlertsEnabled: botState.isAutoGoalAlertsEnabled,
    publishingMode,
    cookieHealth,
    lastSyncSource: botState.lastSyncSource || "EMPTY",
    lastSyncMessage: botState.lastSyncMessage || "",
    queueStatus,
    stats: {
      totalTracked: tracked.length,
      liveCount: liveMatches.length,
      finishedCount: finishedMatches.length,
      scheduledCount: tracked.filter((p) => p.status === "SCHEDULED").length,
      totalTweets: tweets.length,
      publishedTweets: tweets.filter((t) => t.status === "PUBLISHED").length,
      totalGoalsTweeted: botState.totalGoalsTweeted,
      totalLikesPerformed: botState.totalLikesPerformed,
      queuedTweetsCount: queueStatus.queueLength,
    },
    trackedPredictions: tracked,
    allTweets: tweets,
    logs,
    lastScrapeTimestamp,
    nextScrapeTimestamp,
    lastScrapeStatus,
    lastScrapeCount,
  });
});

// API: Dedicated Tweet Queue Status
app.get("/api/pipeline/queue-status", (_req, res) => {
  res.json({
    success: true,
    ...getQueueStatus(),
  });
});

// API: Configure Queue Min Spacing (seconds)
app.post("/api/pipeline/queue-config", (req, res) => {
  const { minSpacingSeconds } = req.body;
  if (typeof minSpacingSeconds === "number") {
    setMinSpacingSeconds(minSpacingSeconds);
  }
  res.json({
    success: true,
    ...getQueueStatus(),
  });
});

// API: Toggle Master Auto-Pilot
app.post("/api/bot/toggle", (req, res) => {
  const { enabled } = req.body;
  const isEnabled = typeof enabled === "boolean" ? enabled : !getBotState().isAutoPilotEnabled;
  const state = setAutoPilotEnabled(isEnabled);
  res.json({
    success: true,
    isAutoPilotEnabled: state.isAutoPilotEnabled,
    botState: state,
  });
});

// API: Set Slot Collision Mode (Anti-Collision 1 match/slot VS Publish All)
app.post("/api/bot/set-collision-mode", (req, res) => {
  const { mode } = req.body;
  if (mode === "ANTI_COLLISION" || mode === "PUBLISH_ALL") {
    const state = setSlotCollisionMode(mode);
    return res.json({
      success: true,
      slotCollisionMode: state.slotCollisionMode,
      botState: state,
      tracked: getTrackedPredictions(),
    });
  }
  res.status(400).json({ success: false, message: "Mode invalide (doit être ANTI_COLLISION ou PUBLISH_ALL)" });
});

// API: Force Enqueue All Tonight's Matches
app.post("/api/pipeline/force-enqueue-tonight", async (_req, res) => {
  try {
    const result = forceEnqueueAllTonightMatches();
    res.json({
      success: true,
      result,
      tracked: getTrackedPredictions(),
      tweets: getAllManagedTweets(),
    });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// API: Trigger Smart Slot Auto-Selection
app.post("/api/bot/auto-select", async (_req, res) => {
  try {
    const result = await selectAndScheduleSmartSlotMatches();
    res.json({
      success: true,
      result,
      tracked: getTrackedPredictions(),
      tweets: getAllManagedTweets(),
    });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// API: Force Immediate Auto-Pilot Execution Cycle
app.post("/api/bot/force-run", async (_req, res) => {
  try {
    const result = await runAutoPilotCycle();
    res.json({
      success: true,
      result,
      tracked: getTrackedPredictions(),
      tweets: getAllManagedTweets(),
      logs: getBotLogs(20),
    });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// API: Get Activity Logs
app.get("/api/bot/logs", (req, res) => {
  const limit = parseInt(req.query.limit as string) || 100;
  res.json({
    success: true,
    logs: getBotLogs(limit),
  });
});

// API: Clear Activity Logs
app.post("/api/bot/logs/clear", (_req, res) => {
  clearBotLogs();
  res.json({ success: true, message: "Logs réinitialisés" });
});

// API: Like tweet manually
app.post("/api/x/like-tweet", async (req, res) => {
  const { tweetId } = req.body;
  if (!tweetId) {
    return res.status(400).json({ success: false, message: "tweetId requis" });
  }
  try {
    const result = await likeTweetWithAllAccounts(tweetId);
    res.json({ success: true, result });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// API: Check real scores from ESPN/APIs for LIVE GOALS and FT Finished matches
app.post("/api/scraper/sportytrader/check-live-scores", async (_req, res) => {
  try {
    const result = await checkAndProcessLiveGoalsAndFT();
    const liveScores = await fetchLiveScoresForLeagues();
    res.json({
      success: true,
      goalsDetected: result.goalsDetected,
      finishedMatchesFound: result.finishedCount,
      newTweets: result.newTweets,
      activeTrackedCount: result.activeTrackedCount,
      liveScores,
      allTweets: getAllManagedTweets(),
    });
  } catch (error: any) {
    console.error("[Check Live Scores Error]", error);
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
});

// API: Get live scores from ESPN for European leagues
app.get("/api/football/live-scores", async (_req, res) => {
  try {
    const scores = await fetchLiveScoresForLeagues();
    res.json({
      success: true,
      count: scores.length,
      scores,
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
});

// API: Get all managed/scheduled tweets
app.get("/api/scraper/sportytrader/tweets", (_req, res) => {
  const tweets = getAllManagedTweets();
  res.json({
    success: true,
    count: tweets.length,
    tweets,
  });
});

let lastScrapeTimestamp = 0;
let nextScrapeTimestamp = Date.now() + 30 * 60 * 1000;
let lastScrapeCount = 0;
let lastScrapeStatus = "INITIALIZING";
let inFlightScrapePromise: Promise<any> | null = null;

// API: Get background auto-scraper status
app.get("/api/scraper/sportytrader/status", (_req, res) => {
  const state = getBotState();
  res.json({
    success: true,
    intervalMinutes: 30,
    lastScrapeTimestamp,
    nextScrapeTimestamp,
    lastScrapeStatus,
    lastScrapeCount,
    lastSyncSource: state.lastSyncSource || "EMPTY",
    lastSyncMessage: state.lastSyncMessage || "",
    managedTweetsCount: getAllManagedTweets().length,
  });
});

async function runAutoHourlyScrape() {
  if (inFlightScrapePromise) {
    return inFlightScrapePromise;
  }
  inFlightScrapePromise = (async () => {
    try {
      lastScrapeStatus = "RUNNING";
      const result = await syncSportyTraderAndGenerateTweets();
      lastScrapeTimestamp = Date.now();
      nextScrapeTimestamp = Date.now() + 30 * 60 * 1000;
      lastScrapeCount = result.pronos.length;
      lastScrapeStatus = result.pronos.length > 0 ? "SUCCESS" : "EMPTY";
      console.log(
        `[Auto-Scrape 30m] ✅ ${result.source}: ${result.pronos.length} pronos (${result.newPronosCount} nouveaux). Prochaine sync dans 30min.`
      );
      return result;
    } catch (err: any) {
      lastScrapeStatus = "ERROR";
      console.warn("[Auto-Scrape 30m Error]:", err?.message);
      return null;
    } finally {
      inFlightScrapePromise = null;
    }
  })();
  return inFlightScrapePromise;
}

// API: 24/7 Autonomous Cron Tick (called by GitHub Actions / external cron / open browser tab)
const cronTickHandler: express.RequestHandler = async (req, res) => {
  try {
    const configuredSecret = (process.env.CRON_SECRET || "").trim();
    if (configuredSecret) {
      const authHeader = (req.headers.authorization || "").trim();
      const querySecret = String(req.query.secret || "").trim();
      const headerToken = authHeader.startsWith("Bearer ")
        ? authHeader.slice(7).trim()
        : authHeader;
      // Allow same-origin UI keep-alive pings without secret, enforce secret for external cron callers if header/query absent when referer isn't local
      const isLocalUi =
        req.headers.origin?.includes("localhost") ||
        req.headers.referer?.includes("localhost") ||
        req.headers["x-internal-ui"] === "1";
      if (!isLocalUi && headerToken !== configuredSecret && querySecret !== configuredSecret) {
        return res.status(401).json({ success: false, message: "Unauthorized cron tick" });
      }
    }

    const botState = getBotState();
    const parisToday = getParisNow().isoDate;
    const trackedCountBefore = getTrackedPredictions().length;
    const needsSync =
      lastScrapeTimestamp === 0 ||
      Date.now() - lastScrapeTimestamp > 30 * 60 * 1000 ||
      botState.lastSyncDateParis !== parisToday ||
      trackedCountBefore === 0;

    let synced = false;
    if (needsSync) {
      await runAutoHourlyScrape();
      synced = true;
    }

    const cycle = await runAutoPilotCycle();
    const queueTick = await processQueueTick();
    const updatedState = getBotState();

    res.json({
      success: true,
      timestamp: new Date().toISOString(),
      synced,
      source: updatedState.lastSyncSource || "EMPTY",
      sourceMessage: updatedState.lastSyncMessage || "",
      trackedCount: getTrackedPredictions().length,
      cycle: {
        h1PublishedCount: cycle.h1PublishedCount,
        goalsDetected: cycle.goalsDetected,
        finishedCount: cycle.finishedCount,
        dailyRecapSent: cycle.dailyRecapSent,
      },
      queueTick,
      queueLength: getQueueStatus().queueLength,
      cookieHealth: getCookieHealth(),
      publishingMode: getPublishingMode(),
    });
  } catch (err: any) {
    console.error("[Cron Tick Error]:", err);
    res.status(500).json({ success: false, message: err?.message || "Erreur cron tick" });
  }
};

app.get("/api/cron/tick", cronTickHandler);
app.post("/api/cron/tick", cronTickHandler);

async function startServer() {
  // 1. Purge expired matches synchronously on boot (local disk only, instant)
  try {
    autoPurgeOldMatchesAndSyncFresh();
  } catch (err: any) {
    console.warn("[Auto-Purge Startup]:", err?.message);
  }

  // 2. Vite middleware for development (bind port 3000 ASAP before any outbound network calls)
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);

    // 3. Kick off background network checks & live scrape AFTER port 3000 is already listening
    setTimeout(() => {
      const bootCreds = getServerXCredentials();
      if (bootCreds.authToken && bootCreds.ct0) {
        testXCookies(bootCreds.authToken, bootCreds.ct0)
          .then((diag) => {
            console.log(`[Startup X Check] ${diag.status}: ${diag.message}`);
          })
          .catch((err) => console.warn("[Startup X Check Warning]:", err?.message));
      }

      runAutoHourlyScrape().catch((err) =>
        console.warn("[Auto-Sync Startup]:", err?.message)
      );
    }, 1500);

    // 4. Automatic live re-sync every 30 minutes (keeps upcoming matches & next-day schedule fresh forever)
    setInterval(() => {
      runAutoHourlyScrape().catch((err) =>
        console.warn("[Auto-Sync Background 30m]:", err?.message)
      );
    }, 30 * 60 * 1000);

    // 5. Continuous 30-second Auto-Pilot execution cycle (H-1 predictions, Live goals, FT debriefs, Daily recap)
    setInterval(() => {
      runAutoPilotCycle().catch((err) =>
        console.warn("[Auto-Pilot Background 30s]:", err?.message)
      );
    }, 30 * 1000);
  });
}

startServer();
